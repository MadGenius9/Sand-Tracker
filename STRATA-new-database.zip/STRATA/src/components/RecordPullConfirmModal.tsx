/**
 * Confirm and log a stage pull.
 *
 * This is the last screen before sand leaves the ledger, so every consequence
 * is stated up front: whether the stage is already complete, which cans go
 * negative, which run dry, what the stage total looks like after this record
 * (adaptively — a first pull compares to design, a follow-up partial compares
 * to what is already logged), and whether the manual run-order pins get
 * cleared when the stage closes.
 */

import {
  X,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  ArrowRight,
  Lock,
} from 'lucide-react';
import React, { useEffect, useMemo, useState } from 'react';
import {
  formatLbs,
  formatTons,
  getEffectivePerStageDesign,
  getSiloDerivedStates,
  isStageComplete,
} from '../lib/sandRules';
import { getOperationalDate } from '../lib/dateUtils';
import { cn, sandClasses } from '../lib/theme';
import { AppState } from '../types';

export interface RecordPullConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  wellId: string;
  stageNumber: number;
  stageLbsOverride?: number;
  onRecordRun: (
    records: {
      wellId: string;
      stageNumber: number;
      siloNumber: number;
      sandType: string;
      lbsPulled: number;
      date: string;
      runSequence?: number;
      submissionId?: string;
    }[],
    options?: {
      clearManualOverrides?: boolean;
    }
  ) => Promise<void> | void;
  onSuccess?: () => void;
}

export default function RecordPullConfirmModal({
  isOpen,
  onClose,
  state,
  wellId,
  stageNumber,
  stageLbsOverride,
  onRecordRun,
  onSuccess,
}: RecordPullConfirmModalProps) {
  const { config, runs, deliveries } = state;
  const lbsPerTon = config.lbsPerTon || 2000;

  const wellObj = config.wells.find((w) => w.id === wellId) || {
    id: wellId,
    name: 'Well',
    plannedStages: 40,
  };

  const [date, setDate] = useState<string>(getOperationalDate());
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const isAlreadyComplete = useMemo(
    () => isStageComplete(state, wellId, stageNumber),
    [state, wellId, stageNumber]
  );

  const hasManualOverrides = useMemo(
    () => config.silos.some((s) => s.manualPriority !== null && s.manualPriority !== undefined),
    [config.silos]
  );

  const [clearOverrides, setClearOverrides] = useState<boolean>(
    config.clearManualPriorityAfterStage ?? true
  );

  /* The expensive replay: deliveries and runs per can, plus the run order. */
  const siloDerivedStates = useMemo(
    () => getSiloDerivedStates(state, wellId, stageNumber, stageLbsOverride),
    [config, runs, deliveries, wellId, stageNumber, stageLbsOverride]
  );

  const plannedItems = useMemo(
    () =>
      siloDerivedStates
        .filter((s) => s.plannedPullLbs > 0 && !s.isOutOfService && s.sandType)
        .sort((a, b) => (a.runOrder || 99) - (b.runOrder || 99)),
    [siloDerivedStates]
  );

  // Fallback when the strategy planned nothing: every online can with sand.
  const displayItems = useMemo(() => {
    if (plannedItems.length > 0) return plannedItems;
    return siloDerivedStates
      .filter((s) => !s.isOutOfService && s.sandType)
      .sort((a, b) => (a.runOrder || 99) - (b.runOrder || 99));
  }, [plannedItems, siloDerivedStates]);

  const [actualPulls, setActualPulls] = useState<Record<number, number>>({});

  useEffect(() => {
    const initial: Record<number, number> = {};
    displayItems.forEach((s) => {
      initial[s.siloNumber] = s.plannedPullLbs;
    });
    setActualPulls(initial);
    setErrorMessage(null);
    setIsSubmitting(false);
  }, [wellId, stageNumber, displayItems]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !isSubmitting) onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose, isSubmitting]);

  const totalActualPulledLbs = useMemo(
    () =>
      displayItems.reduce(
        (sum, item) => sum + (actualPulls[item.siloNumber] ?? item.plannedPullLbs ?? 0),
        0
      ),
    [displayItems, actualPulls]
  );

  const totalPlannedLbs = useMemo(
    () => displayItems.reduce((sum, item) => sum + (item.plannedPullLbs || 0), 0),
    [displayItems]
  );

  const stageDesignTotalLbs = useMemo(() => {
    if (stageLbsOverride !== undefined) return stageLbsOverride;
    return config.sandTypes.reduce((sum, st) => sum + (getEffectivePerStageDesign(wellObj, st) || 0), 0);
  }, [stageLbsOverride, config.sandTypes, wellObj]);

  const priorRunsForThisStage = useMemo(
    () =>
      (runs || []).filter(
        (r) => !r.deleted && r.wellId === wellId && r.stageNumber === stageNumber
      ),
    [runs, wellId, stageNumber]
  );

  const previouslyRecordedTotalLbs = useMemo(
    () => priorRunsForThisStage.reduce((sum, r) => sum + (r.lbsPulled || 0), 0),
    [priorRunsForThisStage]
  );

  const stageTotalAfterLbs = previouslyRecordedTotalLbs + totalActualPulledLbs;
  const remainingAfterLbs = Math.max(0, stageDesignTotalLbs - stageTotalAfterLbs);
  const varianceAfterLbs = stageTotalAfterLbs - stageDesignTotalLbs;
  const varianceLbs = totalActualPulledLbs - stageDesignTotalLbs;

  const stageCompletionStatus = useMemo(() => {
    let allMet = true;
    let totalRemaining = 0;

    config.sandTypes.forEach((st) => {
      const design = getEffectivePerStageDesign(wellObj, st);
      if (design > 0) {
        const priorPumped = priorRunsForThisStage
          .filter((r) => r.sandType === st.name)
          .reduce((sum, r) => sum + (r.lbsPulled || 0), 0);

        const newPumped = displayItems
          .filter((item) => item.sandType === st.name)
          .reduce(
            (sum, item) => sum + (actualPulls[item.siloNumber] ?? item.plannedPullLbs ?? 0),
            0
          );

        const totalProjected = priorPumped + newPumped;
        if (totalProjected < design - 1) {
          allMet = false;
          totalRemaining += design - totalProjected;
        }
      }
    });

    return {
      isComplete: allMet && (totalActualPulledLbs > 0 || previouslyRecordedTotalLbs > 0),
      totalRemainingLbs: Math.max(0, totalRemaining),
    };
  }, [
    config.sandTypes,
    wellObj,
    priorRunsForThisStage,
    displayItems,
    actualPulls,
    totalActualPulledLbs,
    previouslyRecordedTotalLbs,
  ]);

  const drySilos = useMemo(
    () =>
      displayItems.filter((item) => {
        const pull = actualPulls[item.siloNumber] ?? item.plannedPullLbs ?? 0;
        return pull > 0 && pull >= item.onHandLbs;
      }),
    [displayItems, actualPulls]
  );

  const negativeSilos = useMemo(
    () =>
      displayItems.filter((item) => {
        const pull = actualPulls[item.siloNumber] ?? item.plannedPullLbs ?? 0;
        return pull > 0 && pull > item.onHandLbs;
      }),
    [displayItems, actualPulls]
  );

  if (!isOpen) return null;

  const handlePullChange = (siloNum: number, rawVal: string) => {
    if (rawVal === '') {
      setActualPulls((prev) => ({ ...prev, [siloNum]: 0 }));
      return;
    }
    const cleaned = rawVal.replace(/[^0-9.]/g, '');
    const num = parseFloat(cleaned);
    setActualPulls((prev) => ({
      ...prev,
      [siloNum]: isNaN(num) ? 0 : Math.max(0, Math.round(num)),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;

    if (isAlreadyComplete) {
      setErrorMessage(
        `Stage ${stageNumber} on ${wellObj.name} is already complete. Edit or delete the existing runs to change it.`
      );
      return;
    }

    setErrorMessage(null);

    const submissionId = `sub_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const recordsToSave: {
      wellId: string;
      stageNumber: number;
      siloNumber: number;
      sandType: string;
      lbsPulled: number;
      date: string;
      runSequence: number;
      submissionId: string;
    }[] = [];

    const orderedItems = [...displayItems].sort((a, b) => (a.runOrder || 99) - (b.runOrder || 99));

    // Continue the sequence across multiple partial submissions of one stage.
    let maxExistingSequence = 0;
    if (priorRunsForThisStage.length > 0) {
      const explicitSeqs = priorRunsForThisStage
        .map((r) => r.runSequence)
        .filter((s): s is number => typeof s === 'number' && s > 0);

      if (explicitSeqs.length > 0) {
        maxExistingSequence = Math.max(...explicitSeqs);
      } else {
        maxExistingSequence = priorRunsForThisStage.length;
      }
      maxExistingSequence = Math.max(maxExistingSequence, priorRunsForThisStage.length);
    }

    let sequenceIndex = maxExistingSequence + 1;
    orderedItems.forEach((item) => {
      const pull = actualPulls[item.siloNumber] ?? item.plannedPullLbs ?? 0;
      if (pull > 0 && item.sandType) {
        recordsToSave.push({
          wellId,
          stageNumber,
          siloNumber: item.siloNumber,
          sandType: item.sandType,
          lbsPulled: pull,
          date,
          runSequence: sequenceIndex++,
          submissionId,
        });
      }
    });

    if (recordsToSave.length === 0) {
      setErrorMessage('Enter at least one silo pull weight above zero.');
      return;
    }

    try {
      setIsSubmitting(true);
      await onRecordRun(recordsToSave, {
        clearManualOverrides: hasManualOverrides && clearOverrides,
      });
      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      console.error('Failed to record run:', err);
      setErrorMessage(err?.message || 'Failed to record stage run. Please retry.');
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget && !isSubmitting) onClose();
      }}
    >
      <div
        className="card my-auto max-h-[94vh] w-full max-w-3xl overflow-y-auto rounded-xl p-5"
        role="dialog"
        aria-modal="true"
        aria-labelledby="record-pull-confirm-title"
      >
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow">Confirm stage pull</div>
            <h2
              id="record-pull-confirm-title"
              className="flex flex-wrap items-center gap-2 text-xl font-medium tracking-tight"
            >
              {wellObj.name}
              <span className="badge badge-critical">
                Stage <span className="num">{stageNumber}</span>
              </span>
            </h2>
            <p className="text-sm text-muted">
              Planned pull is the stage design split across the cans holding that sand. Adjust any
              row where the actual differed, then log it.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            disabled={isSubmitting}
            aria-label="Close"
            className="btn btn-ghost tap shrink-0 px-2"
          >
            <X className="size-5" />
          </button>
        </div>

        <div className="flex flex-col gap-4">
          {/* -------------------------------- already complete warning --- */}
          {isAlreadyComplete && (
            <div className="flex items-start gap-2 rounded-md bg-elevated p-3 ring-danger-1">
              <AlertTriangle className="mt-0.5 size-4 shrink-0 text-danger" />
              <div>
                <div className="eyebrow text-danger">Stage is already complete</div>
                <div className="mt-1 text-sm text-fg">
                  Stage <span className="num">{stageNumber}</span> on {wellObj.name} has met its
                  design. Edit or delete the existing runs to change it.
                </div>
              </div>
            </div>
          )}

          {errorMessage && (
            <div className="flex items-start gap-2 rounded-md bg-elevated p-3 text-sm text-danger ring-danger-1">
              <AlertTriangle className="mt-0.5 size-4 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* ---------------------------------- negative silo warning --- */}
          {negativeSilos.length > 0 && (
            <div className="flex items-start gap-2 rounded-md bg-elevated p-3 ring-warn-1">
              <AlertTriangle className="mt-0.5 size-4 shrink-0 text-warn" />
              <div>
                <div className="eyebrow text-warn">Pulling more than is on hand</div>
                <div className="mt-1 flex flex-col gap-0.5 text-sm text-fg">
                  {negativeSilos.map((s) => (
                    <span key={s.siloNumber}>
                      Silo <span className="num">#{s.siloNumber}</span> —{' '}
                      <span className="num">
                        {formatLbs(actualPulls[s.siloNumber] ?? s.plannedPullLbs)}
                      </span>{' '}
                      against <span className="num">{formatLbs(s.onHandLbs)}</span> on hand.
                    </span>
                  ))}
                </div>
                <div className="mt-1 text-xs text-muted">
                  Recording this leaves the can negative — usually a delivery ticket is missing.
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
            {/* ------------------------------------- well and date --- */}
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-border">
              <div>
                <div className="eyebrow">Well and stage</div>
                <div className="num mt-0.5 text-sm font-semibold">
                  {wellObj.name} — stage {stageNumber}
                </div>
              </div>

              <label className="flex items-center gap-2">
                <span className="eyebrow flex items-center gap-1">
                  <Calendar className="size-3.5" /> Pull date
                </span>
                <input
                  id="record-pull-date"
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="input num w-auto"
                />
              </label>
            </div>

            {/* ---------------------------------- pull breakdown --- */}
            <div>
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <span className="eyebrow">
                  Silo pull breakdown · <span className="num">{displayItems.length}</span> can
                  {displayItems.length === 1 ? '' : 's'}
                </span>
                <span className="eyebrow">Tap a weight to adjust it</span>
              </div>

              <div className="card-flush overflow-x-auto">
                <table className="tbl">
                  <thead>
                    <tr>
                      <th className="n">Order</th>
                      <th>Silo</th>
                      <th>Sand</th>
                      <th className="n">Available</th>
                      <th className="n">Planned</th>
                      <th className="n">Actual pull (lbs)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {displayItems.map((item) => {
                      const actualVal = actualPulls[item.siloNumber] ?? item.plannedPullLbs ?? 0;
                      const runsDry = actualVal >= item.onHandLbs && actualVal > 0;
                      const overPull = actualVal > item.onHandLbs;
                      const tone = sandClasses(item.sandType, config.sandTypes);
                      const isLocked =
                        item.manualPriority !== null && item.manualPriority !== undefined;

                      return (
                        <tr key={item.siloNumber}>
                          <td className="n">
                            <span className={cn(isLocked ? 'text-locked' : 'text-accent')}>
                              {item.runOrder || '—'}
                            </span>
                          </td>
                          <td>
                            <span className="num font-medium">#{item.siloNumber}</span>
                            {runsDry && <span className="badge badge-warn ml-1.5">Dry</span>}
                          </td>
                          <td>
                            <span className="flex items-center gap-1.5">
                              <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                              <span className="truncate">{item.sandType}</span>
                            </span>
                          </td>
                          <td className="n text-muted">{formatLbs(item.onHandLbs)}</td>
                          <td className="n text-muted">{formatLbs(item.plannedPullLbs)}</td>
                          <td className="n">
                            <input
                              type="number"
                              min={0}
                              step="any"
                              inputMode="numeric"
                              value={
                                actualVal === 0 && actualPulls[item.siloNumber] === 0
                                  ? '0'
                                  : actualVal === 0
                                    ? ''
                                    : actualVal
                              }
                              onChange={(e) => handlePullChange(item.siloNumber, e.target.value)}
                              placeholder="0"
                              aria-label={`Actual lbs pulled from silo ${item.siloNumber}`}
                              className={cn('input input-num w-36', overPull && 'ring-warn-1')}
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                  <tfoot>
                    <tr>
                      <td colSpan={4} className="eyebrow">
                        Stage total pull
                      </td>
                      <td className="n text-muted">{formatLbs(totalPlannedLbs)}</td>
                      <td className="n text-base font-semibold text-critical">
                        {formatLbs(totalActualPulledLbs)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* ------------------------------ adaptive variance block --- */}
            {previouslyRecordedTotalLbs > 0 ? (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">Stage design</div>
                  <div className="num mt-1 text-base font-semibold">
                    {formatLbs(stageDesignTotalLbs)}
                  </div>
                  <div className="num text-xs text-muted">
                    {formatTons(stageDesignTotalLbs / lbsPerTon)}
                  </div>
                </div>

                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">Previously recorded</div>
                  <div className="num mt-1 text-base font-semibold">
                    {formatLbs(previouslyRecordedTotalLbs)}
                  </div>
                  <div className="num text-xs text-muted">
                    {priorRunsForThisStage.length} run
                    {priorRunsForThisStage.length === 1 ? '' : 's'}
                  </div>
                </div>

                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">This record</div>
                  <div className="num mt-1 text-base font-semibold text-critical">
                    {formatLbs(totalActualPulledLbs)}
                  </div>
                  <div className="num text-xs text-muted">
                    {formatTons(totalActualPulledLbs / lbsPerTon)}
                  </div>
                </div>

                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">Stage total after</div>
                  <div className="num mt-1 text-base font-semibold">
                    {formatLbs(stageTotalAfterLbs)}
                  </div>
                  <div className="num text-xs text-muted">
                    {formatTons(stageTotalAfterLbs / lbsPerTon)}
                  </div>
                </div>

                <div className="col-span-2 rounded-md bg-elevated p-3 ring-border sm:col-span-1">
                  <div className="eyebrow">Remaining after</div>
                  <div
                    className={cn(
                      'num mt-1 text-base font-semibold',
                      remainingAfterLbs === 0 ? 'text-ok' : 'text-warn'
                    )}
                  >
                    {remainingAfterLbs === 0
                      ? varianceAfterLbs > 0
                        ? `+${formatLbs(varianceAfterLbs)} over`
                        : '0 lbs — complete'
                      : formatLbs(remainingAfterLbs)}
                  </div>
                  <div className="num text-xs text-muted">
                    {formatTons(remainingAfterLbs / lbsPerTon)}
                  </div>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">Stage design target</div>
                  <div className="stat-v mt-1">{formatLbs(stageDesignTotalLbs)}</div>
                  <div className="num text-xs text-muted">
                    {formatTons(stageDesignTotalLbs / lbsPerTon)}
                  </div>
                </div>

                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">This record</div>
                  <div className="stat-v mt-1 text-critical">{formatLbs(totalActualPulledLbs)}</div>
                  <div className="num text-xs text-muted">
                    {formatTons(totalActualPulledLbs / lbsPerTon)}
                  </div>
                </div>

                <div
                  className={cn(
                    'rounded-md bg-elevated p-3',
                    varianceLbs === 0 ? 'ring-border' : varianceLbs > 0 ? 'ring-warn-1' : 'ring-danger-1'
                  )}
                >
                  <div className="eyebrow">Variance vs design</div>
                  <div
                    className={cn(
                      'stat-v mt-1',
                      varianceLbs === 0 ? 'text-ok' : varianceLbs > 0 ? 'text-warn' : 'text-danger'
                    )}
                  >
                    {varianceLbs > 0
                      ? `+${formatLbs(varianceLbs)}`
                      : varianceLbs < 0
                        ? formatLbs(varianceLbs)
                        : '0 lbs'}
                  </div>
                  <div className="text-xs text-muted">
                    {varianceLbs > 0 ? 'Over design' : varianceLbs < 0 ? 'Short of design' : 'Exact match'}
                  </div>
                </div>
              </div>
            )}

            {/* ------------------------------ stage completion callout --- */}
            <div
              className={cn(
                'flex items-start justify-between gap-3 rounded-md bg-elevated p-3',
                stageCompletionStatus.isComplete ? 'ring-border' : 'ring-warn-1'
              )}
            >
              <div className="flex items-start gap-2.5">
                {stageCompletionStatus.isComplete ? (
                  <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-ok" />
                ) : (
                  <AlertTriangle className="mt-0.5 size-5 shrink-0 text-warn" />
                )}
                <div>
                  <div
                    className={cn(
                      'eyebrow',
                      stageCompletionStatus.isComplete ? 'text-ok' : 'text-warn'
                    )}
                  >
                    {stageCompletionStatus.isComplete ? 'Stage will be complete' : 'Partial stage'}
                  </div>
                  <div className="mt-1 text-sm text-fg">
                    {stageCompletionStatus.isComplete
                      ? 'Design is met for this stage — the zipper advances to the next well when this is recorded.'
                      : `Still short by ${formatLbs(stageCompletionStatus.totalRemainingLbs)}. The zipper stays on ${wellObj.name} stage ${stageNumber} until the design is met.`}
                  </div>
                </div>
              </div>

              <span
                className={cn(
                  'badge shrink-0',
                  stageCompletionStatus.isComplete ? 'badge-ok' : 'badge-warn'
                )}
              >
                {stageCompletionStatus.isComplete ? 'Full stage' : 'Partial'}
              </span>
            </div>

            {/* --------------------------------------- dry silo alert --- */}
            {drySilos.length > 0 && (
              <div className="flex items-start gap-2.5 rounded-md bg-elevated p-3 ring-warn-1">
                <span className="badge badge-warn shrink-0">Reload required</span>
                <span className="text-sm text-fg">
                  {drySilos.map((s) => `Silo #${s.siloNumber}`).join(', ')}{' '}
                  {drySilos.length === 1 ? 'is' : 'are'} empty after this stage and ready for the
                  next delivery.
                </span>
              </div>
            )}

            {/* ------------------------------ manual override hygiene --- */}
            {hasManualOverrides && (
              <label
                htmlFor="clear-manual-overrides-check"
                className="flex cursor-pointer items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-locked-1"
              >
                <span className="flex items-start gap-2.5">
                  <Lock className="mt-0.5 size-4 shrink-0 text-locked" />
                  <span>
                    <span className="eyebrow text-locked">Manual run-order pins are active</span>
                    <span className="mt-1 block text-sm text-fg">
                      Clear them once this stage completes and hand the order back to the rotation.
                    </span>
                  </span>
                </span>
                <input
                  id="clear-manual-overrides-check"
                  type="checkbox"
                  checked={clearOverrides}
                  onChange={(e) => setClearOverrides(e.target.checked)}
                  className="size-5 shrink-0 cursor-pointer accent-[var(--color-locked)]"
                />
              </label>
            )}

            {/* ------------------------------------------- footer --- */}
            <div className="flex flex-col-reverse items-stretch justify-end gap-2 sm:flex-row sm:items-center">
              <button
                type="button"
                onClick={onClose}
                disabled={isSubmitting}
                className="btn btn-lg tap"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isSubmitting || totalActualPulledLbs <= 0 || isAlreadyComplete}
                className="btn btn-accent btn-lg tap"
              >
                <CheckCircle2 className="size-5" />
                <span>
                  {isSubmitting
                    ? 'Recording pull'
                    : isAlreadyComplete
                      ? 'Stage already complete'
                      : `Confirm and log ${formatLbs(totalActualPulledLbs)}`}
                </span>
                <ArrowRight className="size-4" />
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

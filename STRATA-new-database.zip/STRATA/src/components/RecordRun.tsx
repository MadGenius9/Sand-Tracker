/**
 * Record run — full page. The header triad plus the shared allocation form.
 */

import { useMemo } from 'react';
import RecordRunForm, { RecordRunPayload } from './RecordRunForm';
import { getPadSummary } from '../lib/sandRules';
import { AppState } from '../types';

interface RecordRunProps {
  state: AppState;
  onRecordRun: (records: RecordRunPayload[]) => void;
  onCancel?: () => void;
}

export default function RecordRun({ state, onRecordRun, onCancel }: RecordRunProps) {
  const { config, runs, deliveries } = state;

  /* Header only — the form keeps its own summary. Same three slices. */
  const padSummary = useMemo(() => getPadSummary(state), [config, runs, deliveries]);

  return (
    <div className="mx-auto flex w-full max-w-4xl flex-col gap-5 pb-12">
      <div>
        <div className="eyebrow">Record run</div>
        <h1 className="text-2xl font-medium tracking-tight">{config.padName || 'Pad'}</h1>
        <p className="max-w-2xl text-sm text-muted">
          The draw strategy proposes the cans and the split; you record what actually went
          downhole. Next up is {padSummary.nextWellName} stage{' '}
          <span className="num">{padSummary.nextStageNumber}</span>.
        </p>
      </div>

      <div className="card">
        <RecordRunForm
          state={state}
          fixedTarget={false}
          onRecordRun={onRecordRun}
          onCancel={onCancel}
        />
      </div>
    </div>
  );
}

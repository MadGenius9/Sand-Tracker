/**
 * Soft-delete confirmation for one ticket or one stage run.
 *
 * The point of the dialog is the balance preview: deleting a ticket takes lbs
 * OUT of a can, deleting a run puts them BACK. The before -> after pair is
 * computed by replaying the ledger without the record, so it is the same
 * number the silo board will show a second later.
 */

import { AlertTriangle, ArrowRight, Trash2, X } from 'lucide-react';
import { FormEvent, useMemo, useState } from 'react';
import { formatLbs, formatTons, getSiloDerivedStates } from '../lib/sandRules';
import { cn, sandClasses } from '../lib/theme';
import { AppState, DeliveryTicket, RunRecord } from '../types';

interface DeleteConfirmModalProps {
  state: AppState;
  target: { type: 'ticket'; item: DeliveryTicket } | { type: 'run'; item: RunRecord };
  onConfirmDelete: (reason?: string) => Promise<void>;
  onClose: () => void;
}

export default function DeleteConfirmModal({
  state,
  target,
  onConfirmDelete,
  onClose,
}: DeleteConfirmModalProps) {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const lbsPerTon = state.config.lbsPerTon || 2000;

  /* Two full ledger replays (current and simulated). Keyed on the record and
     the two slices those replays read, so typing a reason costs nothing. */
  const impact = useMemo(() => {
    const currentSiloStates = getSiloDerivedStates(state);

    if (target.type === 'ticket') {
      const ticket = target.item;
      const siloNumber = ticket.siloNumber;
      const beforeLbs =
        currentSiloStates.find((s) => s.siloNumber === siloNumber)?.onHandLbs || 0;
      const projectedState: AppState = {
        ...state,
        deliveries: state.deliveries.filter((d) => d.id !== ticket.id),
      };
      const afterLbs =
        getSiloDerivedStates(projectedState).find((s) => s.siloNumber === siloNumber)?.onHandLbs ||
        0;
      return {
        siloNumber,
        beforeLbs,
        afterLbs,
        diffLbs: afterLbs - beforeLbs,
        movedLbs: ticket.lbs || 0,
        sandType: ticket.sandType,
        verb: 'Removes',
      };
    }

    const run = target.item;
    const siloNumber = run.siloNumber;
    const beforeLbs = currentSiloStates.find((s) => s.siloNumber === siloNumber)?.onHandLbs || 0;
    const projectedState: AppState = {
      ...state,
      runs: state.runs.filter((r) => r.id !== run.id),
    };
    const afterLbs =
      getSiloDerivedStates(projectedState).find((s) => s.siloNumber === siloNumber)?.onHandLbs || 0;
    return {
      siloNumber,
      beforeLbs,
      afterLbs,
      diffLbs: afterLbs - beforeLbs,
      movedLbs: run.lbsPulled || 0,
      sandType: run.sandType,
      verb: 'Restores',
    };
  }, [state, target]);

  const tone = sandClasses(impact.sandType, state.config.sandTypes);
  const isTicket = target.type === 'ticket';

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setIsSubmitting(true);
    setError(null);

    try {
      await onConfirmDelete(reason.trim() || undefined);
      onClose();
    } catch (err: any) {
      console.error('Failed to soft delete record:', err);
      setError(err?.message || 'Failed to soft delete record');
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="delete-confirm-title"
    >
      <div className="card my-auto max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-xl p-5 ring-danger-1">
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow text-danger">Soft delete</div>
            <h2 id="delete-confirm-title" className="text-xl font-medium tracking-tight">
              {isTicket ? 'Delivery ticket' : 'Stage run record'}
            </h2>
            <p className="text-sm text-muted">
              {isTicket
                ? `Ticket #${target.item.ticketNumber} · ${target.item.supplier || 'No supplier'}`
                : `Stage ${target.item.stageNumber} · Silo #${target.item.siloNumber}`}
            </p>
          </div>
          <button type="button" onClick={onClose} className="btn btn-ghost tap shrink-0 px-2" aria-label="Close">
            <X className="size-5" />
          </button>
        </div>

        {error && (
          <div className="mb-4 flex items-start gap-2 rounded-sm bg-danger-dim p-3 text-sm text-danger">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* ------------------------------------------ record detail --- */}
          <div className="rounded-md bg-elevated p-3 ring-border">
            <table className="tbl">
              <tbody>
                {isTicket ? (
                  <>
                    <tr>
                      <td className="text-muted">Ticket</td>
                      <td className="n text-fg">{target.item.ticketNumber}</td>
                    </tr>
                    <tr>
                      <td className="text-muted">Sand · weight</td>
                      <td className="n">
                        <span className={cn('mr-1.5 inline-block size-2 rounded-full align-middle', tone.fill)} />
                        {target.item.sandType} · {formatLbs(target.item.lbs)}
                      </td>
                    </tr>
                    <tr>
                      <td className="text-muted">Target silo</td>
                      <td className="n">#{target.item.siloNumber}</td>
                    </tr>
                    <tr>
                      <td className="text-muted">Supplier · date</td>
                      <td className="n">
                        {target.item.supplier || '—'} · {target.item.date}
                      </td>
                    </tr>
                  </>
                ) : (
                  <>
                    <tr>
                      <td className="text-muted">Stage</td>
                      <td className="n">{target.item.stageNumber}</td>
                    </tr>
                    <tr>
                      <td className="text-muted">Pulled weight</td>
                      <td className="n">{formatLbs(target.item.lbsPulled)}</td>
                    </tr>
                    <tr>
                      <td className="text-muted">Pulled from</td>
                      <td className="n">
                        <span className={cn('mr-1.5 inline-block size-2 rounded-full align-middle', tone.fill)} />
                        Silo #{target.item.siloNumber} · {target.item.sandType}
                      </td>
                    </tr>
                    <tr>
                      <td className="text-muted">Run date</td>
                      <td className="n">{target.item.date}</td>
                    </tr>
                  </>
                )}
              </tbody>
            </table>
          </div>

          {/* -------------------------------- projected balance impact --- */}
          <div className="rounded-md bg-elevated p-3 ring-danger-1">
            <div className="flex items-center gap-2">
              <AlertTriangle className="size-4 shrink-0 text-danger" />
              <span className="eyebrow text-danger">Silo balance impact</span>
            </div>

            <p className="mt-2 text-sm text-fg">
              {impact.verb} <span className="num">{formatLbs(impact.movedLbs)}</span>{' '}
              {isTicket ? 'from' : 'to'} silo <span className="num">#{impact.siloNumber}</span>.
            </p>

            <div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded-sm bg-surface px-3 py-2">
              <span className="eyebrow">Silo #{impact.siloNumber} on hand</span>
              <div className="flex items-center gap-2">
                <span className="num text-sm text-muted">{formatLbs(impact.beforeLbs)}</span>
                <ArrowRight className="size-4 shrink-0 text-muted" />
                <span
                  className={cn(
                    'num text-sm font-semibold',
                    impact.afterLbs < 0 ? 'text-danger' : 'text-fg'
                  )}
                >
                  {formatLbs(impact.afterLbs)}
                </span>
                <span className={cn('badge', impact.diffLbs >= 0 ? 'badge-ok' : 'badge-danger')}>
                  <span className="num">
                    {impact.diffLbs > 0 ? `+${formatLbs(impact.diffLbs)}` : formatLbs(impact.diffLbs)}
                  </span>
                </span>
              </div>
            </div>

            <div className="mt-1.5 text-xs text-muted">
              <span className="num">{formatTons(impact.afterLbs / lbsPerTon)}</span> after the change.
            </div>
          </div>

          {/* ------------------------------------------------- reason --- */}
          <label className="block">
            <span className="eyebrow">Reason for deletion (optional)</span>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Duplicate ticket entry, scale typo, truck returned"
              className="input mt-1"
            />
          </label>

          <p className="text-xs text-muted">
            Soft delete only — the record moves to the Deleted tab in Logs, keeps its audit trail,
            and can be restored at any time.
          </p>

          <div className="mt-1 flex items-center justify-end gap-2">
            <button type="button" onClick={onClose} disabled={isSubmitting} className="btn tap">
              Cancel
            </button>
            <button type="submit" disabled={isSubmitting} className="btn btn-danger tap">
              <Trash2 className="size-4" />
              {isSubmitting ? 'Deleting' : 'Confirm delete'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

/**
 * Edit one delivery ticket.
 *
 * Everything that can silently corrupt a can's balance is surfaced before the
 * save: a duplicate ticket number, a sand type that disagrees with the silo
 * assignment, and the before -> after on-hand for every silo the edit touches
 * (both the old and the new one when the ticket is moved).
 */

import { AlertTriangle, ArrowRight, Check, X } from 'lucide-react';
import { FormEvent, useMemo, useState } from 'react';
import { formatLbs, formatTons, getSiloDerivedStates } from '../lib/sandRules';
import { normalizeTicketNumber } from '../lib/ticketUtils';
import { getOperationalDate } from '../lib/dateUtils';
import { cn, sandClasses } from '../lib/theme';
import { AppState, DeliveryTicket } from '../types';

interface EditDeliveryModalProps {
  state: AppState;
  ticket: DeliveryTicket;
  onSave: (updates: Partial<Omit<DeliveryTicket, 'id' | 'createdAt'>>) => Promise<void>;
  onClose: () => void;
}

export default function EditDeliveryModal({
  state,
  ticket,
  onSave,
  onClose,
}: EditDeliveryModalProps) {
  const [ticketNumber, setTicketNumber] = useState(ticket.ticketNumber || '');
  const [siloNumber, setSiloNumber] = useState<number>(ticket.siloNumber || 1);
  const [sandType, setSandType] = useState<string>(
    ticket.sandType || state.config.sandTypes[0]?.name || '100 Mesh'
  );
  const [lbs, setLbs] = useState<string>(ticket.lbs ? ticket.lbs.toString() : '');
  const [supplier, setSupplier] = useState<string>(ticket.supplier || '');
  const [date, setDate] = useState(ticket.date || getOperationalDate());
  const [timeOfDay, setTimeOfDay] = useState(ticket.timeOfDay || '');
  const [driverName, setDriverName] = useState(ticket.driverName || '');
  const [notes, setNotes] = useState(ticket.notes || '');

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const lbsPerTon = state.config.lbsPerTon || 2000;
  const supplierList = state.config.suppliers || [];

  // Duplicate check ignores this ticket and anything already soft-deleted.
  const duplicateDelivery = useMemo(() => {
    const normInput = normalizeTicketNumber(ticketNumber);
    if (!normInput) return undefined;
    return state.deliveries.find(
      (d) => !d.deleted && d.id !== ticket.id && normalizeTicketNumber(d.ticketNumber) === normInput
    );
  }, [state.deliveries, ticket.id, ticketNumber]);

  const selectedSiloConfig = state.config.silos.find((s) => s.siloNumber === siloNumber);
  const isSandTypeMismatch = Boolean(
    selectedSiloConfig && selectedSiloConfig.sandType && selectedSiloConfig.sandType !== sandType
  );

  const newWeightLbs = parseInt(lbs, 10) || 0;

  /* Two full ledger replays. Keyed on the three edits that can move sand:
     the target silo, the weight and the sand type. */
  const siloChanges = useMemo(() => {
    const currentSiloDerivedStates = getSiloDerivedStates(state);
    const simulatedState: AppState = {
      ...state,
      deliveries: state.deliveries.map((d) =>
        d.id === ticket.id ? { ...d, siloNumber, lbs: newWeightLbs, sandType } : d
      ),
    };
    const projectedSiloDerivedStates = getSiloDerivedStates(simulatedState);

    const affected = Array.from(new Set([ticket.siloNumber, siloNumber])).sort((a, b) => a - b);
    return affected.map((sNum) => {
      const beforeObj = currentSiloDerivedStates.find((s) => s.siloNumber === sNum);
      const afterObj = projectedSiloDerivedStates.find((s) => s.siloNumber === sNum);
      const beforeLbs = beforeObj?.onHandLbs || 0;
      const afterLbs = afterObj?.onHandLbs || 0;
      return {
        siloNumber: sNum,
        siloName: beforeObj?.name || `Silo ${sNum}`,
        sandType: beforeObj?.sandType || null,
        beforeLbs,
        afterLbs,
        diff: afterLbs - beforeLbs,
      };
    });
  }, [state, ticket.id, ticket.siloNumber, siloNumber, newWeightLbs, sandType]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setSubmitError(null);
    const errs: Record<string, string> = {};

    if (!ticketNumber.trim()) {
      errs.ticketNumber = 'Ticket number is required';
    }

    const numericLbs = parseInt(lbs, 10);
    if (!numericLbs || numericLbs <= 0) {
      errs.lbs = 'Valid sand weight in lbs is required';
    }

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    setIsSubmitting(true);

    try {
      await onSave({
        ticketNumber: ticketNumber.trim(),
        siloNumber,
        sandType,
        lbs: numericLbs,
        supplier: supplier.trim(),
        date,
        timeOfDay: timeOfDay || undefined,
        driverName: driverName.trim() || undefined,
        notes: notes.trim() || undefined,
      });
      onClose();
    } catch (err: any) {
      console.error('Failed to update ticket:', err);
      setSubmitError(err?.message || 'Failed to update ticket');
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-delivery-title"
    >
      <div className="card my-auto max-h-[92vh] w-full max-w-2xl overflow-y-auto rounded-xl p-5">
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow">Ticket entry</div>
            <h2 id="edit-delivery-title" className="text-xl font-medium tracking-tight">
              Edit ticket <span className="num">#{ticket.ticketNumber}</span>
            </h2>
            <p className="text-sm text-muted">
              Weight, silo and sand type all re-base the can's on-hand — the preview below is the
              ledger replayed with your edit.
            </p>
          </div>
          <button type="button" onClick={onClose} className="btn btn-ghost tap shrink-0 px-2" aria-label="Close">
            <X className="size-5" />
          </button>
        </div>

        {submitError && (
          <div className="mb-4 flex items-start gap-2 rounded-sm bg-danger-dim p-3 text-sm text-danger">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            <span>{submitError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
          {/* ------------------------------------ ticket no. and date --- */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="eyebrow">Ticket number</span>
              <input
                type="text"
                inputMode="numeric"
                value={ticketNumber}
                onChange={(e) => {
                  setTicketNumber(e.target.value);
                  setErrors((prev) => ({ ...prev, ticketNumber: '' }));
                }}
                placeholder="104928"
                className={cn('input num mt-1 uppercase', errors.ticketNumber && 'ring-danger-1')}
              />
              {errors.ticketNumber && (
                <span className="mt-1 block text-xs text-danger">{errors.ticketNumber}</span>
              )}
            </label>

            <label className="block">
              <span className="eyebrow">Delivery date</span>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="input num mt-1"
              />
            </label>
          </div>

          {duplicateDelivery && (
            <div className="rounded-md bg-elevated p-3 ring-warn-1">
              <div className="flex items-center gap-2">
                <AlertTriangle className="size-4 shrink-0 text-warn" />
                <span className="eyebrow text-warn">Duplicate ticket number</span>
              </div>
              <p className="mt-1 text-sm text-fg">
                Ticket <span className="num">#{duplicateDelivery.ticketNumber}</span> is already
                logged in silo <span className="num">#{duplicateDelivery.siloNumber}</span> at{' '}
                <span className="num">{formatLbs(duplicateDelivery.lbs)}</span> on{' '}
                <span className="num">{duplicateDelivery.date}</span>.
              </p>
            </div>
          )}

          {/* ---------------------------------------- silo and weight --- */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="eyebrow">Target silo</span>
              <select
                value={siloNumber}
                onChange={(e) => setSiloNumber(parseInt(e.target.value, 10))}
                className="select num mt-1"
              >
                {!state.config.silos.some((s) => s.siloNumber === siloNumber) && (
                  <option value={siloNumber}>
                    Silo #{siloNumber} — not in current pad config
                  </option>
                )}
                {state.config.silos.map((s) => (
                  <option key={s.siloNumber} value={s.siloNumber}>
                    Silo #{s.siloNumber}
                    {s.name ? ` (${s.name})` : ''} — {s.sandType || 'Empty'}
                  </option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="eyebrow">Net sand weight (lbs)</span>
              <input
                type="number"
                inputMode="numeric"
                value={lbs}
                onChange={(e) => {
                  setLbs(e.target.value);
                  setErrors((prev) => ({ ...prev, lbs: '' }));
                }}
                placeholder="52380"
                className={cn('input input-num mt-1', errors.lbs && 'ring-danger-1')}
              />
              <span className="mt-1 block text-xs text-muted">
                <span className="num">{formatTons(newWeightLbs / lbsPerTon)}</span>
              </span>
              {errors.lbs && <span className="mt-1 block text-xs text-danger">{errors.lbs}</span>}
            </label>
          </div>

          {/* ------------------------------------- sand and supplier --- */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="eyebrow">Sand type</span>
              <select
                value={sandType}
                onChange={(e) => setSandType(e.target.value)}
                className="select mt-1"
              >
                {state.config.sandTypes.map((st) => (
                  <option key={st.id} value={st.name}>
                    {st.name}
                  </option>
                ))}
              </select>
            </label>

            <div>
              <span className="eyebrow">Supplier / hauler</span>
              {supplierList.length > 0 ? (
                <div className="mt-1 flex flex-col gap-2">
                  <select
                    value={supplierList.includes(supplier) ? supplier : '__OTHER__'}
                    onChange={(e) => {
                      if (e.target.value !== '__OTHER__') {
                        setSupplier(e.target.value);
                      }
                    }}
                    className="select"
                  >
                    {supplierList.map((sup) => (
                      <option key={sup} value={sup}>
                        {sup}
                      </option>
                    ))}
                    <option value="__OTHER__">Custom supplier name</option>
                  </select>
                  {(!supplierList.includes(supplier) || supplier === '') && (
                    <input
                      type="text"
                      value={supplier}
                      onChange={(e) => setSupplier(e.target.value)}
                      placeholder="Enter supplier name"
                      className="input"
                    />
                  )}
                </div>
              ) : (
                <input
                  type="text"
                  value={supplier}
                  onChange={(e) => setSupplier(e.target.value)}
                  placeholder="Atlas Sand"
                  className="input mt-1"
                />
              )}
            </div>
          </div>

          {isSandTypeMismatch && (
            <div className="rounded-md bg-elevated p-3 ring-warn-1">
              <div className="flex items-center gap-2">
                <AlertTriangle className="size-4 shrink-0 text-warn" />
                <span className="eyebrow text-warn">Sand type mismatch</span>
              </div>
              <p className="mt-1 text-sm text-fg">
                Silo <span className="num">#{siloNumber}</span> is assigned{' '}
                {selectedSiloConfig?.sandType}, but this ticket says {sandType}. The ticket will be
                tracked against {sandType}.
              </p>
            </div>
          )}

          {/* ------------------------------ projected balance impact --- */}
          <div className="rounded-md bg-elevated p-3 ring-accent-1">
            <div className="flex items-center justify-between gap-2">
              <span className="eyebrow text-accent">Projected silo balance impact</span>
              <span className="eyebrow">On-hand adjustment</span>
            </div>

            <div className="mt-2 flex flex-col gap-2">
              {siloChanges.map((sc) => {
                const tone = sandClasses(sc.sandType, state.config.sandTypes);
                return (
                  <div
                    key={sc.siloNumber}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-sm bg-surface px-3 py-2"
                  >
                    <div className="flex min-w-0 items-center gap-2">
                      <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                      <span className="truncate text-sm font-medium">
                        Silo <span className="num">#{sc.siloNumber}</span>
                      </span>
                      <span className="truncate text-xs text-muted">{sc.siloName}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="num text-sm text-muted">{formatLbs(sc.beforeLbs)}</span>
                      <ArrowRight className="size-4 shrink-0 text-muted" />
                      <span
                        className={cn(
                          'num text-sm font-semibold',
                          sc.afterLbs < 0 ? 'text-danger' : 'text-fg'
                        )}
                      >
                        {formatLbs(sc.afterLbs)}
                      </span>
                      {sc.diff !== 0 && (
                        <span className={cn('badge', sc.diff > 0 ? 'badge-ok' : 'badge-warn')}>
                          <span className="num">
                            {sc.diff > 0 ? `+${formatLbs(sc.diff)}` : formatLbs(sc.diff)}
                          </span>
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* --------------------------------------- driver and time --- */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="eyebrow">Driver name (optional)</span>
              <input
                type="text"
                value={driverName}
                onChange={(e) => setDriverName(e.target.value)}
                placeholder="Driver full name"
                className="input mt-1"
              />
            </label>

            <label className="block">
              <span className="eyebrow">Time of day (optional)</span>
              <input
                type="time"
                value={timeOfDay}
                onChange={(e) => setTimeOfDay(e.target.value)}
                className="input num mt-1"
              />
            </label>
          </div>

          <label className="block">
            <span className="eyebrow">Reason / notes for this edit (optional)</span>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Shift 1 load, re-weighed at scale"
              className="input mt-1"
            />
          </label>

          <div className="mt-1 flex items-center justify-end gap-2">
            <button type="button" onClick={onClose} disabled={isSubmitting} className="btn tap">
              Cancel
            </button>
            <button type="submit" disabled={isSubmitting} className="btn btn-accent tap">
              <Check className="size-4" />
              {isSubmitting ? 'Saving' : 'Save ticket changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

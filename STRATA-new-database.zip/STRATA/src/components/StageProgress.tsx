/**
 * Stage progress — where every well stands, stage by stage.
 *
 * The heat grid is the point of this screen: one cell per planned stage, so a
 * company man can see the shape of the job (a run of completes, a gap, a
 * partial that never finished) without reading a single number. The tables
 * underneath carry the numbers they sign off on.
 *
 * Stage completion is `isStageComplete` via `getWellProgress` — a stage is done
 * only when every sand type in its design is satisfied, not merely when some
 * sand was pulled against it.
 */

import { Activity, CheckCircle2, Layers } from 'lucide-react';
import { useMemo } from 'react';
import {
  formatLbsNumber,
  calculateSandDesignForWell,
  calculateSandPumpedForWell,
} from '../lib/sandRules';
import { getWellProgress, type WellProgress } from '../lib/analytics';
import { sandClasses, cn } from '../lib/theme';
import { AppState, WellConfig } from '../types';

interface StageProgressProps {
  state: AppState;
}

/** Kept from the previous build: an unconfigured pad still renders a shape. */
const PLACEHOLDER_WELL: WellConfig = { id: 'w-1', name: 'Well 1H', plannedStages: 40 };

function emptyProgress(well: WellConfig): WellProgress {
  const planned = well.plannedStages || 0;
  return {
    well,
    planned,
    completed: 0,
    remaining: planned,
    pct: 0,
    pumpedLbs: 0,
    stages: Array.from({ length: planned }, (_, i) => ({
      stage: i + 1,
      complete: false,
      pumpedLbs: 0,
      pct: 0,
    })),
  };
}

/** complete · partial · empty — three states, nothing in between. */
function cellClass(stage: WellProgress['stages'][number]): string {
  if (stage.complete) return 'bg-accent text-accent-fg';
  if (stage.pumpedLbs > 0) return 'bg-warn-dim text-warn';
  return 'bg-elevated text-subtle';
}

export default function StageProgress({ state }: StageProgressProps) {
  const { config, runs } = state;
  const lbsPerTon = config.lbsPerTon || 2000;

  // Stable identity: a fresh `[PLACEHOLDER_WELL]` every render would defeat
  // every memo below it.
  const wells = useMemo(
    () => (config.wells.length > 0 ? config.wells : [PLACEHOLDER_WELL]),
    [config.wells]
  );

  /* getWellProgress walks every run once per well — memoized on the slices it
     reads so scrolling a 60-stage grid does not recompute the pad. */
  const wellProgress = useMemo(() => getWellProgress(state), [config, runs]);

  const progressByWell = useMemo(() => {
    const map = new Map<string, WellProgress>();
    for (const p of wellProgress) map.set(p.well.id, p);
    return map;
  }, [wellProgress]);

  /** Per-well design vs pumped, by sand type. */
  const rows = useMemo(
    () =>
      wells.map((well) => {
        const progress = progressByWell.get(well.id) || emptyProgress(well);

        const sandTypeBreakdown = config.sandTypes.map((st) => {
          const designLbs = calculateSandDesignForWell(well, st);
          const pumpedLbs = calculateSandPumpedForWell(well.id, st.name, state);
          const varianceLbs = pumpedLbs - designLbs;
          return {
            sandType: st,
            designLbs,
            pumpedLbs,
            varianceLbs,
            variancePercent: designLbs > 0 ? (varianceLbs / designLbs) * 100 : 0,
          };
        });

        const totalSandDesignLbs = sandTypeBreakdown.reduce((s, b) => s + b.designLbs, 0);
        const estimatedSandRemainingLbs = Math.max(
          0,
          totalSandDesignLbs - progress.pumpedLbs
        );

        // The stage the crew is standing on: first incomplete, else past the end.
        const firstIncomplete = progress.stages.find((s) => !s.complete);
        const currentActiveStage = firstIncomplete
          ? firstIncomplete.stage
          : progress.planned + 1;

        return {
          well,
          progress,
          sandTypeBreakdown,
          totalSandDesignLbs,
          totalSandPumpedLbs: progress.pumpedLbs,
          totalSandPumpedTons: progress.pumpedLbs / lbsPerTon,
          estimatedSandRemainingLbs,
          estimatedSandRemainingTons: estimatedSandRemainingLbs / lbsPerTon,
          currentActiveStage,
        };
      }),
    // calculateSandPumpedForWell reads state.runs only; keying on the slice
    // rather than on `state` keeps a padId or status change from recomputing.
    [wells, progressByWell, config.sandTypes, runs, lbsPerTon]
  );

  const padTotals = useMemo(() => {
    const planned = rows.reduce((s, r) => s + r.progress.planned, 0);
    const done = rows.reduce((s, r) => s + r.progress.completed, 0);
    const pumpedLbs = rows.reduce((s, r) => s + r.totalSandPumpedLbs, 0);
    const designLbs = rows.reduce((s, r) => s + r.totalSandDesignLbs, 0);
    const remainingLbs = Math.max(0, designLbs - pumpedLbs);
    return {
      planned,
      done,
      remaining: Math.max(0, planned - done),
      pct: planned > 0 ? Math.min(100, Math.round((done / planned) * 100)) : 0,
      pumpedLbs,
      pumpedTons: pumpedLbs / lbsPerTon,
      designLbs,
      remainingLbs,
      remainingTons: remainingLbs / lbsPerTon,
    };
  }, [rows, lbsPerTon]);

  /** Pad-wide design vs pumped, by sand type. */
  const padSandTypeTotals = useMemo(
    () =>
      config.sandTypes.map((st) => {
        const padDesignLbs = wells.reduce(
          (sum, w) => sum + calculateSandDesignForWell(w, st),
          0
        );
        const padPumpedLbs = wells.reduce(
          (sum, w) => sum + calculateSandPumpedForWell(w.id, st.name, state),
          0
        );
        const varianceLbs = padPumpedLbs - padDesignLbs;
        return {
          sandType: st,
          padDesignLbs,
          padPumpedLbs,
          varianceLbs,
          variancePercent: padDesignLbs > 0 ? (varianceLbs / padDesignLbs) * 100 : 0,
        };
      }),
    [config.sandTypes, wells, runs]
  );

  const padDesignSum = padSandTypeTotals.reduce((s, p) => s + p.padDesignLbs, 0);
  const padPumpedSum = padSandTypeTotals.reduce((s, p) => s + p.padPumpedLbs, 0);
  const padVarianceSum = padSandTypeTotals.reduce((s, p) => s + p.varianceLbs, 0);

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 pb-12">
      {/* ------------------------------------------------ pad header --- */}
      <div className="card">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="eyebrow">Well pad operations</div>
            <h1 className="flex items-center gap-2 text-2xl font-medium tracking-tight">
              <Activity className="size-5 text-muted" /> Stage progress
            </h1>
            <p className="max-w-2xl text-sm text-muted">
              A stage counts complete only when every sand type in its design is satisfied.
              Partial stages show amber in the grid; remaining sand is design minus pumped
              across all wells.
            </p>
          </div>

          <div className="shrink-0 text-right">
            <div className="eyebrow">Pad completion</div>
            <div className="stat-v mt-1 text-accent">{padTotals.pct}%</div>
            <div className="text-xs text-muted">
              <span className="num">{padTotals.done}</span> of{' '}
              <span className="num">{padTotals.planned}</span> stages
            </div>
          </div>
        </div>

        <div className="mt-4">
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="flex items-center gap-1.5 text-ok">
              <CheckCircle2 className="size-4" />
              <span className="num">{padTotals.done}</span> pumped
            </span>
            <span className="text-muted">
              <span className="num">{padTotals.remaining}</span> remaining
            </span>
            <span className="text-muted">
              <span className="num">{padTotals.planned}</span> total planned
            </span>
          </div>
          <div className="meter mt-2">
            <span style={{ width: `${padTotals.pct}%` }} />
          </div>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-4">
          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Planned stages</div>
            <div className="stat-v mt-1">{padTotals.planned}</div>
            <div className="text-xs text-muted">
              <span className="num">{wells.length}</span>{' '}
              {wells.length === 1 ? 'well' : 'wells'} active
            </div>
          </div>

          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Pumped stages</div>
            <div className="stat-v mt-1 text-ok">{padTotals.done}</div>
            <div className="text-xs text-muted">
              <span className="num">{padTotals.pct}%</span> complete
            </div>
          </div>

          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Remaining stages</div>
            <div className="stat-v mt-1">{padTotals.remaining}</div>
            <div className="text-xs text-muted">
              <span className="num">{formatLbsNumber(padTotals.remainingLbs)}</span> lbs ·{' '}
              <span className="num">{padTotals.remainingTons.toFixed(1)}</span> t left
            </div>
          </div>

          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Sand pumped to date</div>
            <div className="stat-v mt-1">{formatLbsNumber(padTotals.pumpedLbs)}</div>
            <div className="text-xs text-muted">
              <span className="num">{padTotals.pumpedTons.toFixed(1)}</span> tons
            </div>
          </div>
        </div>
      </div>

      {/* --------------------------------------------- per-well cards --- */}
      <div className="flex flex-col gap-3">
        <div className="eyebrow px-1">
          Per-well breakdown · {wells.length} {wells.length === 1 ? 'well' : 'wells'}
        </div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {rows.map((row) => (
            <div key={row.well.id} className="card flex flex-col gap-4">
              {/* well header */}
              <div className="card-hd mb-0 items-center">
                <div>
                  <div className="eyebrow">
                    Current stage {row.currentActiveStage}
                    {row.well.customerName ? ` · ${row.well.customerName}` : ''}
                  </div>
                  <h2 className="text-lg font-medium tracking-tight">{row.well.name}</h2>
                </div>
                <div className="shrink-0 text-right">
                  <div className="num text-xl font-semibold text-accent">
                    {Math.round(row.progress.pct)}%
                  </div>
                  <div className="eyebrow">Progress</div>
                </div>
              </div>

              <div>
                <div className="meter">
                  <span style={{ width: `${Math.round(row.progress.pct)}%` }} />
                </div>
                <div className="mt-1.5 flex justify-between text-[11px] text-muted">
                  <span className="num">
                    {row.progress.completed} / {row.progress.planned} stages
                  </span>
                  <span className="num">{row.progress.remaining} left</span>
                </div>
              </div>

              {/* ---------------------------------- stage heat grid --- */}
              <div>
                <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                  <span className="eyebrow">Stage grid</span>
                  <div className="flex items-center gap-3 text-[11px] text-muted">
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block size-2.5 rounded-xs bg-accent" />
                      Complete
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block size-2.5 rounded-xs bg-warn-dim" />
                      Partial
                    </span>
                    <span className="flex items-center gap-1.5">
                      <span className="inline-block size-2.5 rounded-xs bg-elevated" />
                      Not started
                    </span>
                  </div>
                </div>

                {row.progress.stages.length === 0 ? (
                  <p className="text-xs text-subtle">
                    No planned stages configured for this well.
                  </p>
                ) : (
                  <div
                    className="grid gap-1"
                    style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(28px, 1fr))' }}
                  >
                    {row.progress.stages.map((stage) => (
                      <div
                        key={stage.stage}
                        title={`${row.well.name} · stage ${stage.stage} · ${formatLbsNumber(stage.pumpedLbs)} lbs · ${
                          stage.complete
                            ? 'complete'
                            : stage.pumpedLbs > 0
                              ? `partial (${Math.round(stage.pct)}%)`
                              : 'not started'
                        }`}
                        className={cn(
                          'num flex aspect-square items-center justify-center rounded-xs text-[10px] font-medium leading-none',
                          cellClass(stage)
                        )}
                      >
                        {stage.stage}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* --------------------------------------- stat tiles --- */}
              <div className="grid grid-cols-3 gap-2">
                <div className="rounded-md bg-elevated p-2.5 text-center ring-border">
                  <div className="eyebrow">Planned</div>
                  <div className="num mt-0.5 text-base font-semibold">
                    {row.progress.planned}
                  </div>
                  <div className="text-[10px] text-subtle">stages</div>
                </div>
                <div className="rounded-md bg-elevated p-2.5 text-center ring-border">
                  <div className="eyebrow">Pumped</div>
                  <div className="num mt-0.5 text-base font-semibold text-ok">
                    {row.progress.completed}
                  </div>
                  <div className="text-[10px] text-subtle">complete</div>
                </div>
                <div className="rounded-md bg-elevated p-2.5 text-center ring-border">
                  <div className="eyebrow">Remaining</div>
                  <div className="num mt-0.5 text-base font-semibold">
                    {row.progress.remaining}
                  </div>
                  <div className="text-[10px] text-subtle">to pump</div>
                </div>
              </div>

              {/* ------------------------ per sand design vs pumped --- */}
              <div className="rounded-md bg-elevated p-3 ring-border">
                <div className="eyebrow mb-1">Sand type design vs pumped</div>
                <div className="overflow-x-auto no-scrollbar">
                  <table className="tbl">
                    <thead>
                      <tr>
                        <th>Sand</th>
                        <th className="n">Design</th>
                        <th className="n">Pumped</th>
                        <th className="n">Variance</th>
                      </tr>
                    </thead>
                    <tbody>
                      {row.sandTypeBreakdown.map((sb) => {
                        const tone = sandClasses(sb.sandType.name, config.sandTypes);
                        return (
                          <tr key={sb.sandType.id}>
                            <td className={cn('font-medium', tone.text)}>
                              {sb.sandType.name}
                            </td>
                            <td className="n text-muted">{formatLbsNumber(sb.designLbs)}</td>
                            <td className="n">{formatLbsNumber(sb.pumpedLbs)}</td>
                            <td
                              className={cn(
                                'n',
                                sb.varianceLbs > 0
                                  ? 'text-warn'
                                  : sb.varianceLbs < 0
                                    ? 'text-muted'
                                    : 'text-subtle'
                              )}
                            >
                              {sb.varianceLbs > 0 ? '+' : ''}
                              {formatLbsNumber(sb.varianceLbs)}
                              <span className="ml-1 text-[10px] text-subtle">
                                ({sb.variancePercent > 0 ? '+' : ''}
                                {sb.variancePercent.toFixed(1)}%)
                              </span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* ------------------------------------ sand footer --- */}
              <div className="flex items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-border">
                <div>
                  <div className="eyebrow">Total sand pumped</div>
                  <div className="num text-sm font-semibold">
                    {formatLbsNumber(row.totalSandPumpedLbs)} lbs
                  </div>
                  <div className="num text-[11px] text-muted">
                    {row.totalSandPumpedTons.toFixed(1)} t
                  </div>
                </div>
                <div className="text-right">
                  <div className="eyebrow">Est. sand remaining</div>
                  <div className="num text-sm font-semibold text-accent">
                    {formatLbsNumber(row.estimatedSandRemainingLbs)} lbs
                  </div>
                  <div className="num text-[11px] text-muted">
                    {row.estimatedSandRemainingTons.toFixed(1)} t
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* -------------------------------------- pad totals by sand --- */}
      <div className="card">
        <div className="card-hd">
          <div>
            <div className="eyebrow">All wells</div>
            <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
              <Layers className="size-4 text-muted" /> Pad totals by sand type
            </h2>
            <p className="mt-1 text-sm text-muted">
              Planned design (stages × per-stage, honouring per-well overrides) against sand
              actually pumped across the whole pad.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto no-scrollbar">
          <table className="tbl">
            <thead>
              <tr>
                <th>Sand type</th>
                <th className="n">Total pad design</th>
                <th className="n">Pumped to date</th>
                <th className="n">Variance (lbs)</th>
                <th className="n">Variance (%)</th>
              </tr>
            </thead>
            <tbody>
              {padSandTypeTotals.map((pst) => {
                const tone = sandClasses(pst.sandType.name, config.sandTypes);
                const varianceTone =
                  pst.varianceLbs > 0
                    ? 'text-warn'
                    : pst.varianceLbs < 0
                      ? 'text-muted'
                      : 'text-subtle';
                return (
                  <tr key={pst.sandType.id}>
                    <td className={cn('font-medium', tone.text)}>{pst.sandType.name}</td>
                    <td className="n text-muted">{formatLbsNumber(pst.padDesignLbs)}</td>
                    <td className="n font-semibold">{formatLbsNumber(pst.padPumpedLbs)}</td>
                    <td className={cn('n', varianceTone)}>
                      {pst.varianceLbs > 0 ? '+' : ''}
                      {formatLbsNumber(pst.varianceLbs)}
                    </td>
                    <td className={cn('n', varianceTone)}>
                      {pst.variancePercent > 0 ? '+' : ''}
                      {pst.variancePercent.toFixed(1)}%
                    </td>
                  </tr>
                );
              })}

              <tr className="bg-elevated">
                <td className="font-medium">Total all sands</td>
                <td className="n">{formatLbsNumber(padDesignSum)}</td>
                <td className="n font-semibold text-accent">
                  {formatLbsNumber(padPumpedSum)}
                </td>
                <td className="n">
                  {padVarianceSum > 0 ? '+' : ''}
                  {formatLbsNumber(padVarianceSum)}
                </td>
                <td className="n">
                  {((padVarianceSum / (padDesignSum || 1)) * 100).toFixed(1)}%
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

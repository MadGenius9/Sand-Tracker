/**
 * The canister — a silo drawn as equipment, not as a progress bar.
 *
 * Pure divs: a cap, a body with an inset wall shadow, a bottom-anchored fill,
 * and three sight-glass lines at 25/50/75. No SVG, no canvas, no gradient
 * stack — cheap enough to render eight full-size plus a compact strip on the
 * dashboard without thinking about it, and every color is a theme token.
 *
 * Fill color comes from the SAND TYPE (so a coordinator reads product at a
 * glance), while STATUS is carried by the ring and the footer sentence. Those
 * are two independent channels on purpose: a full can of the wrong sand and an
 * empty can of the right sand must not look alike.
 */

import { Wrench, Lock, AlertTriangle } from 'lucide-react';
import type { SiloDerivedState, SandTypeSpec } from '../../types';
import { sandClasses, cn } from '../../lib/theme';
import { formatLbs } from '../../lib/sandRules';

type Status = 'oos' | 'neg' | 'over' | 'empty' | 'low' | 'ok';

/** One priority chain, computed once, driving both the ring and the message. */
function statusOf(silo: SiloDerivedState): Status {
  if (silo.status === 'OUT_OF_SERVICE') return 'oos';
  if (silo.isNegative) return 'neg';
  if (silo.isOverCapacity) return 'over';
  if (silo.status === 'EMPTY') return 'empty';
  if (silo.percentFull < 22) return 'low';
  return 'ok';
}

const RING: Record<Status, string> = {
  oos: 'ring-border',
  neg: 'ring-danger-1',
  over: 'ring-warn-1',
  empty: 'ring-danger-1',
  low: 'ring-warn-1',
  ok: 'ring-border',
};

function message(silo: SiloDerivedState, status: Status): { text: string; cls: string } {
  switch (status) {
    case 'oos':
      return { text: 'Out of service', cls: 'text-muted' };
    case 'neg':
      return { text: 'Negative balance — check tickets', cls: 'text-danger' };
    case 'over':
      return { text: `Over capacity at ${Math.round(silo.percentFull)}%`, cls: 'text-warn' };
    case 'empty':
      return { text: 'Empty', cls: 'text-danger' };
    case 'low':
      return { text: `Low — ${silo.stagesLeft.toFixed(1)} stages left`, cls: 'text-warn' };
    default:
      return { text: `${silo.stagesLeft.toFixed(1)} stages in this can`, cls: 'text-muted' };
  }
}

export interface CanisterProps {
  silo: SiloDerivedState;
  sandTypes?: SandTypeSpec[];
  compact?: boolean;
  onClick?: () => void;
  /** Show the planned pull for the upcoming stage. */
  showPull?: boolean;
  /** Highlight — used when another silo shares this run-order slot. */
  duplicateSlot?: boolean;
  className?: string;
}

export function Canister({
  silo,
  sandTypes,
  compact = false,
  onClick,
  showPull = true,
  duplicateSlot = false,
  className,
}: CanisterProps) {
  const status = statusOf(silo);
  const tone = sandClasses(silo.sandType, sandTypes);
  const pct = Math.max(0, Math.min(100, silo.percentFull));
  const msg = message(silo, status);
  const pinned = silo.manualPriority !== null && silo.manualPriority !== undefined;

  const Root = onClick ? 'button' : 'div';

  return (
    <Root
      type={onClick ? 'button' : undefined}
      onClick={onClick}
      className={cn(
        'card-flush relative flex w-full flex-col gap-2 p-3 text-left transition-[box-shadow,transform] duration-150',
        onClick && 'tap hover:shadow-[var(--shadow-border-hover)]',
        duplicateSlot ? 'ring-danger-1' : RING[status],
        silo.isOutOfService && 'opacity-70',
        className
      )}
    >
      {/* header: silo number, side, pull slot */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-baseline gap-2">
          <span className="num text-lg font-semibold leading-none">
            {silo.name || silo.siloNumber}
          </span>
          {silo.side ? <span className="eyebrow">{silo.side}</span> : null}
        </div>

        {silo.isOutOfService ? (
          <Wrench className="size-4 shrink-0 text-muted" />
        ) : silo.runOrder ? (
          <span
            className={cn(
              'num flex size-6 shrink-0 items-center justify-center rounded-full text-xs font-semibold',
              duplicateSlot
                ? 'bg-danger text-bg'
                : pinned
                  ? 'bg-locked text-bg'
                  : 'bg-accent text-accent-fg'
            )}
            title={pinned ? `Pinned to slot ${silo.runOrder}` : `Pull order ${silo.runOrder}`}
          >
            {silo.runOrder}
          </span>
        ) : null}
      </div>

      {/* the can */}
      <div className={cn('relative w-full', compact ? 'h-24' : 'h-40')}>
        {/* top hatch */}
        <div className="absolute inset-x-[18%] top-0 h-2 rounded-t-sm bg-panel" />
        {/* body */}
        <div className="absolute inset-x-[12%] bottom-0 top-2 overflow-hidden rounded-b-md rounded-t-sm bg-elevated shadow-[inset_0_0_0_1px_var(--color-border)]">
          <div
            className={cn(
              'absolute inset-x-0 bottom-0 transition-[height] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]',
              silo.isOutOfService ? 'bg-panel' : tone.fill
            )}
            style={{
              height: silo.isOutOfService ? '8%' : `${pct}%`,
              opacity: silo.isOutOfService ? 1 : 0.85,
            }}
          />
          {/* sight glasses */}
          <div className="absolute inset-x-0 top-1/4 border-t border-border/60" />
          <div className="absolute inset-x-0 top-2/4 border-t border-border/60" />
          <div className="absolute inset-x-0 top-3/4 border-t border-border/60" />

          <div className="absolute inset-0 flex items-center justify-center">
            <span className="num text-sm font-medium text-fg drop-shadow-[0_1px_2px_rgba(0,0,0,0.85)]">
              {silo.isNegative ? '—' : `${Math.round(pct)}%`}
            </span>
          </div>
        </div>

        {pinned && !silo.isOutOfService ? (
          <Lock className="absolute right-0 top-3 size-3 text-locked" />
        ) : null}
      </div>

      {/* readout */}
      <div className="min-w-0">
        <div className={cn('truncate text-xs font-medium', tone.text)}>
          {silo.sandType || <span className="text-subtle">No sand assigned</span>}
        </div>
        <div
          className={cn(
            'num mt-0.5 text-sm font-medium',
            silo.isNegative ? 'text-danger' : 'text-fg'
          )}
        >
          {formatLbs(silo.onHandLbs)}
        </div>
      </div>

      {!compact && (
        <>
          <div className="flex items-center justify-between text-[11px] text-muted">
            <span className="num">{silo.onHandTons.toFixed(1)} t</span>
            <span className="num">{silo.stagesLeft.toFixed(1)} stg</span>
          </div>

          {showPull && silo.plannedPullLbs > 0 ? (
            <div className="num rounded-sm bg-critical-dim px-2 py-1 text-xs font-semibold text-critical">
              Pull {formatLbs(silo.plannedPullLbs)}
            </div>
          ) : null}

          <div className={cn('flex items-center gap-1 text-[11px]', msg.cls)}>
            {(status === 'neg' || status === 'over') && (
              <AlertTriangle className="size-3 shrink-0" />
            )}
            <span className="truncate">{msg.text}</span>
          </div>
        </>
      )}
    </Root>
  );
}

export default Canister;

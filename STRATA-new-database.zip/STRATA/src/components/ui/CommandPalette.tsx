/**
 * Command palette — ⌘K / Ctrl-K.
 *
 * Two things in one surface, because they are the same intent: "get me to the
 * answer." Type a view name and you jump; type a question and Gemini answers it
 * against live pad state without leaving the screen you're on.
 *
 * The hint column doubles as hidden search keywords — typing "burn" finds
 * Forecast, "integrity" finds Diagnostics — so discovery costs nothing.
 */

import { useEffect, useMemo, useRef, useState } from 'react';
import { Search, CornerDownLeft, Sparkles, Loader2, X, ArrowUp, ArrowDown } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { AppState } from '../../types';
import { askThePad, SUGGESTED_QUESTIONS } from '../../lib/gemini';
import { cn } from '../../lib/theme';

export interface PaletteItem {
  id: string;
  label: string;
  hint: string;
  icon: LucideIcon;
  run: () => void;
}

interface Props {
  open: boolean;
  onClose: () => void;
  items: PaletteItem[];
  state: AppState | null;
  geminiAvailable: boolean;
}

/** A question, not a destination: has a space and either a ? or a question word. */
function looksLikeQuestion(q: string): boolean {
  const t = q.trim();
  if (t.length < 8) return false;
  if (t.includes('?')) return true;
  return /^(how|what|when|why|which|where|who|do|does|is|are|can|should|will|am|any)\b/i.test(t);
}

export function CommandPalette({ open, onClose, items, state, geminiAvailable }: Props) {
  const [query, setQuery] = useState('');
  const [cursor, setCursor] = useState(0);
  const [answer, setAnswer] = useState<string | null>(null);
  const [asking, setAsking] = useState(false);
  const [askError, setAskError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setQuery('');
      setCursor(0);
      setAnswer(null);
      setAskError(null);
      // Focus after paint so the dialog is mounted.
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [open]);

  const matches = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return items;
    return items.filter(
      (i) => i.label.toLowerCase().includes(q) || i.hint.toLowerCase().includes(q)
    );
  }, [items, query]);

  const canAsk = geminiAvailable && state && looksLikeQuestion(query);
  // The ask row sits at the top of the list when it's offered.
  const rowCount = matches.length + (canAsk ? 1 : 0);

  useEffect(() => {
    setCursor(0);
  }, [query]);

  async function ask(question: string) {
    if (!state) return;
    setAsking(true);
    setAnswer(null);
    setAskError(null);
    try {
      const res = await askThePad(state, question);
      setAnswer(res);
    } catch (err) {
      setAskError(err instanceof Error ? err.message : 'Could not reach the assistant.');
    } finally {
      setAsking(false);
    }
  }

  function activate(index: number) {
    if (canAsk && index === 0) {
      void ask(query.trim());
      return;
    }
    const item = matches[canAsk ? index - 1 : index];
    if (item) {
      item.run();
      onClose();
    }
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Escape') {
      e.preventDefault();
      onClose();
      return;
    }
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setCursor((c) => (rowCount ? (c + 1) % rowCount : 0));
      return;
    }
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      setCursor((c) => (rowCount ? (c - 1 + rowCount) % rowCount : 0));
      return;
    }
    if (e.key === 'Enter') {
      e.preventDefault();
      activate(cursor);
    }
  }

  // Keep the highlighted row in view when arrowing past the fold.
  useEffect(() => {
    const el = listRef.current?.querySelector<HTMLElement>('[data-cursor="true"]');
    el?.scrollIntoView({ block: 'nearest' });
  }, [cursor, matches.length]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-start justify-center bg-bg/80 p-4 pt-[12vh] backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-label="Command palette"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="card-flush w-full max-w-lg overflow-hidden">
        {/* search row */}
        <div className="flex items-center gap-3 px-4">
          <Search className="size-4 shrink-0 text-muted" />
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder={
              geminiAvailable ? 'Jump to a view, or ask about the pad…' : 'Jump to a view…'
            }
            className="h-12 flex-1 bg-transparent text-[15px] text-fg outline-none placeholder:text-subtle"
            aria-label="Search views or ask a question"
          />
          <button type="button" onClick={onClose} className="btn-ghost btn size-8 shrink-0 !px-0">
            <X className="size-4" />
          </button>
        </div>

        <div className="divider" />

        {/* answer */}
        {(asking || answer || askError) && (
          <div className="border-b border-border bg-elevated/60 px-4 py-3">
            {asking ? (
              <div className="flex items-center gap-2 text-sm text-muted">
                <Loader2 className="size-4 animate-spin" />
                Reading the pad…
              </div>
            ) : askError ? (
              <div className="text-sm text-danger">{askError}</div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-accent">
                  <Sparkles className="size-3.5" />
                  <span className="eyebrow !text-accent">Answer</span>
                </div>
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-fg">{answer}</p>
                <p className="text-[11px] text-subtle">
                  Computed from live pad state. Verify anything you act on against the pull sheet.
                </p>
              </div>
            )}
          </div>
        )}

        {/* results */}
        <div ref={listRef} className="max-h-80 overflow-auto p-2">
          {canAsk && (
            <button
              type="button"
              data-cursor={cursor === 0}
              onMouseEnter={() => setCursor(0)}
              onClick={() => activate(0)}
              className={cn(
                'flex h-12 w-full items-center gap-3 rounded-sm px-3 text-left text-sm',
                cursor === 0 ? 'bg-elevated' : 'hover:bg-elevated/60'
              )}
            >
              <Sparkles className="size-4 shrink-0 text-accent" />
              <span className="min-w-0 flex-1 truncate text-accent">Ask: “{query.trim()}”</span>
              <CornerDownLeft className="size-3.5 shrink-0 text-subtle" />
            </button>
          )}

          {matches.map((item, i) => {
            const index = canAsk ? i + 1 : i;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                data-cursor={cursor === index}
                onMouseEnter={() => setCursor(index)}
                onClick={() => activate(index)}
                className={cn(
                  'flex h-12 w-full items-center gap-3 rounded-sm px-3 text-left text-sm',
                  cursor === index ? 'bg-elevated' : 'hover:bg-elevated/60'
                )}
              >
                <Icon className="size-4 shrink-0 text-muted" />
                <span className="min-w-0 flex-1 truncate">{item.label}</span>
                <span className="shrink-0 text-xs text-subtle">{item.hint}</span>
              </button>
            );
          })}

          {!matches.length && !canAsk && (
            <div className="px-4 py-8 text-center text-sm text-muted">
              {geminiAvailable ? (
                <>No matching view. End with a question mark to ask the assistant instead.</>
              ) : looksLikeQuestion(query) ? (
                <>
                  That looks like a question, but the assistant is not configured on this
                  deployment. Add <span className="num text-fg">GEMINI_API_KEY</span> in the AI
                  Studio Secrets panel to enable it. Every figure it would quote is on the Forecast
                  and Command screens already.
                </>
              ) : (
                <>No matching view.</>
              )}
            </div>
          )}

          {/* starter questions, only on an empty box */}
          {geminiAvailable && state && !query.trim() && !answer && !asking && (
            <div className="mt-2 border-t border-border pt-2">
              <div className="eyebrow px-3 pb-1.5">Ask the pad</div>
              {SUGGESTED_QUESTIONS.slice(0, 4).map((q) => (
                <button
                  key={q}
                  type="button"
                  onClick={() => {
                    setQuery(q);
                    void ask(q);
                  }}
                  className="flex w-full items-center gap-3 rounded-sm px-3 py-2 text-left text-sm text-muted hover:bg-elevated/60 hover:text-fg"
                >
                  <Sparkles className="size-3.5 shrink-0 text-subtle" />
                  <span className="min-w-0 flex-1 truncate">{q}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="divider" />
        <div className="flex items-center gap-4 px-4 py-2 text-[11px] text-subtle">
          <span className="flex items-center gap-1">
            <ArrowUp className="size-3" />
            <ArrowDown className="size-3" />
            navigate
          </span>
          <span className="flex items-center gap-1">
            <CornerDownLeft className="size-3" />
            select
          </span>
          <span>esc close</span>
        </div>
      </div>
    </div>
  );
}

export default CommandPalette;

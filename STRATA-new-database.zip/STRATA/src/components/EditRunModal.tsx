/**
 * Edit one stage run record.
 *
 * A run is the only thing that takes sand OUT of a can, so every field here
 * moves a balance. The projected impact block replays the ledger with the edit
 * applied and shows both the silo the run is leaving and the one it lands on.
 */

import { AlertTriangle, ArrowRight, Check, X } from 'lucide-react';
import { FormEvent, useMemo, useState } from 'react';
import { formatLbs, formatTons, getSiloDerivedStates } from '../lib/sandRules';
import { getOperationalDate } from '../lib/dateUtils';
import { cn, sandClasses } from '../lib/theme';
import { AppState, RunRecord } from '../types';

interface EditRunModalProps {
  state: AppState;
  run: RunRecord;
  onSave: (updates: Partial<Omit<RunRecord, 'id' | 'createdAt'>>) => Promise<void>;
  onClose: () => void;
}

export default function EditRunModal({ state, run, onSave, onClose }: EditRunModalProps) {
  const [wellId, setWellId] = useState<string>(run.wellId || state.config.wells[0]?.id || 'w-1');
  const [stageNumber, setStageNumber] = useState<number>(run.stageNumber || 1);
  const [siloNumber, setSiloNumber] = useState<number>(run.siloNumber || 1);
  const [sandType, setSandType] = useState<string>(
    run.sandType || state.config.sandTypes[0]?.name || '100 Mesh'
  );
  const [lbsPulled, setLbsPulled] = useState<string>(
    run.lbsPulled ? run.lbsPulled.toString() : ''
  );
  const [date, setDate] = useState<string>(run.date || getOperationalDate());

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const lbsPerTon = state.config.lbsPerTon || 2000;
  const newLbsPulled = parseInt(lbsPulled, 10) || 0;

  /* Two full ledger replays, keyed on the fields that move sand. */
  const siloChanges = useMemo(() => {
    const currentSiloDerivedStates = getSiloDerivedStates(state);
    const simulatedState: AppState = {
      ...state,
      runs: state.runs.map((r) =>
        r.id === run.id
          ? { ...r, wellId, stageNumber, siloNumber, sandType, lbsPulled: newLbsPulled, date }
          : r
      ),
    };
    const projectedSiloDerivedStates = getSiloDerivedStates(simulatedState);

    const affected = Array.from(new Set([run.siloNumber, siloNumber])).sort((a, b) => a - b);
    return affected.map((sNum) => {
      const beforeObj = currentSiloDerivedStates.find((s) => s.siloNumber === sNum);
      const afterObj = projectedSiloDerivedStates.find((s) => s.siloNumber === sNum);
      const beforeLbs = beforeObj?.onHandLbs || 0;
      const afterLbs = afterObj?.onHandLbs || 0;
      return {
        siloNumber: sNum,
        siloName: beforeObj?.name || `Silo ${sNum}`,
        sandType: beforeObj?.sandType || null,
        beforeLbs,
        afterLbs,
        diff: afterLbs - beforeLbs,
      };
    });
  }, [state, run.id, run.siloNumber, wellId, stageNumber, siloNumber, sandType, newLbsPulled, date]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setSubmitError(null);
    const errs: Record<string, string> = {};

    const numericLbs = parseInt(lbsPulled, 10);
    if (isNaN(numericLbs) || numericLbs < 0) {
      errs.lbsPulled = 'Valid weight pulled in lbs is required';
    }

    if (!stageNumber || stageNumber <= 0) {
      errs.stageNumber = 'Valid stage number is required';
    }

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }

    setIsSubmitting(true);

    try {
      await onSave({
        wellId,
        stageNumber,
        siloNumber,
        sandType,
        lbsPulled: numericLbs,
        date,
      });
      onClose();
    } catch (err: any) {
      console.error('Failed to update stage run:', err);
      setSubmitError(err?.message || 'Failed to update stage run');
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="edit-run-title"
    >
      <div className="card my-auto max-h-[92vh] w-full max-w-xl overflow-y-auto rounded-xl p-5">
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow">Stage run record</div>
            <h2 id="edit-run-title" className="text-xl font-medium tracking-tight">
              Edit run — silo <span className="num">#{run.siloNumber}</span>
            </h2>
            <p className="text-sm text-muted">
              Changing the silo, weight or sand type re-bases on-hand on both cans involved.
            </p>
          </div>
          <button type="button" onClick={onClose} className="btn btn-ghost tap shrink-0 px-2" aria-label="Close">
            <X className="size-5" />
          </button>
        </div>

        {submitError && (
          <div className="mb-4 flex items-start gap-2 rounded-sm bg-danger-dim p-3 text-sm text-danger">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            <span>{submitError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-4">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="eyebrow">Well</span>
              <select
                value={wellId}
                onChange={(e) => setWellId(e.target.value)}
                className="select mt-1"
              >
                {state.config.wells.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="eyebrow">Stage number</span>
              <input
                type="number"
                inputMode="numeric"
                value={stageNumber}
                onChange={(e) => {
                  setStageNumber(parseInt(e.target.value, 10) || 1);
                  setErrors((prev) => ({ ...prev, stageNumber: '' }));
                }}
                className={cn('input input-num mt-1', errors.stageNumber && 'ring-danger-1')}
              />
              {errors.stageNumber && (
                <span className="mt-1 block text-xs text-danger">{errors.stageNumber}</span>
              )}
            </label>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="eyebrow">Pulled from silo</span>
              <select
                value={siloNumber}
                onChange={(e) => setSiloNumber(parseInt(e.target.value, 10))}
                className="select num mt-1"
              >
                {!state.config.silos.some((s) => s.siloNumber === siloNumber) && (
                  <option value={siloNumber}>
                    Silo #{siloNumber} — not in current pad config
                  </option>
                )}
                {state.config.silos.map((s) => (
                  <option key={s.siloNumber} value={s.siloNumber}>
                    Silo #{s.siloNumber}
                    {s.name ? ` (${s.name})` : ''} — {s.sandType || 'Empty'}
                  </option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="eyebrow">Sand pulled (lbs)</span>
              <input
                type="number"
                inputMode="numeric"
                value={lbsPulled}
                onChange={(e) => {
                  setLbsPulled(e.target.value);
                  setErrors((prev) => ({ ...prev, lbsPulled: '' }));
                }}
                placeholder="120000"
                className={cn('input input-num mt-1', errors.lbsPulled && 'ring-danger-1')}
              />
              <span className="mt-1 block text-xs text-muted">
                <span className="num">{formatTons(newLbsPulled / lbsPerTon)}</span>
              </span>
              {errors.lbsPulled && (
                <span className="mt-1 block text-xs text-danger">{errors.lbsPulled}</span>
              )}
            </label>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <label className="block">
              <span className="eyebrow">Sand type</span>
              <select
                value={sandType}
                onChange={(e) => setSandType(e.target.value)}
                className="select mt-1"
              >
                {state.config.sandTypes.map((st) => (
                  <option key={st.id} value={st.name}>
                    {st.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="block">
              <span className="eyebrow">Run date</span>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="input num mt-1"
              />
            </label>
          </div>

          {/* ------------------------------ projected balance impact --- */}
          <div className="rounded-md bg-elevated p-3 ring-accent-1">
            <div className="flex items-center justify-between gap-2">
              <span className="eyebrow text-accent">Projected silo balance impact</span>
              <span className="eyebrow">On-hand adjustment</span>
            </div>

            <div className="mt-2 flex flex-col gap-2">
              {siloChanges.map((sc) => {
                const tone = sandClasses(sc.sandType, state.config.sandTypes);
                return (
                  <div
                    key={sc.siloNumber}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-sm bg-surface px-3 py-2"
                  >
                    <div className="flex min-w-0 items-center gap-2">
                      <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                      <span className="truncate text-sm font-medium">
                        Silo <span className="num">#{sc.siloNumber}</span>
                      </span>
                      <span className="truncate text-xs text-muted">{sc.siloName}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="num text-sm text-muted">{formatLbs(sc.beforeLbs)}</span>
                      <ArrowRight className="size-4 shrink-0 text-muted" />
                      <span
                        className={cn(
                          'num text-sm font-semibold',
                          sc.afterLbs < 0 ? 'text-danger' : 'text-fg'
                        )}
                      >
                        {formatLbs(sc.afterLbs)}
                      </span>
                      {sc.diff !== 0 && (
                        <span className={cn('badge', sc.diff > 0 ? 'badge-ok' : 'badge-warn')}>
                          <span className="num">
                            {sc.diff > 0 ? `+${formatLbs(sc.diff)}` : formatLbs(sc.diff)}
                          </span>
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="mt-1 flex items-center justify-end gap-2">
            <button type="button" onClick={onClose} disabled={isSubmitting} className="btn tap">
              Cancel
            </button>
            <button type="submit" disabled={isSubmitting} className="btn btn-accent tap">
              <Check className="size-4" />
              {isSubmitting ? 'Saving' : 'Save run changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

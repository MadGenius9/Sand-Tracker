import { initializeApp, getApps, getApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';
import { getAuth, signInAnonymously, onAuthStateChanged, User } from 'firebase/auth';
import config from '../../firebase-applet-config.json';

/**
 * True when firebase-applet-config.json still holds the shipped placeholders.
 *
 * This app is deliberately checked in WITHOUT live credentials so that an
 * import, a fork or a fresh clone cannot silently attach itself to a running
 * job's database and start writing tickets into it. Point it at a database on
 * purpose or it points nowhere.
 */
export const isFirebaseConfigured = !String(config.projectId).startsWith('REPLACE_WITH_');

const UNCONFIGURED_MESSAGE =
  'No database is connected yet — fill in firebase-applet-config.json with the new Firebase project details.';

const firebaseConfig = {
  apiKey: config.apiKey,
  authDomain: config.authDomain,
  projectId: config.projectId,
  storageBucket: config.storageBucket,
  messagingSenderId: config.messagingSenderId,
  appId: config.appId,
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export const db =
  config.firestoreDatabaseId && config.firestoreDatabaseId !== '(default)'
    ? getFirestore(app, config.firestoreDatabaseId)
    : getFirestore(app);

/**
 * Cloud Storage. Ticket photos live here, never in the Firestore document —
 * a phone JPEG is 2-5 MB and Firestore's hard document ceiling is 1 MiB, so a
 * base64 photo in `delivery.photoUrl` takes the whole ticket down with it.
 */
export const storage = getStorage(app);

export const auth = getAuth(app);

export let authError: string | null = null;
type ErrorCallback = (err: string | null) => void;
let errorListeners: ErrorCallback[] = [];

export function onFirebaseError(cb: ErrorCallback) {
  errorListeners.push(cb);
  if (authError) cb(authError);
  return () => {
    errorListeners = errorListeners.filter((l) => l !== cb);
  };
}

export function triggerFirebaseError(msg: string) {
  authError = msg;
  errorListeners.forEach((l) => l(msg));
}

let authReadyPromise: Promise<User | null> | null = null;

/**
 * Returns a cached Promise that resolves when Firebase Auth has initialized
 * and an authenticated user (or anonymous session) is ready.
 * If authentication fails, the promise rejects and the cache is cleared so retry can proceed.
 */
export function waitForFirebaseAuth(timeoutMs = 15000): Promise<User | null> {
  if (authReadyPromise) return authReadyPromise;

  // Fail immediately rather than waiting out the 15s gate on credentials that
  // were never going to resolve.
  if (!isFirebaseConfigured) {
    triggerFirebaseError(UNCONFIGURED_MESSAGE);
    return Promise.reject(new Error(UNCONFIGURED_MESSAGE));
  }

  authReadyPromise = new Promise<User | null>((resolve, reject) => {
    if (auth.currentUser) {
      resolve(auth.currentUser);
      return;
    }

    let isSettled = false;
    const timer = setTimeout(() => {
      if (!isSettled) {
        console.warn('[AUTH GATE] Auth state did not resolve within timeout window.');
      }
    }, timeoutMs);

    const unsubscribe = onAuthStateChanged(
      auth,
      async (user) => {
        if (user) {
          isSettled = true;
          clearTimeout(timer);
          unsubscribe();
          resolve(user);
          return;
        }

        // If no authenticated user, initiate anonymous sign in
        try {
          const cred = await signInAnonymously(auth);
          isSettled = true;
          clearTimeout(timer);
          unsubscribe();
          resolve(cred.user);
        } catch (err: any) {
          isSettled = true;
          clearTimeout(timer);
          unsubscribe();
          authReadyPromise = null; // Clear so subsequent call can retry
          console.error('[AUTH GATE] Anonymous sign-in failed:', err);
          reject(err);
        }
      },
      (err) => {
        isSettled = true;
        clearTimeout(timer);
        unsubscribe();
        authReadyPromise = null;
        console.error('[AUTH GATE] onAuthStateChanged error:', err);
        reject(err);
      }
    );
  });

  return authReadyPromise;
}

export function resetAuthReadyPromise() {
  authReadyPromise = null;
}

# STRATA style guide

The design system lives in `src/index.css`. Read it before touching a component.
Nothing in this app declares a raw color. If you need one that isn't here, it's
a design bug — say so rather than inventing a hex.

## Palette (Tailwind utilities, generated from `@theme`)

| Token | Utility | Use |
|---|---|---|
| `--color-bg` `#0b0c0a` | `bg-bg` | Page ground |
| `--color-surface` `#141512` | `bg-surface` | Cards |
| `--color-elevated` `#1c1e19` | `bg-elevated` | Inputs, chips, hover |
| `--color-panel` `#22251f` | `bg-panel` | Silo cap, active tab |
| `--color-fg` `#e8e6df` | `text-fg` | Primary text |
| `--color-muted` `#9a9a8e` | `text-muted` | Secondary text, labels |
| `--color-subtle` `#6e6e64` | `text-subtle` | Placeholders, empty cells |
| `--color-accent` `#8fb9a8` | `bg-accent` `text-accent` | Primary action, pull order |
| `--color-accent-dim` | `bg-accent-dim` | Accent chip ground |
| `--color-ok` / `-dim` | `text-ok` `bg-ok-dim` | Healthy |
| `--color-warn` / `-dim` | `text-warn` `bg-warn-dim` | Low, over capacity, cross-check |
| `--color-danger` / `-dim` | `text-danger` `bg-danger-dim` | Shortfall, negative, duplicate |
| `--color-critical` / `-dim` | `text-critical` `bg-critical-dim` | **The number a crew acts on**: PULL LBS, shortage amount |
| `--color-locked` / `-dim` | `text-locked` `bg-locked-dim` | Manual run-order override. Never a warning. |

`critical` and `locked` are scarce on purpose. If everything is critical,
nothing is. A screen should have at most one or two critical elements.

## Borders are shadows

There is no `border` on any card. Use `ring-border` (the `--shadow-border`
utility) — a 0-blur 1px box-shadow. Status is a swap of the same property:
`ring-accent-1` `ring-warn-1` `ring-danger-1` `ring-critical-1` `ring-locked-1`.
No layout impact, animates cleanly.

## Component classes (in `index.css`, use these instead of utility soup)

`card` · `card-flush` · `card-hd` · `eyebrow` · `num` · `stat-v` ·
`btn` `btn-accent` `btn-critical` `btn-danger` `btn-ghost` `btn-lg` `btn-xl` ·
`input` `input-lg` `input-num` · `select` ·
`badge` `badge-accent` `badge-ok` `badge-warn` `badge-danger` `badge-critical` `badge-locked` ·
`tbl` (with `td.n` / `th.n` for numeric columns) · `meter` · `divider` ·
`no-scrollbar` · `tap`

## Typography — the one absolute rule

**Every quantity is `font-mono` and tabular. Every label is sans.**
Use the `num` class (it sets both). Columns must never jitter.

Weight tops out at `font-medium` (500) for headings; `font-semibold` only on
badges and numerals. **Never `font-black`** — the old build shouted everything
and so nothing stood out.

Micro-label style is the `eyebrow` class: 11px, uppercase, `tracking-wider`,
`text-muted`. Use it for eyebrows, KPI labels, table headers, side headers.

## Every view header is the same triad

```tsx
<div>
  <div className="eyebrow">Silo board</div>
  <h1 className="text-2xl font-medium tracking-tight">{padName}</h1>
  <p className="text-sm text-muted">Emptiest first · Next up: Well A stage 41</p>
</div>
```

The subtitle **discloses the model**. Say how a number was computed:
"Burn uses the last seven pumping days." "Cross-check flags at >2% drift."
That one line replaces a legend, a tooltip and a help doc.

## Layout conventions

- Page wrapper: `mx-auto flex w-full flex-col gap-5` + `max-w-6xl` (dense data),
  `max-w-3xl` (forms), `max-w-5xl` (logs).
- Card padding `p-4`, radius via the `card` class. Grid gaps `gap-3`,
  section gaps `gap-5`.
- KPI pattern: label (eyebrow) / value (`stat-v`) / hint (`text-xs text-muted`).
  **Every number ships a second unit** — tons *and* lbs, stages *and* loads. A
  coordinator should never convert in their head.

## Touch targets

This runs on a tablet on a frac pad. Gloves, glare, one hand.
Buttons `btn` (44px) minimum, `btn-lg` (52px) for primary actions,
`btn-xl` (64px) for the scan/save button in kiosk flows. Inputs 44px+.
`inputMode="numeric"` on every weight and ticket field.

## Motion

One signature: `duration-150 ease-[cubic-bezier(0.22,1,0.36,1)]` for controls,
500ms for the canister fill. `tap` class (`active:scale-[0.98]`) on buttons.
Nothing else animates. No bounce, no pulse except a genuine live alert.

## Sand colors

**Never** map a sand name to a color inline. Always:

```ts
import { sandClasses, cn } from '../lib/theme';
const tone = sandClasses(sandTypeName, config.sandTypes);
// tone.fill  tone.text  tone.dim  tone.ring  tone.cssVar  tone.printHex
```

The old build did this in three files with three different rules and 40/70
rendered blue on one screen and emerald on another. That is a safety bug on a
pull sheet.

## Print

`src/index.css` owns all print CSS. Do not add `@media print` or an inline
`<style>` to a component. Use the existing hooks: `no-print`, `print-only`,
`screen-only`, `page-break-inside-avoid`, `summary-strip`, `print-allow`
(on an input or button that must survive printing), `stage-pull-sheet`.

## Don't

- No `alert()` / `confirm()`. Use the toast and modal systems.
- No `localStorage` for anything Firestore owns.
- No new print stylesheets.
- No recomputing a figure that `sandRules.ts` or `analytics.ts` already exposes.
- No emoji in UI copy.
- No `border-4`, `rounded-3xl`, `shadow-2xl` — that was the old visual language.

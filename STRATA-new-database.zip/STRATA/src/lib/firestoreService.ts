import {
  collection,
  doc,
  getDoc,
  getDocs,
  getCountFromServer,
  onSnapshot,
  setDoc,
  deleteDoc,
  updateDoc,
  writeBatch,
  runTransaction,
} from 'firebase/firestore';
import { db, triggerFirebaseError } from './firebase';
import {
  AppState,
  DeliveryTicket,
  PadConfig,
  RunRecord,
  SiloConfig,
  OfflineQueueItem,
  SandTypeSpec,
  WellConfig,
} from '../types';
import {
  enqueueOfflineAction,
  isOnline,
  clearOfflineQueue,
  registerQueueExecutor,
  recordPermanentFailure,
} from './offlineQueue';
import { normalizeTicketNumber } from './ticketUtils';
import {
  uploadTicketPhoto,
  downscaleTicketPhotoToDataUrl,
  isDataUrl,
  isStoredPhotoUrl,
  TicketPhotoSource,
} from './photoService';

/* ------------------------------------------------------------- warnings --- */

/**
 * Non-fatal problems the data layer needs a human to know about — chiefly a
 * ticket photo that could not be uploaded. These are NOT errors: the write
 * they belong to succeeded, and the operation must not be rolled back for
 * them. `triggerFirebaseError` is the connection banner and is the wrong
 * channel; this is its own, quieter one.
 */
type ServiceWarningListener = (message: string) => void;
const warningListeners = new Set<ServiceWarningListener>();

export function onServiceWarning(cb: ServiceWarningListener): () => void {
  warningListeners.add(cb);
  return () => {
    warningListeners.delete(cb);
  };
}

export function emitServiceWarning(message: string) {
  console.warn('[STRATA]', message);
  warningListeners.forEach((cb) => {
    try {
      cb(message);
    } catch (e) {
      console.error('Error in service warning listener:', e);
    }
  });
}

/** Marks an error the offline queue must never retry. */
function permanentError(message: string): Error & { permanent: true } {
  const err = new Error(message) as Error & { permanent: true };
  err.permanent = true;
  return err;
}

/**
 * Asserts that a pad is writable (not tombstoned and pad document exists).
 * Rejects writes early before corrupting Firestore.
 */
export async function assertPadWritable(padId: string): Promise<void> {
  if (!padId) {
    throw new Error('No pad ID specified for write operation.');
  }

  // 1. Check if tombstone exists
  const tombstoneDoc = await getDoc(doc(db, 'deletedPads', padId));
  if (tombstoneDoc.exists()) {
    throw new Error(`Cannot modify well pad: Well pad "${padId}" has been deleted.`);
  }

  // 2. Check if pad document exists
  const padDocRef = doc(db, 'pads', padId);
  const padSnap = await getDoc(padDocRef);
  if (!padSnap.exists()) {
    throw new Error(`Cannot modify well pad: Well pad "${padId}" does not exist.`);
  }
}

export const blankPadConfig: PadConfig = {
  customerName: '',
  padName: '',
  siloCount: 6,
  lbsPerTruckload: 55000,
  lbsPerTon: 2000,
  drawStrategy: 'sequential_rotation',
  partialThresholdPct: 0.75,
  reorderThresholdStages: 5,
  suppliers: [],
  wells: [],
  sandTypes: [],
  silos: [
    { siloNumber: 1, side: 'A', sandType: null, manualPriority: null, maxCapacityLbs: 390000, startingBalanceLbs: 0, isOutOfService: false },
    { siloNumber: 2, side: 'B', sandType: null, manualPriority: null, maxCapacityLbs: 390000, startingBalanceLbs: 0, isOutOfService: false },
    { siloNumber: 3, side: 'A', sandType: null, manualPriority: null, maxCapacityLbs: 390000, startingBalanceLbs: 0, isOutOfService: false },
    { siloNumber: 4, side: 'B', sandType: null, manualPriority: null, maxCapacityLbs: 390000, startingBalanceLbs: 0, isOutOfService: false },
    { siloNumber: 5, side: 'A', sandType: null, manualPriority: null, maxCapacityLbs: 390000, startingBalanceLbs: 0, isOutOfService: false },
    { siloNumber: 6, side: 'B', sandType: null, manualPriority: null, maxCapacityLbs: 390000, startingBalanceLbs: 0, isOutOfService: false },
  ],
  productCodeMappings: [],
  clearManualPriorityAfterStage: true,
  autoAdvanceWellStage: true,
};

export function subscribeToPad(
  padId: string,
  onStateUpdate: (state: AppState) => void,
  onError?: (err: Error) => void
) {
  console.log('[PAD SUBSCRIBE]', padId);
  const padDocRef = doc(db, 'pads', padId);
  const deliveriesColRef = collection(db, 'pads', padId, 'deliveries');
  const runsColRef = collection(db, 'pads', padId, 'runs');

  let currentConfig: PadConfig | null = null;
  let currentDeliveries: DeliveryTicket[] = [];
  let currentDeletedDeliveries: DeliveryTicket[] = [];
  let currentRuns: RunRecord[] = [];
  let currentDeletedRuns: RunRecord[] = [];
  let padFound = false;

  const publish = () => {
    if (!padFound || !currentConfig) return;
    onStateUpdate({
      status: 'ready',
      padId,
      config: currentConfig,
      deliveries: currentDeliveries,
      runs: currentRuns,
      deletedDeliveries: currentDeletedDeliveries,
      deletedRuns: currentDeletedRuns,
    });
  };

  // 1. Subscribe to Pad Config document
  const unsubPad = onSnapshot(
    padDocRef,
    (snapshot) => {
      if (snapshot.exists()) {
        padFound = true;
        const data = snapshot.data();
        currentConfig = data.config || data;
        publish();
      } else {
        padFound = false;
        console.log('[PAD NOT FOUND]', padId);
        onStateUpdate({
          status: 'not_found',
          padId,
          config: blankPadConfig,
          deliveries: [],
          runs: [],
          deletedDeliveries: [],
          deletedRuns: [],
        });
      }
    },
    (err) => {
      console.error('Firestore pad subscription error:', err);
      triggerFirebaseError("Can't reach the database — check that Anonymous sign-in is enabled in Firebase.");
      if (onError) onError(err);
    }
  );

  // 2. Subscribe to Deliveries subcollection
  const unsubDeliveries = onSnapshot(
    deliveriesColRef,
    (snapshot) => {
      const items: DeliveryTicket[] = [];
      snapshot.forEach((d) => {
        items.push({ id: d.id, ...d.data() } as DeliveryTicket);
      });
      items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

      currentDeliveries = items.filter((d) => !d.deleted);
      currentDeletedDeliveries = items
        .filter((d) => d.deleted)
        .sort((a, b) => (b.deletedAt || 0) - (a.deletedAt || 0));
      publish();
    },
    (err) => {
      console.error('Firestore deliveries subscription error:', err);
      triggerFirebaseError("Can't reach the database — check that Anonymous sign-in is enabled in Firebase.");
    }
  );

  // 3. Subscribe to Runs subcollection
  const unsubRuns = onSnapshot(
    runsColRef,
    (snapshot) => {
      const items: RunRecord[] = [];
      snapshot.forEach((r) => {
        items.push({ id: r.id, ...r.data() } as RunRecord);
      });
      items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

      currentRuns = items.filter((r) => !r.deleted);
      currentDeletedRuns = items
        .filter((r) => r.deleted)
        .sort((a, b) => (b.deletedAt || 0) - (a.deletedAt || 0));
      publish();
    },
    (err) => {
      console.error('Firestore runs subscription error:', err);
      triggerFirebaseError("Can't reach the database — check that Anonymous sign-in is enabled in Firebase.");
    }
  );

  return () => {
    console.log('[PAD UNSUBSCRIBE]', padId);
    unsubPad();
    unsubDeliveries();
    unsubRuns();
  };
}

export async function createPad(padId: string, config: PadConfig): Promise<void> {
  const cleanConfig = Object.fromEntries(
    Object.entries(config).filter(([, v]) => v !== undefined)
  ) as PadConfig;

  // Keep a local copy for recovery
  backupPadConfigLocally(padId, cleanConfig);

  // Clear any tombstone if re-creating / creating intentionally
  try {
    await deleteDoc(doc(db, 'deletedPads', padId));
  } catch (_) {}

  if (!isOnline()) {
    enqueueOfflineAction(padId, 'CREATE_PAD', { config: cleanConfig });
    return;
  }

  try {
    const padDocRef = doc(db, 'pads', padId);
    await setDoc(padDocRef, {
      config: cleanConfig,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    });
  } catch (err: any) {
    console.warn('createPad failed, falling back to offline queue:', err);
    enqueueOfflineAction(padId, 'CREATE_PAD', { config: cleanConfig });
  }
}

export async function savePadConfig(padId: string, newConfig: PadConfig): Promise<void> {
  const cleanConfig = Object.fromEntries(
    Object.entries(newConfig).filter(([, v]) => v !== undefined)
  ) as PadConfig;

  // Always keep a local copy for recovery
  backupPadConfigLocally(padId, cleanConfig);

  if (!isOnline()) {
    enqueueOfflineAction(padId, 'SAVE_PAD_CONFIG', { config: cleanConfig });
    return;
  }

  // 1. Check if the pad was deleted (tombstone check)
  const tombstoneDoc = await getDoc(doc(db, 'deletedPads', padId));
  if (tombstoneDoc.exists()) {
    throw new Error(`Cannot update configuration: Well pad "${padId}" has been deleted.`);
  }

  // 2. Check if the pad document exists (cannot create missing pad via normal update)
  const padDocRef = doc(db, 'pads', padId);
  const padSnap = await getDoc(padDocRef);
  if (!padSnap.exists()) {
    throw new Error(`Cannot update configuration: Well pad "${padId}" does not exist.`);
  }

  try {
    await updateDoc(padDocRef, {
      config: cleanConfig,
      updatedAt: Date.now(),
    });
  } catch (err: any) {
    console.warn('savePadConfig failed, falling back to offline queue:', err);
    enqueueOfflineAction(padId, 'SAVE_PAD_CONFIG', { config: cleanConfig });
  }
}

export function backupPadConfigLocally(padId: string, config: PadConfig) {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      localStorage.setItem(`sandtracker_pad_config_backup_${padId}`, JSON.stringify(config));
      // Also track known configs
      const raw = localStorage.getItem('sandtracker_known_pad_backups');
      const map = raw ? JSON.parse(raw) : {};
      map[padId] = {
        name: config.padName,
        customer: config.customerName,
        savedAt: Date.now(),
        wells: config.wells?.map((w) => w.name) || [],
        sandTypes: config.sandTypes?.map((s) => s.name) || [],
        config,
      };
      localStorage.setItem('sandtracker_known_pad_backups', JSON.stringify(map));
    }
  } catch (e) {
    console.warn('Failed to backup pad config locally:', e);
  }
}

export function getLocalPadConfigBackup(padId: string): PadConfig | null {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem(`sandtracker_pad_config_backup_${padId}`);
      if (raw) return JSON.parse(raw) as PadConfig;
    }
  } catch (e) {
    console.warn('Failed to read local pad config backup:', e);
  }
  return null;
}

export function getAllLocalPadBackups(): Record<string, { name: string; customer?: string; savedAt: number; wells: string[]; sandTypes: string[]; config: PadConfig }> {
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const raw = localStorage.getItem('sandtracker_known_pad_backups');
      if (raw) return JSON.parse(raw);
    }
  } catch (e) {
    console.warn('Failed to read known pad backups:', e);
  }
  return {};
}

export function reconstructPadConfigFromHistory(state: AppState): PadConfig {
  const { config, deliveries, runs } = state;
  const allDeliveries = [...deliveries, ...(state.deletedDeliveries || [])];
  const allRuns = [...runs, ...(state.deletedRuns || [])];

  // 1. Detect all unique sand types from logged deliveries and runs
  const detectedSandNames = new Set<string>();
  allDeliveries.forEach((d) => {
    if (d.sandType && d.sandType.trim()) detectedSandNames.add(d.sandType.trim());
  });
  allRuns.forEach((r) => {
    if (r.sandType && r.sandType.trim()) detectedSandNames.add(r.sandType.trim());
  });

  const sandNameList = Array.from(detectedSandNames);
  const colorCategories: ('orange' | 'blue' | 'emerald' | 'amber' | 'slate')[] = [
    'orange',
    'blue',
    'emerald',
    'amber',
    'slate',
  ];

  const reconstructedSandTypes: SandTypeSpec[] = sandNameList.length > 0
    ? sandNameList.map((name, index) => {
        const existing = config.sandTypes.find((st) => st.name.toLowerCase() === name.toLowerCase());
        const color =
          existing?.colorCategory ||
          colorCategories[index % colorCategories.length];

        return {
          id: existing?.id || `st-rec-${index + 1}`,
          name,
          perStageDesignLbs: existing?.perStageDesignLbs || 150000,
          jobDesignTotalLbs: existing?.jobDesignTotalLbs || 10000000,
          colorCategory: color,
        };
      })
    : config.sandTypes;

  // 2. Detect silo assignments based on the most recent delivery or run for each silo
  const siloCount = Math.max(
    config.siloCount || 6,
    ...allDeliveries.map((d) => d.siloNumber || 1),
    ...allRuns.map((r) => r.siloNumber || 1)
  );

  const reconstructedSilos: SiloConfig[] = [];
  for (let i = 1; i <= siloCount; i++) {
    const existingSilo = config.silos.find((s) => s.siloNumber === i);
    // Find the latest delivery or run for this silo to determine actual sand type
    const siloDeliveries = allDeliveries
      .filter((d) => d.siloNumber === i && d.sandType)
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    const siloRuns = allRuns
      .filter((r) => r.siloNumber === i && r.sandType)
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    let assignedSand: string | null = null;
    if (siloDeliveries.length > 0) {
      assignedSand = siloDeliveries[0].sandType;
    } else if (siloRuns.length > 0) {
      assignedSand = siloRuns[0].sandType;
    } else {
      assignedSand = existingSilo?.sandType ?? null;
    }

    reconstructedSilos.push({
      siloNumber: i,
      side: existingSilo?.side || (i % 2 === 1 ? 'A' : 'B'),
      sandType: assignedSand,
      manualPriority: existingSilo?.manualPriority ?? null,
      maxCapacityLbs: existingSilo?.maxCapacityLbs || 350000,
      startingBalanceLbs: existingSilo?.startingBalanceLbs || 0,
      isOutOfService: existingSilo?.isOutOfService || false,
    });
  }

  // 3. Detect wells from run records
  const wellIdSet = new Set<string>();
  allRuns.forEach((r) => {
    if (r.wellId) wellIdSet.add(r.wellId);
  });

  const reconstructedWells: WellConfig[] = [];
  if (wellIdSet.size > 0) {
    Array.from(wellIdSet).forEach((wId, idx) => {
      const existingWell = config.wells.find((w) => w.id === wId);
      const wellRuns = allRuns.filter((r) => r.wellId === wId);
      const maxStage = Math.max(0, ...wellRuns.map((r) => r.stageNumber || 0));
      const plannedStages = Math.max(existingWell?.plannedStages || 40, maxStage + 5);

      reconstructedWells.push({
        id: wId,
        name: existingWell?.name || `Well ${idx + 1}`,
        customerName: existingWell?.customerName || config.customerName || 'Diamondback Energy',
        plannedStages,
        perStageDesignOverrides: existingWell?.perStageDesignOverrides,
      });
    });
  } else {
    reconstructedWells.push(...config.wells);
  }

  return {
    ...config,
    siloCount,
    sandTypes: reconstructedSandTypes,
    silos: reconstructedSilos,
    wells: reconstructedWells,
  };
}

export interface AddDeliveryOptions {
  supervisorOverride?: boolean;
  overrideReason?: string;
}

export type AddDeliveryResult = DeliveryTicket & {
  pendingSync?: boolean;
  /** Set when the ticket saved but its photo did not. Never fatal. */
  photoWarning?: string;
};

/**
 * Splits a photo off a ticket before it is written.
 *
 * `AddDelivery` hands us `photoUrl` as a `data:image/jpeg;base64,...` string
 * from a FileReader. Writing that into the document is what used to kill the
 * whole ticket — 2-5 MB against a 1 MiB document ceiling — and because the
 * failure fell through to the offline queue, the ticket then failed forever
 * until the 5-retry drop, with the operator told nothing.
 *
 * So the data URL never reaches Firestore. It is held here, the ticket is
 * written with `photoUrl: null`, and the photo is uploaded to Storage and
 * patched in afterwards.
 */
function detachPhoto<T extends { photoUrl?: string | null }>(
  ticket: T
): { record: T; photoSource: TicketPhotoSource | null } {
  const raw = ticket.photoUrl;
  if (isDataUrl(raw)) {
    return { record: { ...ticket, photoUrl: null }, photoSource: raw };
  }
  if (raw && !isStoredPhotoUrl(raw)) {
    // Not a data URL and not something the rules will accept (over 2048 chars).
    emitServiceWarning('The ticket photo reference was too long to store and was dropped.');
    return { record: { ...ticket, photoUrl: null }, photoSource: null };
  }
  return { record: ticket, photoSource: null };
}

/**
 * Upload a detached photo and patch the saved ticket with its URL.
 *
 * Returns a warning string instead of throwing: at this point the DELIVERY IS
 * ALREADY SAVED, and losing a whole load of sand from the ledger because a
 * camera photo would not upload is never the right trade.
 */
async function attachTicketPhoto(
  padId: string,
  deliveryId: string,
  photoSource: TicketPhotoSource
): Promise<{ photoUrl: string | null; warning?: string }> {
  try {
    const url = await uploadTicketPhoto(padId, deliveryId, photoSource);
    await updateDoc(doc(db, 'pads', padId, 'deliveries', deliveryId), { photoUrl: url });
    return { photoUrl: url };
  } catch (err: any) {
    const warning = `Ticket saved, but its photo could not be uploaded (${
      err?.message || 'unknown error'
    }). The ticket itself is safe — re-attach the photo from Logs → Edit.`;
    emitServiceWarning(warning);
    return { photoUrl: null, warning };
  }
}

/** Beyond this, a queued photo is a threat to the whole localStorage queue. */
const MAX_QUEUED_PHOTO_CHARS = 1_500_000;

/**
 * Shrink a photo down to something safe to park in localStorage until the
 * connection returns. Returns null — with a warning — rather than risking the
 * queue: a lost photo is an inconvenience, a blown localStorage quota loses
 * every unsynced ticket on the tablet.
 */
async function prepareQueuedPhoto(source: TicketPhotoSource | null): Promise<string | null> {
  if (!source) return null;
  try {
    const dataUrl = await downscaleTicketPhotoToDataUrl(source);
    if (dataUrl.length > MAX_QUEUED_PHOTO_CHARS) {
      emitServiceWarning(
        'The ticket is queued, but its photo is too large to hold offline and was dropped. Re-attach it from Logs → Edit once you have signal.'
      );
      return null;
    }
    return dataUrl;
  } catch (err: any) {
    emitServiceWarning(
      `The ticket is queued, but its photo could not be prepared for offline storage (${
        err?.message || 'unknown error'
      }).`
    );
    return null;
  }
}

/**
 * The one authoritative delivery write.
 *
 * Both the online path and the offline-queue replay go through here, so a
 * ticket entered with no signal gets exactly the same duplicate protection
 * and the same `ticketNumbers` index entry as one entered online. Previously
 * the queue executor did a bare `setDoc` with no index write at all, which
 * meant offline entry silently defeated duplicate detection AND left holes in
 * the index that made later detection unreliable.
 */
async function commitDeliveryWithIndex(
  padId: string,
  clean: DeliveryTicket,
  options?: AddDeliveryOptions
): Promise<void> {
  const normTicket = normalizeTicketNumber(clean.ticketNumber || '');
  if (!normTicket) throw permanentError('PERMANENT: Ticket number is required.');

  const ticketIndexRef = doc(db, 'pads', padId, 'ticketNumbers', normTicket);
  const deliveryDocRef = doc(db, 'pads', padId, 'deliveries', clean.id);

  if (options?.supervisorOverride) {
    // An override is a deliberate, reasoned duplicate. It still writes the
    // index entry — the audit trail is the whole point of the override.
    const batch = writeBatch(db);
    batch.set(deliveryDocRef, clean);
    batch.set(
      ticketIndexRef,
      {
        deliveryId: clean.id,
        ticketNumber: normTicket,
        createdAt: clean.createdAt || Date.now(),
        deleted: false,
        overridden: true,
        overrideReason: options.overrideReason?.trim() || 'Supervisor Override',
      },
      { merge: true }
    );
    await batch.commit();
    return;
  }

  await runTransaction(db, async (tx) => {
    const indexSnap = await tx.get(ticketIndexRef);
    if (indexSnap.exists()) {
      const idxData = indexSnap.data();
      // An index entry pointing at THIS delivery is a replay of our own write
      // (an offline item flushed twice, a retry after a dropped response) —
      // idempotent, not a duplicate.
      if (idxData && idxData.deliveryId !== clean.id && !idxData.deleted) {
        throw permanentError(
          `DUPLICATE TICKET: Ticket #${normTicket} already exists on this pad. Explicit Supervisor Override with reason is required.`
        );
      }
    }

    tx.set(deliveryDocRef, clean);
    tx.set(ticketIndexRef, {
      deliveryId: clean.id,
      ticketNumber: normTicket,
      createdAt: clean.createdAt || Date.now(),
      deleted: false,
    });
  });
}

export async function addDeliveryTicket(
  padId: string,
  ticket: Omit<DeliveryTicket, 'id' | 'createdAt'>,
  options?: AddDeliveryOptions
): Promise<AddDeliveryResult> {
  const normTicket = normalizeTicketNumber(ticket.ticketNumber || '');
  if (!normTicket) {
    throw new Error('Ticket number is required.');
  }

  const newId = 'del-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
  const fullTicket: DeliveryTicket = {
    ...ticket,
    id: newId,
    ticketNumber: normTicket,
    createdAt: Date.now(),
    editedBy: null,
    editedByEmail: null,
    deleted: false,
    deletedAt: null,
    deletedReason: null,
    deletedBy: null,
    deletedByEmail: null,
    supervisorOverride: options?.supervisorOverride || false,
    overrideReason: options?.overrideReason?.trim() || null,
  };

  // The photo comes off BEFORE anything is serialised or queued.
  const { record, photoSource } = detachPhoto(fullTicket);

  const clean = Object.fromEntries(
    Object.entries(record).filter(([, v]) => v !== undefined)
  ) as DeliveryTicket;

  if (!isOnline()) {
    // The pending photo rides along in the queue payload, downscaled first and
    // under a key the document write strips, so a ticket photographed at a
    // dead-signal pad still reaches Storage when the connection comes back.
    const pendingPhotoDataUrl = await prepareQueuedPhoto(photoSource);
    enqueueOfflineAction(padId, 'ADD_DELIVERY', {
      ...clean,
      ...(pendingPhotoDataUrl ? { pendingPhotoDataUrl } : {}),
    });
    return { ...clean, pendingSync: true };
  }

  // 1. Guard with pad writable check
  await assertPadWritable(padId);

  // 2. Authoritative duplicate ticket protection with ticketNumbers index & transaction
  try {
    await commitDeliveryWithIndex(padId, clean, options);
  } catch (err: any) {
    if (err?.message?.includes('DUPLICATE TICKET')) {
      throw err;
    }
    console.warn('addDeliveryTicket write failed, falling back to offline queue:', err);
    const pendingPhotoDataUrl = await prepareQueuedPhoto(photoSource);
    enqueueOfflineAction(padId, 'ADD_DELIVERY', {
      ...clean,
      ...(pendingPhotoDataUrl ? { pendingPhotoDataUrl } : {}),
    });
    return { ...clean, pendingSync: true };
  }

  // 3. The ticket is safe. Now — and only now — the photo.
  if (photoSource) {
    const { photoUrl, warning } = await attachTicketPhoto(padId, newId, photoSource);
    return { ...clean, photoUrl, photoWarning: warning };
  }

  return { ...clean };
}

export async function deleteDeliveryTicket(
  padId: string,
  ticketId: string,
  reason?: string,
  deletedBy?: string | null,
  deletedByEmail?: string | null
) {
  const payload = {
    ticketId,
    reason: reason?.trim() || null,
    deletedBy: deletedBy ?? null,
    deletedByEmail: deletedByEmail ?? null,
  };

  if (!isOnline()) {
    enqueueOfflineAction(padId, 'DELETE_DELIVERY', payload);
    return;
  }

  try {
    await assertPadWritable(padId);
    const deliveryDocRef = doc(db, 'pads', padId, 'deliveries', ticketId);
    const snap = await getDoc(deliveryDocRef);
    if (snap.exists()) {
      const data = snap.data();
      const norm = normalizeTicketNumber(data.ticketNumber || '');
      const batch = writeBatch(db);
      batch.update(deliveryDocRef, {
        deleted: true,
        deletedAt: Date.now(),
        deletedReason: payload.reason,
        deletedBy: payload.deletedBy,
        deletedByEmail: payload.deletedByEmail,
      });
      if (norm) {
        const ticketIndexRef = doc(db, 'pads', padId, 'ticketNumbers', norm);
        batch.set(ticketIndexRef, {
          deliveryId: ticketId,
          ticketNumber: norm,
          deleted: true,
          deletedAt: Date.now(),
        }, { merge: true });
      }
      await batch.commit();
    }
  } catch (err: any) {
    console.warn('deleteDeliveryTicket failed, falling back to offline queue:', err);
    enqueueOfflineAction(padId, 'DELETE_DELIVERY', payload);
  }
}

export async function restoreDeliveryTicket(padId: string, ticketId: string) {
  if (!isOnline()) {
    enqueueOfflineAction(padId, 'RESTORE_DELIVERY', { ticketId });
    return;
  }

  try {
    await assertPadWritable(padId);
    const deliveryDocRef = doc(db, 'pads', padId, 'deliveries', ticketId);
    const snap = await getDoc(deliveryDocRef);
    if (snap.exists()) {
      const data = snap.data();
      const norm = normalizeTicketNumber(data.ticketNumber || '');
      const batch = writeBatch(db);
      batch.update(deliveryDocRef, {
        deleted: false,
        deletedAt: null,
        deletedReason: null,
        deletedBy: null,
        deletedByEmail: null,
      });
      if (norm) {
        const ticketIndexRef = doc(db, 'pads', padId, 'ticketNumbers', norm);
        batch.set(ticketIndexRef, {
          deliveryId: ticketId,
          ticketNumber: norm,
          createdAt: Date.now(),
          deleted: false,
        }, { merge: true });
      }
      await batch.commit();
    }
  } catch (err: any) {
    console.warn('restoreDeliveryTicket failed, falling back to offline queue:', err);
    enqueueOfflineAction(padId, 'RESTORE_DELIVERY', { ticketId });
  }
}

export async function updateDeliveryTicket(
  padId: string,
  ticketId: string,
  updates: Partial<Omit<DeliveryTicket, 'id' | 'createdAt'>>,
  editedBy?: string | null,
  editedByEmail?: string | null
) {
  // Same rule as the add path: a data-URL photo never enters the document.
  const { record: safeUpdates, photoSource } = detachPhoto({ ...updates });

  const payload: Record<string, any> = {
    ticketId,
    updates: {
      ...safeUpdates,
      editedAt: Date.now(),
      editedBy: editedBy ?? null,
      editedByEmail: editedByEmail ?? null,
    },
  };

  if (!isOnline()) {
    const pendingPhotoDataUrl = await prepareQueuedPhoto(photoSource);
    if (pendingPhotoDataUrl) payload.pendingPhotoDataUrl = pendingPhotoDataUrl;
    enqueueOfflineAction(padId, 'UPDATE_DELIVERY', payload);
    return;
  }

  try {
    await assertPadWritable(padId);
    const deliveryDocRef = doc(db, 'pads', padId, 'deliveries', ticketId);
    const snap = await getDoc(deliveryDocRef);
    const currentData = snap.exists() ? snap.data() : {};
    const currentCount = (currentData.editCount || 0) + 1;

    const fullPayload = {
      ...safeUpdates,
      editedAt: Date.now(),
      editCount: currentCount,
      editedBy: editedBy ?? currentData.editedBy ?? null,
      editedByEmail: editedByEmail ?? currentData.editedByEmail ?? null,
    };

    const clean = Object.fromEntries(
      Object.entries(fullPayload).filter(([, v]) => v !== undefined)
    );

    await updateDoc(deliveryDocRef, clean);
  } catch (err: any) {
    console.warn('updateDeliveryTicket failed, falling back to offline queue:', err);
    const pendingPhotoDataUrl = await prepareQueuedPhoto(photoSource);
    if (pendingPhotoDataUrl) payload.pendingPhotoDataUrl = pendingPhotoDataUrl;
    enqueueOfflineAction(padId, 'UPDATE_DELIVERY', payload);
    return;
  }

  // The edit is committed; a photo failure downgrades to a warning.
  if (photoSource) {
    await attachTicketPhoto(padId, ticketId, photoSource);
  }
}

export async function addRunRecords(
  padId: string,
  records: (Omit<RunRecord, 'id' | 'createdAt'> & { id?: string; submissionId?: string; runSequence?: number })[]
) {
  const batchTime = Date.now();
  const defaultSubId = `sub_${batchTime.toString(36)}_${Math.random().toString(36).substring(2, 6)}`;

  const created: RunRecord[] = [];
  records.forEach((r, idx) => {
    const subId = r.submissionId || defaultSubId;
    const runSeq = r.runSequence !== undefined && r.runSequence !== null ? r.runSequence : idx + 1;
    const newId = r.id || `run_${r.wellId}_stg_${r.stageNumber}_silo_${r.siloNumber}_${subId}_${runSeq}`;

    const fullRecord: RunRecord = {
      ...r,
      id: newId,
      submissionId: subId,
      runSequence: runSeq,
      createdAt: batchTime + idx,
      editedBy: null,
      editedByEmail: null,
      deleted: false,
      deletedAt: null,
      deletedReason: null,
      deletedBy: null,
      deletedByEmail: null,
    };
    const clean = Object.fromEntries(
      Object.entries(fullRecord).filter(([, v]) => v !== undefined)
    ) as RunRecord;
    created.push(clean);
  });

  if (!isOnline()) {
    enqueueOfflineAction(padId, 'ADD_RUNS', { records: created });
    return created.map((r) => ({ ...r, pendingSync: true }));
  }

  try {
    await assertPadWritable(padId);
    const batch = writeBatch(db);
    for (const record of created) {
      const runDocRef = doc(db, 'pads', padId, 'runs', record.id);
      batch.set(runDocRef, record, { merge: true });

      // Stage level idempotency and record tracking
      const stageRecordRef = doc(db, 'pads', padId, 'stageRecords', `${record.wellId}_stage_${record.stageNumber}`);
      batch.set(
        stageRecordRef,
        {
          wellId: record.wellId,
          stageNumber: record.stageNumber,
          lastSubmissionId: record.submissionId,
          lastUpdated: batchTime,
        },
        { merge: true }
      );
    }
    await batch.commit();
    return created;
  } catch (err: any) {
    console.warn('addRunRecords failed, falling back to offline queue:', err);
    enqueueOfflineAction(padId, 'ADD_RUNS', { records: created });
    return created.map((r) => ({ ...r, pendingSync: true }));
  }
}

export async function deleteRunRecord(
  padId: string,
  runId: string,
  reason?: string,
  deletedBy?: string | null,
  deletedByEmail?: string | null
) {
  const payload = {
    runId,
    reason: reason?.trim() || null,
    deletedBy: deletedBy ?? null,
    deletedByEmail: deletedByEmail ?? null,
  };

  if (!isOnline()) {
    enqueueOfflineAction(padId, 'DELETE_RUN', payload);
    return;
  }

  try {
    const runDocRef = doc(db, 'pads', padId, 'runs', runId);
    await updateDoc(runDocRef, {
      deleted: true,
      deletedAt: Date.now(),
      deletedReason: payload.reason,
      deletedBy: payload.deletedBy,
      deletedByEmail: payload.deletedByEmail,
    });
  } catch (err: any) {
    console.warn('deleteRunRecord failed, falling back to offline queue:', err);
    enqueueOfflineAction(padId, 'DELETE_RUN', payload);
  }
}

export async function restoreRunRecord(padId: string, runId: string) {
  if (!isOnline()) {
    enqueueOfflineAction(padId, 'RESTORE_RUN', { runId });
    return;
  }

  try {
    const runDocRef = doc(db, 'pads', padId, 'runs', runId);
    await updateDoc(runDocRef, {
      deleted: false,
      deletedAt: null,
      deletedReason: null,
      deletedBy: null,
      deletedByEmail: null,
    });
  } catch (err: any) {
    console.warn('restoreRunRecord failed, falling back to offline queue:', err);
    enqueueOfflineAction(padId, 'RESTORE_RUN', { runId });
  }
}

export async function updateRunRecord(
  padId: string,
  runId: string,
  updates: Partial<Omit<RunRecord, 'id' | 'createdAt'>>,
  editedBy?: string | null,
  editedByEmail?: string | null
) {
  const payload = {
    runId,
    updates: {
      ...updates,
      editedAt: Date.now(),
      editedBy: editedBy ?? null,
      editedByEmail: editedByEmail ?? null,
    },
  };

  if (!isOnline()) {
    enqueueOfflineAction(padId, 'UPDATE_RUN', payload);
    return;
  }

  try {
    const runDocRef = doc(db, 'pads', padId, 'runs', runId);
    const snap = await getDoc(runDocRef);
    const currentData = snap.exists() ? snap.data() : {};
    const currentCount = (currentData.editCount || 0) + 1;

    const fullPayload = {
      ...updates,
      editedAt: Date.now(),
      editCount: currentCount,
      editedBy: editedBy ?? currentData.editedBy ?? null,
      editedByEmail: editedByEmail ?? currentData.editedByEmail ?? null,
    };

    const clean = Object.fromEntries(
      Object.entries(fullPayload).filter(([, v]) => v !== undefined)
    );

    await updateDoc(runDocRef, clean);
  } catch (err: any) {
    console.warn('updateRunRecord failed, falling back to offline queue:', err);
    enqueueOfflineAction(padId, 'UPDATE_RUN', payload);
  }
}

/* --------------------------------------------------------- silo config --- */

/**
 * Merge a set of silos onto the live config by silo number.
 *
 * Replacing the whole array would resurrect silos a co-worker had removed and
 * clobber ones they had just edited. Merging per silo number keeps a
 * concurrent edit to silo 4 while this call is reassigning silo 2.
 */
function mergeSilosByNumber(current: SiloConfig[], incoming: SiloConfig[]): SiloConfig[] {
  const byNumber = new Map<number, SiloConfig>();
  incoming.forEach((s) => byNumber.set(s.siloNumber, s));
  const merged = current.map((s) => byNumber.get(s.siloNumber) ?? s);
  // Silos in `incoming` that the live config does not have yet (a silo count
  // that grew while we were offline) are appended rather than dropped.
  const known = new Set(current.map((s) => s.siloNumber));
  incoming.forEach((s) => {
    if (!known.has(s.siloNumber)) merged.push(s);
  });
  return merged;
}

/**
 * Apply a silo change inside a transaction.
 *
 * The previous implementation was a read-modify-write with nothing holding it
 * together: `getDoc` → mutate → full-config `updateDoc`. Two crew members
 * reassigning silos at the same moment — which is precisely the situation this
 * app exists for — each read the same config and each wrote a full copy of it,
 * so whoever committed second silently erased the other's change. Deliveries
 * got a proper `runTransaction`; config did not.
 */
async function transactSiloConfig(
  padId: string,
  mutate: (silos: SiloConfig[]) => SiloConfig[]
): Promise<PadConfig | null> {
  const padDocRef = doc(db, 'pads', padId);
  const tombstoneRef = doc(db, 'deletedPads', padId);

  const newConfig = await runTransaction(db, async (tx) => {
    // All reads first — Firestore transactions require it.
    const tombstoneSnap = await tx.get(tombstoneRef);
    const padSnap = await tx.get(padDocRef);

    if (tombstoneSnap.exists()) {
      throw new Error(`Cannot update silos: Well pad "${padId}" has been archived.`);
    }
    if (!padSnap.exists()) return null;

    const data = padSnap.data();
    const currentConfig: PadConfig = data.config || data;
    const updated: PadConfig = {
      ...currentConfig,
      silos: mutate(currentConfig.silos || []),
    };

    const cleanConfig = Object.fromEntries(
      Object.entries(updated).filter(([, v]) => v !== undefined)
    ) as PadConfig;

    tx.update(padDocRef, { config: cleanConfig, updatedAt: Date.now() });
    return cleanConfig;
  });

  if (newConfig) backupPadConfigLocally(padId, newConfig);
  return newConfig;
}

/** The config this device last knew about — the only basis for an offline edit. */
function requireLocalConfig(padId: string): PadConfig {
  const local = getLocalPadConfigBackup(padId);
  if (!local) {
    throw new Error(
      'Silo settings cannot be changed offline on this device — it has no local copy of the pad setup yet.'
    );
  }
  return local;
}

export async function updateSiloInPad(
  padId: string,
  siloNumber: number,
  updateFn: (silo: SiloConfig) => SiloConfig
) {
  const apply = (silos: SiloConfig[]) =>
    silos.map((s) => (s.siloNumber === siloNumber ? updateFn(s) : s));

  if (!isOnline()) {
    // Queue the RESULTING silo, not the function — a closure cannot be
    // serialised, which is why UPDATE_SILO was in the action union but never
    // actually enqueued by anything.
    const local = requireLocalConfig(padId);
    const nextSilos = apply(local.silos || []);
    const changed = nextSilos.find((s) => s.siloNumber === siloNumber);
    if (!changed) return;
    backupPadConfigLocally(padId, { ...local, silos: nextSilos });
    enqueueOfflineAction(padId, 'UPDATE_SILO', { siloNumber, silo: changed });
    return;
  }

  try {
    await transactSiloConfig(padId, apply);
  } catch (err: any) {
    if (String(err?.message || '').includes('has been archived')) throw err;
    console.warn('updateSiloInPad failed, falling back to offline queue:', err);
    const local = getLocalPadConfigBackup(padId);
    if (!local) throw err;
    const nextSilos = apply(local.silos || []);
    const changed = nextSilos.find((s) => s.siloNumber === siloNumber);
    if (changed) {
      backupPadConfigLocally(padId, { ...local, silos: nextSilos });
      enqueueOfflineAction(padId, 'UPDATE_SILO', { siloNumber, silo: changed });
    }
  }
}

export async function updateSilosInPad(
  padId: string,
  updateFn: (silos: SiloConfig[]) => SiloConfig[]
) {
  if (!isOnline()) {
    const local = requireLocalConfig(padId);
    const nextSilos = updateFn(local.silos || []);
    backupPadConfigLocally(padId, { ...local, silos: nextSilos });
    enqueueOfflineAction(padId, 'UPDATE_SILOS', { silos: nextSilos });
    return;
  }

  try {
    await transactSiloConfig(padId, updateFn);
  } catch (err: any) {
    if (String(err?.message || '').includes('has been archived')) throw err;
    console.warn('updateSilosInPad failed, falling back to offline queue:', err);
    const local = getLocalPadConfigBackup(padId);
    if (!local) throw err;
    const nextSilos = updateFn(local.silos || []);
    backupPadConfigLocally(padId, { ...local, silos: nextSilos });
    enqueueOfflineAction(padId, 'UPDATE_SILOS', { silos: nextSilos });
  }
}

export async function executeQueueItem(item: OfflineQueueItem): Promise<void> {
  const { padId, type, payload } = item;

  // 1. Check if the pad was deleted (tombstone check)
  const tombstoneDoc = await getDoc(doc(db, 'deletedPads', padId));
  if (tombstoneDoc.exists()) {
    // Dropping this is correct — but it is still a write the crew made that
    // will never exist, so it goes in the failure log rather than a console
    // line nobody standing on a pad will ever see.
    recordPermanentFailure(item, `The pad "${padId}" was archived before this change could sync.`);
    return;
  }

  // Special case: CREATE_PAD can create the document if tombstone is not present
  if (type === 'CREATE_PAD') {
    const padDocRef = doc(db, 'pads', padId);
    const padSnap = await getDoc(padDocRef);
    if (!padSnap.exists()) {
      await setDoc(padDocRef, {
        config: payload.config,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      });
    } else {
      await updateDoc(padDocRef, {
        config: payload.config,
        updatedAt: Date.now(),
      });
    }
    return;
  }

  // 2. For all other mutations, check if the pad document itself exists
  const padDocRef = doc(db, 'pads', padId);
  const padSnap = await getDoc(padDocRef);
  if (!padSnap.exists()) {
    recordPermanentFailure(item, `The pad "${padId}" no longer exists, so this change cannot sync.`);
    return;
  }

  switch (type) {
    case 'SAVE_PAD_CONFIG': {
      await updateDoc(padDocRef, {
        config: payload.config,
        updatedAt: Date.now(),
      });
      break;
    }
    case 'ADD_DELIVERY': {
      // THE fix: this used to be a bare setDoc with no ticketNumbers index
      // write at all, so a ticket entered offline both skipped duplicate
      // detection and left the index missing an entry — which then let a
      // genuine duplicate through later. It now takes exactly the same
      // transactional path as an online entry, and a duplicate surfaces as a
      // real, permanent, operator-visible failure instead of a silent drop.
      const {
        pendingSync: _pendingSync,
        pendingPhotoDataUrl,
        ...rest
      } = payload as Record<string, any>;

      const clean = Object.fromEntries(
        Object.entries(rest).filter(([, v]) => v !== undefined)
      ) as DeliveryTicket;

      await commitDeliveryWithIndex(padId, clean, {
        supervisorOverride: Boolean(clean.supervisorOverride),
        overrideReason: clean.overrideReason || undefined,
      });

      if (isDataUrl(pendingPhotoDataUrl)) {
        // The ticket is committed; a failed photo must not fail the item and
        // send an already-saved delivery back around the retry loop.
        await attachTicketPhoto(padId, clean.id, pendingPhotoDataUrl);
      }
      break;
    }
    case 'UPDATE_DELIVERY': {
      const docRef = doc(db, 'pads', padId, 'deliveries', payload.ticketId);
      const clean = Object.fromEntries(
        Object.entries(payload.updates || {}).filter(([k, v]) => k !== 'pendingSync' && v !== undefined)
      );
      await updateDoc(docRef, clean);
      if (isDataUrl(payload.pendingPhotoDataUrl)) {
        await attachTicketPhoto(padId, payload.ticketId, payload.pendingPhotoDataUrl);
      }
      break;
    }
    case 'DELETE_DELIVERY': {
      const docRef = doc(db, 'pads', padId, 'deliveries', payload.ticketId);
      await updateDoc(docRef, {
        deleted: true,
        deletedAt: Date.now(),
        deletedReason: payload.reason || null,
        deletedBy: payload.deletedBy || null,
        deletedByEmail: payload.deletedByEmail || null,
      });
      break;
    }
    case 'RESTORE_DELIVERY': {
      const docRef = doc(db, 'pads', padId, 'deliveries', payload.ticketId);
      await updateDoc(docRef, {
        deleted: false,
        deletedAt: null,
        deletedReason: null,
        deletedBy: null,
        deletedByEmail: null,
      });
      break;
    }
    case 'ADD_RUNS': {
      const records = (payload.records || []) as RunRecord[];
      if (records.length === 0) break;
      const batch = writeBatch(db);
      const stageRecordsToUpdate = new Map<string, { wellId: string; stageNumber: number; submissionId: string; timestamp: number }>();

      for (const record of records) {
        const docRef = doc(db, 'pads', padId, 'runs', record.id);
        const clean = Object.fromEntries(
          Object.entries(record).filter(([k, v]) => k !== 'pendingSync' && v !== undefined)
        );
        batch.set(docRef, clean, { merge: true });

        const stageKey = `${record.wellId}_stage_${record.stageNumber}`;
        stageRecordsToUpdate.set(stageKey, {
          wellId: record.wellId,
          stageNumber: record.stageNumber,
          submissionId: record.submissionId || '',
          timestamp: record.createdAt || Date.now(),
        });
      }

      for (const [stageKey, info] of stageRecordsToUpdate.entries()) {
        const stageRecordRef = doc(db, 'pads', padId, 'stageRecords', stageKey);
        batch.set(
          stageRecordRef,
          {
            wellId: info.wellId,
            stageNumber: info.stageNumber,
            lastSubmissionId: info.submissionId,
            lastUpdated: info.timestamp,
          },
          { merge: true }
        );
      }

      await batch.commit();
      break;
    }
    case 'UPDATE_RUN': {
      const docRef = doc(db, 'pads', padId, 'runs', payload.runId);
      const clean = Object.fromEntries(
        Object.entries(payload.updates || {}).filter(([k, v]) => k !== 'pendingSync' && v !== undefined)
      );
      await updateDoc(docRef, clean);
      break;
    }
    case 'DELETE_RUN': {
      const docRef = doc(db, 'pads', padId, 'runs', payload.runId);
      await updateDoc(docRef, {
        deleted: true,
        deletedAt: Date.now(),
        deletedReason: payload.reason || null,
        deletedBy: payload.deletedBy || null,
        deletedByEmail: payload.deletedByEmail || null,
      });
      break;
    }
    case 'RESTORE_RUN': {
      const docRef = doc(db, 'pads', padId, 'runs', payload.runId);
      await updateDoc(docRef, {
        deleted: false,
        deletedAt: null,
        deletedReason: null,
        deletedBy: null,
        deletedByEmail: null,
      });
      break;
    }
    /* Silo edits made with no signal. These two action types existed in the
       union but nothing enqueued them and the executor had no case for them,
       so they fell through to `default: console.warn`. Reassigning a can in
       the field with no bars is a real, frequent case, so they are now
       implemented rather than removed — replayed transactionally and merged
       per silo number so they do not clobber a concurrent change. */
    case 'UPDATE_SILO': {
      const incoming = payload.silo as SiloConfig | undefined;
      if (!incoming) break;
      await transactSiloConfig(padId, (silos) => mergeSilosByNumber(silos, [incoming]));
      break;
    }
    case 'UPDATE_SILOS': {
      const incoming = (payload.silos || []) as SiloConfig[];
      if (incoming.length === 0) break;
      await transactSiloConfig(padId, (silos) => mergeSilosByNumber(silos, incoming));
      break;
    }
    default:
      // Reached only for a queue item written by a newer build than this one.
      recordPermanentFailure(item, `This device does not understand the queued action "${type}".`);
  }
}

/* The queue cannot import this module (we import it), so we hand it the
   executor. This is what lets the queue drain on its own timer and on the
   'online' event, instead of only when a mounted OfflineBanner decides to. */
registerQueueExecutor(executeQueueItem);

export async function createNewPad(padName: string): Promise<string> {
  const newId = 'pad-' + Date.now();
  const newConfig: PadConfig = {
    ...blankPadConfig,
    padName: padName.trim() || 'New Well Pad',
  };
  await createPad(newId, newConfig);
  return newId;
}

export interface ListPadsOptions {
  /** Include archived pads. Default false — an archived job is off the list. */
  includeArchived?: boolean;
}

export interface PadListEntry {
  id: string;
  name: string;
  archived?: boolean;
}

export async function listPads(options?: ListPadsOptions): Promise<PadListEntry[]> {
  const colRef = collection(db, 'pads');
  const snapshot = await getDocs(colRef);
  const result: PadListEntry[] = [];
  snapshot.forEach((d) => {
    const data = d.data();
    const archived = data.archived === true;
    if (archived && !options?.includeArchived) return;
    const padName = data.config?.padName || data.padName || d.id;
    result.push({ id: d.id, name: padName, archived });
  });
  return result;
}

export interface PadSummaryInfo {
  id: string;
  name: string;
  deliveryCount: number;
  runCount: number;
  archived?: boolean;
  archivedAt?: number | null;
  archivedReason?: string | null;
}

/** Aggregate count, with a full read only as a fallback. */
async function countCollection(padId: string, sub: string): Promise<number> {
  const colRef = collection(db, 'pads', padId, sub);
  try {
    // A server-side aggregate: one round trip, and it does not stream a
    // 700-ticket ledger down an LTE hotspot just to print "700".
    const agg = await getCountFromServer(colRef);
    return agg.data().count;
  } catch (err) {
    console.warn(`count(${padId}/${sub}) fell back to a full read:`, err);
    const snap = await getDocs(colRef);
    return snap.size;
  }
}

/**
 * Pad list with live ticket and run counts.
 *
 * Was O(pads × 2) sequential `getDocs` — every pad's entire deliveries and
 * runs subcollections were downloaded, one pad at a time, to produce two
 * integers. Ten finished jobs of 700 tickets each meant twenty serialised
 * round trips and several MB pulled over a hotspot before the screen painted.
 *
 * Now: one aggregate count per subcollection (server-side, no documents
 * transferred) and every pad fanned out in parallel.
 */
export async function listPadsWithDetails(options?: ListPadsOptions): Promise<PadSummaryInfo[]> {
  const colRef = collection(db, 'pads');
  const snapshot = await getDocs(colRef);

  const docs = snapshot.docs.filter(
    (d) => options?.includeArchived || d.data().archived !== true
  );

  return Promise.all(
    docs.map(async (d) => {
      const data = d.data();
      const [deliveryCount, runCount] = await Promise.all([
        countCollection(d.id, 'deliveries'),
        countCollection(d.id, 'runs'),
      ]);

      return {
        id: d.id,
        name: data.config?.padName || data.padName || d.id,
        deliveryCount,
        runCount,
        archived: data.archived === true,
        archivedAt: data.archivedAt ?? null,
        archivedReason: data.archivedReason ?? null,
      };
    })
  );
}

export async function fetchPadFullState(padId: string): Promise<AppState | null> {
  const padDoc = await getDoc(doc(db, 'pads', padId));
  if (!padDoc.exists()) {
    console.log('[PAD NOT FOUND in fetchPadFullState]', padId);
    return null;
  }
  const padData = padDoc.data();
  const config: PadConfig = padData?.config || padData;

  const [delSnap, runSnap] = await Promise.all([
    getDocs(collection(db, 'pads', padId, 'deliveries')),
    getDocs(collection(db, 'pads', padId, 'runs')),
  ]);

  const allDeliveries: DeliveryTicket[] = [];
  delSnap.forEach((d) => {
    allDeliveries.push({ id: d.id, ...d.data() } as DeliveryTicket);
  });
  allDeliveries.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

  const allRuns: RunRecord[] = [];
  runSnap.forEach((r) => {
    allRuns.push({ id: r.id, ...r.data() } as RunRecord);
  });
  allRuns.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

  return {
    status: 'ready',
    padId,
    config,
    deliveries: allDeliveries.filter((d) => !d.deleted),
    runs: allRuns.filter((r) => !r.deleted),
    deletedDeliveries: allDeliveries.filter((d) => d.deleted),
    deletedRuns: allRuns.filter((r) => r.deleted),
  };
}

export interface ArchivePadResult {
  padId: string;
  archived: true;
  /** Ticket count retained under the archived pad. Nothing was destroyed. */
  deliveryCount: number;
  runCount: number;
}

/**
 * Archive a job.
 *
 * This used to hard-delete four subcollections in 450-operation batches. The
 * new firestore.rules forbid client deletes outright (`allow delete: if false`
 * on pads, deliveries, runs and the ticket index) — destroying a customer's
 * entire ledger from a tablet at a gate is not a thing a field tool should be
 * able to do, and the batch loop would now simply fail partway through,
 * leaving the pad half-shredded.
 *
 * So: the pad is flagged `archived`, its tombstone is still written so no
 * stale client keeps writing to it, and every ticket, run, index entry and
 * stage record stays exactly where it is. Real destruction is a console
 * operation. `unarchivePad` puts it back.
 */
export async function archivePad(
  padId: string,
  reason?: string
): Promise<ArchivePadResult> {
  console.log('[PAD ARCHIVE]', padId);
  // 1. Purge offline writes for this pad immediately
  clearOfflineQueue(padId);

  // 2. Remove local recovery backup
  if (typeof window !== 'undefined' && window.localStorage) {
    try {
      localStorage.removeItem(`sandtracker_pad_config_backup_${padId}`);
      const raw = localStorage.getItem('sandtracker_known_pad_backups');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
          delete parsed[padId];
          localStorage.setItem('sandtracker_known_pad_backups', JSON.stringify(parsed));
        } else if (Array.isArray(parsed)) {
          const filtered = parsed.filter((id: string) => id !== padId);
          localStorage.setItem('sandtracker_known_pad_backups', JSON.stringify(filtered));
        }
      }
    } catch (_) {}
  }

  // 3. Count what is being retained (cheap, server-side aggregate)
  const [deliveryCount, runCount] = await Promise.all([
    countCollection(padId, 'deliveries'),
    countCollection(padId, 'runs'),
  ]);

  // 4. Flag the pad archived. The rules validate the whole merged document,
  //    so `config` has to still be present and valid — it is, since this is an
  //    update to an existing pad and updateDoc merges.
  const padDocRef = doc(db, 'pads', padId);
  await updateDoc(padDocRef, {
    archived: true,
    archivedAt: Date.now(),
    archivedReason: reason?.trim() || 'Archived from the pad manager',
    updatedAt: Date.now(),
  });

  // 5. Tombstone LAST, so a failed archive leaves the pad fully writable
  //    rather than tombstoned-but-live.
  await setDoc(doc(db, 'deletedPads', padId), {
    deletedAt: Date.now(),
    archivedAt: Date.now(),
    padId,
  });

  return { padId, archived: true, deliveryCount, runCount };
}

/**
 * @deprecated Client deletes are forbidden by firestore.rules. This is an
 * alias for {@link archivePad} so older call sites keep working; nothing is
 * destroyed.
 */
export const deletePad = archivePad;

/** Put an archived job back in service. */
export async function unarchivePad(padId: string): Promise<void> {
  console.log('[PAD UNARCHIVE]', padId);
  // Tombstone first — while it exists every write is rejected by
  // assertPadWritable, including the one below.
  try {
    await deleteDoc(doc(db, 'deletedPads', padId));
  } catch (err) {
    console.warn('unarchivePad: could not clear the tombstone:', err);
  }

  await updateDoc(doc(db, 'pads', padId), {
    archived: false,
    archivedAt: null,
    archivedReason: null,
    updatedAt: Date.now(),
  });
}

export async function restorePad(padId: string, config?: PadConfig): Promise<void> {
  // 1. Remove tombstone
  await deleteDoc(doc(db, 'deletedPads', padId));

  // 2. Restore pad configuration
  const cfg = config || getLocalPadConfigBackup(padId) || blankPadConfig;
  await createPad(padId, cfg);

  // 3. An archived pad that is being restored is no longer archived.
  try {
    await updateDoc(doc(db, 'pads', padId), {
      archived: false,
      archivedAt: null,
      archivedReason: null,
    });
  } catch (_) {}
}

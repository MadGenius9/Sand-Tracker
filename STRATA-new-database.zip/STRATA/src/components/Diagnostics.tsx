/**
 * Pad diagnostics — an inspection report, not an error list.
 *
 * Every check renders every time, clean or not. A check that passes says so in
 * a sentence ("No duplicate ticket numbers.") and carries a zero count badge;
 * a check that fails carries its count and the rows behind it. Seeing the
 * passing checks is the point — it is how a coordinator knows the audit
 * actually ran rather than wondering whether an empty screen means healthy or
 * broken. The header rolls all of it into one badge: Clean, or n flags.
 */

import {
  AlertTriangle,
  CheckCircle2,
  Copy,
  FileText,
  Layers,
  RefreshCw,
  QrCode,
  ScanLine,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { Children, Fragment, ReactNode, useMemo, useState } from 'react';
import { formatLbs, formatTons, getDiagnosticsReport } from '../lib/sandRules';
import { parseTicketScanValue } from '../lib/ticketUtils';
import { cn, sandClasses } from '../lib/theme';
import { AppState } from '../types';
import TicketScannerModal from './TicketScannerModal';
import PadRecoveryModal from './PadRecoveryModal';

interface DiagnosticsProps {
  state: AppState;
  onSelectPad?: (padId: string) => void;
}

type Severity = 'warn' | 'danger';

/**
 * A findings list that refuses to run away.
 *
 * A pad whose silo sand assignment was changed mid-job can produce several
 * hundred "sand type mismatch" findings at once. Rendered flat, that turned
 * this page into a 40,000-pixel scroll where the checks below it were
 * unreachable. The count in the badge is the number that matters; the rows are
 * evidence, and eight of them is enough to see the pattern.
 */
function CappedList({ children, initial = 8 }: { children: ReactNode; initial?: number }) {
  const items = Children.toArray(children);
  const [expanded, setExpanded] = useState(false);
  const hidden = items.length - initial;

  return (
    <div className="flex flex-col gap-2">
      {(expanded ? items : items.slice(0, initial)).map((child, i) => (
        <Fragment key={i}>{child}</Fragment>
      ))}
      {hidden > 0 && (
        <button
          type="button"
          onClick={() => setExpanded((e) => !e)}
          className="btn btn-ghost w-full"
        >
          {expanded ? 'Show fewer' : `Show all ${items.length} — ${hidden} more`}
        </button>
      )}
    </div>
  );
}

function CheckCard({
  index,
  title,
  icon,
  count,
  severity,
  unit,
  passMessage,
  model,
  children,
}: {
  index: number;
  title: string;
  icon: ReactNode;
  count: number;
  severity: Severity;
  unit: string;
  passMessage: string;
  model?: string;
  children?: ReactNode;
}) {
  const isClean = count === 0;

  return (
    <div
      className={cn(
        'card',
        isClean ? 'ring-border' : severity === 'danger' ? 'ring-danger-1' : 'ring-warn-1'
      )}
    >
      <div className="card-hd">
        <div className="flex min-w-0 items-start gap-2.5">
          <span
            className={cn(
              'mt-0.5 shrink-0',
              isClean ? 'text-muted' : severity === 'danger' ? 'text-danger' : 'text-warn'
            )}
          >
            {icon}
          </span>
          <div className="min-w-0">
            <div className="eyebrow">Check {index}</div>
            <h2 className="text-base font-medium tracking-tight">{title}</h2>
            {model && <p className="text-xs text-muted">{model}</p>}
          </div>
        </div>

        <span
          className={cn(
            'badge shrink-0',
            isClean ? 'badge-ok' : severity === 'danger' ? 'badge-danger' : 'badge-warn'
          )}
        >
          <span className="num">{count}</span> {unit}
        </span>
      </div>

      {isClean ? (
        <div className="flex items-center gap-2 rounded-md bg-elevated px-3 py-2.5 text-sm text-fg">
          <CheckCircle2 className="size-4 shrink-0 text-ok" />
          <span>{passMessage}</span>
        </div>
      ) : (
        children
      )}
    </div>
  );
}

export default function Diagnostics({ state, onSelectPad }: DiagnosticsProps) {
  const { config, deliveries, runs } = state;

  /* getDiagnosticsReport walks every ticket and run on the pad twice — once
     for the sand-type totals and once per silo. Keyed on the three slices it
     reads, so opening the scanner or the recovery tool is free. */
  const report = useMemo(() => getDiagnosticsReport(state), [config, deliveries, runs]);

  const lbsPerTon = config.lbsPerTon || 2000;

  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isRecoveryOpen, setIsRecoveryOpen] = useState(false);
  const [testScanResult, setTestScanResult] = useState<{
    rawValue: string;
    format: string;
    winningScale?: string;
    engine?: string;
  } | null>(null);

  const flagCount = useMemo(
    () =>
      (report.isPadTotalMismatch ? 1 : 0) +
      report.negativeSilos.length +
      report.duplicateTicketNumbers.length +
      report.mismatchedDeliveries.length +
      report.unassignedSilos.length +
      report.unassignedSiloDeliveries.length +
      report.unassignedSiloRuns.length,
    [report]
  );

  const parsedTestScan = useMemo(
    () =>
      testScanResult
        ? parseTicketScanValue(testScanResult.rawValue, config.productCodeMappings || [])
        : null,
    [testScanResult, config.productCodeMappings]
  );

  const padDelta = report.computedPadOnHandLbs - report.sumOfSilosOnHandLbs;

  const handleTestScan = (result: {
    rawValue: string;
    format: string;
    winningScale?: string;
    engine?: string;
  }) => {
    setIsScannerOpen(false);
    setTestScanResult(result);
  };

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-5 pb-12">
      {/* ------------------------------------------------- header --- */}
      <div className="card flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0">
          <div className="eyebrow">Diagnostics</div>
          <h1 className="text-2xl font-medium tracking-tight">{config.padName || 'Pad'}</h1>
          <p className="max-w-2xl text-sm text-muted">
            Nine audits over the live ledger — every one runs on every visit and reports either its
            count or a clean result. Balances replay starting balance plus deliveries minus pulls,
            per can and per sand type.
          </p>
        </div>

        <div className="shrink-0">
          {flagCount === 0 ? (
            <span className="badge badge-ok">
              <CheckCircle2 className="size-3.5" /> Clean
            </span>
          ) : (
            <span className="badge badge-danger">
              <AlertTriangle className="size-3.5" /> <span className="num">{flagCount}</span> flag
              {flagCount === 1 ? '' : 's'}
            </span>
          )}
        </div>
      </div>

      {/* --------------------------- 1. pad on-hand reconciliation --- */}
      <CheckCard
        index={1}
        title="Pad total on-hand reconciliation"
        icon={<RefreshCw className="size-5" />}
        count={report.isPadTotalMismatch ? 1 : 0}
        severity="danger"
        unit={report.isPadTotalMismatch ? 'mismatch' : 'mismatches'}
        passMessage="Sand-type totals and silo balances agree to the pound."
        model="Sum of the per-sand-type totals against the sum of the per-silo balances."
      >
        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            <div className="rounded-md bg-elevated p-3 ring-border">
              <div className="eyebrow">Sum of sand type totals</div>
              <div className="stat-v mt-1">{formatLbs(report.computedPadOnHandLbs)}</div>
              <div className="num text-xs text-muted">
                {formatTons(report.computedPadOnHandLbs / lbsPerTon)}
              </div>
            </div>

            <div className="rounded-md bg-elevated p-3 ring-border">
              <div className="eyebrow">Sum of silo balances</div>
              <div className="stat-v mt-1">{formatLbs(report.sumOfSilosOnHandLbs)}</div>
              <div className="num text-xs text-muted">
                {formatTons(report.sumOfSilosOnHandLbs / lbsPerTon)}
              </div>
            </div>
          </div>

          <div className="flex items-start gap-2 rounded-md bg-danger-dim p-3 text-sm text-danger">
            <AlertTriangle className="mt-0.5 size-4 shrink-0" />
            <div>
              <div className="font-medium">
                Off by <span className="num">{formatLbs(Math.abs(padDelta))}</span>
              </div>
              <div className="mt-0.5 text-fg">
                Usually sand delivered into a can that was assigned a different sand type at the
                time. Check the sand type mismatch audit below.
              </div>
            </div>
          </div>
        </div>
      </CheckCard>

      {/* -------------------------------- 2. negative silo balances --- */}
      <CheckCard
        index={2}
        title="Negative silo balances"
        icon={<AlertTriangle className="size-5" />}
        count={report.negativeSilos.length}
        severity="danger"
        unit={report.negativeSilos.length === 1 ? 'silo' : 'silos'}
        passMessage="No silo is sitting at a negative balance."
        model="A can whose recorded pulls exceed its starting balance plus deliveries."
      >
        <CappedList>
          {report.negativeSilos.map((item) => (
            <div
              key={item.siloNumber}
              className="flex flex-wrap items-center justify-between gap-2 rounded-md bg-elevated p-3 ring-danger-1"
            >
              <div className="min-w-0">
                <div className="text-sm font-medium">
                  Silo <span className="num">#{item.siloNumber}</span>
                </div>
                <div className="text-xs text-muted">
                  More sand pulled than the delivery tickets account for — a ticket is probably
                  missing.
                </div>
              </div>
              <div className="num shrink-0 text-lg font-semibold text-danger">
                {formatLbs(item.onHandLbs)}
              </div>
            </div>
          ))}
        </CappedList>
      </CheckCard>

      {/* ----------------------------- 3. duplicate ticket numbers --- */}
      <CheckCard
        index={3}
        title="Duplicate delivery ticket numbers"
        icon={<Copy className="size-5" />}
        count={report.duplicateTicketNumbers.length}
        severity="warn"
        unit={report.duplicateTicketNumbers.length === 1 ? 'duplicate' : 'duplicates'}
        passMessage="No duplicate ticket numbers."
        model="Active tickets grouped by normalized ticket number."
      >
        <CappedList>
          {report.duplicateTicketNumbers.map((item) => (
            <div
              key={item.ticketNumber}
              className="flex flex-wrap items-center justify-between gap-2 rounded-md bg-elevated p-3 ring-warn-1"
            >
              <div className="min-w-0">
                <div className="num text-sm font-medium">Ticket #{item.ticketNumber}</div>
                <div className="text-xs text-muted">
                  Logged <span className="num">{item.count}</span> times — the load may have been
                  counted more than once.
                </div>
              </div>
              <span className="badge badge-warn shrink-0">
                <span className="num">{item.count}</span> occurrences
              </span>
            </div>
          ))}
        </CappedList>
      </CheckCard>

      {/* -------------------------------- 4. sand type mismatches --- */}
      <CheckCard
        index={4}
        title="Deliveries against a different sand type"
        icon={<FileText className="size-5" />}
        count={report.mismatchedDeliveries.length}
        severity="warn"
        unit={report.mismatchedDeliveries.length === 1 ? 'mismatch' : 'mismatches'}
        passMessage="Every ticket matches the sand type its silo is assigned."
        model="Ticket sand type against the silo's current assignment."
      >
        <CappedList>
          {report.mismatchedDeliveries.map((m) => {
            const deliveredTone = sandClasses(m.deliverySandType, config.sandTypes);
            const assignedTone = sandClasses(m.siloCurrentSandType, config.sandTypes);
            return (
              <div key={m.ticketId} className="rounded-md bg-elevated p-3 ring-border">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="num text-sm font-medium">#{m.ticketNumber}</span>
                  <span className="badge">
                    Silo <span className="num">#{m.siloNumber}</span>
                  </span>
                  <span className="num text-xs text-muted">{m.date}</span>
                </div>
                <div className="mt-1.5 flex flex-wrap items-center gap-2 text-sm">
                  <span className="flex items-center gap-1.5">
                    <span className={cn('size-2 shrink-0 rounded-full', deliveredTone.fill)} />
                    Delivered {m.deliverySandType}
                  </span>
                  <ArrowRight className="size-3.5 shrink-0 text-subtle" />
                  <span className="flex items-center gap-1.5 text-muted">
                    <span className={cn('size-2 shrink-0 rounded-full', assignedTone.fill)} />
                    Silo assigned {m.siloCurrentSandType}
                  </span>
                </div>
              </div>
            );
          })}
        </CappedList>
      </CheckCard>

      {/* ------------------------------------- 5. unassigned silos --- */}
      <CheckCard
        index={5}
        title="Silos without a sand type"
        icon={<Layers className="size-5" />}
        count={report.unassignedSilos.length}
        severity="warn"
        unit={report.unassignedSilos.length === 1 ? 'silo' : 'silos'}
        passMessage="Every silo has a sand type assigned."
        model="A can with no product assigned cannot be given a pull order."
      >
        <div className="flex flex-wrap gap-1.5">
          {report.unassignedSilos.map((sNum) => (
            <span key={sNum} className="badge badge-warn">
              Silo <span className="num">#{sNum}</span> — empty
            </span>
          ))}
        </div>
      </CheckCard>

      {/* --------------------- 6. deliveries on unconfigured silos --- */}
      <CheckCard
        index={6}
        title="Deliveries against a silo not in the config"
        icon={<AlertTriangle className="size-5" />}
        count={report.unassignedSiloDeliveries.length}
        severity="danger"
        unit={report.unassignedSiloDeliveries.length === 1 ? 'ticket' : 'tickets'}
        passMessage="Every delivery ticket points at a configured silo."
        model="Ticket silo numbers that do not exist in this pad's silo list."
      >
        <CappedList>
          <p className="text-sm text-muted">
            These tickets are stored but invisible to the board. Reassign the silo in Logs, or add
            the missing can in Setup.
          </p>
          {report.unassignedSiloDeliveries.map((del) => {
            const tone = sandClasses(del.sandType, config.sandTypes);
            return (
              <div
                key={del.id}
                className="flex flex-wrap items-center justify-between gap-2 rounded-md bg-elevated p-3 ring-danger-1"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="num text-sm font-medium">#{del.ticketNumber}</span>
                    <span className="badge badge-danger">
                      Silo <span className="num">#{del.siloNumber}</span> not configured
                    </span>
                    <span className="num text-xs text-muted">{del.date}</span>
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-xs text-muted">
                    <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                    {del.sandType} · {del.supplier || 'No supplier'}
                  </div>
                </div>
                <div className="num shrink-0 text-sm font-semibold">{formatLbs(del.lbs)}</div>
              </div>
            );
          })}
        </CappedList>
      </CheckCard>

      {/* --------------------------- 7. runs on unconfigured silos --- */}
      <CheckCard
        index={7}
        title="Stage runs from a silo not in the config"
        icon={<AlertTriangle className="size-5" />}
        count={report.unassignedSiloRuns.length}
        severity="danger"
        unit={report.unassignedSiloRuns.length === 1 ? 'run' : 'runs'}
        passMessage="Every stage run was pulled from a configured silo."
        model="Run silo numbers that do not exist in this pad's silo list."
      >
        <CappedList>
          <p className="text-sm text-muted">
            These pulls still count against pad totals but not against any can on the board.
          </p>
          {report.unassignedSiloRuns.map((r) => {
            const wellObj = config.wells.find((w) => w.id === r.wellId);
            const tone = sandClasses(r.sandType, config.sandTypes);
            return (
              <div
                key={r.id}
                className="flex flex-wrap items-center justify-between gap-2 rounded-md bg-elevated p-3 ring-danger-1"
              >
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-medium">{wellObj?.name || 'Well'}</span>
                    <span className="badge">
                      Stage <span className="num">{r.stageNumber}</span>
                    </span>
                    <span className="badge badge-danger">
                      Silo <span className="num">#{r.siloNumber}</span> not configured
                    </span>
                    <span className="num text-xs text-muted">{r.date}</span>
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-xs text-muted">
                    <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                    {r.sandType}
                  </div>
                </div>
                <div className="num shrink-0 text-sm font-semibold">{formatLbs(r.lbsPulled)}</div>
              </div>
            );
          })}
        </CappedList>
      </CheckCard>

      {/* ------------------------------------- 8. ticket scan test --- */}
      <div className="card">
        <div className="card-hd">
          <div className="flex min-w-0 items-start gap-2.5">
            <ScanLine className="mt-0.5 size-5 shrink-0 text-muted" />
            <div className="min-w-0">
              <div className="eyebrow">Check 8</div>
              <h2 className="text-base font-medium tracking-tight">Ticket scan test</h2>
              <p className="text-xs text-muted">
                Reads a barcode and dumps the raw payload, the format and what the parser made of
                it. Nothing is saved.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsScannerOpen(true)}
            className="btn btn-accent tap shrink-0"
          >
            <QrCode className="size-4" /> Test scan
          </button>
        </div>

        {testScanResult && parsedTestScan ? (
          <div className="flex flex-col gap-3 rounded-md bg-elevated p-3 ring-accent-1">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="eyebrow flex items-center gap-1.5 text-accent">
                <CheckCircle2 className="size-3.5 text-ok" /> Scan result
              </span>
              <div className="flex flex-wrap items-center gap-1.5">
                {testScanResult.winningScale && (
                  <span className="badge badge-ok">Scale {testScanResult.winningScale}</span>
                )}
                {testScanResult.engine && <span className="badge">{testScanResult.engine}</span>}
                <span className="badge badge-accent">Format {testScanResult.format}</span>
              </div>
            </div>

            <div>
              <div className="eyebrow">Raw decoded value</div>
              <div className="num mt-1 select-all break-all rounded-sm bg-surface p-3 text-sm">
                {testScanResult.rawValue}
              </div>
            </div>

            <div>
              <div className="eyebrow">Parsed fields</div>
              <div className="mt-1 rounded-sm bg-surface p-3">
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
                  <div>
                    <div className="eyebrow">Ticket</div>
                    <div className="num text-sm">{parsedTestScan.ticketNumber || '—'}</div>
                  </div>
                  <div>
                    <div className="eyebrow">Weight</div>
                    <div className="num text-sm">
                      {parsedTestScan.lbs ? `${parsedTestScan.lbs.toLocaleString()} lbs` : '—'}
                    </div>
                  </div>
                  <div className="min-w-0">
                    <div className="eyebrow">Carrier</div>
                    <div className="truncate text-sm">{parsedTestScan.carrier || '—'}</div>
                  </div>
                  <div className="min-w-0">
                    <div className="eyebrow">Truck</div>
                    <div className="num truncate text-sm">{parsedTestScan.truck || '—'}</div>
                  </div>
                  <div className="min-w-0">
                    <div className="eyebrow">PO</div>
                    <div className="num truncate text-sm">{parsedTestScan.poNumber || '—'}</div>
                  </div>
                  <div className="min-w-0">
                    <div className="eyebrow">Mine code</div>
                    <div className="num truncate text-sm">{parsedTestScan.productCode || '—'}</div>
                  </div>
                </div>

                {parsedTestScan.matchedSandType && (
                  <div className="mt-3 flex items-center gap-1.5 border-t border-border pt-2.5 text-sm text-ok">
                    <CheckCircle2 className="size-4 shrink-0" />
                    Auto-matched sand type: {parsedTestScan.matchedSandType}
                  </div>
                )}
              </div>
            </div>

            <p className="text-xs text-muted">This diagnostic scan saved nothing.</p>
          </div>
        ) : (
          <div className="rounded-md bg-elevated px-3 py-2.5 text-sm text-muted">
            Run a test scan to inspect a ticket's raw barcode format before trusting auto-fill on
            it.
          </div>
        )}
      </div>

      {/* ---------------------------------- 9. recovery launcher --- */}
      <div className="card">
        <div className="card-hd">
          <div className="flex min-w-0 items-start gap-2.5">
            <Sparkles className="mt-0.5 size-5 shrink-0 text-muted" />
            <div className="min-w-0">
              <div className="eyebrow">Check 9</div>
              <h2 className="text-base font-medium tracking-tight">
                Well and sand data recovery
              </h2>
              <p className="text-xs text-muted">
                Rebuild well names, sand types and silo assignments from logged tickets and runs,
                another database pad, or a device snapshot.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setIsRecoveryOpen(true)}
            className="btn btn-accent tap shrink-0"
          >
            <Sparkles className="size-4" /> Open recovery
          </button>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 rounded-md bg-elevated px-3 py-2.5">
          <span className="text-sm text-muted">
            <span className="num">{deliveries.length}</span> active tickets and{' '}
            <span className="num">{runs.length}</span> runs are available to reconstruct from.
          </span>
          <button
            type="button"
            onClick={() => setIsRecoveryOpen(true)}
            className="btn btn-ghost tap shrink-0"
          >
            Launch recovery <ArrowRight className="size-4" />
          </button>
        </div>
      </div>

      <TicketScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleTestScan}
        title="Diagnostic ticket scan"
      />

      <PadRecoveryModal
        isOpen={isRecoveryOpen}
        onClose={() => setIsRecoveryOpen(false)}
        state={state}
        onSelectPad={onSelectPad}
      />
    </div>
  );
}

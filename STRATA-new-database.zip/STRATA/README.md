# STRATA — Sand Command

Real-time frac sand tracking for well pad crews. Live silo levels, an automatic
pull-order carousel, printable stage pull sheets, barcode and AI ticket capture,
burn-rate forecasting, and natural-language questions answered against live pad
state.

Built as a Google AI Studio applet: Vite + React 19 + Tailwind v4 + Firebase
Firestore, with an Express server that does two things — serve the app and proxy
Gemini server-side.

---

## Getting it running

### 0. Point it at a database

`firebase-applet-config.json` ships with `REPLACE_WITH_...` placeholders on
purpose. The app refuses to connect until they are filled in, so an import or a
fork cannot silently attach itself to a live job and start writing tickets into
it. Fill it in from **Firebase console -> Project settings -> Your apps -> SDK
setup and configuration**, and set `firestoreDatabaseId` to `(default)` unless
you deliberately created a named database.

Until it is filled in the app shows: *"No database is connected yet -- fill in
firebase-applet-config.json with the new Firebase project details."*

### 1. Enable Anonymous sign-in in Firebase

The app authenticates every device anonymously so a gate guard on a shared
tablet never sees a login form. This has to be switched on once:

1. Open [console.firebase.google.com](https://console.firebase.google.com/) and
   select the project named in `firebase-applet-config.json`.
2. **Build → Authentication → Sign-in method**.
3. Under **Native providers**, click **Anonymous**, toggle **Enable**, **Save**.

Until this is on, the app shows a red banner reading *"Can't reach the database
— check that Anonymous sign-in is enabled in Firebase."*

### 2. Publish the security rules

```
firebase deploy --only firestore:rules,storage:rules
```

`firestore.rules` and `storage.rules` are not optional. The defaults Firebase
ships, and the rules the previous build used, allow any anonymous session to
read, rewrite and permanently delete every customer's job. See **Security**
below.

### 3. Add the Gemini key (optional)

`GEMINI_API_KEY` in the AI Studio **Secrets** panel. Two features use it, and
both degrade cleanly to nothing when it is absent:

- **Ticket vision OCR** — reads a ticket whose barcode is smeared, folded,
  sun-bleached or simply not there.
- **Ask the pad** — ⌘K, then type a question.

### Commands

```
npm run dev     # tsx server.ts — Vite middleware + the Gemini proxy on :3000
npm run build   # vite build, then esbuild the server to dist/server.cjs
npm start       # node dist/server.cjs
npm test        # vitest — 27 cases over the rotation and reliability logic
npm run lint    # tsc --noEmit
```

---

## How the app is put together

```
src/lib/sandRules.ts    Domain truth. On-hand balances, the pull-order
                        carousel, stage completion, the zipper rotation,
                        job-design cross-checks. 1,070 lines, 27 tests.
                        Nothing above it may recompute what it exposes.

src/lib/analytics.ts    Derived and forward-looking: burn rate, days of cover,
                        forecast, shift report, silo suggestion, pad alerts.
                        Reads sandRules; never the raw ledger where a rule
                        already answers the question.

src/lib/theme.ts        The single source of truth for sand-type colors.

src/lib/gemini.ts       Client side of the Gemini proxy, plus buildPadSnapshot.

src/lib/firestoreService.ts   All reads and writes. Transactions, soft delete,
                              the offline queue integration, archiving.

src/components/         Views. Presentation only — every figure comes from
                        sandRules or analytics through a useMemo.
```

The screens all read from the same two layers, so the CSV export, the printed
pull sheet, the dashboard and an AI answer cannot disagree with each other.

### Views

| View | What it answers |
|---|---|
| Command center | What is the state of this pad right now |
| Silo board | What is in each can, and what pulls next |
| Stage pull sheet | Exactly what to pull, in what order — printable |
| Ticket entry | Log an inbound load |
| Record run | Log a stage pull manually |
| Stage progress | How far through the wells we are |
| Job design | Delivered and pumped against the frac design |
| Forecast | Burn rate, days of cover, how many trucks to order |
| Activity log | Every ticket and run, searchable, with a restore bin |
| Diagnostics | Nine integrity audits over the live ledger |
| Pad setup | Wells, sand types, silos, suppliers, product codes |

**⌘K / Ctrl-K** opens the command palette from anywhere: jump to a view, or ask
a question about the pad.

### URL modes

| Parameter | Effect |
|---|---|
| `?pad=<id>` | Open a specific job |
| `?well=<id>&stage=<n>` | Pinned read-only pull sheet — the link to text a crew |
| `?mode=entry` | Kiosk ticket entry: one screen, huge targets, nothing else |

---

## Design

The whole design system is `src/index.css` — tokens in `@theme`, primitives in
`@layer components`. `STYLE_GUIDE.md` is the contract; read it before touching a
component.

A warm olive-shifted dark palette, committed to (there is no light mode; the
print stylesheet is the second theme). Barlow for labels, IBM Plex Mono with
`tabular-nums` for **every** quantity, so columns never jitter. Borders are
0-blur box-shadows, which means a status change is a swap of one property with
no layout impact.

Two colors are deliberately scarce:

- **critical** (`#e8b44a`) — the number a crew acts on. PULL LBS, a shortage
  amount. At most one or two per screen.
- **locked** (`#9a86c4`) — a manual pull-order override. Never a warning; a
  pinned silo is a decision someone made, not a problem.

Touch targets are 44px minimum, 52px for primary actions, 64px for the kiosk
scan and save buttons. Gloves, glare, one hand, a moving truck.

---

## Security

`firestore.rules` keeps anonymous auth but closes the destructive holes:

- **Nothing is deletable from the client.** Tickets and runs soft-delete and
  stay auditable; pads archive rather than disappear. Destroying a job's ledger
  is now a console operation.
- **Every write is shape- and range-checked**, so a stale build or a curl loop
  cannot poison a silo balance with a string or a 40-million-pound ticket.
- **Immutable fields stay immutable** — a ticket's number and its `createdAt`.
  The silo *is* editable, because entering a load against the wrong can is the
  most common field mistake and Log → Edit exists to fix it.
- **The duplicate-ticket index is create-only**, which is what makes duplicate
  detection actually hold.

`storage.rules` allows one JPEG per ticket under 2 MB, and no deletes.

**What this is not:** a tenancy model. Anyone with the URL can still *read*
every pad in the project. If jobs need to be isolated from each other, that
requires real identity — the `oAuthClientId` is already provisioned in
`firebase-applet-config.json`, and the `editedBy` / `deletedBy` fields are
already threaded through every write path waiting to be populated.

---

## Things worth knowing before you change something

**Dates are the pad's, not the device's.** Everything routes through
`dateUtils.ts` and `America/Chicago`. A ticket logged at 01:18 belongs to the
night shift's operational date, and date arithmetic is noon-anchored so DST
cannot shift a day.

**Run ids are deterministic.** `run_{wellId}_stg_{n}_silo_{n}_{submissionId}_{seq}`
written with `merge: true`. Re-submitting a stage is idempotent by construction
rather than by a guard that can be raced.

**Manual pull-order pins clear only when a stage actually completes.** Clearing
them on a partial pull makes the carousel jump mid-stage.

**Burn rate averages over pumping days, not calendar days.** A pad down on
Sunday should not report a lower burn. Below three pumping days the forecast
marks itself provisional and refuses to print a projected-empty date — a rate
from one catch-up shift would put "order 600 trucks" in front of a coordinator
who is fine.

**The scanner is a three-tier ladder.** Native `BarcodeDetector` and ZXing WASM
across nine downscale rungs × three preprocessing passes (grayscale, CLAHE,
Otsu) — thermal paper decodes at one specific scale and you cannot predict
which. Then Gemini Vision. Then manual entry. Nothing past tier one is ever
auto-committed; everything routes through the confirmation modal, and
`scanMetadata` records which rung and which engine produced the number.

**Sand colors come from `theme.ts` and nowhere else.** The previous build
inferred them from name substrings in three files with three different rules, so
40/70 rendered blue on one screen and emerald on another. On a pull sheet that
is a safety problem, not a style one.

**Photos go to Cloud Storage.** A base64 data URL in a Firestore document
exceeds the 1 MiB limit, and the failure used to cascade: the write failed, the
ticket fell into the offline queue, and it died there after five silent retries.

**The offline queue auto-flushes** on `window` `online`, on enqueue, and on a
backed-off timer. Queued deliveries go through the same duplicate transaction as
online ones. A write that permanently fails now names itself in the banner
instead of vanishing into a console warning.

---

## Sample data

**Setup → Pad manager → One-click restore** rebuilds University 40E: two wells
at 86 stages, six silos, 688 tickets and 184 runs. It is lazily imported, so the
176 KB of sample job data is not in the initial bundle.

`Setup → Export` writes a JSON job package that round-trips through
**Import backup package**, so a job can be backed up and restored whole.

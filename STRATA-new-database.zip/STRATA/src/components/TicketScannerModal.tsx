import React, { useEffect, useRef, useState } from 'react';
import {
  Camera,
  X,
  Zap,
  ZapOff,
  ShieldAlert,
  AlertTriangle,
  Keyboard,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { prepareZXingModule, readBarcodes, type ReaderOptions } from 'zxing-wasm/reader';
import zxingWasmUrl from 'zxing-wasm/reader/zxing_reader.wasm?url';
import { toGrayscale, applyCLAHE, applyOtsuThreshold } from '../lib/imagePreprocessing';
import { ParsedTicketScan, normalizeTicketNumber, selectBestCandidate } from '../lib/ticketUtils';
import { isGeminiAvailable, readTicketFromImage, type VisionTicketRead } from '../lib/gemini';
import { ProductCodeMapping } from '../types';

// Pre-configure WASM loading to always use the local bundled wasm binary (no CDN/network)
if (typeof window !== 'undefined') {
  try {
    prepareZXingModule({
      overrides: {
        locateFile: (path: string, prefix: string) => {
          if (path.endsWith('.wasm')) {
            return zxingWasmUrl;
          }
          return prefix + path;
        },
      },
    });
  } catch (err) {
    console.warn('ZXing WASM initialization error:', err);
  }
}

export interface ScanResult {
  rawValue: string;
  format: string;
  parsed: ParsedTicketScan;
  candidates?: ParsedTicketScan[];
  isAmbiguous?: boolean;
  winningScale?: string;
  engine?: string;
  /**
   * How the number actually got here. The forensic trail is the point: a
   * ticket read off a still photo by a vision model is not the same evidence
   * as one decoded off the live viewfinder, and the record should say so.
   * Callers previously hardcoded 'camera' for every path.
   */
  method?: 'camera' | 'photo';
}

interface TicketScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (result: ScanResult) => void;
  title?: string;
  mappings?: ProductCodeMapping[];
}

// 9-rung ladder on long edge for still photos
const PHOTO_LADDER_RUNGS = [1600, 1400, 1200, 1000, 900, 800, 700, 600, 500];

/**
 * Preprocessing passes tried at each photo rung, cheapest first.
 *
 * Otsu binarisation was written and then never called. It earns its place
 * here: thermal paper that has darkened in a truck cab produces a genuinely
 * bimodal histogram, which is the exact case Otsu solves and the one CLAHE's
 * local equalisation handles worst. 9 rungs x 3 passes = 27 attempts.
 */
const PHOTO_PASSES: { label: string; run: (d: ImageData) => ImageData }[] = [
  { label: 'Grayscale', run: (d) => toGrayscale(d) },
  { label: 'CLAHE Contrast', run: (d) => applyCLAHE(d, 3.0, 8, 8) },
  { label: 'Otsu Threshold', run: (d) => applyOtsuThreshold(d) },
];
const PHOTO_ATTEMPT_TOTAL = PHOTO_LADDER_RUNGS.length * PHOTO_PASSES.length;

// Live video scale ladder (cycled across successive frames for speed & coverage)
const VIDEO_LADDER_RUNGS = [1200, 1000, 900, 800, 700, 600, 500, 400];

// Support multiple barcode and 2D formats as specified in Bug 9
const readerOptions: ReaderOptions = {
  formats: ['QRCode', 'Code128', 'Code39', 'DataMatrix', 'PDF417'],
  tryHarder: true,
  tryRotate: true,
  tryInvert: true,
  maxNumberOfSymbols: 8,
};

const NATIVE_FORMATS = ['qr_code', 'code_128', 'code_39', 'data_matrix', 'pdf417'];

export default function TicketScannerModal({
  isOpen,
  onClose,
  onScan,
  title = 'SCAN SAND TICKET',
  mappings = [],
}: TicketScannerModalProps) {
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [hasTorch, setHasTorch] = useState<boolean>(false);
  const [isTorchOn, setIsTorchOn] = useState<boolean>(false);
  const [isInitializing, setIsInitializing] = useState<boolean>(true);
  const [showScanHint, setShowScanHint] = useState<boolean>(false);
  const [engineName, setEngineName] = useState<string>('ZXing WASM (C++ Engine)');
  const [currentLiveRung, setCurrentLiveRung] = useState<number>(800);
  const [lastDebugInfo, setLastDebugInfo] = useState<{ scale: string; rawValue: string; engine: string } | null>(null);
  const [isDecodingPhoto, setIsDecodingPhoto] = useState<boolean>(false);
  const [photoStepInfo, setPhotoStepInfo] = useState<string>('');
  const [photoDecodeError, setPhotoDecodeError] = useState<string | null>(null);

  /* --- Tier 3: vision OCR. Only ever offered on a PHOTO whose barcode ladder
     has already failed, and only when the server has a Gemini key. When it is
     not configured the button never renders — no dead affordance. --- */
  const [geminiAvailable, setGeminiAvailable] = useState<boolean>(false);
  const [lastPhoto, setLastPhoto] = useState<{ dataUrl: string; mimeType: string } | null>(null);
  const [isReadingWithAI, setIsReadingWithAI] = useState<boolean>(false);
  const [aiRead, setAiRead] = useState<VisionTicketRead | null>(null);
  const [aiError, setAiError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const hintTimerRef = useRef<NodeJS.Timeout | null>(null);
  const barcodeDetectorRef = useRef<any>(null);
  const isDetectingFrameRef = useRef<boolean>(false);
  const isScanProcessingRef = useRef<boolean>(false);
  const lastRawValueRef = useRef<string>('');
  const lastScanTimeRef = useRef<number>(0);
  const ladderIndexRef = useRef<number>(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const scannerActiveRef = useRef<boolean>(false);

  useEffect(() => {
    if (!isOpen) {
      scannerActiveRef.current = false;
      stopCamera();
      return;
    }

    scannerActiveRef.current = true;
    setCameraError(null);
    setIsInitializing(true);
    setHasTorch(false);
    setIsTorchOn(false);
    setShowScanHint(false);
    setPhotoDecodeError(null);
    setIsDecodingPhoto(false);
    setPhotoStepInfo('');
    setLastPhoto(null);
    setAiRead(null);
    setAiError(null);
    setIsReadingWithAI(false);
    ladderIndexRef.current = 0;
    isScanProcessingRef.current = false;
    isDetectingFrameRef.current = false;

    // Check if BarcodeDetector is available natively in browser
    if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
      try {
        const detector = new (window as any).BarcodeDetector({ formats: NATIVE_FORMATS });
        barcodeDetectorRef.current = detector;
        setEngineName('BarcodeDetector (Native) + ZXing WASM');
      } catch (err) {
        barcodeDetectorRef.current = null;
        setEngineName('ZXing WASM (Bundled C++)');
      }
    } else {
      barcodeDetectorRef.current = null;
      setEngineName('ZXing WASM (Bundled C++)');
    }

    // Start 5-second timer for helpful scan hint if scan takes long
    hintTimerRef.current = setTimeout(() => {
      if (scannerActiveRef.current) {
        setShowScanHint(true);
      }
    }, 5000);

    // Is vision OCR configured on the server? Cached in gemini.ts; a failure
    // here just means the button never appears.
    isGeminiAvailable()
      .then((ok) => {
        if (scannerActiveRef.current) setGeminiAvailable(ok);
      })
      .catch(() => setGeminiAvailable(false));

    // Start Video Stream
    startCamera();

    return () => {
      scannerActiveRef.current = false;
      stopCamera();
    };
  }, [isOpen]);

  const startCamera = async () => {
    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
          focusMode: { ideal: 'continuous' },
          advanced: [{ focusMode: 'continuous' }],
        } as unknown as MediaTrackConstraints,
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      if (!scannerActiveRef.current) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      streamRef.current = stream;

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
        if (!scannerActiveRef.current) return;
        setIsInitializing(false);

        // Check Torch capability
        const track = stream.getVideoTracks()[0];
        if (track) {
          const capabilities = track.getCapabilities ? (track.getCapabilities() as unknown as { torch?: boolean }) : {};
          if (capabilities.torch) {
            setHasTorch(true);
          }
        }

        // Start processing loop
        animFrameRef.current = requestAnimationFrame(processVideoFrame);
      }
    } catch (err) {
      if (!scannerActiveRef.current) return;
      setIsInitializing(false);
      console.error('Camera startup error:', err);
      setCameraError(
        'Camera access was denied or is unavailable. Use TAKE A PHOTO INSTEAD below or check permissions.'
      );
    }
  };

  const stopCamera = () => {
    scannerActiveRef.current = false;
    if (hintTimerRef.current) {
      clearTimeout(hintTimerRef.current);
      hintTimerRef.current = null;
    }
    if (animFrameRef.current) {
      cancelAnimationFrame(animFrameRef.current);
      animFrameRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => {
        try {
          track.stop();
        } catch (_) {}
      });
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  };

  // Helper to handle winning candidate(s)
  const handleWinningCandidates = (
    rawCandidates: { rawValue: string; format?: string }[],
    winningScale: string,
    engine: string,
    method: 'camera' | 'photo'
  ): boolean => {
    if (!scannerActiveRef.current) return false;
    if (!rawCandidates || rawCandidates.length === 0) return false;

    const bestResult = selectBestCandidate(rawCandidates, mappings);
    if (!bestResult.selected) return false;

    const rawJoined = rawCandidates.map((c) => c.rawValue).join(';');
    const now = Date.now();

    // Debounce duplicate identical scans within 1500ms
    if (lastRawValueRef.current === rawJoined && now - lastScanTimeRef.current < 1500) {
      return false;
    }

    lastRawValueRef.current = rawJoined;
    lastScanTimeRef.current = now;

    // Scan lock: prevent repeated frame processing
    isScanProcessingRef.current = true;

    if (scannerActiveRef.current) {
      setLastDebugInfo({
        scale: winningScale,
        rawValue: bestResult.selected.ticketNumber
          ? `#${bestResult.selected.ticketNumber}`
          : bestResult.selected.rawValue,
        engine,
      });
    }

    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate([100, 50, 100]);
      } catch (e) {}
    }

    stopCamera();

    onScan({
      rawValue: bestResult.selected.rawValue,
      format: bestResult.selected.format || 'QR_CODE',
      parsed: bestResult.selected,
      candidates: bestResult.candidates,
      isAmbiguous: bestResult.isAmbiguous,
      winningScale,
      engine,
      method,
    });

    return true;
  };

  // Live video frame processing: Cycles one ladder rung per frame
  const processVideoFrame = async () => {
    if (!scannerActiveRef.current) return;
    if (isScanProcessingRef.current) return;

    const video = videoRef.current;
    const detector = barcodeDetectorRef.current;

    if (!video || video.readyState !== video.HAVE_ENOUGH_DATA) {
      if (scannerActiveRef.current && !isScanProcessingRef.current) {
        animFrameRef.current = requestAnimationFrame(processVideoFrame);
      }
      return;
    }

    if (isDetectingFrameRef.current) {
      if (scannerActiveRef.current && !isScanProcessingRef.current) {
        animFrameRef.current = requestAnimationFrame(processVideoFrame);
      }
      return;
    }

    const vw = video.videoWidth;
    const vh = video.videoHeight;
    if (vw === 0 || vh === 0) {
      if (scannerActiveRef.current && !isScanProcessingRef.current) {
        animFrameRef.current = requestAnimationFrame(processVideoFrame);
      }
      return;
    }

    // Tighter guide box: 45% of narrower dimension
    const cropSize = Math.floor(Math.min(vw, vh) * 0.45);
    const sx = Math.floor((vw - cropSize) / 2);
    const sy = Math.floor((vh - cropSize) / 2);

    isDetectingFrameRef.current = true;

    try {
      if (!scannerActiveRef.current) return;

      // Pass 1: Browser Native BarcodeDetector (if supported)
      if (detector) {
        try {
          const codes = await detector.detect(video);
          if (codes && codes.length > 0) {
            const rawCandidates = codes
              .filter((c: any) => c && c.rawValue)
              .map((c: any) => ({ rawValue: c.rawValue, format: c.format || 'qr_code' }));

            if (rawCandidates.length > 0) {
              const handled = handleWinningCandidates(
                rawCandidates,
                'Full Native Video',
                'BarcodeDetector (Native)',
                'camera'
              );
              if (handled) return;
            }
          }
        } catch (err) {
          // Continue to ZXing WASM fallback
        }
      }

      if (!scannerActiveRef.current) return;

      // Pass 2: ZXing WASM Ladder — 1 rung per frame
      const currentRung = VIDEO_LADDER_RUNGS[ladderIndexRef.current];
      ladderIndexRef.current = (ladderIndexRef.current + 1) % VIDEO_LADDER_RUNGS.length;
      if (scannerActiveRef.current) {
        setCurrentLiveRung(currentRung);
      }

      if (!canvasRef.current) {
        canvasRef.current = document.createElement('canvas');
      }
      const canvas = canvasRef.current;
      canvas.width = currentRung;
      canvas.height = currentRung;
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      if (ctx) {
        // Draw 45% tight crop scaled to current ladder rung
        ctx.drawImage(video, sx, sy, cropSize, cropSize, 0, 0, currentRung, currentRung);
        const rawImgData = ctx.getImageData(0, 0, currentRung, currentRung);

        // Attempt 1: Grayscale on this rung
        const grayData = toGrayscale(rawImgData);
        let results = await readBarcodes(grayData, readerOptions);

        if (!scannerActiveRef.current) return;

        // Attempt 2: If grayscale fails on this frame, try CLAHE contrast
        if (!results || results.length === 0 || !results.some((r) => r.text)) {
          const claheData = applyCLAHE(rawImgData, 3.0, 8, 8);
          results = await readBarcodes(claheData, readerOptions);
        }

        if (!scannerActiveRef.current) return;

        // Check if barcodes/QR codes decoded successfully
        if (results && results.length > 0) {
          const rawCandidates = results
            .filter((r) => r && r.text)
            .map((r) => ({ rawValue: r.text, format: r.format || 'QRCode' }));

          if (rawCandidates.length > 0) {
            const handled = handleWinningCandidates(
              rawCandidates,
              `${currentRung}px (45% Crop)`,
              'ZXing WASM',
              'camera'
            );
            if (handled) return;
          }
        }
      }
    } catch (err) {
      console.warn('Frame decode error:', err);
    } finally {
      isDetectingFrameRef.current = false;
    }

    if (scannerActiveRef.current && !isScanProcessingRef.current) {
      animFrameRef.current = requestAnimationFrame(processVideoFrame);
    }
  };

  /**
   * PHOTO PATH — tier 1 and 2, then the handoff to tier 3.
   *
   *   1. Native BarcodeDetector on the full-resolution photo.
   *   2. ZXing WASM scale ladder: 9 rungs x 3 preprocessing passes.
   *   3. If BOTH fail, the photo is kept in state and "Read the ticket with
   *      AI" is offered — see handleReadWithAI. It is never automatic: an
   *      unattended model read of a delivery weight is exactly the thing this
   *      app must not do.
   */
  const handlePhotoFallbackSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsDecodingPhoto(true);
    setPhotoDecodeError(null);
    setAiRead(null);
    setAiError(null);
    setLastPhoto(null);
    setPhotoStepInfo('Loading image...');

    // Reset the input so picking the SAME file again re-fires onChange —
    // otherwise "Retake photo" is dead after one failed attempt.
    const inputEl = e.target;

    try {
      // Read once as a data URL: the ladder needs an <img>, and if the ladder
      // fails, tier 3 needs the same bytes without asking for the photo again.
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Could not read the photo file'));
        reader.readAsDataURL(file);
      });

      const img = new Image();
      img.src = dataUrl;
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = () => reject(new Error('Could not load image file'));
      });

      const origW = img.naturalWidth || img.width || 1200;
      const origH = img.naturalHeight || img.height || 1200;
      const maxEdge = Math.max(origW, origH);

      // 1. Native BarcodeDetector first on full photo if available
      if (typeof window !== 'undefined' && 'BarcodeDetector' in window) {
        setPhotoStepInfo('Trying Native BarcodeDetector...');
        try {
          const detector = new (window as any).BarcodeDetector({ formats: NATIVE_FORMATS });
          const codes = await detector.detect(img);
          if (codes && codes.length > 0) {
            const rawCandidates = codes
              .filter((c: any) => c && c.rawValue)
              .map((c: any) => ({ rawValue: c.rawValue, format: c.format || 'qr_code' }));

            if (rawCandidates.length > 0) {
              const handled = handleWinningCandidates(
                rawCandidates,
                `Native Full Res (${origW}x${origH})`,
                'BarcodeDetector (Native)',
                'photo'
              );
              if (handled) {
                setIsDecodingPhoto(false);
                return;
              }
            }
          }
        } catch (err) {
          console.warn('Native photo detect failed, starting ZXing WASM ladder:', err);
        }
      }

      // 2. ZXing WASM ladder: every rung x every preprocessing pass, stopping
      //    at the first success.
      const workCanvas = document.createElement('canvas');
      const workCtx = workCanvas.getContext('2d', { willReadFrequently: true });
      if (!workCtx) throw new Error('Could not create canvas context');

      let totalAttempts = 0;
      for (const rung of PHOTO_LADDER_RUNGS) {
        const scale = rung / maxEdge;
        const targetW = Math.max(1, Math.round(origW * scale));
        const targetH = Math.max(1, Math.round(origH * scale));

        workCanvas.width = targetW;
        workCanvas.height = targetH;
        workCtx.drawImage(img, 0, 0, targetW, targetH);
        const rawImgData = workCtx.getImageData(0, 0, targetW, targetH);

        for (const pass of PHOTO_PASSES) {
          totalAttempts++;
          setPhotoStepInfo(
            `Testing ladder rung ${rung}px (${pass.label}) [${totalAttempts}/${PHOTO_ATTEMPT_TOTAL}]...`
          );

          const results = await readBarcodes(pass.run(rawImgData), readerOptions);
          if (!results || results.length === 0) continue;

          const rawCandidates = results
            .filter((r) => r && r.text)
            .map((r) => ({ rawValue: r.text, format: r.format || 'QRCode' }));

          if (rawCandidates.length > 0) {
            const handled = handleWinningCandidates(
              rawCandidates,
              `${rung}px long-edge (${pass.label})`,
              'ZXing WASM',
              'photo'
            );
            if (handled) {
              setIsDecodingPhoto(false);
              return;
            }
          }
        }
      }

      // 3. Both barcode tiers are out. Hold the photo so vision OCR can be
      //    offered on it without a second trip to the camera.
      setLastPhoto({ dataUrl, mimeType: file.type || 'image/jpeg' });
      setPhotoDecodeError(
        `No barcode or QR code found in ${PHOTO_ATTEMPT_TOTAL} scale and contrast attempts (1600px - 500px). The code may be smeared, folded, sun-bleached or simply absent.`
      );
    } catch (err: any) {
      console.error('Error decoding photo:', err);
      setPhotoDecodeError(err?.message || 'Failed to process photo file.');
    } finally {
      setIsDecodingPhoto(false);
      try {
        inputEl.value = '';
      } catch (_) {}
    }
  };

  /* ------------------------------------------------- tier 3: vision OCR --- */

  const handleReadWithAI = async () => {
    if (!lastPhoto) return;
    setIsReadingWithAI(true);
    setAiError(null);
    setAiRead(null);
    try {
      const read = await readTicketFromImage(lastPhoto.dataUrl, lastPhoto.mimeType);
      setAiRead(read);
    } catch (err: any) {
      console.error('Gemini ticket read failed:', err);
      setAiError(err?.message || 'The AI read failed. Type the ticket number instead.');
    } finally {
      setIsReadingWithAI(false);
    }
  };

  /**
   * Hand a vision read to the operator for confirmation.
   *
   * Deliberately mapped so it can NEVER be auto-applied: `parser: 'unknown'`,
   * and the model's own "high" is downgraded to 'probable' while medium and
   * low become 'unknown'. Neither value is 'confirmed', and both AddDelivery
   * and QuickEntry route anything short of 'confirmed' through
   * ScanConfirmationModal — so a model reading always passes under a human eye
   * before it touches a silo balance.
   */
  const applyAiRead = () => {
    if (!aiRead) return;

    const ticketNumber = aiRead.ticketNumber
      ? normalizeTicketNumber(aiRead.ticketNumber)
      : undefined;
    const weightLbs =
      typeof aiRead.weightLbs === 'number' && aiRead.weightLbs > 0 ? aiRead.weightLbs : undefined;

    const productCode = aiRead.productCode?.trim() || undefined;
    const matchedSandType =
      productCode && mappings.length > 0
        ? mappings.find((m) => m.mineCode.trim().toLowerCase() === productCode.toLowerCase())
            ?.sandType || null
        : null;

    const summary = [
      ticketNumber ? `Ticket ${ticketNumber}` : 'Ticket not legible',
      weightLbs ? `${weightLbs.toLocaleString()} lbs` : null,
      productCode || aiRead.sandDescription || null,
      aiRead.carrier || aiRead.supplier || null,
    ]
      .filter(Boolean)
      .join(' · ');

    const parsed: ParsedTicketScan = {
      rawValue: `Gemini Vision read — ${summary}`,
      ticketNumber,
      weightLbs,
      lbs: weightLbs ?? null,
      productCode: productCode ?? null,
      supplier: aiRead.supplier?.trim() || null,
      carrier: aiRead.carrier?.trim() || null,
      truck: aiRead.truck?.trim() || null,
      poNumber: aiRead.poNumber?.trim() || null,
      matchedSandType,
      confidence: aiRead.confidence === 'high' ? 'probable' : 'unknown',
      parser: 'unknown',
      isSixPartAtlas: false,
      format: 'AI_VISION',
      warning: aiRead.notes?.trim() || undefined,
    };

    stopCamera();
    onScan({
      rawValue: parsed.rawValue,
      format: 'AI_VISION',
      parsed,
      candidates: [parsed],
      isAmbiguous: false,
      winningScale: 'Full photo (vision OCR)',
      engine: 'Gemini Vision',
      method: 'photo',
    });
  };

  const toggleTorch = async () => {
    if (!streamRef.current || !hasTorch) return;
    try {
      const track = streamRef.current.getVideoTracks()[0];
      if (track) {
        const nextState = !isTorchOn;
        await track.applyConstraints({
          advanced: [{ torch: nextState } as unknown as MediaTrackConstraintSet],
        });
        setIsTorchOn(nextState);
      }
    } catch (err) {
      console.warn('Torch toggle failed:', err);
    }
  };

  const handleClose = () => {
    stopCamera();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/95 flex flex-col justify-between text-white p-4 overflow-hidden selection:bg-amber-500 selection:text-slate-950">
      {/* Top Bar */}
      <div className="flex items-center justify-between gap-4 max-w-xl mx-auto w-full z-10 pt-2 pb-1">
        <div className="flex items-center gap-2">
          <Camera className="w-6 h-6 text-amber-400" />
          <div>
            <h2 className="text-base sm:text-lg font-black uppercase tracking-wider text-amber-400 font-mono">
              {title}
            </h2>
            {/* Live Engine & Debug Status */}
            <div className="text-[11px] font-mono font-bold text-slate-300 flex items-center gap-1.5 flex-wrap">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
              <span className="text-slate-300">{engineName}</span>
              <span className="text-amber-400 bg-amber-950/80 border border-amber-500/40 px-1.5 py-0.2 rounded text-[10px]">
                Live: {currentLiveRung}px
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasTorch && (
            <button
              type="button"
              onClick={toggleTorch}
              className={`p-3 rounded-2xl font-black text-xs flex items-center gap-2 border transition ${
                isTorchOn
                  ? 'bg-amber-500 text-slate-950 border-amber-300 shadow-lg'
                  : 'bg-slate-800 text-slate-200 border-slate-700 hover:bg-slate-700'
              }`}
              title="Toggle Flashlight / Torch"
            >
              {isTorchOn ? <Zap className="w-5 h-5 fill-slate-950" /> : <ZapOff className="w-5 h-5" />}
              <span>{isTorchOn ? 'FLASH ON' : 'FLASH'}</span>
            </button>
          )}

          <button
            type="button"
            onClick={handleClose}
            className="bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white p-3 rounded-2xl border border-slate-700 flex items-center justify-center transition"
            title="Cancel Scan"
          >
            <X className="w-6 h-6 stroke-[2.5]" />
          </button>
        </div>
      </div>

      {/* Live Decoder Debug Line */}
      {lastDebugInfo && (
        <div className="max-w-xl mx-auto w-full bg-emerald-950/90 border border-emerald-500/60 rounded-xl px-3 py-1.5 text-[11px] font-mono text-emerald-300 flex items-center justify-between gap-2 shadow-lg">
          <div className="flex items-center gap-1.5 truncate">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
            <span className="font-bold text-amber-300">[{lastDebugInfo.scale}]</span>
            <span className="truncate">{lastDebugInfo.rawValue}</span>
          </div>
          <span className="text-[10px] text-emerald-400/80 shrink-0 font-bold">DECODED</span>
        </div>
      )}

      {/* Camera Viewfinder Area */}
      <div className="flex-1 flex flex-col items-center justify-center relative my-2 max-w-xl mx-auto w-full">
        {cameraError ? (
          <div className="bg-slate-900 border-2 border-red-500/80 rounded-3xl p-6 text-center space-y-4 max-w-md w-full shadow-2xl">
            <div className="w-16 h-16 bg-red-600/20 text-red-400 rounded-2xl flex items-center justify-center mx-auto border border-red-500/40">
              <ShieldAlert className="w-10 h-10 stroke-[2.5]" />
            </div>
            <div>
              <h3 className="text-xl font-black uppercase text-red-400">
                LIVE CAMERA UNAVAILABLE
              </h3>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                {cameraError}
              </p>
            </div>
            <div className="space-y-2 pt-2">
              <label className="w-full bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-black py-4 px-4 rounded-2xl shadow-xl uppercase tracking-wider text-sm transition flex items-center justify-center gap-2 cursor-pointer">
                <Camera className="w-5 h-5 stroke-[2.5]" />
                <span>TAKE A PHOTO INSTEAD</span>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoFallbackSelect}
                  className="hidden"
                />
              </label>

              <button
                type="button"
                onClick={handleClose}
                className="w-full bg-slate-800 hover:bg-slate-700 text-white font-black py-3 px-4 rounded-2xl uppercase tracking-wider text-xs transition flex items-center justify-center gap-2"
              >
                <Keyboard className="w-4 h-4" />
                <span>TYPE NUMBER MANUALLY</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="relative w-full h-full max-h-[500px] bg-black rounded-3xl overflow-hidden border-2 border-slate-800 shadow-2xl flex items-center justify-center">
            {/* HTML Video Stream */}
            <video
              ref={videoRef}
              playsInline
              muted
              className="w-full h-full object-cover"
            />

            {/* Target Viewfinder Overlay: 45% tight crop with explicit instruction */}
            <div className="absolute inset-0 pointer-events-none flex flex-col items-center justify-center">
              <div className="w-[200px] h-[200px] max-w-[45%] max-h-[45%] aspect-square border-2 border-amber-400/90 rounded-2xl relative shadow-[0_0_0_9999px_rgba(0,0,0,0.68)]">
                {/* Corner Markers */}
                <div className="absolute -top-1 -left-1 w-6 h-6 border-t-4 border-l-4 border-amber-400 rounded-tl-lg" />
                <div className="absolute -top-1 -right-1 w-6 h-6 border-t-4 border-r-4 border-amber-400 rounded-tr-lg" />
                <div className="absolute -bottom-1 -left-1 w-6 h-6 border-b-4 border-l-4 border-amber-400 rounded-bl-lg" />
                <div className="absolute -bottom-1 -right-1 w-6 h-6 border-b-4 border-r-4 border-amber-400 rounded-br-lg" />

                {/* Laser scan line effect */}
                <div className="absolute left-2 right-2 top-1/2 h-0.5 bg-red-500/80 shadow-[0_0_8px_rgba(239,68,68,1)] animate-pulse" />
              </div>

              <div className="mt-3 bg-slate-900/95 backdrop-blur border-2 border-amber-400/80 text-amber-300 text-xs font-black uppercase tracking-wider px-4 py-1.5 rounded-xl text-center shadow-2xl">
                fill this box with the ticket QR / Barcode
              </div>
            </div>

            {/* Photo decode progress overlay */}
            {isDecodingPhoto && (
              <div className="absolute inset-0 bg-slate-950/95 backdrop-blur-md z-30 flex flex-col items-center justify-center gap-3 p-6 text-center">
                <div className="w-12 h-12 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
                <div className="text-base font-black text-amber-400 uppercase tracking-wide">
                  Processing Photo with Scale Ladder...
                </div>
                <div className="text-xs text-amber-300 font-mono bg-slate-900/90 px-3 py-1.5 rounded-lg border border-slate-700">
                  {photoStepInfo ||
                    `Running ${PHOTO_ATTEMPT_TOTAL}-step ZXing WASM scale & contrast ladder`}
                </div>
                <p className="text-[11px] text-slate-400 max-w-xs">
                  Testing 1600, 1400, 1200, 1000, 900, 800, 700, 600, 500 px with grayscale, CLAHE
                  contrast and Otsu threshold
                </p>
              </div>
            )}

            {/* Photo decode error banner — and the tier-3 handoff */}
            {photoDecodeError && !aiRead && (
              <div className="absolute bottom-4 inset-x-4 bg-red-600 text-white p-4 rounded-2xl border-2 border-red-300 shadow-2xl space-y-2 z-30">
                <div className="flex items-center gap-2 font-black text-xs uppercase">
                  <AlertTriangle className="w-5 h-5 shrink-0 stroke-[2.5]" />
                  <span>{photoDecodeError}</span>
                </div>

                {/* Tier 3. Rendered only when the server actually has a key,
                    so an unconfigured deployment shows no dead button. */}
                {geminiAvailable && lastPhoto && (
                  <button
                    type="button"
                    onClick={handleReadWithAI}
                    disabled={isReadingWithAI}
                    className="w-full bg-slate-950 text-amber-400 border-2 border-amber-400 font-black text-xs py-3 px-3 rounded-xl flex items-center justify-center gap-2 uppercase disabled:opacity-60"
                  >
                    {isReadingWithAI ? (
                      <>
                        <span className="w-4 h-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                        READING THE PRINTED TICKET...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 stroke-[2.5]" />
                        READ THE TICKET WITH AI
                      </>
                    )}
                  </button>
                )}
                {geminiAvailable && lastPhoto && !isReadingWithAI && (
                  <p className="text-[10px] text-red-100 leading-snug">
                    Reads the printed numbers instead of the barcode. You confirm every field
                    before anything is saved.
                  </p>
                )}
                {aiError && (
                  <p className="text-[11px] font-bold bg-red-950 rounded-lg px-2.5 py-1.5">
                    {aiError}
                  </p>
                )}

                <div className="flex items-center gap-2 pt-1">
                  <label className="flex-1 bg-white text-red-700 font-black text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 uppercase cursor-pointer shadow">
                    <Camera className="w-4 h-4" /> RETAKE PHOTO
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handlePhotoFallbackSelect}
                      className="hidden"
                    />
                  </label>
                  <button
                    type="button"
                    onClick={handleClose}
                    className="bg-red-950 text-white font-bold text-xs py-2.5 px-3 rounded-xl border border-red-800 uppercase"
                  >
                    Type it
                  </button>
                </div>
              </div>
            )}

            {/* Vision OCR result — a proposal, never a save. */}
            {aiRead && (
              <div className="absolute bottom-4 inset-x-4 bg-slate-900 text-white p-4 rounded-2xl border-2 border-amber-400 shadow-2xl space-y-3 z-30 max-h-[80%] overflow-y-auto">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 font-black text-xs uppercase text-amber-400">
                    <Sparkles className="w-4 h-4 shrink-0 stroke-[2.5]" />
                    <span>AI read — not saved yet</span>
                  </div>
                  <span
                    className={`text-[10px] font-black uppercase px-2 py-0.5 rounded border ${
                      aiRead.confidence === 'high'
                        ? 'text-emerald-300 border-emerald-500/60 bg-emerald-950/70'
                        : aiRead.confidence === 'medium'
                          ? 'text-amber-300 border-amber-500/60 bg-amber-950/70'
                          : 'text-red-300 border-red-500/60 bg-red-950/70'
                    }`}
                  >
                    {aiRead.confidence} confidence
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 font-mono text-sm">
                  <div className="bg-slate-950/80 rounded-lg px-2.5 py-1.5 border border-slate-700">
                    <div className="text-[10px] uppercase text-slate-400 font-sans">Ticket</div>
                    <div className="text-amber-300 font-bold break-all">
                      {aiRead.ticketNumber || 'not legible'}
                    </div>
                  </div>
                  <div className="bg-slate-950/80 rounded-lg px-2.5 py-1.5 border border-slate-700">
                    <div className="text-[10px] uppercase text-slate-400 font-sans">Net weight</div>
                    <div className="text-amber-300 font-bold">
                      {aiRead.weightLbs ? `${aiRead.weightLbs.toLocaleString()} lbs` : 'not legible'}
                    </div>
                  </div>
                </div>

                {(aiRead.productCode || aiRead.sandDescription || aiRead.carrier) && (
                  <div className="flex flex-wrap gap-1.5 text-[10px] font-mono">
                    {aiRead.productCode && (
                      <span className="bg-slate-950/80 border border-slate-700 rounded px-2 py-0.5">
                        code {aiRead.productCode}
                      </span>
                    )}
                    {aiRead.sandDescription && (
                      <span className="bg-slate-950/80 border border-slate-700 rounded px-2 py-0.5">
                        {aiRead.sandDescription}
                      </span>
                    )}
                    {aiRead.carrier && (
                      <span className="bg-slate-950/80 border border-slate-700 rounded px-2 py-0.5">
                        {aiRead.carrier}
                      </span>
                    )}
                  </div>
                )}

                {/* The model's own caveat, verbatim. It is the most useful
                    thing on this panel when the read is shaky. */}
                {aiRead.notes && aiRead.notes.trim() && (
                  <div className="flex items-start gap-2 bg-amber-950/70 border border-amber-500/50 rounded-lg px-2.5 py-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
                    <p className="text-[11px] text-amber-100 leading-snug">{aiRead.notes}</p>
                  </div>
                )}

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={applyAiRead}
                    className="flex-1 bg-amber-500 text-slate-950 font-black text-xs py-3 px-3 rounded-xl uppercase flex items-center justify-center gap-1.5"
                  >
                    <CheckCircle2 className="w-4 h-4 stroke-[2.5]" />
                    Check it against the paper
                  </button>
                  <button
                    type="button"
                    onClick={() => setAiRead(null)}
                    className="bg-slate-800 text-white font-bold text-xs py-3 px-3 rounded-xl border border-slate-700 uppercase"
                  >
                    Discard
                  </button>
                </div>
              </div>
            )}

            {/* Helpful Scan Hint Banner (if scan takes > 5 seconds) */}
            {showScanHint && !photoDecodeError && !isDecodingPhoto && !aiRead && (
              <div className="absolute bottom-4 inset-x-4 bg-amber-500 text-slate-950 p-4 rounded-2xl border-2 border-amber-300 shadow-2xl space-y-2.5 animate-bounce z-20">
                <div className="flex items-center gap-2 font-black text-xs uppercase">
                  <AlertTriangle className="w-5 h-5 shrink-0 stroke-[2.5]" />
                  <span>Trouble scanning curved thermal paper? Try taking a photo!</span>
                </div>
                <div className="flex items-center gap-2">
                  <label className="flex-1 bg-slate-950 text-amber-400 border-2 border-amber-400 font-black text-xs py-2.5 px-3 rounded-xl flex items-center justify-center gap-1.5 uppercase cursor-pointer shadow-lg">
                    <Camera className="w-4 h-4 stroke-[2.5]" /> TAKE A PHOTO INSTEAD
                    <input
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handlePhotoFallbackSelect}
                      className="hidden"
                    />
                  </label>
                  <button
                    type="button"
                    onClick={handleClose}
                    className="bg-slate-950 text-white font-bold text-xs py-2.5 px-3 rounded-xl border border-slate-700"
                  >
                    TYPE NUMBER
                  </button>
                </div>
              </div>
            )}

            {isInitializing && (
              <div className="absolute inset-0 bg-slate-950 flex items-center justify-center gap-3">
                <div className="w-6 h-6 border-4 border-amber-500 border-t-transparent rounded-full animate-spin" />
                <span className="text-sm font-black uppercase text-amber-400">
                  Starting Camera & ZXing Engine...
                </span>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Bottom Action Controls */}
      <div className="max-w-xl mx-auto w-full z-10 pt-2 pb-3 space-y-2">
        {/* TAKE A PHOTO INSTEAD PROMINENT BUTTON */}
        <label className="w-full bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-slate-950 font-black text-base py-3.5 px-4 rounded-2xl shadow-xl border-2 border-amber-300 flex items-center justify-center gap-2 cursor-pointer transition uppercase tracking-wider">
          <Camera className="w-6 h-6 stroke-[2.5]" />
          <span>TAKE A PHOTO INSTEAD</span>
          <input
            type="file"
            accept="image/*"
            capture="environment"
            onChange={handlePhotoFallbackSelect}
            className="hidden"
          />
        </label>

        <button
          type="button"
          onClick={handleClose}
          className="w-full bg-slate-800 hover:bg-slate-700 active:bg-slate-900 text-white font-black text-sm py-3 rounded-2xl border-2 border-slate-700 transition tracking-wider uppercase flex items-center justify-center gap-2"
        >
          <X className="w-5 h-5 stroke-[2.5]" />
          <span>CANCEL SCAN</span>
        </button>
      </div>
    </div>
  );
}

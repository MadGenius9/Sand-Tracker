/**
 * Field activity logs — the ledger, five ways.
 *
 * Tickets are laid out as one column per silo because the question asked here
 * is almost always "what went into can 4", not "what happened at 14:02". A
 * ticket whose silo is not in the pad config gets its own red UNASSIGNED
 * column rather than being dropped: a load nobody can see is a load nobody
 * will fix.
 *
 * Every filter is memoized on the ledger and the query. Searching used to
 * refilter the whole job on every keystroke.
 */

import {
  AlertTriangle,
  ArrowDown10,
  ArrowUp10,
  ArrowUpDown,
  Calendar,
  Camera,
  Clock,
  FileSpreadsheet,
  FileText,
  Filter,
  History,
  Layers,
  Pencil,
  RotateCcw,
  Search,
  Trash2,
  Truck,
  User,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import { AppState, DeliveryTicket, RunRecord, SiloConfig } from '../types';
import DeliveriesByDay from './DeliveriesByDay';
import JobExport from './JobExport';
import EditDeliveryModal from './EditDeliveryModal';
import EditRunModal from './EditRunModal';
import DeleteConfirmModal from './DeleteConfirmModal';
import { formatLbs, formatTons } from '../lib/sandRules';
import { sandClasses, cn } from '../lib/theme';

type SubTab = 'deliveries' | 'by_day' | 'runs' | 'deleted' | 'export';
type SortOrder = 'stage_asc' | 'stage_desc' | 'date_desc' | 'date_asc';

interface LogsProps {
  state: AppState;
  onDeleteDelivery: (id: string, reason?: string) => Promise<void> | void;
  onRestoreDelivery?: (id: string) => Promise<void> | void;
  onUpdateDelivery?: (id: string, updates: Partial<DeliveryTicket>) => Promise<void>;
  onDeleteRun: (id: string, reason?: string) => Promise<void> | void;
  onRestoreRun?: (id: string) => Promise<void> | void;
  onUpdateRun?: (id: string, updates: Partial<RunRecord>) => Promise<void>;
  onSuccessMessage?: (msg: string) => void;
}

const STAMP: Intl.DateTimeFormatOptions = {
  month: 'numeric',
  day: 'numeric',
  year: 'numeric',
  hour: 'numeric',
  minute: '2-digit',
  hour12: true,
};

const SHORT_STAMP: Intl.DateTimeFormatOptions = {
  month: 'numeric',
  day: 'numeric',
  hour: 'numeric',
  minute: '2-digit',
  hour12: true,
};

export default function Logs({
  state,
  onDeleteDelivery,
  onRestoreDelivery,
  onUpdateDelivery,
  onDeleteRun,
  onRestoreRun,
  onUpdateRun,
  onSuccessMessage,
}: LogsProps) {
  const [activeTab, setActiveTab] = useState<SubTab>('deliveries');
  const [searchTerm, setSearchTerm] = useState('');
  const [viewingPhotoUrl, setViewingPhotoUrl] = useState<string | null>(null);
  const [editingTicket, setEditingTicket] = useState<DeliveryTicket | null>(null);
  const [editingRun, setEditingRun] = useState<RunRecord | null>(null);
  const [deletingTarget, setDeletingTarget] = useState<
    { type: 'ticket'; item: DeliveryTicket } | { type: 'run'; item: RunRecord } | null
  >(null);

  const [selectedWellFilter, setSelectedWellFilter] = useState<string>('all');
  const [stageSortOrder, setStageSortOrder] = useState<SortOrder>('stage_asc');

  const { config, deliveries, runs } = state;
  const lbsPerTon = config.lbsPerTon || 2000;
  const deletedDeliveries = state.deletedDeliveries || [];
  const deletedRuns = state.deletedRuns || [];
  const deletedTotalCount = deletedDeliveries.length + deletedRuns.length;

  /* The pad's silos, backfilled so a config that lost a silo still renders a
     column for it rather than silently swallowing its tickets. */
  const siloList = useMemo<SiloConfig[]>(() => {
    const siloCount = config.siloCount || config.silos?.length || 6;
    return Array.from({ length: siloCount }, (_, idx) => {
      const siloNum = idx + 1;
      const existing = config.silos?.find((s) => s.siloNumber === siloNum);
      return (
        existing || {
          siloNumber: siloNum,
          name: `Silo ${siloNum}`,
          side: 'A',
          sandType: null,
          manualPriority: null,
          maxCapacityLbs: 350000,
          startingBalanceLbs: 0,
          isOutOfService: false,
        }
      );
    });
  }, [config.siloCount, config.silos]);

  /* ------------------------------------------------------- filtering --- */

  const filteredDeliveries = useMemo(() => {
    if (activeTab !== 'deliveries') return [] as DeliveryTicket[];
    const term = searchTerm.trim().toLowerCase();
    if (!term) return deliveries;
    return deliveries.filter(
      (d) =>
        d.ticketNumber.toLowerCase().includes(term) ||
        d.supplier.toLowerCase().includes(term) ||
        d.sandType.toLowerCase().includes(term) ||
        (d.driverName && d.driverName.toLowerCase().includes(term)) ||
        (d.notes && d.notes.toLowerCase().includes(term)) ||
        `silo ${d.siloNumber}`.includes(term)
    );
  }, [deliveries, searchTerm, activeTab]);

  const unassignedDeliveries = useMemo(
    () =>
      filteredDeliveries
        .filter((d) => !siloList.some((s) => s.siloNumber === d.siloNumber))
        .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0)),
    [filteredDeliveries, siloList]
  );

  const allUnassignedDeliveriesCount = useMemo(
    () => deliveries.filter((d) => !siloList.some((s) => s.siloNumber === d.siloNumber)).length,
    [deliveries, siloList]
  );

  const totalUnassignedLbs = useMemo(
    () => unassignedDeliveries.reduce((sum, d) => sum + d.lbs, 0),
    [unassignedDeliveries]
  );

  /* Tickets grouped per silo once, instead of a filter pass per column. */
  const ticketsBySilo = useMemo(() => {
    const map = new Map<number, DeliveryTicket[]>();
    for (const s of siloList) map.set(s.siloNumber, []);
    for (const d of filteredDeliveries) {
      const bucket = map.get(d.siloNumber);
      if (bucket) bucket.push(d);
    }
    for (const bucket of map.values()) {
      bucket.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
    }
    return map;
  }, [filteredDeliveries, siloList]);

  const wellRunStats = useMemo(() => {
    const stats: Record<
      string,
      { runCount: number; stages: Set<number>; totalLbs: number; sandBreakdown: Record<string, number> }
    > = {};

    config.wells.forEach((w) => {
      stats[w.id] = { runCount: 0, stages: new Set(), totalLbs: 0, sandBreakdown: {} };
    });

    runs.forEach((r) => {
      const wellKey = r.wellId || 'unassigned';
      if (!stats[wellKey]) {
        stats[wellKey] = { runCount: 0, stages: new Set(), totalLbs: 0, sandBreakdown: {} };
      }
      stats[wellKey].runCount += 1;
      stats[wellKey].stages.add(r.stageNumber);
      stats[wellKey].totalLbs += r.lbsPulled || 0;
      const st = r.sandType || 'Unknown';
      stats[wellKey].sandBreakdown[st] = (stats[wellKey].sandBreakdown[st] || 0) + (r.lbsPulled || 0);
    });

    return stats;
  }, [config.wells, runs]);

  const totalRunLbs = useMemo(
    () => runs.reduce((s, r) => s + (r.lbsPulled || 0), 0),
    [runs]
  );

  const filteredRuns = useMemo(() => {
    if (activeTab !== 'runs') return [] as RunRecord[];
    return runs
      .filter((r) => {
        if (selectedWellFilter !== 'all') {
          if (selectedWellFilter === 'unassigned') {
            const isConfiguredWell = config.wells.some((w) => w.id === r.wellId);
            if (isConfiguredWell) return false;
          } else if (r.wellId !== selectedWellFilter) {
            return false;
          }
        }

        if (!searchTerm.trim()) return true;
        const term = searchTerm.toLowerCase().trim();
        const wellObj = config.wells.find((w) => w.id === r.wellId);
        const wellName = wellObj ? wellObj.name.toLowerCase() : '';
        return (
          wellName.includes(term) ||
          `stage ${r.stageNumber}`.includes(term) ||
          `#${r.stageNumber}`.includes(term) ||
          `${r.stageNumber}` === term ||
          `silo ${r.siloNumber}`.includes(term) ||
          (r.sandType && r.sandType.toLowerCase().includes(term)) ||
          (r.date && r.date.toLowerCase().includes(term))
        );
      })
      .sort((a, b) => {
        if (stageSortOrder === 'stage_asc') {
          if (selectedWellFilter === 'all') {
            const wellIdxA = config.wells.findIndex((w) => w.id === a.wellId);
            const wellIdxB = config.wells.findIndex((w) => w.id === b.wellId);
            const safeIdxA = wellIdxA === -1 ? 999 : wellIdxA;
            const safeIdxB = wellIdxB === -1 ? 999 : wellIdxB;
            if (safeIdxA !== safeIdxB) return safeIdxA - safeIdxB;
          }
          const stageDiff = (a.stageNumber || 0) - (b.stageNumber || 0);
          if (stageDiff !== 0) return stageDiff;
          const siloDiff = (a.siloNumber || 0) - (b.siloNumber || 0);
          if (siloDiff !== 0) return siloDiff;
          return (a.createdAt || 0) - (b.createdAt || 0);
        }

        if (stageSortOrder === 'stage_desc') {
          if (selectedWellFilter === 'all') {
            const wellIdxA = config.wells.findIndex((w) => w.id === a.wellId);
            const wellIdxB = config.wells.findIndex((w) => w.id === b.wellId);
            const safeIdxA = wellIdxA === -1 ? 999 : wellIdxA;
            const safeIdxB = wellIdxB === -1 ? 999 : wellIdxB;
            if (safeIdxA !== safeIdxB) return safeIdxA - safeIdxB;
          }
          const stageDiff = (b.stageNumber || 0) - (a.stageNumber || 0);
          if (stageDiff !== 0) return stageDiff;
          return (a.siloNumber || 0) - (b.siloNumber || 0);
        }

        if (stageSortOrder === 'date_desc') return (b.createdAt || 0) - (a.createdAt || 0);
        if (stageSortOrder === 'date_asc') return (a.createdAt || 0) - (b.createdAt || 0);
        return 0;
      });
  }, [runs, selectedWellFilter, searchTerm, config.wells, stageSortOrder, activeTab]);

  const allUnassignedRunsCount = useMemo(
    () => runs.filter((r) => !siloList.some((s) => s.siloNumber === r.siloNumber)).length,
    [runs, siloList]
  );

  const unassignedWellRunsCount = useMemo(
    () => runs.filter((r) => !config.wells.some((w) => w.id === r.wellId)).length,
    [runs, config.wells]
  );

  const filteredDeletedItems = useMemo(() => {
    if (activeTab !== 'deleted') {
      return [] as Array<
        | { kind: 'ticket'; item: DeliveryTicket; deletedAt: number }
        | { kind: 'run'; item: RunRecord; deletedAt: number }
      >;
    }
    const all = [
      ...deletedDeliveries.map((d) => ({
        kind: 'ticket' as const,
        item: d,
        deletedAt: d.deletedAt || 0,
      })),
      ...deletedRuns.map((r) => ({
        kind: 'run' as const,
        item: r,
        deletedAt: r.deletedAt || 0,
      })),
    ].sort((a, b) => b.deletedAt - a.deletedAt);

    const term = searchTerm.trim().toLowerCase();
    if (!term) return all;

    return all.filter((entry) => {
      if (entry.kind === 'ticket') {
        const t = entry.item;
        return (
          (t.ticketNumber && t.ticketNumber.toLowerCase().includes(term)) ||
          (t.supplier && t.supplier.toLowerCase().includes(term)) ||
          (t.sandType && t.sandType.toLowerCase().includes(term)) ||
          (t.deletedReason && t.deletedReason.toLowerCase().includes(term)) ||
          (t.deletedByEmail && t.deletedByEmail.toLowerCase().includes(term)) ||
          (t.deletedBy && t.deletedBy.toLowerCase().includes(term)) ||
          `silo ${t.siloNumber}`.includes(term)
        );
      }
      const r = entry.item;
      const well = config.wells.find((w) => w.id === r.wellId);
      return (
        `stage ${r.stageNumber}`.includes(term) ||
        (well && well.name.toLowerCase().includes(term)) ||
        (r.sandType && r.sandType.toLowerCase().includes(term)) ||
        (r.deletedReason && r.deletedReason.toLowerCase().includes(term)) ||
        (r.deletedByEmail && r.deletedByEmail.toLowerCase().includes(term)) ||
        (r.deletedBy && r.deletedBy.toLowerCase().includes(term)) ||
        `silo ${r.siloNumber}`.includes(term)
      );
    });
  }, [deletedDeliveries, deletedRuns, searchTerm, config.wells, activeTab]);

  const scrollToSiloColumn = (siloKey: string | number) => {
    const colEl = document.getElementById(`silo-col-${siloKey}`);
    if (colEl) {
      colEl.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
    }
  };

  const tabClass = (tab: SubTab, danger = false) =>
    cn(
      'tap flex h-10 shrink-0 items-center gap-2 rounded-xs px-3 text-xs font-medium transition-colors duration-150',
      activeTab === tab
        ? danger
          ? 'bg-danger-dim text-danger'
          : 'bg-accent text-accent-fg'
        : 'text-muted hover:text-fg'
    );

  const sortBtnClass = (order: SortOrder) =>
    cn(
      'tap flex h-9 items-center gap-1.5 rounded-xs px-3 text-xs font-medium transition-colors duration-150',
      stageSortOrder === order ? 'bg-accent text-accent-fg' : 'text-muted hover:text-fg'
    );

  const sortLabel =
    stageSortOrder === 'stage_asc'
      ? 'stage number ascending'
      : stageSortOrder === 'stage_desc'
        ? 'stage number descending'
        : 'entry time, newest first';

  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-5 pb-16">
      {/* ------------------------------------------------------- header --- */}
      <div className="card">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div className="flex items-start gap-3">
            <History className="mt-1 size-5 shrink-0 text-accent" />
            <div>
              <div className="eyebrow">Field activity</div>
              <h1 className="text-2xl font-medium tracking-tight">Logs</h1>
              <p className="max-w-xl text-sm text-muted">
                Every ticket and stage run on this pad · deleted records are soft-deleted and
                excluded from balances until restored · search matches ticket, well, driver, silo,
                supplier and sand type.
              </p>
            </div>
          </div>

          <div className="no-scrollbar flex items-center gap-1 overflow-x-auto rounded-sm bg-elevated p-1 ring-border">
            <button type="button" onClick={() => setActiveTab('deliveries')} className={tabClass('deliveries')}>
              <Truck className="size-4" /> Tickets <span className="num">{deliveries.length}</span>
            </button>
            <button type="button" onClick={() => setActiveTab('by_day')} className={tabClass('by_day')}>
              <Calendar className="size-4" /> By day
            </button>
            <button type="button" onClick={() => setActiveTab('runs')} className={tabClass('runs')}>
              <Layers className="size-4" /> Stage runs <span className="num">{runs.length}</span>
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('deleted')}
              className={tabClass('deleted', true)}
            >
              <Trash2 className="size-4" /> Deleted <span className="num">{deletedTotalCount}</span>
            </button>
            <button type="button" onClick={() => setActiveTab('export')} className={tabClass('export')}>
              <FileSpreadsheet className="size-4" /> Export
            </button>
          </div>
        </div>
      </div>

      {activeTab === 'by_day' ? <DeliveriesByDay state={state} /> : null}

      {activeTab === 'export' ? (
        <JobExport state={state} onSuccessMessage={onSuccessMessage} />
      ) : null}

      {/* -------------------------------------------------------- search --- */}
      {activeTab !== 'by_day' && activeTab !== 'export' ? (
        <div className="relative">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 size-4 -translate-y-1/2 text-muted" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Filter by ticket, well, driver, silo, supplier or sand type"
            className="input pl-10"
          />
        </div>
      ) : null}

      {/* --------------------------------------------------- deliveries --- */}
      {activeTab === 'deliveries' ? (
        <div className="flex flex-col gap-4">
          {allUnassignedDeliveriesCount > 0 ? (
            <div className="card flex items-start gap-3 ring-danger-1">
              <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" />
              <div className="text-sm">
                <div className="eyebrow text-danger">Tickets on unconfigured silos</div>
                <p className="mt-1 text-muted">
                  <span className="num text-fg">{allUnassignedDeliveriesCount}</span>{' '}
                  {allUnassignedDeliveriesCount === 1 ? 'ticket is' : 'tickets are'} logged to
                  silos that are not in this pad's config. Fix the silo with Edit in the
                  unassigned column, or add the missing silo in Setup.
                </p>
              </div>
            </div>
          ) : null}

          {/* mobile silo jump */}
          <div className="no-scrollbar flex items-center gap-2 overflow-x-auto pb-1 min-[900px]:hidden">
            <span className="eyebrow-aside">Jump to</span>
            {siloList.map((s) => (
              <button
                key={s.siloNumber}
                type="button"
                onClick={() => scrollToSiloColumn(s.siloNumber)}
                className="btn h-10 shrink-0 px-3 text-xs"
              >
                <span>Silo <span className="num">{s.siloNumber}</span></span>
                <span className="badge num">{(ticketsBySilo.get(s.siloNumber) || []).length}</span>
              </button>
            ))}
            {unassignedDeliveries.length > 0 ? (
              <button
                type="button"
                onClick={() => scrollToSiloColumn('unassigned')}
                className="btn btn-danger h-10 shrink-0 px-3 text-xs"
              >
                <AlertTriangle className="size-3.5" />
                <span>Unassigned</span>
                <span className="num">{unassignedDeliveries.length}</span>
              </button>
            ) : null}
          </div>

          {/* per-silo columns */}
          <div
            className="no-scrollbar flex snap-x snap-mandatory gap-4 overflow-x-auto scroll-smooth pb-4 min-[900px]:grid"
            style={{
              gridTemplateColumns: `repeat(${siloList.length + (unassignedDeliveries.length > 0 ? 1 : 0)}, minmax(0, 1fr))`,
            }}
          >
            {siloList.map((silo) => {
              const siloTickets = ticketsBySilo.get(silo.siloNumber) || [];
              const totalLbs = siloTickets.reduce((sum, d) => sum + d.lbs, 0);
              const colTone = sandClasses(silo.sandType, config.sandTypes);

              return (
                <div
                  key={silo.siloNumber}
                  id={`silo-col-${silo.siloNumber}`}
                  className="w-[85vw] max-w-[340px] shrink-0 snap-center space-y-3 min-[900px]:w-auto"
                >
                  <div
                    className={cn(
                      'space-y-1.5 rounded-md bg-surface p-3',
                      silo.sandType ? colTone.ring : 'ring-border'
                    )}
                  >
                    <div className="flex items-center justify-between gap-1.5">
                      <span className="text-sm font-medium">
                        Silo <span className="num">{silo.siloNumber}</span>
                      </span>
                      <span
                        className={cn(
                          'badge',
                          silo.sandType ? cn(colTone.dim, colTone.text) : null
                        )}
                      >
                        {silo.sandType || 'not set'}
                      </span>
                    </div>
                    <div className="num text-xs text-muted">
                      {siloTickets.length} {siloTickets.length === 1 ? 'load' : 'loads'} ·{' '}
                      {formatLbs(totalLbs)}
                    </div>
                  </div>

                  {siloTickets.length === 0 ? (
                    <div className="rounded-md p-6 text-center ring-border">
                      <span className="eyebrow">No tickets</span>
                    </div>
                  ) : (
                    <div className="space-y-2.5">
                      {siloTickets.map((del) => (
                        <div
                          key={del.id}
                          className="space-y-2 rounded-md bg-elevated p-3 ring-border"
                        >
                          <div className="flex items-center justify-between gap-1.5">
                            <span className="num text-base font-semibold text-accent">
                              #{del.ticketNumber}
                            </span>
                            <div className="flex items-center gap-1">
                              {del.photoUrl ? (
                                <button
                                  type="button"
                                  onClick={() => setViewingPhotoUrl(del.photoUrl || null)}
                                  className="btn h-9 px-2"
                                  title="View ticket photo"
                                >
                                  <Camera className="size-4" />
                                </button>
                              ) : null}
                              <button
                                type="button"
                                onClick={() => setEditingTicket(del)}
                                className="btn h-9 px-2.5 text-xs"
                                title="Edit ticket details"
                              >
                                <Pencil className="size-3.5" />
                                <span>Edit</span>
                              </button>
                              <button
                                type="button"
                                onClick={() => setDeletingTarget({ type: 'ticket', item: del })}
                                className="btn btn-ghost h-9 px-2 text-danger"
                                title="Delete ticket"
                              >
                                <Trash2 className="size-4" />
                              </button>
                            </div>
                          </div>

                          <div className="flex items-baseline justify-between gap-2">
                            <div className="num text-lg font-semibold">{formatLbs(del.lbs)}</div>
                            <div className="num text-xs text-muted">
                              {formatTons(del.lbs / lbsPerTon)}
                            </div>
                          </div>

                          <div className="divider" />

                          <div className="flex flex-wrap items-center gap-1.5 text-xs text-muted">
                            <span className="num">{del.date}</span>
                            {del.timeOfDay ? (
                              <>
                                <span className="text-subtle">·</span>
                                <span className="num">{del.timeOfDay}</span>
                              </>
                            ) : null}
                            <span className="text-subtle">·</span>
                            <span className="truncate text-fg">{del.supplier}</span>
                          </div>

                          <div className="flex flex-wrap items-center justify-between gap-1.5">
                            {del.createdAt ? (
                              <span className="num text-[11px] text-subtle">
                                Entered {new Date(del.createdAt).toLocaleString('en-US', STAMP)}
                              </span>
                            ) : null}

                            {del.editedAt ? (
                              <span className="badge badge-warn">
                                <Pencil className="size-2.5" />
                                Edited
                                <span className="num">
                                  {new Date(del.editedAt).toLocaleString('en-US', SHORT_STAMP)}
                                </span>
                                {del.editedBy ? <span>· {del.editedBy}</span> : null}
                              </span>
                            ) : null}
                          </div>

                          {del.driverName || del.notes ? (
                            <div className="space-y-0.5 text-[11px] text-muted">
                              {del.driverName ? (
                                <div className="flex items-center gap-1 truncate">
                                  <User className="size-3 shrink-0 text-accent" />
                                  <span className="truncate">{del.driverName}</span>
                                </div>
                              ) : null}
                              {del.notes ? (
                                <div className="flex items-center gap-1 truncate">
                                  <FileText className="size-3 shrink-0 text-subtle" />
                                  <span className="truncate">{del.notes}</span>
                                </div>
                              ) : null}
                            </div>
                          ) : null}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}

            {/* UNASSIGNED column */}
            {unassignedDeliveries.length > 0 ? (
              <div
                id="silo-col-unassigned"
                className="w-[85vw] max-w-[340px] shrink-0 snap-center space-y-3 min-[900px]:w-auto"
              >
                <div className="space-y-1.5 rounded-md bg-danger-dim p-3 ring-danger-1">
                  <div className="flex items-center justify-between gap-1.5">
                    <span className="flex items-center gap-1.5 text-sm font-medium text-danger">
                      <AlertTriangle className="size-4 shrink-0" />
                      Unassigned
                    </span>
                    <span className="badge badge-danger">Silo not in config</span>
                  </div>
                  <div className="num text-xs text-danger">
                    {unassignedDeliveries.length}{' '}
                    {unassignedDeliveries.length === 1 ? 'load' : 'loads'} ·{' '}
                    {formatLbs(totalUnassignedLbs)}
                  </div>
                </div>

                <div className="space-y-2.5">
                  {unassignedDeliveries.map((del) => (
                    <div
                      key={del.id}
                      className="space-y-2.5 rounded-md bg-elevated p-3 ring-danger-1"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <span className="num text-sm font-semibold text-accent">
                            #{del.ticketNumber}
                          </span>
                          <span className="badge badge-danger">
                            Silo <span className="num">{del.siloNumber}</span>
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          {del.photoUrl ? (
                            <button
                              type="button"
                              onClick={() => setViewingPhotoUrl(del.photoUrl!)}
                              className="btn h-9 px-2"
                              title="View scanned ticket photo"
                            >
                              <Camera className="size-4" />
                            </button>
                          ) : null}
                          <button
                            type="button"
                            onClick={() => setEditingTicket(del)}
                            className="btn btn-danger h-9 px-2.5 text-xs"
                            title="Edit and assign to a configured silo"
                          >
                            <Pencil className="size-3.5" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeletingTarget({ type: 'ticket', item: del })}
                            className="btn btn-ghost h-9 px-2 text-danger"
                            title="Delete delivery"
                          >
                            <Trash2 className="size-4" />
                          </button>
                        </div>
                      </div>

                      <div>
                        <div className="flex items-baseline justify-between gap-2">
                          <span className="num text-lg font-semibold">{formatLbs(del.lbs)}</span>
                          <span className="num text-xs text-muted">
                            {formatTons(del.lbs / lbsPerTon)}
                          </span>
                        </div>
                        <div className="mt-0.5 truncate text-xs text-muted">
                          {del.sandType} · {del.supplier}
                        </div>
                      </div>

                      <div className="divider" />

                      <div className="flex items-center justify-between text-[11px] text-muted">
                        <span>Delivered</span>
                        <span className="num text-fg">
                          {del.date}
                          {del.timeOfDay ? ` ${del.timeOfDay}` : ''}
                        </span>
                      </div>

                      {del.driverName || del.notes ? (
                        <div className="space-y-0.5 text-[11px] text-muted">
                          {del.driverName ? (
                            <div className="flex items-center gap-1 truncate">
                              <User className="size-3 shrink-0 text-accent" />
                              <span className="truncate">{del.driverName}</span>
                            </div>
                          ) : null}
                          {del.notes ? (
                            <div className="flex items-center gap-1 truncate">
                              <FileText className="size-3 shrink-0 text-subtle" />
                              <span className="truncate">{del.notes}</span>
                            </div>
                          ) : null}
                        </div>
                      ) : null}
                    </div>
                  ))}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      ) : null}

      {/* --------------------------------------------------- stage runs --- */}
      {activeTab === 'runs' ? (
        <div className="flex flex-col gap-4">
          {allUnassignedRunsCount > 0 ? (
            <div className="card flex items-start gap-3 ring-danger-1">
              <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" />
              <div className="text-sm">
                <div className="eyebrow text-danger">Runs on unconfigured silos</div>
                <p className="mt-1 text-muted">
                  <span className="num text-fg">{allUnassignedRunsCount}</span> stage{' '}
                  {allUnassignedRunsCount === 1 ? 'run is' : 'runs are'} logged to silos that are
                  not in this pad's config. Fix the silo with Edit, or add the missing silo in
                  Setup.
                </p>
              </div>
            </div>
          ) : null}

          {/* controls */}
          <div className="card space-y-4">
            <div className="flex flex-col justify-between gap-4 md:flex-row md:items-start">
              <div>
                <div className="eyebrow">Stage run logs</div>
                <h2 className="text-lg font-medium tracking-tight">
                  {selectedWellFilter === 'all'
                    ? 'All wells'
                    : config.wells.find((w) => w.id === selectedWellFilter)?.name ||
                      'Unassigned well'}
                </h2>
                <p className="text-sm text-muted">
                  Sorted by {sortLabel} · stage counts are distinct stage numbers, not run records.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-1 rounded-sm bg-elevated p-1 ring-border">
                <span className="eyebrow flex items-center gap-1 px-2">
                  <ArrowUpDown className="size-3 text-accent" /> Order
                </span>
                <button
                  type="button"
                  onClick={() => setStageSortOrder('stage_asc')}
                  className={sortBtnClass('stage_asc')}
                  title="Stage 1 first"
                >
                  <ArrowUp10 className="size-3.5" />
                  <span className="num">1 to N</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStageSortOrder('stage_desc')}
                  className={sortBtnClass('stage_desc')}
                  title="Highest stage first"
                >
                  <ArrowDown10 className="size-3.5" />
                  <span className="num">N to 1</span>
                </button>
                <button
                  type="button"
                  onClick={() => setStageSortOrder('date_desc')}
                  className={sortBtnClass('date_desc')}
                  title="Newest entry first"
                >
                  <Clock className="size-3.5" />
                  <span>Newest</span>
                </button>
              </div>
            </div>

            <div className="divider" />

            {/* well filter */}
            <div className="space-y-2">
              <div className="eyebrow flex items-center gap-1.5">
                <Filter className="size-3.5 text-accent" />
                <span>Filter by well</span>
              </div>
              <div className="no-scrollbar flex items-center gap-2 overflow-x-auto pb-1">
                <button
                  type="button"
                  onClick={() => setSelectedWellFilter('all')}
                  className={cn(
                    'btn h-10 shrink-0 px-3 text-xs',
                    selectedWellFilter === 'all' && 'btn-accent'
                  )}
                >
                  <span>All wells</span>
                  <span className="num">{runs.length}</span>
                </button>

                {config.wells.map((well) => {
                  const stats = wellRunStats[well.id] || {
                    runCount: 0,
                    stages: new Set<number>(),
                    totalLbs: 0,
                  };
                  const isSelected = selectedWellFilter === well.id;
                  return (
                    <button
                      key={well.id}
                      type="button"
                      onClick={() => setSelectedWellFilter(well.id)}
                      className={cn('btn h-10 shrink-0 px-3 text-xs', isSelected && 'btn-accent')}
                    >
                      <span>{well.name}</span>
                      <span className="num">
                        {stats.stages.size}
                        {well.plannedStages ? `/${well.plannedStages}` : ''} stg
                      </span>
                    </button>
                  );
                })}

                {unassignedWellRunsCount > 0 ? (
                  <button
                    type="button"
                    onClick={() => setSelectedWellFilter('unassigned')}
                    className={cn(
                      'btn h-10 shrink-0 px-3 text-xs',
                      selectedWellFilter === 'unassigned' ? 'btn-danger' : 'text-danger'
                    )}
                  >
                    <AlertTriangle className="size-3.5" />
                    <span>Unassigned well</span>
                    <span className="num">{unassignedWellRunsCount}</span>
                  </button>
                ) : null}
              </div>
            </div>

            {/* well summary */}
            {selectedWellFilter !== 'all' ? (
              (() => {
                const wellObj = config.wells.find((w) => w.id === selectedWellFilter);
                const stats = wellRunStats[selectedWellFilter] || {
                  runCount: 0,
                  stages: new Set<number>(),
                  totalLbs: 0,
                  sandBreakdown: {},
                };
                return (
                  <div className="flex flex-col justify-between gap-4 rounded-md bg-elevated p-4 ring-border md:flex-row md:items-center">
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <div className="eyebrow">Stages done</div>
                        <div className="stat-v mt-1">
                          {stats.stages.size}
                          {wellObj?.plannedStages ? (
                            <span className="text-base text-muted">/{wellObj.plannedStages}</span>
                          ) : null}
                        </div>
                      </div>
                      <div>
                        <div className="eyebrow">Run records</div>
                        <div className="stat-v mt-1">{stats.runCount}</div>
                      </div>
                      <div>
                        <div className="eyebrow">Sand pulled</div>
                        <div className="stat-v mt-1">{formatLbs(stats.totalLbs)}</div>
                        <div className="num text-xs text-muted">
                          {formatTons(stats.totalLbs / lbsPerTon)}
                        </div>
                      </div>
                    </div>

                    {Object.keys(stats.sandBreakdown).length > 0 ? (
                      <div className="flex flex-wrap items-center gap-2">
                        {Object.entries(stats.sandBreakdown).map(([st, lbsPulled]) => {
                          const rowTone = sandClasses(st, config.sandTypes);
                          return (
                            <div
                              key={st}
                              className={cn(
                                'rounded-sm px-2.5 py-1 text-xs',
                                rowTone.dim,
                                rowTone.text
                              )}
                            >
                              {st}{' '}
                              <span className="num font-semibold text-fg">
                                {formatLbs(Number(lbsPulled) || 0)}
                              </span>
                            </div>
                          );
                        })}
                      </div>
                    ) : null}
                  </div>
                );
              })()
            ) : (
              <div className="flex items-center justify-between gap-3 rounded-md bg-elevated px-4 py-2.5 text-xs text-muted ring-border">
                <span>
                  Showing <span className="num text-fg">{filteredRuns.length}</span> stage runs
                  across all wells.
                </span>
                <span className="num text-fg">Total {formatLbs(totalRunLbs)}</span>
              </div>
            )}
          </div>

          {/* run records */}
          <div className="card space-y-3">
            <div className="card-hd">
              <div className="eyebrow">
                Logged stage runs <span className="num">{filteredRuns.length}</span>
              </div>
            </div>

            {filteredRuns.length === 0 ? (
              <div className="rounded-md bg-elevated py-12 text-center text-sm text-muted ring-border">
                No stage runs match the active well and search filter.
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredRuns.map((r) => {
                  const wellObj = config.wells.find((w) => w.id === r.wellId);
                  const isUnassignedSilo = !siloList.some((s) => s.siloNumber === r.siloNumber);
                  const rowTone = sandClasses(r.sandType, config.sandTypes);
                  return (
                    <div
                      key={r.id}
                      className={cn(
                        'flex flex-col justify-between gap-3 rounded-md bg-elevated p-4 sm:flex-row sm:items-center',
                        isUnassignedSilo ? 'ring-danger-1' : 'ring-border'
                      )}
                    >
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="badge badge-accent">
                            Stage <span className="num">{r.stageNumber}</span>
                          </span>
                          <span className="text-base font-medium">
                            {wellObj?.name || 'Unassigned well'}
                          </span>

                          {isUnassignedSilo ? (
                            <span className="badge badge-danger">
                              <AlertTriangle className="size-3" />
                              Unconfigured silo <span className="num">{r.siloNumber}</span>
                            </span>
                          ) : (
                            <span className="badge">
                              Silo <span className="num">{r.siloNumber}</span>
                            </span>
                          )}

                          <span className={cn('badge', rowTone.dim, rowTone.text)}>
                            {r.sandType}
                          </span>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 text-xs text-muted">
                          <span>
                            Run date <span className="num text-fg">{r.date}</span>
                          </span>
                          {r.createdAt ? (
                            <span className="num text-[11px] text-subtle">
                              Entered {new Date(r.createdAt).toLocaleString('en-US', STAMP)}
                            </span>
                          ) : null}
                          {r.editedAt ? (
                            <span className="badge badge-warn">
                              <Pencil className="size-2.5" />
                              Edited
                              <span className="num">
                                {new Date(r.editedAt).toLocaleString('en-US', SHORT_STAMP)}
                              </span>
                              {r.editedBy ? <span>· {r.editedBy}</span> : null}
                            </span>
                          ) : null}
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-3 sm:justify-end">
                        <div className="text-left sm:text-right">
                          <div className="num text-lg font-semibold">
                            {formatLbs(r.lbsPulled)}
                          </div>
                          <div className="num text-xs text-muted">
                            {formatTons(r.lbsPulled / lbsPerTon)}
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={() => setEditingRun(r)}
                            className="btn h-10 px-3 text-xs"
                            title="Edit stage run record"
                          >
                            <Pencil className="size-3.5" />
                            <span>Edit</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setDeletingTarget({ type: 'run', item: r })}
                            className="btn btn-ghost h-10 px-2 text-danger"
                            title="Delete record"
                          >
                            <Trash2 className="size-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      ) : null}

      {/* ------------------------------------------------------ deleted --- */}
      {activeTab === 'deleted' ? (
        <div className="flex flex-col gap-4">
          <div className="card flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
            <div>
              <div className="eyebrow text-danger">Soft-deleted audit trail</div>
              <p className="mt-1 text-sm text-muted">
                These records are excluded from silo balances, daily totals and diagnostics.
                Restore puts one back into live inventory.
              </p>
            </div>
            <span className="badge badge-danger shrink-0">
              <span className="num">{deletedTotalCount}</span> deleted
            </span>
          </div>

          {filteredDeletedItems.length === 0 ? (
            <div className="card py-12 text-center">
              <Trash2 className="mx-auto size-8 text-subtle" />
              <p className="mt-2 text-sm font-medium">No deleted records</p>
              <p className="text-xs text-muted">
                {searchTerm
                  ? 'No deleted items matched the search filter.'
                  : 'No tickets or stage runs have been deleted.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredDeletedItems.map((entry) => {
                if (entry.kind === 'ticket') {
                  const del = entry.item;
                  const rowTone = sandClasses(del.sandType, config.sandTypes);
                  return (
                    <div key={`del-ticket-${del.id}`} className="card space-y-3">
                      <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="badge badge-danger">Delivery ticket</span>
                          <span className="num text-base text-muted line-through">
                            #{del.ticketNumber}
                          </span>
                          <span className="badge">
                            Silo <span className="num">{del.siloNumber}</span>
                          </span>
                          <span className={cn('badge', rowTone.dim, rowTone.text)}>
                            {del.sandType}
                          </span>
                        </div>

                        <button
                          type="button"
                          onClick={() => onRestoreDelivery && onRestoreDelivery(del.id)}
                          className="btn shrink-0"
                          title="Restore this ticket into live inventory"
                          disabled={!onRestoreDelivery}
                        >
                          <RotateCcw className="size-3.5" />
                          <span>Restore ticket</span>
                        </button>
                      </div>

                      <div className="divider" />

                      <div className="grid grid-cols-1 gap-3 text-xs sm:grid-cols-3">
                        <div>
                          <div className="eyebrow">Weight / supplier</div>
                          <div className="num mt-1 text-sm font-semibold">
                            {formatLbs(del.lbs)}{' '}
                            <span className="text-xs font-normal text-muted">
                              {formatTons(del.lbs / lbsPerTon)}
                            </span>
                          </div>
                          <div className="mt-0.5 text-muted">{del.supplier}</div>
                        </div>

                        <div>
                          <div className="eyebrow">Delivery date</div>
                          <div className="num mt-1">
                            {del.date}
                            {del.timeOfDay ? ` · ${del.timeOfDay}` : ''}
                          </div>
                          {del.createdAt ? (
                            <div className="num mt-0.5 text-[11px] text-muted">
                              Entered {new Date(del.createdAt).toLocaleString('en-US', STAMP)}
                            </div>
                          ) : null}
                        </div>

                        <div>
                          <div className="eyebrow">Deletion audit</div>
                          <div className="num mt-1 text-danger">
                            {entry.deletedAt
                              ? new Date(entry.deletedAt).toLocaleString('en-US', STAMP)
                              : 'Soft deleted'}
                          </div>
                          {del.deletedByEmail || del.deletedBy ? (
                            <div className="mt-0.5 text-[11px] text-muted">
                              Deleted by{' '}
                              <span className="text-fg">
                                {del.deletedByEmail || del.deletedBy}
                              </span>
                            </div>
                          ) : null}
                        </div>
                      </div>

                      {del.deletedReason ? (
                        <div className="flex items-center gap-2 rounded-sm bg-danger-dim px-3 py-2 text-xs text-danger">
                          <span className="eyebrow shrink-0 text-danger">Reason</span>
                          <span className="text-fg">{del.deletedReason}</span>
                        </div>
                      ) : null}
                    </div>
                  );
                }

                const run = entry.item;
                const wellObj = config.wells.find((w) => w.id === run.wellId);
                const rowTone = sandClasses(run.sandType, config.sandTypes);
                return (
                  <div key={`del-run-${run.id}`} className="card space-y-3">
                    <div className="flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="badge badge-warn">Stage run</span>
                        <span className="num text-base text-muted line-through">
                          {wellObj?.name || 'Well'} · stage {run.stageNumber}
                        </span>
                        <span className="badge">
                          Silo <span className="num">{run.siloNumber}</span>
                        </span>
                        <span className={cn('badge', rowTone.dim, rowTone.text)}>
                          {run.sandType}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => onRestoreRun && onRestoreRun(run.id)}
                        className="btn shrink-0"
                        title="Restore this run into live calculations"
                        disabled={!onRestoreRun}
                      >
                        <RotateCcw className="size-3.5" />
                        <span>Restore run</span>
                      </button>
                    </div>

                    <div className="divider" />

                    <div className="grid grid-cols-1 gap-3 text-xs sm:grid-cols-3">
                      <div>
                        <div className="eyebrow">Pulled weight</div>
                        <div className="num mt-1 text-sm font-semibold">
                          {formatLbs(run.lbsPulled)}{' '}
                          <span className="text-xs font-normal text-muted">
                            {formatTons(run.lbsPulled / lbsPerTon)}
                          </span>
                        </div>
                      </div>

                      <div>
                        <div className="eyebrow">Run date</div>
                        <div className="num mt-1">{run.date}</div>
                        {run.createdAt ? (
                          <div className="num mt-0.5 text-[11px] text-muted">
                            Entered {new Date(run.createdAt).toLocaleString('en-US', STAMP)}
                          </div>
                        ) : null}
                      </div>

                      <div>
                        <div className="eyebrow">Deletion audit</div>
                        <div className="num mt-1 text-danger">
                          {entry.deletedAt
                            ? new Date(entry.deletedAt).toLocaleString('en-US', STAMP)
                            : 'Soft deleted'}
                        </div>
                        {run.deletedByEmail || run.deletedBy ? (
                          <div className="mt-0.5 text-[11px] text-muted">
                            Deleted by{' '}
                            <span className="text-fg">{run.deletedByEmail || run.deletedBy}</span>
                          </div>
                        ) : null}
                      </div>
                    </div>

                    {run.deletedReason ? (
                      <div className="flex items-center gap-2 rounded-sm bg-danger-dim px-3 py-2 text-xs text-danger">
                        <span className="eyebrow shrink-0 text-danger">Reason</span>
                        <span className="text-fg">{run.deletedReason}</span>
                      </div>
                    ) : null}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : null}

      {/* -------------------------------------------------------- modals --- */}
      {deletingTarget ? (
        <DeleteConfirmModal
          state={state}
          target={deletingTarget}
          onConfirmDelete={async (reason) => {
            if (deletingTarget.type === 'ticket') {
              await onDeleteDelivery(deletingTarget.item.id, reason);
            } else {
              await onDeleteRun(deletingTarget.item.id, reason);
            }
          }}
          onClose={() => setDeletingTarget(null)}
        />
      ) : null}

      {editingTicket ? (
        <EditDeliveryModal
          state={state}
          ticket={editingTicket}
          onSave={async (updates) => {
            if (onUpdateDelivery) {
              await onUpdateDelivery(editingTicket.id, updates);
            }
          }}
          onClose={() => setEditingTicket(null)}
        />
      ) : null}

      {editingRun ? (
        <EditRunModal
          state={state}
          run={editingRun}
          onSave={async (updates) => {
            if (onUpdateRun) {
              await onUpdateRun(editingRun.id, updates);
            }
          }}
          onClose={() => setEditingRun(null)}
        />
      ) : null}

      {viewingPhotoUrl ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-bg/90 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-2xl">
            <div className="card-hd">
              <div className="eyebrow">Attached ticket scan</div>
              <button
                type="button"
                onClick={() => setViewingPhotoUrl(null)}
                className="btn h-9 px-3 text-xs"
              >
                Close
              </button>
            </div>
            <img
              src={viewingPhotoUrl}
              alt="Full ticket scan"
              className="max-h-[75vh] w-full rounded-md object-contain"
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}

export interface WellConfig {
  id: string;
  name: string;
  customerName?: string; // e.g. "Diamondback Energy", "Chevron"
  plannedStages: number;
  perStageDesignOverrides?: Record<string, number>; // key: sandTypeId or sandTypeName -> perStageDesignLbs override
}

export interface SandTypeSpec {
  id: string;
  name: string; // e.g. "100 Mesh", "40/70"
  perStageDesignLbs: number; // e.g. 150000 lbs per stage
  jobDesignTotalLbs?: number; // e.g. 13,050,000 lbs whole job figure from frac design
  colorCategory: 'orange' | 'blue' | 'emerald' | 'amber' | 'slate';
}

export interface SiloConfig {
  siloNumber: number; // 1, 2, 3, 4, 5, 6...
  name?: string; // Optional custom name / label (e.g. "Silo 1A", "North Silo 1")
  side: string; // 'A' | 'B' | 'East' | 'West' or custom side label
  sandType: string | null; // e.g. "100 Mesh" or null if empty
  manualPriority: number | null; // e.g. 1, 2, 3 override for pull sequence
  maxCapacityLbs: number; // e.g. 350,000 lbs
  startingBalanceLbs: number; // set at pad setup for takeover on hand
  isOutOfService: boolean; // marked offline for maintenance
}

export type DrawStrategy =
  | 'sequential_rotation'
  | 'partials_then_rotate'
  | 'least_used_first'
  | 'emptiest_first'
  | 'fullest_first';

export interface ProductCodeMapping {
  mineCode: string; // e.g. "100M"
  sandType: string; // e.g. "100 Mesh"
}

export interface PadConfig {
  customerName?: string; // e.g. "Diamondback Energy"
  padName: string;
  siloCount: number; // default 6
  lbsPerTruckload: number; // default 57000 lbs
  lbsPerTon: number; // default 2000 lbs
  drawStrategy: DrawStrategy;
  partialThresholdPct?: number; // default 0.75 (75%)
  reorderThresholdStages: number; // default 5 stages
  suppliers?: string[]; // supplier dropdown list
  wells: WellConfig[];
  sandTypes: SandTypeSpec[];
  silos: SiloConfig[];
  productCodeMappings?: ProductCodeMapping[];
  clearManualPriorityAfterStage?: boolean; // default true: resets manual silo overrides after recording stage
  autoAdvanceWellStage?: boolean; // default true: advances zipper well/stage after recording run
}

export type TicketConfidence = 'confirmed' | 'probable' | 'unknown';
/**
 * `known_supplier` used to sit in this union and was awarded 80 points by
 * scoreCandidate, but no parser has ever produced it — a dead scoring branch
 * that could only ever mislead someone reading the ranking. Removed.
 */
export type TicketParserType = 'atlas' | 'atlas-partial' | 'generic_labeled' | 'unknown';

export interface ScanMetadata {
  method: 'camera' | 'photo' | 'manual';
  format?: string;
  parser?: TicketParserType;
  confidence?: TicketConfidence;
  rawValue?: string;
  winningScale?: string;
  engine?: string;
  scannedAt?: number;
}

export interface DeliveryTicket {
  id: string;
  date: string; // YYYY-MM-DD
  timeOfDay?: string; // e.g. "14:30"
  sandType: string;
  supplier: string;
  driverName?: string;
  notes?: string;
  siloNumber: number;
  ticketNumber: string;
  lbs: number;
  createdAt: number;
  editedAt?: number;
  editCount?: number;
  editedBy?: string | null;
  editedByEmail?: string | null;
  deleted?: boolean;
  deletedAt?: number | null;
  deletedReason?: string | null;
  deletedBy?: string | null;
  deletedByEmail?: string | null;
  photoUrl?: string | null;
  carrier?: string;
  truck?: string;
  poNumber?: string;
  productCode?: string;
  scanMetadata?: ScanMetadata;
  supervisorOverride?: boolean;
  overrideReason?: string | null;
  pendingSync?: boolean;
}

export interface RunRecord {
  id: string;
  date: string; // YYYY-MM-DD
  wellId: string;
  stageNumber: number;
  siloNumber: number;
  sandType: string; // tracked against silo AND sand type
  lbsPulled: number;
  runSequence?: number; // 1, 2, 3... explicit execution order within the stage
  submissionId?: string; // Idempotency key for stage submission
  createdAt: number;
  editedAt?: number;
  editCount?: number;
  editedBy?: string | null;
  editedByEmail?: string | null;
  deleted?: boolean;
  deletedAt?: number | null;
  deletedReason?: string | null;
  deletedBy?: string | null;
  deletedByEmail?: string | null;
  pendingSync?: boolean;
}

export type QueueActionType =
  | 'CREATE_PAD'
  | 'ADD_DELIVERY'
  | 'UPDATE_DELIVERY'
  | 'DELETE_DELIVERY'
  | 'RESTORE_DELIVERY'
  | 'ADD_RUNS'
  | 'UPDATE_RUN'
  | 'DELETE_RUN'
  | 'RESTORE_RUN'
  | 'SAVE_PAD_CONFIG'
  | 'UPDATE_SILO'
  | 'UPDATE_SILOS';

export interface OfflineQueueItem {
  id: string;
  type: QueueActionType;
  padId: string;
  payload: any;
  createdAt: number;
  retries: number;
  status: 'pending' | 'syncing' | 'failed';
  error?: string;
}

export interface AppState {
  status?: 'ready' | 'not_found';
  padId?: string;
  config: PadConfig;
  deliveries: DeliveryTicket[];
  runs: RunRecord[];
  deletedDeliveries?: DeliveryTicket[];
  deletedRuns?: RunRecord[];
}

// Derived calculation types
export interface SiloDerivedState {
  siloNumber: number;
  name?: string;
  side: string;
  sandType: string | null;
  manualPriority: number | null;
  maxCapacityLbs: number;
  startingBalanceLbs: number;
  isOutOfService: boolean;
  onHandLbs: number;
  onHandTons: number;
  percentFull: number; // 0 - 100+
  isOverCapacity: boolean;
  isNegative: boolean;
  status: 'OK' | 'LOW' | 'EMPTY' | 'OUT_OF_SERVICE';
  runOrder: number | null; // 1, 2, 3 rank in pull sequence
  plannedPullLbs: number; // Lbs calculated for target stage run
  stagesLeft: number;
}

export interface SandTypeSummary {
  sandType: string;
  onHandLbs: number;
  onHandTons: number;
  stagesLeft: number;
  perStageDesignLbs: number;
  reorderThresholdLbs: number;
  isBelowReorderThreshold: boolean;
  stageShortfallLbs: number;
}

export interface PadSummary {
  customerName?: string;
  activeWellCustomerName?: string;
  padName: string;
  activeWellId: string;
  nextWellName: string;
  nextStageNumber: number;
  sandTypeSummaries: SandTypeSummary[];
  totalPadOnHandLbs: number;
  hasReorderAlert: boolean;
}

export interface MismatchedDelivery {
  ticketId: string;
  ticketNumber: string;
  siloNumber: number;
  deliverySandType: string;
  siloCurrentSandType: string;
  date: string;
}

export interface DiagnosticsReport {
  computedPadOnHandLbs: number;
  sumOfSilosOnHandLbs: number;
  isPadTotalMismatch: boolean;
  negativeSilos: { siloNumber: number; onHandLbs: number }[];
  duplicateTicketNumbers: { ticketNumber: string; count: number }[];
  mismatchedDeliveries: MismatchedDelivery[];
  unassignedSilos: number[];
  unassignedSiloDeliveries: DeliveryTicket[];
  unassignedSiloRuns: RunRecord[];
}

export type StartupStatus =
  | 'initializing_auth'
  | 'loading_pad'
  | 'ready'
  | 'offline_cached'
  | 'connection_error'
  | 'no_pad_selected'
  | 'pad_not_found';

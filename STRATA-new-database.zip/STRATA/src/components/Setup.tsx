/**
 * Pad setup — everything the rest of the app derives from.
 *
 * The six sections are the pad's whole model: identity and draw strategy,
 * wells and their per-sand design overrides, sand types (including the color
 * that identifies each one everywhere in the app), the cans, the supplier
 * list, and the mine-code map the scanner uses.
 *
 * Nothing here writes until Save. With no pad loaded the screen falls back to
 * the job list, because there is nothing to configure yet.
 */

import {
  Plus,
  Trash2,
  FolderPlus,
  Wrench,
  ArrowRight,
  Tag,
  AlertTriangle,
  ChevronUp,
  ChevronDown,
  Sparkles,
  Check,
  X,
} from 'lucide-react';
import { useMemo, useState, useEffect } from 'react';
import JobExport from './JobExport';
import JobManagement from './JobManagement';
import PadRecoveryModal from './PadRecoveryModal';
import { createNewPad, blankPadConfig } from '../lib/firestoreService';
import { formatLbs, formatTons } from '../lib/sandRules';
import { TONE, cn, sandClasses } from '../lib/theme';
import type { SandTone } from '../lib/theme';
import {
  DrawStrategy,
  PadConfig,
  ProductCodeMapping,
  SandTypeSpec,
  WellConfig,
  AppState,
} from '../types';

interface SetupProps {
  state?: AppState | null;
  config?: PadConfig | null;
  currentPadId: string;
  padList: { id: string; name: string }[];
  onSelectPad: (padId: string) => void;
  onRefreshPadList?: () => void;
  onUpdateConfig: (newConfig: PadConfig) => void;
  onSuccessMessage?: (msg: string) => void;
  /** Optional host toast. Without it, messages still show in the inline banner. */
  onToast?: (msg: string, tone?: 'ok' | 'warn' | 'danger') => void;
}

const STRATEGY_LABEL: Record<DrawStrategy, string> = {
  sequential_rotation: 'Sequential carousel',
  partials_then_rotate: 'Partials, then rotate',
  least_used_first: 'Least used first',
  emptiest_first: 'Emptiest first',
  fullest_first: 'Fullest first',
};

const STRATEGY_MODEL: Record<DrawStrategy, string> = {
  sequential_rotation:
    'Finish any can left partially drained by the previous stage, then rotate through the rest in ascending silo number.',
  partials_then_rotate:
    'Finish open partials first (under the threshold below, emptiest first), then rotate through cans not pulled last stage, least run-to-date first. Cans used last stage are the last resort.',
  least_used_first:
    'Rank by total lbs already run out of each can, ascending. Entering delivery tickets never reshuffles the order.',
  emptiest_first: 'Cans with the least sand on hand are pulled first, to empty them out.',
  fullest_first: 'Cans with the most sand on hand are pulled first, to free headspace.',
};

/**
 * The five sand identity tones. `value` is what lands on the config; the theme
 * resolves legacy aliases (orange reads as amber, purple as violet), so the
 * value is typed as a plain string and narrowed on write.
 */
const SAND_TONE_OPTIONS: { value: string; tone: SandTone; label: string }[] = [
  { value: 'amber', tone: 'amber', label: 'Amber' },
  { value: 'blue', tone: 'blue', label: 'Blue' },
  { value: 'emerald', tone: 'emerald', label: 'Emerald' },
  { value: 'violet', tone: 'violet', label: 'Violet' },
  { value: 'slate', tone: 'slate', label: 'Slate' },
];

export default function Setup({
  state,
  config: incomingConfig,
  currentPadId,
  padList,
  onSelectPad,
  onRefreshPadList,
  onUpdateConfig,
  onSuccessMessage,
  onToast,
}: SetupProps) {
  const config = incomingConfig || blankPadConfig;

  // ------------------------------------------------- local edit copy ---
  const [customerName, setCustomerName] = useState(config.customerName || '');
  const [padName, setPadName] = useState(config.padName || '');
  const [siloCount, setSiloCount] = useState(config.siloCount || 6);
  const [lbsPerTruckload, setLbsPerTruckload] = useState(config.lbsPerTruckload || 57000);
  const [lbsPerTon, setLbsPerTon] = useState(config.lbsPerTon || 2000);
  const [drawStrategy, setDrawStrategy] = useState<DrawStrategy>(
    config.drawStrategy || 'partials_then_rotate'
  );
  const [partialThresholdPct, setPartialThresholdPct] = useState<number>(
    config.partialThresholdPct ?? 0.75
  );
  const [reorderThresholdStages, setReorderThresholdStages] = useState(
    config.reorderThresholdStages || 5
  );

  const [wells, setWells] = useState<WellConfig[]>(config.wells || []);
  const [sandTypes, setSandTypes] = useState<SandTypeSpec[]>(config.sandTypes || []);
  const [silos, setSilos] = useState(config.silos || []);
  const [suppliers, setSuppliers] = useState<string[]>(config.suppliers || []);
  const [productCodeMappings, setProductCodeMappings] = useState<ProductCodeMapping[]>(
    config.productCodeMappings || [
      { mineCode: '100M', sandType: '100 Mesh' },
      { mineCode: '4070', sandType: '40/70' },
      { mineCode: '40/70', sandType: '40/70' },
    ]
  );

  useEffect(() => {
    const c = incomingConfig || blankPadConfig;
    setCustomerName(c.customerName || '');
    setPadName(c.padName || '');
    setSiloCount(c.siloCount || 6);
    setLbsPerTruckload(c.lbsPerTruckload || 57000);
    setLbsPerTon(c.lbsPerTon || 2000);
    setDrawStrategy(c.drawStrategy || 'partials_then_rotate');
    setPartialThresholdPct(c.partialThresholdPct ?? 0.75);
    setReorderThresholdStages(c.reorderThresholdStages || 5);
    setWells(c.wells || []);
    setSandTypes(c.sandTypes || []);
    setSilos(c.silos || []);
    setSuppliers(c.suppliers || []);
    setProductCodeMappings(c.productCodeMappings || []);
  }, [incomingConfig, currentPadId]);

  const [isCreatingPad, setIsCreatingPad] = useState(false);
  const [isCreatingPadBusy, setIsCreatingPadBusy] = useState(false);
  const [isRecoveryOpen, setIsRecoveryOpen] = useState(false);
  const [newPadNameInput, setNewPadNameInput] = useState('');

  const [notice, setNotice] = useState<{ msg: string; tone: 'ok' | 'warn' | 'danger' } | null>(
    null
  );

  const [newWellName, setNewWellName] = useState('');
  const [newWellCustomer, setNewWellCustomer] = useState('');
  const [newWellStages, setNewWellStages] = useState('40');

  const [newSandName, setNewSandName] = useState('');
  const [newSandDesign, setNewSandDesign] = useState('150000');
  const [newSandJobDesign, setNewSandJobDesign] = useState('13050000');

  const [newSupplierName, setNewSupplierName] = useState('');

  const [newMineCode, setNewMineCode] = useState('');
  const [newMappingSandType, setNewMappingSandType] = useState(sandTypes[0]?.name || '100 Mesh');

  const announce = (msg: string, tone: 'ok' | 'warn' | 'danger' = 'ok') => {
    setNotice({ msg, tone });
    if (onToast) onToast(msg, tone);
    if (tone === 'ok' && onSuccessMessage) onSuccessMessage(msg);
  };

  /* Orphan detection walks both ledgers. Keyed on the silo list being edited
     and the two record slices. */
  const orphans = useMemo(() => {
    const currentSiloNumbers = silos.map((s) => s.siloNumber);
    const activeDeliveries = (state?.deliveries || []).filter((d) => !d.deleted);
    const activeRuns = (state?.runs || []).filter((r) => !r.deleted);
    const orphanedDeliveries = activeDeliveries.filter(
      (d) => !currentSiloNumbers.includes(d.siloNumber)
    );
    const orphanedRuns = activeRuns.filter((r) => !currentSiloNumbers.includes(r.siloNumber));
    return {
      orphanedDeliveries,
      orphanedRuns,
      total: orphanedDeliveries.length + orphanedRuns.length,
    };
  }, [silos, state?.deliveries, state?.runs]);

  // ----------------------------------------------------- silo edits ---
  const handleSiloCountChange = (count: number) => {
    setSiloCount(count);
    const updatedSilos = [...silos];
    if (count > updatedSilos.length) {
      for (let i = updatedSilos.length + 1; i <= count; i++) {
        updatedSilos.push({
          siloNumber: i,
          name: `Silo ${i}`,
          side: i % 2 === 1 ? 'A' : 'B',
          sandType: sandTypes[0]?.name || null,
          manualPriority: null,
          maxCapacityLbs: 350000,
          startingBalanceLbs: 0,
          isOutOfService: false,
        });
      }
    } else if (count < updatedSilos.length) {
      updatedSilos.length = count;
    }
    setSilos(updatedSilos);
  };

  const handleAddSilo = () => {
    const nextNum = silos.length > 0 ? Math.max(...silos.map((s) => s.siloNumber)) + 1 : 1;
    const updated = [
      ...silos,
      {
        siloNumber: nextNum,
        name: `Silo ${nextNum}`,
        side: nextNum % 2 === 1 ? 'A' : 'B',
        sandType: sandTypes[0]?.name || null,
        manualPriority: null,
        maxCapacityLbs: 350000,
        startingBalanceLbs: 0,
        isOutOfService: false,
      },
    ];
    setSilos(updated);
    setSiloCount(updated.length);
  };

  const handleDeleteSilo = (siloNum: number) => {
    if (silos.length <= 1) {
      announce('A pad needs at least one silo.', 'warn');
      return;
    }
    const updated = silos.filter((s) => s.siloNumber !== siloNum);
    setSilos(updated);
    setSiloCount(updated.length);
  };

  const updateSilo = (siloNum: number, patch: Partial<(typeof silos)[number]>) => {
    setSilos(silos.map((item) => (item.siloNumber === siloNum ? { ...item, ...patch } : item)));
  };

  // ----------------------------------------------------- well edits ---
  const handleAddWell = () => {
    if (!newWellName.trim()) {
      announce('A well needs a name before it can be added.', 'warn');
      return;
    }
    const stages = parseInt(newWellStages, 10) || 40;
    setWells([
      ...wells,
      {
        id: 'w-' + Date.now(),
        name: newWellName.trim(),
        customerName: newWellCustomer.trim() || customerName.trim() || undefined,
        plannedStages: stages,
        perStageDesignOverrides: {},
      },
    ]);
    setNewWellName('');
    setNewWellCustomer('');
  };

  const handleRemoveWell = (id: string) => {
    setWells(wells.filter((w) => w.id !== id));
  };

  const handleWellOverrideChange = (wellId: string, sandTypeId: string, valStr: string) => {
    setWells(
      wells.map((w) => {
        if (w.id !== wellId) return w;
        const overrides = { ...(w.perStageDesignOverrides || {}) };
        if (valStr.trim() === '') {
          delete overrides[sandTypeId];
        } else {
          const num = parseInt(valStr, 10);
          if (!isNaN(num)) overrides[sandTypeId] = num;
        }
        return { ...w, perStageDesignOverrides: overrides };
      })
    );
  };

  // ------------------------------------------------ sand type edits ---
  const handleAddSandType = () => {
    if (!newSandName.trim()) {
      announce('A sand type needs a name before it can be added.', 'warn');
      return;
    }
    const design = parseInt(newSandDesign, 10) || 150000;
    const jobDesign = parseInt(newSandJobDesign, 10) || design * 87;
    // Give each new sand the next unused identity color so no two match.
    const nextTone = SAND_TONE_OPTIONS[sandTypes.length % SAND_TONE_OPTIONS.length].value;
    setSandTypes([
      ...sandTypes,
      {
        id: 'st-' + Date.now(),
        name: newSandName.trim(),
        perStageDesignLbs: design,
        jobDesignTotalLbs: jobDesign,
        colorCategory: nextTone as SandTypeSpec['colorCategory'],
      },
    ]);
    setNewSandName('');
  };

  const handleRemoveSandType = (id: string) => {
    setSandTypes(sandTypes.filter((st) => st.id !== id));
  };

  const handleUpdateSandType = (id: string, updates: Partial<SandTypeSpec>) => {
    setSandTypes(sandTypes.map((st) => (st.id === id ? { ...st, ...updates } : st)));
  };

  const handleReorderSandType = (index: number, direction: 'up' | 'down') => {
    const newArr = [...sandTypes];
    const targetIdx = direction === 'up' ? index - 1 : index + 1;
    if (targetIdx < 0 || targetIdx >= newArr.length) return;
    const temp = newArr[index];
    newArr[index] = newArr[targetIdx];
    newArr[targetIdx] = temp;
    setSandTypes(newArr);
  };

  // ------------------------------------------------- supplier edits ---
  const handleAddSupplier = () => {
    const name = newSupplierName.trim();
    if (!name) return;
    if (!suppliers.includes(name)) setSuppliers([...suppliers, name]);
    setNewSupplierName('');
  };

  const handleRemoveSupplier = (name: string) => {
    setSuppliers(suppliers.filter((s) => s !== name));
  };

  // --------------------------------------------- product code edits ---
  const handleAddProductCodeMapping = () => {
    if (!newMineCode.trim()) {
      announce('Enter the mine product code to map.', 'warn');
      return;
    }
    const cleanCode = newMineCode.trim().toUpperCase();
    const existingIdx = productCodeMappings.findIndex(
      (m) => m.mineCode.trim().toUpperCase() === cleanCode
    );
    if (existingIdx >= 0) {
      const updated = [...productCodeMappings];
      updated[existingIdx] = { mineCode: cleanCode, sandType: newMappingSandType };
      setProductCodeMappings(updated);
    } else {
      setProductCodeMappings([
        ...productCodeMappings,
        { mineCode: cleanCode, sandType: newMappingSandType },
      ]);
    }
    setNewMineCode('');
  };

  const handleRemoveProductCodeMapping = (mineCode: string) => {
    setProductCodeMappings(
      productCodeMappings.filter((m) => m.mineCode.toLowerCase() !== mineCode.toLowerCase())
    );
  };

  // ---------------------------------------------------- pad create ---
  const handleCreatePadSubmit = async () => {
    if (!newPadNameInput.trim() || isCreatingPadBusy) return;
    setIsCreatingPadBusy(true);
    try {
      const createdId = await createNewPad(newPadNameInput.trim());
      const created = newPadNameInput.trim();
      setIsCreatingPad(false);
      setNewPadNameInput('');
      onSelectPad(createdId);
      announce(`Created well pad "${created}".`);
    } catch (err) {
      console.error('Failed to create new pad:', err);
      announce('Could not create the pad. Check the connection and try again.', 'danger');
    } finally {
      setIsCreatingPadBusy(false);
    }
  };

  // ------------------------------------------------------- save all ---
  const handleSaveAll = () => {
    const updatedConfig: PadConfig = {
      ...config,
      customerName: customerName.trim(),
      padName,
      siloCount,
      lbsPerTruckload,
      lbsPerTon,
      drawStrategy,
      partialThresholdPct,
      reorderThresholdStages,
      suppliers,
      wells,
      sandTypes,
      silos,
      productCodeMappings,
    };

    onUpdateConfig(updatedConfig);
    announce('Pad setup saved.');
  };

  // ---------------------------------------------------------------- ---
  const noticeBanner = notice ? (
    <div
      className={cn(
        'flex items-start justify-between gap-3 rounded-md bg-elevated p-3',
        notice.tone === 'danger'
          ? 'ring-danger-1'
          : notice.tone === 'warn'
            ? 'ring-warn-1'
            : 'ring-accent-1'
      )}
      role="status"
      aria-live="polite"
    >
      <div className="flex items-start gap-2">
        {notice.tone === 'ok' ? (
          <Check className="mt-0.5 size-4 shrink-0 text-ok" />
        ) : (
          <AlertTriangle
            className={cn(
              'mt-0.5 size-4 shrink-0',
              notice.tone === 'danger' ? 'text-danger' : 'text-warn'
            )}
          />
        )}
        <span className="text-sm text-fg">{notice.msg}</span>
      </div>
      <button
        type="button"
        onClick={() => setNotice(null)}
        className="btn btn-ghost tap shrink-0 px-2"
        aria-label="Dismiss"
      >
        <X className="size-4" />
      </button>
    </div>
  ) : null;

  const createPadModal = isCreatingPad ? (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="create-pad-title"
    >
      <div className="card w-full max-w-md rounded-xl p-5">
        <div className="card-hd">
          <div>
            <div className="eyebrow">New job</div>
            <h2 id="create-pad-title" className="text-xl font-medium tracking-tight">
              Create a well pad
            </h2>
            <p className="text-sm text-muted">
              The pad starts on the default template — six cans, 57,000 lbs a truckload — and you
              configure it here.
            </p>
          </div>
        </div>

        <label className="block">
          <span className="eyebrow">Pad name</span>
          <input
            type="text"
            autoFocus
            placeholder="Eagle Ford Unit Pad 2"
            value={newPadNameInput}
            onChange={(e) => setNewPadNameInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleCreatePadSubmit();
            }}
            className="input input-lg mt-1"
          />
        </label>

        <div className="mt-5 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={() => setIsCreatingPad(false)}
            disabled={isCreatingPadBusy}
            className="btn tap"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleCreatePadSubmit}
            disabled={!newPadNameInput.trim() || isCreatingPadBusy}
            className="btn btn-accent tap"
          >
            {isCreatingPadBusy ? 'Creating' : 'Create and switch'}
          </button>
        </div>
      </div>
    </div>
  ) : null;

  // =================================================== job list view ===
  // No pad loaded: there is nothing to configure, so this screen is the job
  // list. Same manager component the configured view embeds.
  if (!state) {
    return (
      <div className="mx-auto flex w-full max-w-5xl flex-col gap-5 pb-12">
        <div className="card flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0">
            <div className="eyebrow">Job list</div>
            <h1 className="text-2xl font-medium tracking-tight">No active pad</h1>
            <p className="max-w-2xl text-sm text-muted">
              Pick a job to open it, or create a new pad. Ticket counts are read live from the
              database.
            </p>
          </div>

          <div className="flex shrink-0 flex-wrap items-center gap-2">
            {padList.length > 0 && (
              <select
                value=""
                onChange={(e) => {
                  if (e.target.value) onSelectPad(e.target.value);
                }}
                className="select w-auto"
                aria-label="Open a well pad"
              >
                <option value="">Open a pad</option>
                {padList.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name}
                  </option>
                ))}
              </select>
            )}

            <button type="button" onClick={() => setIsCreatingPad(true)} className="btn btn-accent tap">
              <FolderPlus className="size-4" /> New pad
            </button>
          </div>
        </div>

        {noticeBanner}

        <JobManagement
          currentPadId={currentPadId}
          currentState={state}
          onSelectPad={onSelectPad}
          onPadListUpdated={onRefreshPadList}
          onSuccessMessage={onSuccessMessage}
          onToast={onToast}
        />

        {createPadModal}
      </div>
    );
  }

  // ==================================================== full setup ===
  return (
    <div className="mx-auto flex w-full max-w-5xl flex-col gap-5 pb-12">
      {/* ------------------------------------------------ header --- */}
      <div className="card flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <div className="eyebrow">Pad setup{customerName ? ` · ${customerName}` : ''}</div>
          <h1 className="text-2xl font-medium tracking-tight">{padName || 'Untitled pad'}</h1>
          <p className="max-w-2xl text-sm text-muted">
            Identity, wells, sand types, cans, suppliers and mine codes. Nothing here is written
            until you save — the {STRATEGY_LABEL[drawStrategy]} draw and the per-stage designs
            below are what every other screen computes from.
          </p>
        </div>

        <div className="flex shrink-0 flex-wrap items-center gap-2">
          <button type="button" onClick={() => setIsRecoveryOpen(true)} className="btn tap">
            <Sparkles className="size-4" /> Recover wells and sand
          </button>

          <select
            value={currentPadId}
            onChange={(e) => onSelectPad(e.target.value)}
            className="select w-auto"
            aria-label="Active pad"
          >
            {padList.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>

          <button type="button" onClick={() => setIsCreatingPad(true)} className="btn tap">
            <FolderPlus className="size-4" /> New pad
          </button>
        </div>
      </div>

      {noticeBanner}

      {createPadModal}

      {/* --------------------------------------------- job manager --- */}
      <JobManagement
        currentPadId={currentPadId}
        currentState={state}
        onSelectPad={onSelectPad}
        onPadListUpdated={onRefreshPadList}
        onSuccessMessage={onSuccessMessage}
        onToast={onToast}
      />

      {/* ------------------------------ 1. identity and draw strategy --- */}
      <div className="card flex flex-col gap-4">
        <div className="card-hd mb-0">
          <div>
            <div className="eyebrow">Section 1</div>
            <h2 className="text-lg font-medium tracking-tight">Pad identity and draw strategy</h2>
            <p className="text-sm text-muted">
              The draw strategy decides which can gets pulled next whenever no manual pin is set.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
          <label className="block">
            <span className="eyebrow">Customer / operator</span>
            <input
              type="text"
              placeholder="Operator name"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
              className="input input-lg mt-1"
            />
          </label>

          <label className="block">
            <span className="eyebrow">Well pad name</span>
            <input
              type="text"
              placeholder="Pad name"
              value={padName}
              onChange={(e) => setPadName(e.target.value)}
              className="input input-lg mt-1"
            />
          </label>

          <label className="block">
            <span className="eyebrow">Silo draw strategy</span>
            <select
              value={drawStrategy}
              onChange={(e) => setDrawStrategy(e.target.value as DrawStrategy)}
              className="select input-lg mt-1"
            >
              {(Object.keys(STRATEGY_LABEL) as DrawStrategy[]).map((key) => (
                <option key={key} value={key}>
                  {STRATEGY_LABEL[key]}
                </option>
              ))}
            </select>
          </label>
        </div>

        <p className="rounded-md bg-elevated p-3 text-sm text-muted ring-border">
          {STRATEGY_MODEL[drawStrategy]}
        </p>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <label className="block">
            <span className="eyebrow">Silo count</span>
            <input
              type="number"
              inputMode="numeric"
              value={siloCount}
              onChange={(e) => handleSiloCountChange(parseInt(e.target.value, 10) || 6)}
              min={1}
              max={12}
              className="input input-num mt-1"
            />
          </label>

          <label className="block">
            <span className="eyebrow">Lbs per truckload</span>
            <input
              type="number"
              inputMode="numeric"
              value={lbsPerTruckload}
              onChange={(e) => setLbsPerTruckload(parseInt(e.target.value, 10) || 57000)}
              className="input input-num mt-1"
            />
            <span className="mt-1 block text-xs text-muted">
              <span className="num">{formatTons(lbsPerTruckload / (lbsPerTon || 2000))}</span> a
              load
            </span>
          </label>

          <label className="block">
            <span className="eyebrow">Lbs per ton</span>
            <input
              type="number"
              inputMode="numeric"
              value={lbsPerTon}
              onChange={(e) => setLbsPerTon(parseInt(e.target.value, 10) || 2000)}
              className="input input-num mt-1"
            />
          </label>

          <label className="block">
            <span className="eyebrow">Reorder alert (stages)</span>
            <input
              type="number"
              inputMode="numeric"
              value={reorderThresholdStages}
              onChange={(e) => setReorderThresholdStages(parseInt(e.target.value, 10) || 5)}
              className="input input-num mt-1"
            />
            <span className="mt-1 block text-xs text-muted">
              Alerts when a sand drops under this many stages of reserve.
            </span>
          </label>

          <label className="block">
            <span className="eyebrow">Partial below (% full)</span>
            <input
              type="number"
              inputMode="numeric"
              min={10}
              max={99}
              value={Math.round(partialThresholdPct * 100)}
              onChange={(e) => {
                const val = parseInt(e.target.value, 10);
                setPartialThresholdPct((isNaN(val) ? 75 : val) / 100);
              }}
              className="input input-num mt-1"
            />
            <span className="mt-1 block text-xs text-muted">
              A can under this counts as a partial to finish first.
            </span>
          </label>
        </div>

        {orphans.total > 0 && (
          <div className="flex items-start gap-2.5 rounded-md bg-elevated p-3 ring-danger-1">
            <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" />
            <div>
              <div className="eyebrow text-danger">
                <span className="num">{orphans.total}</span> record
                {orphans.total === 1 ? '' : 's'} logged against removed silos
              </div>
              <p className="mt-1 text-sm text-fg">
                Lowering the silo count leaves{' '}
                <span className="num">{orphans.orphanedDeliveries.length}</span> ticket
                {orphans.orphanedDeliveries.length === 1 ? '' : 's'} and{' '}
                <span className="num">{orphans.orphanedRuns.length}</span> stage run
                {orphans.orphanedRuns.length === 1 ? '' : 's'} unassigned. Nothing is destroyed —
                they surface in the unassigned column in Logs and in Diagnostics.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* ---------------------------------------------- 2. wells --- */}
      <div className="card flex flex-col gap-4">
        <div className="card-hd mb-0">
          <div>
            <div className="eyebrow">Section 2</div>
            <h2 className="text-lg font-medium tracking-tight">
              Wells, planned stages and design overrides
            </h2>
            <p className="text-sm text-muted">
              A per-well override replaces the pad default for that sand on that well only. Leave
              it blank to inherit.
            </p>
          </div>
          <span className="badge shrink-0">
            <span className="num">{wells.length}</span> well{wells.length === 1 ? '' : 's'}
          </span>
        </div>

        <div className="flex flex-col gap-3">
          {wells.map((well) => (
            <div key={well.id} className="rounded-md bg-elevated p-3 ring-border">
              <div className="flex flex-col gap-3 border-b border-border pb-3 sm:flex-row sm:items-end">
                <div className="grid flex-1 grid-cols-1 gap-3 sm:grid-cols-3">
                  <label className="block">
                    <span className="eyebrow">Well name</span>
                    <input
                      type="text"
                      value={well.name}
                      onChange={(e) =>
                        setWells(
                          wells.map((w) => (w.id === well.id ? { ...w, name: e.target.value } : w))
                        )
                      }
                      className="input mt-1"
                    />
                  </label>

                  <label className="block">
                    <span className="eyebrow">Customer</span>
                    <input
                      type="text"
                      placeholder="Operator name"
                      value={well.customerName ?? customerName ?? ''}
                      onChange={(e) =>
                        setWells(
                          wells.map((w) =>
                            w.id === well.id ? { ...w, customerName: e.target.value } : w
                          )
                        )
                      }
                      className="input mt-1"
                    />
                  </label>

                  <label className="block">
                    <span className="eyebrow">Planned stages</span>
                    <input
                      type="number"
                      inputMode="numeric"
                      value={well.plannedStages || 0}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10) || 0;
                        setWells(
                          wells.map((w) => (w.id === well.id ? { ...w, plannedStages: val } : w))
                        );
                      }}
                      className="input input-num mt-1"
                    />
                  </label>
                </div>

                <button
                  type="button"
                  onClick={() => handleRemoveWell(well.id)}
                  className="btn btn-ghost tap shrink-0 px-2.5"
                  title={`Remove ${well.name}`}
                  aria-label={`Remove well ${well.name}`}
                >
                  <Trash2 className="size-4" />
                </button>
              </div>

              <div className="mt-3">
                <div className="eyebrow">
                  Per-stage design overrides (lbs) — blank inherits the pad default
                </div>
                <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-2 md:grid-cols-3">
                  {sandTypes.map((st) => {
                    const tone = sandClasses(st.name, sandTypes);
                    const overrideVal =
                      well.perStageDesignOverrides?.[st.id] ??
                      well.perStageDesignOverrides?.[st.name] ??
                      '';
                    return (
                      <label key={st.id} className="block rounded-sm bg-surface p-2.5 ring-border">
                        <span className="eyebrow flex items-center gap-1.5">
                          <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                          <span className="truncate">{st.name}</span>
                        </span>
                        <input
                          type="number"
                          inputMode="numeric"
                          placeholder={`${st.perStageDesignLbs.toLocaleString()}`}
                          value={overrideVal}
                          onChange={(e) =>
                            handleWellOverrideChange(well.id, st.id, e.target.value)
                          }
                          className="input input-num mt-1"
                        />
                        <span className="mt-1 block text-xs text-subtle">
                          Default <span className="num">{formatLbs(st.perStageDesignLbs)}</span>
                        </span>
                      </label>
                    );
                  })}

                  {sandTypes.length === 0 && (
                    <p className="text-sm text-subtle">
                      Add a sand type below to set per-well overrides.
                    </p>
                  )}
                </div>
              </div>
            </div>
          ))}

          {wells.length === 0 && (
            <div className="rounded-md bg-elevated p-6 text-center text-sm text-subtle ring-border">
              No wells on this pad yet.
            </div>
          )}
        </div>

        {/* add well */}
        <div className="rounded-md bg-elevated p-3 ring-border">
          <div className="eyebrow">Add a well</div>
          <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-end">
            <label className="block flex-1">
              <span className="eyebrow">Well name</span>
              <input
                type="text"
                placeholder="Well 4H"
                value={newWellName}
                onChange={(e) => setNewWellName(e.target.value)}
                className="input mt-1"
              />
            </label>

            <label className="block flex-1">
              <span className="eyebrow">Customer</span>
              <input
                type="text"
                placeholder="Operator name"
                value={newWellCustomer}
                onChange={(e) => setNewWellCustomer(e.target.value)}
                className="input mt-1"
              />
            </label>

            <label className="block sm:w-32">
              <span className="eyebrow">Stages</span>
              <input
                type="number"
                inputMode="numeric"
                placeholder="45"
                value={newWellStages}
                onChange={(e) => setNewWellStages(e.target.value)}
                className="input input-num mt-1"
              />
            </label>

            <button type="button" onClick={handleAddWell} className="btn btn-accent tap shrink-0">
              <Plus className="size-4" /> Add well
            </button>
          </div>
        </div>
      </div>

      {/* ------------------------------------------ 3. sand types --- */}
      <div className="card flex flex-col gap-4">
        <div className="card-hd mb-0">
          <div>
            <div className="eyebrow">Section 3</div>
            <h2 className="text-lg font-medium tracking-tight">
              Sand types, per-stage design and job totals
            </h2>
            <p className="text-sm text-muted">
              List order is the stage run order. Each sand's color identifies it on every screen —
              the board, the pull sheet and every chart.
            </p>
          </div>
          <span className="badge shrink-0">List order = run order</span>
        </div>

        <div className="flex flex-col gap-3">
          {sandTypes.map((st, idx) => {
            const tone = sandClasses(st.name, sandTypes);
            const perStageTons = (st.perStageDesignLbs || 0) / (lbsPerTon || 2000);
            const jobTotalTons = (st.jobDesignTotalLbs || 0) / (lbsPerTon || 2000);
            const activeTone = (st.colorCategory || '').toLowerCase();

            return (
              <div key={st.id} className="rounded-md bg-elevated p-3 ring-border">
                {/* order, name, controls */}
                <div className="flex flex-col gap-3 border-b border-border pb-3 sm:flex-row sm:items-end sm:justify-between">
                  <div className="flex flex-1 items-end gap-3">
                    <div className="shrink-0">
                      <div className="eyebrow">Order</div>
                      <div className="num mt-1 flex size-11 items-center justify-center rounded-sm bg-surface text-base font-semibold ring-border">
                        {idx + 1}
                      </div>
                    </div>

                    <label className="block flex-1">
                      <span className="eyebrow flex items-center gap-1.5">
                        <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                        Sand mesh / type name
                      </span>
                      <input
                        type="text"
                        value={st.name}
                        onChange={(e) => handleUpdateSandType(st.id, { name: e.target.value })}
                        className="input mt-1 sm:max-w-xs"
                      />
                    </label>
                  </div>

                  <div className="flex shrink-0 items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleReorderSandType(idx, 'up')}
                      disabled={idx === 0}
                      className="btn tap px-2.5"
                      title="Move earlier in the run order"
                      aria-label={`Move ${st.name} earlier`}
                    >
                      <ChevronUp className="size-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleReorderSandType(idx, 'down')}
                      disabled={idx === sandTypes.length - 1}
                      className="btn tap px-2.5"
                      title="Move later in the run order"
                      aria-label={`Move ${st.name} later`}
                    >
                      <ChevronDown className="size-4" />
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRemoveSandType(st.id)}
                      className="btn btn-ghost tap px-2.5"
                      title="Delete this sand type"
                      aria-label={`Delete ${st.name}`}
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>

                {/* ------------------------------------ color picker --- */}
                <div className="mt-3">
                  <div className="eyebrow">Identity color</div>
                  <div className="mt-1.5 flex flex-wrap items-center gap-2">
                    {SAND_TONE_OPTIONS.map((opt) => {
                      const isActive =
                        activeTone === opt.value ||
                        (opt.value === 'amber' && activeTone === 'orange') ||
                        (opt.value === 'violet' && activeTone === 'purple');
                      return (
                        <button
                          key={opt.value}
                          type="button"
                          onClick={() =>
                            handleUpdateSandType(st.id, {
                              colorCategory: opt.value as SandTypeSpec['colorCategory'],
                            })
                          }
                          aria-pressed={isActive}
                          title={`${opt.label} identifies ${st.name || 'this sand'}`}
                          className={cn(
                            'tap inline-flex h-11 items-center gap-2 rounded-sm bg-surface px-3 text-sm transition-[box-shadow] duration-150',
                            isActive ? TONE[opt.tone].ring : 'ring-border'
                          )}
                        >
                          <span
                            className={cn('size-4 shrink-0 rounded-full', TONE[opt.tone].fill)}
                          />
                          <span className={isActive ? TONE[opt.tone].text : 'text-muted'}>
                            {opt.label}
                          </span>
                          {isActive && <Check className="size-3.5" />}
                        </button>
                      );
                    })}
                  </div>
                  <p className="mt-1.5 text-xs text-muted">
                    This color is how {st.name || 'this sand'} is identified everywhere in the app —
                    the canister fill, the pull sheet and every chart.
                  </p>
                </div>

                {/* --------------------------------------- designs --- */}
                <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <label className="block rounded-sm bg-surface p-3 ring-border">
                    <span className="flex items-center justify-between gap-2">
                      <span className="eyebrow">Per-stage design (lbs)</span>
                      <span className="num text-xs text-muted">
                        {perStageTons.toFixed(1)} tons / stage
                      </span>
                    </span>
                    <input
                      type="number"
                      inputMode="numeric"
                      value={st.perStageDesignLbs || 0}
                      onChange={(e) =>
                        handleUpdateSandType(st.id, {
                          perStageDesignLbs: parseInt(e.target.value, 10) || 0,
                        })
                      }
                      className="input input-num mt-1.5"
                    />
                    <span className="mt-1 block text-xs text-muted">
                      Default weight of {st.name || 'this sand'} in one stage.
                    </span>
                  </label>

                  <label className="block rounded-sm bg-surface p-3 ring-border">
                    <span className="flex items-center justify-between gap-2">
                      <span className="eyebrow">Whole-job design (lbs)</span>
                      <span className="num text-xs text-muted">
                        {jobTotalTons.toFixed(1)} tons total
                      </span>
                    </span>
                    <input
                      type="number"
                      inputMode="numeric"
                      value={st.jobDesignTotalLbs || 0}
                      onChange={(e) =>
                        handleUpdateSandType(st.id, {
                          jobDesignTotalLbs: parseInt(e.target.value, 10) || 0,
                        })
                      }
                      className="input input-num mt-1.5"
                    />
                    <span className="mt-1 block text-xs text-muted">
                      Total volume in the frac proposal for the whole pad.
                    </span>
                  </label>
                </div>
              </div>
            );
          })}

          {sandTypes.length === 0 && (
            <div className="rounded-md bg-elevated p-6 text-center text-sm text-subtle ring-border">
              No sand types configured. Silos cannot be assigned until one exists.
            </div>
          )}
        </div>

        {/* add sand type */}
        <div className="rounded-md bg-elevated p-3 ring-border">
          <div className="eyebrow">Add a sand type</div>
          <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <label className="block">
              <span className="eyebrow">Sand name / mesh</span>
              <input
                type="text"
                placeholder="30/50"
                value={newSandName}
                onChange={(e) => setNewSandName(e.target.value)}
                className="input mt-1"
              />
            </label>

            <label className="block">
              <span className="eyebrow">Per-stage design (lbs)</span>
              <input
                type="number"
                inputMode="numeric"
                placeholder="150000"
                value={newSandDesign}
                onChange={(e) => setNewSandDesign(e.target.value)}
                className="input input-num mt-1"
              />
            </label>

            <label className="block">
              <span className="eyebrow">Whole-job design (lbs)</span>
              <input
                type="number"
                inputMode="numeric"
                placeholder="13050000"
                value={newSandJobDesign}
                onChange={(e) => setNewSandJobDesign(e.target.value)}
                className="input input-num mt-1"
              />
            </label>
          </div>

          <div className="mt-3 flex items-center justify-between gap-3">
            <span className="text-xs text-muted">
              It gets the next unused identity color, editable above.
            </span>
            <button type="button" onClick={handleAddSandType} className="btn btn-accent tap">
              <Plus className="size-4" /> Add sand type
            </button>
          </div>
        </div>
      </div>

      {/* ----------------------------------------------- 4. silos --- */}
      <div className="card flex flex-col gap-4">
        <div className="card-hd mb-0">
          <div>
            <div className="eyebrow">Section 4</div>
            <h2 className="text-lg font-medium tracking-tight">
              Silos, sides, capacity and starting balances
            </h2>
            <p className="text-sm text-muted">
              Starting balance is the takeover on-hand — every later balance is that plus tickets
              minus pulls. Side labels group the rows on the board.
            </p>
          </div>
          <button type="button" onClick={handleAddSilo} className="btn tap shrink-0">
            <Plus className="size-4" /> Add silo
          </button>
        </div>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
          {silos.map((s) => {
            const tone = sandClasses(s.sandType, sandTypes);
            const startTons = (s.startingBalanceLbs || 0) / (lbsPerTon || 2000);
            const maxTons = (s.maxCapacityLbs || 350000) / (lbsPerTon || 2000);

            return (
              <div
                key={s.siloNumber}
                className={cn(
                  'flex flex-col gap-3 rounded-md bg-elevated p-3',
                  s.isOutOfService ? 'ring-danger-1' : 'ring-border'
                )}
              >
                <div className="flex items-center justify-between gap-2 border-b border-border pb-2">
                  <div className="flex min-w-0 items-center gap-2">
                    <span className={cn('size-2.5 shrink-0 rounded-full', tone.fill)} />
                    <span className="num text-sm font-semibold">Silo #{s.siloNumber}</span>
                    {s.name && s.name !== `Silo ${s.siloNumber}` && (
                      <span className="truncate text-xs text-muted">{s.name}</span>
                    )}
                  </div>

                  <div className="flex shrink-0 items-center gap-1.5">
                    <button
                      type="button"
                      aria-pressed={s.isOutOfService}
                      onClick={() => updateSilo(s.siloNumber, { isOutOfService: !s.isOutOfService })}
                      title={s.isOutOfService ? 'Bring back online' : 'Take offline'}
                      className={cn(
                        'tap inline-flex h-8 items-center gap-1.5 rounded-full px-2.5 text-[11px] font-medium uppercase tracking-[0.04em] transition-colors duration-150',
                        s.isOutOfService
                          ? 'bg-danger-dim text-danger'
                          : 'bg-surface text-muted hover:text-fg'
                      )}
                    >
                      <Wrench className="size-3" />
                      {s.isOutOfService ? 'Offline' : 'Online'}
                    </button>

                    {silos.length > 1 && (
                      <button
                        type="button"
                        title={`Delete silo #${s.siloNumber}`}
                        aria-label={`Delete silo ${s.siloNumber}`}
                        onClick={() => handleDeleteSilo(s.siloNumber)}
                        className="btn btn-ghost tap px-2"
                      >
                        <Trash2 className="size-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <label className="block">
                  <span className="eyebrow">Silo name / identifier</span>
                  <input
                    type="text"
                    placeholder={`Silo ${s.siloNumber}`}
                    value={s.name ?? `Silo ${s.siloNumber}`}
                    onChange={(e) => updateSilo(s.siloNumber, { name: e.target.value })}
                    className="input mt-1"
                  />
                </label>

                <div className="grid grid-cols-2 gap-2">
                  <label className="block">
                    <span className="eyebrow">Side / location</span>
                    <input
                      type="text"
                      list={`side-presets-${s.siloNumber}`}
                      placeholder="A, B, East"
                      value={s.side || ''}
                      onChange={(e) => updateSilo(s.siloNumber, { side: e.target.value })}
                      className="input mt-1"
                    />
                    <datalist id={`side-presets-${s.siloNumber}`}>
                      <option value="A" />
                      <option value="B" />
                      <option value="Side A" />
                      <option value="Side B" />
                      <option value="East" />
                      <option value="West" />
                      <option value="North" />
                      <option value="South" />
                    </datalist>
                  </label>

                  <label className="block">
                    <span className="eyebrow">Assigned sand</span>
                    <select
                      value={s.sandType || ''}
                      onChange={(e) =>
                        updateSilo(s.siloNumber, { sandType: e.target.value || null })
                      }
                      className="select mt-1"
                    >
                      {sandTypes.map((st) => (
                        <option key={st.id} value={st.name}>
                          {st.name}
                        </option>
                      ))}
                      <option value="">None / empty</option>
                    </select>
                  </label>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <label className="block">
                    <span className="flex items-center justify-between gap-1">
                      <span className="eyebrow">Starting bal. (lbs)</span>
                      <span className="num text-[11px] text-muted">{startTons.toFixed(1)} T</span>
                    </span>
                    <input
                      type="number"
                      inputMode="numeric"
                      value={s.startingBalanceLbs || 0}
                      onChange={(e) =>
                        updateSilo(s.siloNumber, {
                          startingBalanceLbs: parseInt(e.target.value, 10) || 0,
                        })
                      }
                      className="input input-num mt-1"
                    />
                  </label>

                  <label className="block">
                    <span className="flex items-center justify-between gap-1">
                      <span className="eyebrow">Max capacity (lbs)</span>
                      <span className="num text-[11px] text-muted">{maxTons.toFixed(1)} T</span>
                    </span>
                    <input
                      type="number"
                      inputMode="numeric"
                      value={s.maxCapacityLbs || 350000}
                      onChange={(e) =>
                        updateSilo(s.siloNumber, {
                          maxCapacityLbs: parseInt(e.target.value, 10) || 350000,
                        })
                      }
                      className="input input-num mt-1"
                    />
                  </label>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ------------------------------------------- 5. suppliers --- */}
      <div className="card flex flex-col gap-4">
        <div className="card-hd mb-0">
          <div>
            <div className="eyebrow">Section 5</div>
            <h2 className="text-lg font-medium tracking-tight">Saved sand suppliers</h2>
            <p className="text-sm text-muted">
              These fill the supplier dropdown on the ticket entry screen and group the supplier
              totals in the job export.
            </p>
          </div>
          <span className="badge shrink-0">
            <span className="num">{suppliers.length}</span> saved
          </span>
        </div>

        {suppliers.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {suppliers.map((sup) => (
              <span
                key={sup}
                className="inline-flex items-center gap-1.5 rounded-sm bg-elevated py-1 pl-3 pr-1 text-sm ring-border"
              >
                {sup}
                <button
                  type="button"
                  onClick={() => handleRemoveSupplier(sup)}
                  className="btn btn-ghost tap h-8 px-1.5"
                  title={`Remove ${sup}`}
                  aria-label={`Remove ${sup}`}
                >
                  <X className="size-3.5" />
                </button>
              </span>
            ))}
          </div>
        ) : (
          <div className="rounded-md bg-elevated p-4 text-center ring-border">
            <div className="eyebrow">No suppliers saved</div>
            <p className="mt-1 text-sm text-muted">
              Add hauler or mine names so ticket entry can pick from a list instead of retyping.
            </p>
          </div>
        )}

        <div className="flex flex-col gap-2 sm:flex-row">
          <input
            type="text"
            placeholder="Supplier or hauler name"
            value={newSupplierName}
            onChange={(e) => setNewSupplierName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleAddSupplier();
              }
            }}
            className="input flex-1"
          />
          <button type="button" onClick={handleAddSupplier} className="btn tap shrink-0">
            <Plus className="size-4" /> Add supplier
          </button>
        </div>
      </div>

      {/* --------------------------------- 6. product code mappings --- */}
      <div className="card flex flex-col gap-4">
        <div className="card-hd mb-0">
          <div className="flex min-w-0 items-start gap-2.5">
            <Tag className="mt-0.5 size-5 shrink-0 text-accent" />
            <div>
              <div className="eyebrow">Section 6</div>
              <h2 className="text-lg font-medium tracking-tight">
                Product code mappings — mine code to sand type
              </h2>
              <p className="text-sm text-muted">
                Field 4 of an Atlas six-part QR carries a mine product code such as 100M. Map the
                codes your mines use and a scan fills the sand type by itself.
              </p>
            </div>
          </div>
          <span className="badge shrink-0">
            <span className="num">{productCodeMappings.length}</span> mapped
          </span>
        </div>

        <div className="flex flex-col gap-2">
          {productCodeMappings.map((m) => {
            const tone = sandClasses(m.sandType, sandTypes);
            return (
              <div
                key={m.mineCode}
                className="flex items-center justify-between gap-3 rounded-md bg-elevated p-2.5 ring-border"
              >
                <div className="flex min-w-0 items-center gap-3">
                  <span className="num rounded-sm bg-surface px-3 py-1 text-sm font-semibold ring-border">
                    {m.mineCode}
                  </span>
                  <ArrowRight className="size-4 shrink-0 text-subtle" />
                  <span className="flex min-w-0 items-center gap-1.5">
                    <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                    <span className="truncate text-sm font-medium">{m.sandType}</span>
                  </span>
                </div>

                <button
                  type="button"
                  onClick={() => handleRemoveProductCodeMapping(m.mineCode)}
                  className="btn btn-ghost tap shrink-0 px-2"
                  title={`Remove mapping for ${m.mineCode}`}
                  aria-label={`Remove mapping for ${m.mineCode}`}
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            );
          })}

          {productCodeMappings.length === 0 && (
            <div className="rounded-md bg-elevated p-4 text-center text-sm text-subtle ring-border">
              No mappings yet — scans will leave the sand type for the operator to pick.
            </div>
          )}
        </div>

        <div className="rounded-md bg-elevated p-3 ring-border">
          <div className="eyebrow">Add a mapping</div>
          <div className="mt-2 flex flex-col gap-3 sm:flex-row sm:items-end">
            <label className="block flex-1">
              <span className="eyebrow">Mine product code</span>
              <input
                type="text"
                placeholder="100M, 4070, RC-100"
                value={newMineCode}
                onChange={(e) => setNewMineCode(e.target.value)}
                className="input num mt-1 uppercase"
              />
            </label>

            <label className="block flex-1">
              <span className="eyebrow">Our sand type</span>
              <select
                value={newMappingSandType}
                onChange={(e) => setNewMappingSandType(e.target.value)}
                className="select mt-1"
              >
                {sandTypes.map((st) => (
                  <option key={st.id} value={st.name}>
                    {st.name}
                  </option>
                ))}
              </select>
            </label>

            <button
              type="button"
              onClick={handleAddProductCodeMapping}
              className="btn btn-accent tap shrink-0"
            >
              <Plus className="size-4" /> Add pairing
            </button>
          </div>
        </div>
      </div>

      {/* ----------------------------------------- save all changes --- */}
      {orphans.total > 0 && (
        <div className="card flex items-start gap-3 ring-danger-1">
          <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" />
          <div>
            <div className="eyebrow text-danger">
              Saving leaves <span className="num">{orphans.total}</span> record
              {orphans.total === 1 ? '' : 's'} unassigned
            </div>
            <p className="mt-1 text-sm text-fg">
              <span className="num">{orphans.orphanedDeliveries.length}</span> ticket
              {orphans.orphanedDeliveries.length === 1 ? '' : 's'} and{' '}
              <span className="num">{orphans.orphanedRuns.length}</span> stage run
              {orphans.orphanedRuns.length === 1 ? '' : 's'} point at silos that will not exist in
              the new setup. They stay in the database and show in the unassigned column in Logs.
            </p>
          </div>
        </div>
      )}

      <div className="flex justify-center">
        <button type="button" onClick={handleSaveAll} className="btn btn-accent btn-xl tap w-full sm:w-auto">
          <Check className="size-5" /> Save all setup changes
        </button>
      </div>

      {/* --------------------------------------------- job export --- */}
      <div className="border-t border-border pt-5">
        <JobExport state={state} onSuccessMessage={onSuccessMessage} />
      </div>

      <PadRecoveryModal
        isOpen={isRecoveryOpen}
        onClose={() => setIsRecoveryOpen(false)}
        state={state}
        onSelectPad={onSelectPad}
      />
    </div>
  );
}

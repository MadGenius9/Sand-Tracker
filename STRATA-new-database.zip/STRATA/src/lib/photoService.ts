/**
 * Ticket photo storage.
 *
 * A ticket photo is evidence: it is the thing a coordinator opens six weeks
 * later when a supplier disputes a load. It has to survive, and it cannot
 * survive inside the Firestore document.
 *
 * Firestore's hard ceiling is 1 MiB per document. A phone camera JPEG is
 * 2-5 MB, and base64 inflates it by a further ~33%, so writing a real photo
 * into `delivery.photoUrl` fails EVERY time — and because the delivery write
 * is one document, the ticket dies with the photo. The new firestore.rules
 * make that explicit by capping `photoUrl` at 2048 characters: a Storage
 * download URL fits comfortably, a data URL cannot.
 *
 * So: downscale on the device (a 1600px long edge is more than enough to read
 * a printed ticket number, and cuts a 4 MB photo to roughly 200-400 KB),
 * upload to Cloud Storage under a path derived from the ticket's own ids, and
 * put only the URL in the document.
 */

import {
  ref as storageRef,
  uploadBytes,
  getDownloadURL,
  deleteObject,
} from 'firebase/storage';
import { storage } from './firebase';

/** Longest edge, in pixels, of the stored image. */
export const MAX_PHOTO_EDGE_PX = 1600;
/** JPEG quality for the stored image. */
export const PHOTO_JPEG_QUALITY = 0.8;

export type TicketPhotoSource = File | Blob | string;

/** Storage path for a ticket photo. Deterministic, so a re-upload replaces. */
export function ticketPhotoPath(padId: string, deliveryId: string): string {
  return `pads/${padId}/tickets/${deliveryId}.jpg`;
}

/** True for the `data:image/...;base64,...` strings AddDelivery's FileReader produces. */
export function isDataUrl(value: unknown): value is string {
  return typeof value === 'string' && value.startsWith('data:');
}

/** True for a value already safe to write straight into the document. */
export function isStoredPhotoUrl(value: unknown): value is string {
  return (
    typeof value === 'string' &&
    !value.startsWith('data:') &&
    value.length > 0 &&
    value.length <= 2048
  );
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Could not decode the ticket photo.'));
    img.src = src;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob> {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (blob) => {
        if (blob) resolve(blob);
        else reject(new Error('Could not encode the downscaled ticket photo.'));
      },
      'image/jpeg',
      quality
    );
  });
}

/**
 * Downscale to `MAX_PHOTO_EDGE_PX` on the long edge and re-encode as JPEG.
 *
 * Runs entirely on the device, before a single byte leaves it — the point is
 * a tablet on a metered LTE hotspot at a pad, not server convenience.
 */
export async function downscaleTicketPhoto(
  source: TicketPhotoSource,
  maxEdge: number = MAX_PHOTO_EDGE_PX,
  quality: number = PHOTO_JPEG_QUALITY
): Promise<Blob> {
  if (typeof document === 'undefined') {
    // No DOM (SSR / test): upload what we were given rather than failing.
    if (typeof source === 'string') throw new Error('Cannot process a data URL without a DOM.');
    return source;
  }

  const objectUrl = typeof source === 'string' ? null : URL.createObjectURL(source);
  const src = typeof source === 'string' ? source : (objectUrl as string);

  try {
    const img = await loadImage(src);
    const w = img.naturalWidth || img.width;
    const h = img.naturalHeight || img.height;
    if (!w || !h) throw new Error('The ticket photo has no readable dimensions.');

    const scale = Math.min(1, maxEdge / Math.max(w, h));
    const targetW = Math.max(1, Math.round(w * scale));
    const targetH = Math.max(1, Math.round(h * scale));

    const canvas = document.createElement('canvas');
    canvas.width = targetW;
    canvas.height = targetH;
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get a canvas context for the ticket photo.');
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, targetW, targetH);

    return await canvasToBlob(canvas, quality);
  } finally {
    if (objectUrl) URL.revokeObjectURL(objectUrl);
  }
}

/**
 * Downscale and return a data URL rather than a Blob.
 *
 * This exists for the offline queue only. A queued ticket has to carry its
 * photo in localStorage until the connection returns, and localStorage holds
 * ~5 MB for the entire origin — one raw phone JPEG would fill it and take the
 * whole write queue down with it. Downscaled, a ticket photo is 200-400 KB.
 */
export async function downscaleTicketPhotoToDataUrl(
  source: TicketPhotoSource
): Promise<string> {
  const blob = await downscaleTicketPhoto(source);
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = () => reject(new Error('Could not re-encode the ticket photo.'));
    reader.readAsDataURL(blob);
  });
}

/**
 * Downscale, upload to `pads/{padId}/tickets/{deliveryId}.jpg`, return the
 * download URL. Throws on failure — the CALLER decides what a failed photo
 * costs, and for a delivery ticket the answer is "the warning, not the ticket".
 */
export async function uploadTicketPhoto(
  padId: string,
  deliveryId: string,
  source: TicketPhotoSource
): Promise<string> {
  if (!padId) throw new Error('A pad id is required to store a ticket photo.');
  if (!deliveryId) throw new Error('A delivery id is required to store a ticket photo.');

  const blob = await downscaleTicketPhoto(source);
  const objectRef = storageRef(storage, ticketPhotoPath(padId, deliveryId));

  await uploadBytes(objectRef, blob, {
    contentType: 'image/jpeg',
    cacheControl: 'public,max-age=31536000,immutable',
    customMetadata: { padId, deliveryId },
  });

  const url = await getDownloadURL(objectRef);
  if (url.length > 2048) {
    // Would be rejected by firestore.rules; better to know here.
    throw new Error('The storage URL for this photo is too long to record on the ticket.');
  }
  return url;
}

/**
 * Remove a ticket photo. A missing object is not an error — deleting a photo
 * that was never uploaded is the normal outcome of a failed upload.
 */
export async function deleteTicketPhoto(padId: string, deliveryId: string): Promise<void> {
  if (!padId || !deliveryId) return;
  try {
    await deleteObject(storageRef(storage, ticketPhotoPath(padId, deliveryId)));
  } catch (err: any) {
    if (err?.code === 'storage/object-not-found') return;
    throw err;
  }
}

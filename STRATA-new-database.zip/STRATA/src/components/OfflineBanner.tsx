/**
 * Offline queue banner.
 *
 * Three states, one strip: offline (warn), queued-and-online (accent), and
 * queued-with-failures (danger). It is not just a label — it flushes:
 *
 *  - `window` 'online' fires  ->  flush automatically, no tap required
 *  - a queue that still has items while online  ->  flush once on mount
 *  - the Sync now button      ->  force a retry of everything, including
 *                                 items already marked failed
 *
 * `flushOfflineQueue` is itself re-entrancy guarded (it returns a zero result
 * while a flush is in flight), so an auto-flush and a thumb on the button can
 * never double-post the same queued write.
 */

import { WifiOff, RefreshCw, CheckCircle2, AlertTriangle, CloudUpload, X } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  flushOfflineQueue,
  getOfflineQueue,
  getPermanentFailures,
  acknowledgePermanentFailure,
  isOnline,
  subscribeOfflineState,
  type QueuePermanentFailure,
} from '../lib/offlineQueue';
import { executeQueueItem } from '../lib/firestoreService';
import { cn } from '../lib/theme';
import { OfflineQueueItem } from '../types';

interface OfflineBannerProps {
  padId?: string;
  onSyncComplete?: (count: number) => void;
}

export default function OfflineBanner({ padId, onSyncComplete }: OfflineBannerProps) {
  const [online, setOnline] = useState<boolean>(isOnline());
  const [queue, setQueue] = useState<OfflineQueueItem[]>(getOfflineQueue(padId));
  const [failures, setFailures] = useState<QueuePermanentFailure[]>(getPermanentFailures(padId));
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);
  const [lastFailedCount, setLastFailedCount] = useState<number>(0);

  // The flush closure is rebuilt whenever padId changes; the listener reads it
  // through a ref so the 'online' subscription itself never re-registers.
  const isSyncingRef = useRef<boolean>(false);

  useEffect(() => {
    const unsub = subscribeOfflineState((currentOnline, currentQueue, currentFailures) => {
      setOnline(currentOnline);
      const filtered = padId
        ? currentQueue.filter((item) => item.padId === padId)
        : currentQueue;
      setQueue(filtered);
      setFailures(
        padId ? (currentFailures || []).filter((f) => f.padId === padId) : currentFailures || []
      );
    });
    return unsub;
  }, [padId]);

  const runFlush = useCallback(
    async (trigger: 'manual' | 'auto') => {
      if (isSyncingRef.current) return;
      if (!isOnline()) return;
      if (getOfflineQueue(padId).length === 0) {
        if (trigger === 'manual') {
          setSyncStatusMsg('Everything on this device is already saved to the cloud.');
          setTimeout(() => setSyncStatusMsg(null), 2500);
        }
        return;
      }

      isSyncingRef.current = true;
      setIsSyncing(true);
      setSyncStatusMsg(
        trigger === 'auto'
          ? 'Connection is back — sending queued changes.'
          : 'Sending queued changes to the cloud.'
      );

      try {
        const { processed, failed } = await flushOfflineQueue(executeQueueItem, padId);
        setLastFailedCount(failed);

        if (processed > 0 && failed === 0) {
          setSyncStatusMsg(`Synced ${processed} change${processed > 1 ? 's' : ''}.`);
          if (onSyncComplete) onSyncComplete(processed);
          setTimeout(() => setSyncStatusMsg(null), 4000);
        } else if (processed > 0 && failed > 0) {
          setSyncStatusMsg(
            `Synced ${processed}, ${failed} still failing. They stay queued and retry on the next connection.`
          );
          if (onSyncComplete) onSyncComplete(processed);
        } else if (failed > 0) {
          setSyncStatusMsg(
            `${failed} change${failed > 1 ? 's' : ''} could not be sent. They stay queued and retry on the next connection.`
          );
        } else {
          setSyncStatusMsg('Everything on this device is already saved to the cloud.');
          setTimeout(() => setSyncStatusMsg(null), 2500);
        }
      } catch (err) {
        console.error('Offline queue flush failed:', err);
        setSyncStatusMsg('Sync error. The queue is intact and retries when the connection returns.');
      } finally {
        isSyncingRef.current = false;
        setIsSyncing(false);
      }
    },
    [padId, onSyncComplete]
  );

  /* Auto-flush. The browser 'online' event is the whole point: a crew that
     drives back into coverage should not have to know a Sync button exists. */
  useEffect(() => {
    const handleOnline = () => {
      void runFlush('auto');
    };
    window.addEventListener('online', handleOnline);
    // A tab that opens already online with a stale queue gets the same treatment.
    if (isOnline() && getOfflineQueue(padId).length > 0) {
      void runFlush('auto');
    }
    return () => window.removeEventListener('online', handleOnline);
  }, [runFlush, padId]);

  const { pendingCount, failedCount, retryCount } = useMemo(() => {
    return {
      pendingCount: queue.length,
      failedCount: queue.filter((item) => item.status === 'failed').length,
      retryCount: queue.reduce((sum, item) => sum + (item.retries || 0), 0),
    };
  }, [queue]);

  // Nothing queued, connected, nothing lost, nothing to say.
  if (online && pendingCount === 0 && !syncStatusMsg && failures.length === 0) {
    return null;
  }

  const tone = !online
    ? 'warn'
    : failedCount > 0
      ? 'danger'
      : pendingCount > 0
        ? 'accent'
        : 'ok';

  return (
    <div
      className={cn(
        'no-print w-full bg-surface px-4 py-2.5 sm:px-6',
        tone === 'warn' && 'ring-warn-1',
        tone === 'danger' && 'ring-danger-1',
        tone === 'accent' && 'ring-accent-1',
        tone === 'ok' && 'ring-border'
      )}
      role="status"
      aria-live="polite"
    >
      <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-3">
        <div className="flex min-w-0 items-start gap-2.5">
          {!online ? (
            <WifiOff className="mt-0.5 size-5 shrink-0 text-warn" />
          ) : failedCount > 0 ? (
            <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" />
          ) : pendingCount > 0 ? (
            <CloudUpload className="mt-0.5 size-5 shrink-0 text-accent" />
          ) : (
            <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-ok" />
          )}

          <div className="min-w-0">
            <div
              className={cn(
                'eyebrow',
                tone === 'warn' && 'text-warn',
                tone === 'danger' && 'text-danger',
                tone === 'accent' && 'text-accent',
                tone === 'ok' && 'text-ok'
              )}
            >
              {!online
                ? 'Offline — writing to this device'
                : failedCount > 0
                  ? 'Sync incomplete'
                  : pendingCount > 0
                    ? 'Queued for the cloud'
                    : 'Sync'}
            </div>

            <div className="mt-0.5 text-sm text-fg">
              {!online ? (
                <>
                  Tickets and runs are saved on this tablet and go up the moment the
                  connection returns.
                </>
              ) : syncStatusMsg ? (
                syncStatusMsg
              ) : (
                <>
                  <span className="num">{pendingCount}</span> change
                  {pendingCount === 1 ? '' : 's'} waiting to send.
                </>
              )}
            </div>

            {(pendingCount > 0 || failedCount > 0 || retryCount > 0) && (
              <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
                <span className="badge">
                  <span className="num">{pendingCount}</span> queued
                </span>
                {failedCount > 0 && (
                  <span className="badge badge-danger">
                    <span className="num">{failedCount}</span> failed
                  </span>
                )}
                {retryCount > 0 && (
                  <span className="badge badge-warn">
                    <span className="num">{retryCount}</span> retr{retryCount === 1 ? 'y' : 'ies'}
                  </span>
                )}
                {lastFailedCount > 0 && failedCount === 0 && (
                  <span className="badge badge-ok">Cleared</span>
                )}
              </div>
            )}
          </div>
        </div>

        {online && pendingCount > 0 && (
          <button
            type="button"
            onClick={() => void runFlush('manual')}
            disabled={isSyncing}
            className="btn tap shrink-0"
            title="Force a retry of every queued change, including ones already marked failed"
          >
            <RefreshCw className={cn('size-4', isSyncing && 'animate-spin')} />
            {isSyncing ? 'Syncing' : failedCount > 0 ? 'Retry now' : 'Sync now'}
          </button>
        )}
      </div>

      {/* Permanently lost writes.
          The old build dropped an item after five retries with a console.warn
          and nothing else — a ticket entered in a dead zone could vanish and
          the only trace was in a devtools log nobody on a pad ever opens.
          A lost write now names itself and stays on screen until dismissed,
          with enough detail to re-enter it by hand. */}
      {failures.length > 0 && (
        <div className="mx-auto mt-3 w-full max-w-6xl space-y-2">
          {failures.map((f) => (
            <div
              key={f.id}
              className="flex items-start gap-2.5 rounded-sm bg-danger-dim px-3 py-2.5 ring-danger-1"
            >
              <AlertTriangle className="mt-0.5 size-4 shrink-0 text-danger" />
              <div className="min-w-0 flex-1">
                <div className="text-sm font-medium text-danger">
                  Not saved: {f.label}
                </div>
                <div className="mt-0.5 text-xs text-muted">
                  {f.reason} — this change never reached the cloud after {f.retries} attempt
                  {f.retries === 1 ? '' : 's'}. Re-enter it by hand.
                </div>
              </div>
              <button
                type="button"
                onClick={() => acknowledgePermanentFailure(f.id)}
                className="btn btn-ghost size-8 shrink-0 !px-0"
                aria-label="Dismiss"
                title="Dismiss — the change is still not saved"
              >
                <X className="size-4" />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

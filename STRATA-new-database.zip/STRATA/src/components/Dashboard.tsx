/**
 * Dashboard — the pad executive summary.
 *
 * Every figure on this screen comes from `sandRules.ts` (domain truth) or
 * `analytics.ts` (forward-looking / time series). Nothing is recomputed here
 * except the presentation-only reshapes that no model function exposes, and
 * every one of those is memoized on the state slices it reads.
 *
 * The previous build called five whole-state aggregators on every render with
 * no memoization at all; on a field tablet that meant a full pad recompute for
 * every keystroke and every Firestore heartbeat.
 */

import {
  AlertTriangle,
  Boxes,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Factory,
  FileSpreadsheet,
  Gauge,
  Layers,
  Sparkles,
  Users,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  calculateDeliveredBySupplier,
  calculateJobDesignMetrics,
  formatLbsNumber,
  getDiagnosticsReport,
  getPadSummary,
  getSiloDerivedStates,
} from '../lib/sandRules';
import {
  getDailySeries,
  getForecast,
  getPadAlerts,
  getWellProgress,
  type PadAlert,
} from '../lib/analytics';
import { sandClasses, cn } from '../lib/theme';
import { AppState } from '../types';
import Canister from './ui/Canister';
import PadRecoveryModal from './PadRecoveryModal';

type TabName =
  | 'dashboard'
  | 'board'
  | 'pullsheet'
  | 'job_design'
  | 'progress'
  | 'delivery'
  | 'run'
  | 'logs'
  | 'diagnostics'
  | 'setup';

interface DashboardProps {
  state: AppState;
  onNavigateTab: (tab: TabName, opts?: { siloNumber?: number }) => void;
  onSelectPad?: (padId: string) => void;
}

/**
 * `PadAlert.target` names the view that resolves the alert, in the analytics
 * layer's own vocabulary. This is the only place that vocabulary is translated
 * into this app's tab names, so a deep link can never silently go nowhere.
 */
const ALERT_TARGETS: Record<string, { tab: TabName; action: string }> = {
  board: { tab: 'board', action: 'Silo board' },
  forecast: { tab: 'delivery', action: 'Add deliveries' },
  diagnostics: { tab: 'diagnostics', action: 'Diagnostics' },
  setup: { tab: 'setup', action: 'Open setup' },
  logs: { tab: 'logs', action: 'Open logs' },
  pullsheet: { tab: 'pullsheet', action: 'Pull sheet' },
  job_design: { tab: 'job_design', action: 'Job design' },
};

const ALERT_BADGE: Record<PadAlert['tone'], { cls: string; label: string }> = {
  danger: { cls: 'badge badge-danger', label: 'Act now' },
  warn: { cls: 'badge badge-warn', label: 'Watch' },
  ok: { cls: 'badge badge-ok', label: 'Clear' },
};

function fmtDay(dateStr: string): string {
  const d = new Date(`${dateStr}T12:00:00`);
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function fmtWeekday(dateStr: string): string {
  const d = new Date(`${dateStr}T12:00:00`);
  return d.toLocaleDateString('en-US', { weekday: 'short' });
}

export default function Dashboard({ state, onNavigateTab, onSelectPad }: DashboardProps) {
  const { config, deliveries, runs } = state;
  const [isRecoveryOpen, setIsRecoveryOpen] = useState(false);

  const lbsPerTon = config.lbsPerTon || 2000;
  const lbsPerTruckload = config.lbsPerTruckload || 57000;
  const reorderThresholdStages = config.reorderThresholdStages || 5;

  const sandTypes = config.sandTypes || [];
  const silos = config.silos || [];

  /* ------------------------------------------------------------ model --- */
  /* Each of these walks every delivery and every run. They are memoized on
     the exact slices they read so a tab switch or a modal open is free. */

  const padSummary = useMemo(() => getPadSummary(state), [config, deliveries, runs]);
  const siloDerivedStates = useMemo(
    () => getSiloDerivedStates(state),
    [config, deliveries, runs]
  );
  const jobMetrics = useMemo(
    () => calculateJobDesignMetrics(state),
    [config, deliveries, runs]
  );
  const supplierRows = useMemo(() => calculateDeliveredBySupplier(state), [config, deliveries]);
  const diagReport = useMemo(() => getDiagnosticsReport(state), [config, deliveries, runs]);
  const forecast = useMemo(() => getForecast(state), [config, deliveries, runs]);
  const wellProgress = useMemo(() => getWellProgress(state), [config, runs]);
  const padAlerts = useMemo(() => getPadAlerts(state), [config, deliveries, runs]);

  /* -------------------------------------------------- recovery nudge --- */

  const uniqueUnconfiguredSands = useMemo(() => {
    const found = new Set<string>();
    for (const d of deliveries) {
      if (!d.sandType) continue;
      const known = sandTypes.some(
        (st) => st.name.toLowerCase() === d.sandType.toLowerCase()
      );
      if (!known) found.add(d.sandType);
    }
    return Array.from(found);
  }, [deliveries, sandTypes]);

  const isPossibleReset =
    uniqueUnconfiguredSands.length > 0 ||
    (config.padName.toLowerCase().includes('rattlesnake') && deliveries.length > 0);

  /* --------------------------------------------------------- alerts --- */

  /**
   * getPadAlerts owns the operational alerts (shortfall, reorder, negative can,
   * over capacity, unassigned silo). It does not speak to ticket hygiene, so
   * the two audit items the old strip carried are appended from the
   * diagnostics report rather than recomputed by hand.
   */
  const alerts = useMemo(() => {
    const rows: Array<PadAlert & { key: string }> = padAlerts.map((a, i) => ({
      ...a,
      key: `pad-${i}`,
    }));

    if (diagReport.unassignedSiloDeliveries.length > 0) {
      rows.push({
        key: 'unconfigured-silo-tickets',
        tone: 'warn',
        target: 'logs',
        message: `${diagReport.unassignedSiloDeliveries.length} ticket(s) are logged to silo numbers that are not in this pad's config.`,
      });
    }

    if (diagReport.duplicateTicketNumbers.length > 0) {
      const totalDups = diagReport.duplicateTicketNumbers.reduce((s, d) => s + d.count, 0);
      rows.push({
        key: 'duplicate-tickets',
        tone: 'danger',
        target: 'logs',
        message: `${diagReport.duplicateTicketNumbers.length} ticket number(s) were entered more than once (${totalDups} entries total).`,
      });
    }

    return rows;
  }, [padAlerts, diagReport]);

  const openAlertCount = alerts.filter((a) => a.tone !== 'ok').length;

  /* ------------------------------------------- 1. on-hand position --- */

  const onHandPositions = useMemo(
    () =>
      sandTypes.map((st) => {
        const startingLbs = silos
          .filter((s) => s.sandType === st.name)
          .reduce((sum, s) => sum + (s.startingBalanceLbs || 0), 0);

        const sandDeliveries = deliveries.filter((d) => d.sandType === st.name);
        const deliveredLbs = sandDeliveries.reduce((sum, d) => sum + (d.lbs || 0), 0);
        const pumpedLbs = runs
          .filter((r) => r.sandType === st.name)
          .reduce((sum, r) => sum + (r.lbsPulled || 0), 0);

        const onHandLbs = startingLbs + deliveredLbs - pumpedLbs;

        let lastDeliveryDate = '—';
        if (sandDeliveries.length > 0) {
          lastDeliveryDate = sandDeliveries.reduce((latest, d) => {
            if (d.date > latest.date) return d;
            if (d.date === latest.date && (d.createdAt || 0) > (latest.createdAt || 0)) return d;
            return latest;
          }).date;
        }

        return {
          sandType: st,
          startingLbs,
          deliveredLbs,
          deliveredTons: deliveredLbs / lbsPerTon,
          deliveredLoads: sandDeliveries.length,
          deliveredTruckloadsEquiv: deliveredLbs / lbsPerTruckload,
          pumpedLbs,
          onHandLbs,
          onHandTons: onHandLbs / lbsPerTon,
          stagesOnHand: st.perStageDesignLbs > 0 ? onHandLbs / st.perStageDesignLbs : 0,
          lastDeliveryDate,
        };
      }),
    [sandTypes, silos, deliveries, runs, lbsPerTon, lbsPerTruckload]
  );

  const totals = useMemo(() => {
    const totalDeliveredLbs = onHandPositions.reduce((s, p) => s + p.deliveredLbs, 0);
    const totalPumpedLbs = onHandPositions.reduce((s, p) => s + p.pumpedLbs, 0);
    const totalOnHandLbs = onHandPositions.reduce((s, p) => s + p.onHandLbs, 0);
    const totalPerStageDesignLbs = sandTypes.reduce(
      (s, st) => s + (st.perStageDesignLbs || 0),
      0
    );

    let lastDeliveryDate = '—';
    for (const d of deliveries) {
      if (lastDeliveryDate === '—' || d.date > lastDeliveryDate) lastDeliveryDate = d.date;
    }

    return {
      totalDeliveredLbs,
      totalDeliveredTons: totalDeliveredLbs / lbsPerTon,
      totalDeliveredLoads: onHandPositions.reduce((s, p) => s + p.deliveredLoads, 0),
      totalDeliveredTruckloadsEquiv: totalDeliveredLbs / lbsPerTruckload,
      totalPumpedLbs,
      totalOnHandLbs,
      totalOnHandTons: totalOnHandLbs / lbsPerTon,
      totalStagesOnHand:
        totalPerStageDesignLbs > 0 ? totalOnHandLbs / totalPerStageDesignLbs : 0,
      lastDeliveryDate,
    };
  }, [onHandPositions, sandTypes, deliveries, lbsPerTon, lbsPerTruckload]);

  /* ------------------------------------------------- 2. sand runway --- */

  const runway = useMemo(() => {
    const rows = onHandPositions.map((pos) => {
      const stages = pos.stagesOnHand;
      let tone: 'danger' | 'warn' | 'ok' = 'ok';
      let label = 'Safe';
      if (stages < reorderThresholdStages) {
        tone = 'danger';
        label = 'Below reorder line';
      } else if (stages <= reorderThresholdStages + 0.5) {
        tone = 'warn';
        label = 'Near reorder line';
      }
      const cover = forecast.sandTypeRows.find((r) => r.sandType === pos.sandType.name);
      return {
        sandType: pos.sandType,
        stagesOnHand: stages,
        threshold: reorderThresholdStages,
        tone,
        label,
        // Only quote a date once the burn rate is built on enough pumping
        // days to mean anything — otherwise the runway bar says SAFE while
        // the line under it says the can empties today.
        projectedEmptyDate:
          forecast.burnConfidence === 'ok' ? (cover?.projectedEmptyDate ?? null) : null,
      };
    });

    const maxScale = Math.max(
      reorderThresholdStages * 2,
      10,
      ...rows.map((r) => Math.ceil(r.stagesOnHand * 1.2))
    );

    return { rows, maxScale };
  }, [onHandPositions, reorderThresholdStages, forecast]);

  /* ----------------------------------------------- 3. stage progress --- */

  const stageTotals = useMemo(() => {
    const planned = wellProgress.reduce((s, w) => s + w.planned, 0);
    const done = wellProgress.reduce((s, w) => s + w.completed, 0);
    return {
      planned,
      done,
      left: Math.max(0, planned - done),
      pct: planned > 0 ? Math.min(100, Math.round((done / planned) * 100)) : 0,
    };
  }, [wellProgress]);

  /* -------------------------------------------- 5. on hand by silo --- */

  const siloTableData = useMemo(
    () =>
      silos.map((silo) => {
        const delivered = deliveries
          .filter((d) => d.siloNumber === silo.siloNumber)
          .reduce((sum, d) => sum + (d.lbs || 0), 0);
        const runToDate = runs
          .filter((r) => r.siloNumber === silo.siloNumber)
          .reduce((sum, r) => sum + (r.lbsPulled || 0), 0);
        const onHandLbs = (silo.startingBalanceLbs || 0) + delivered - runToDate;
        const maxCap = silo.maxCapacityLbs || 350000;
        return {
          silo,
          delivered,
          runToDate,
          onHandLbs,
          percentFull: Math.min(999, Math.max(0, (onHandLbs / maxCap) * 100)),
          isNegative: onHandLbs < 0,
        };
      }),
    [silos, deliveries, runs]
  );

  /* --------------------------------------------- 7. deliveries by day --- */

  /** The window ends on the last day that saw activity, not on today — a pad
      that stood down for a week should still show its last two working weeks. */
  const windowEnd = useMemo(() => {
    let latest = '';
    for (const d of deliveries) if (d.date > latest) latest = d.date;
    for (const r of runs) if (r.date > latest) latest = r.date;
    return latest || undefined;
  }, [deliveries, runs]);

  const daily = useMemo(
    () => getDailySeries(state, 14, windowEnd),
    [deliveries, runs, windowEnd]
  );

  /** Per-sand lbs per day. DailyPoint carries the totals; the sand split is a
      presentation-only reshape, so it lives here — memoized. */
  const dailyBySand = useMemo(() => {
    const byDate = new Map<string, Record<string, number>>();
    for (const point of daily) byDate.set(point.date, {});
    for (const d of deliveries) {
      if (d.deleted) continue;
      const row = byDate.get(d.date);
      if (!row) continue;
      row[d.sandType] = (row[d.sandType] || 0) + (d.lbs || 0);
    }
    return byDate;
  }, [daily, deliveries]);

  const dailyTotals = useMemo(() => {
    const perSand: Record<string, number> = {};
    for (const st of sandTypes) {
      perSand[st.name] = daily.reduce(
        (sum, p) => sum + (dailyBySand.get(p.date)?.[st.name] || 0),
        0
      );
    }
    return {
      perSand,
      deliveredLbs: daily.reduce((s, p) => s + p.deliveredLbs, 0),
      pumpedLbs: daily.reduce((s, p) => s + p.pumpedLbs, 0),
      loads: daily.reduce((s, p) => s + p.loadsIn, 0),
    };
  }, [daily, dailyBySand, sandTypes]);

  const chartData = useMemo(
    () =>
      daily.map((p) => ({
        day: fmtDay(p.date),
        delivered: Math.round(p.deliveredLbs / 100) / 10,
        pumped: Math.round(p.pumpedLbs / 100) / 10,
      })),
    [daily]
  );

  /* ----------------------------------------------------------- view --- */

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 pb-12">
      {/* ---------------------------------------------------- header --- */}
      <div className="card">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div>
            <div className="eyebrow">Pad executive summary</div>
            <h1 className="text-2xl font-medium tracking-tight">
              {config.padName || 'Pad dashboard'}
            </h1>
            <p className="max-w-2xl text-sm text-muted">
              On hand = starting balance + delivered − pumped. Stages of cover use each
              sand&apos;s per-stage design; burn uses the last seven pumping days, not calendar
              days. A stage counts complete only when every sand in its design is satisfied.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setIsRecoveryOpen(true)}
            className="btn tap shrink-0"
            title="Data recovery and well setup reconstruction"
          >
            <Sparkles className="size-4" />
            <span>Restore setup</span>
          </button>
        </div>

        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Pad on hand</div>
            <div className="stat-v mt-1 text-accent">
              {formatLbsNumber(totals.totalOnHandLbs)}
            </div>
            <div className="text-xs text-muted">
              <span className="num">{totals.totalOnHandTons.toFixed(1)}</span> tons ·{' '}
              <span className="num">
                {(totals.totalOnHandLbs / lbsPerTruckload).toFixed(1)}
              </span>{' '}
              loads
            </div>
          </div>

          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Stages of cover</div>
            <div className="stat-v mt-1">{totals.totalStagesOnHand.toFixed(1)}</div>
            <div className="text-xs text-muted">
              reorder at <span className="num">{reorderThresholdStages}.0</span> stages
            </div>
          </div>

          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Stages left</div>
            <div className="stat-v mt-1">{stageTotals.left}</div>
            <div className="text-xs text-muted">
              of <span className="num">{stageTotals.planned}</span> planned
              {/* A pace derived from one or two pumping days is not a pace.
                  Rather than print a confident "3 days" off a single catch-up
                  shift, say what is missing. */}
              {forecast.burnConfidence === 'ok' && forecast.daysToFinishJob !== null ? (
                <>
                  {' '}
                  · <span className="num">{Math.ceil(forecast.daysToFinishJob)}</span> days at
                  current pace
                </>
              ) : (
                <> · pace needs three pumping days</>
              )}
            </div>
          </div>

          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Stages done</div>
            <div className="stat-v mt-1">{stageTotals.done}</div>
            <div className="text-xs text-muted">
              <span className="num">{stageTotals.pct}%</span> of{' '}
              <span className="num">{stageTotals.planned}</span>
            </div>
            <div className="meter mt-2">
              <span style={{ width: `${stageTotals.pct}%` }} />
            </div>
          </div>
        </div>
      </div>

      {/* -------------------------------------------- recovery nudge --- */}
      {isPossibleReset && (
        <div className="card ring-warn-1">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <Sparkles className="mt-0.5 size-5 shrink-0 text-warn" />
              <div>
                <div className="text-sm font-medium text-warn">
                  Recover your well names and sand setup
                </div>
                <p className="mt-0.5 max-w-3xl text-xs text-muted">
                  {uniqueUnconfiguredSands.length > 0
                    ? `Logged tickets carry sand types (${uniqueUnconfiguredSands.join(', ')}) that are not in the current setup.`
                    : 'Did the well or sand configuration reset? Well names, stage counts, sand types and silo mappings can be restored in one step from history or a device backup.'}
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsRecoveryOpen(true)}
              className="btn btn-accent tap shrink-0"
            >
              <Sparkles className="size-4" />
              <span>Recover well &amp; sand setup</span>
            </button>
          </div>
        </div>
      )}

      {/* ---------------------------------------------- alerts strip --- */}
      <div className={cn('card', openAlertCount > 0 && 'ring-danger-1')}>
        <div className="card-hd">
          <div>
            <div className="eyebrow">Attention</div>
            <h2 className="text-base font-medium tracking-tight">
              {openAlertCount > 0
                ? `${openAlertCount} item${openAlertCount === 1 ? '' : 's'} need a decision`
                : 'Pad is clear'}
            </h2>
          </div>
          <span className="eyebrow-aside">Each row links to the fix</span>
        </div>

        <div className="grid grid-cols-1 gap-2 lg:grid-cols-2">
          {alerts.map((alert) => {
            const link = alert.target ? ALERT_TARGETS[alert.target] : undefined;
            return (
              <div
                key={alert.key}
                className="flex items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-border"
              >
                <div className="flex min-w-0 items-start gap-2">
                  {alert.tone === 'ok' ? (
                    <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-ok" />
                  ) : (
                    <AlertTriangle
                      className={cn(
                        'mt-0.5 size-4 shrink-0',
                        alert.tone === 'danger' ? 'text-danger' : 'text-warn'
                      )}
                    />
                  )}
                  <div className="min-w-0">
                    <span className={ALERT_BADGE[alert.tone].cls}>
                      {ALERT_BADGE[alert.tone].label}
                    </span>
                    <p className="mt-1 text-xs text-fg">{alert.message}</p>
                  </div>
                </div>

                {link && (
                  <button
                    type="button"
                    onClick={() => onNavigateTab(link.tab)}
                    className="btn tap shrink-0 px-3 text-xs"
                  >
                    <span>{link.action}</span>
                    <ChevronRight className="size-3.5" />
                  </button>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* -------------------------------------------- canister strip --- */}
      <div className="card">
        <div className="card-hd">
          <div>
            <div className="eyebrow">Cans</div>
            <h2 className="text-base font-medium tracking-tight">Silo field</h2>
          </div>
          <span className="eyebrow-aside">
            Fill is the sand type · ring is the status · tap opens the board
          </span>
        </div>

        {siloDerivedStates.length === 0 && (
          <p className="text-xs text-subtle">
            No silos configured for this pad yet — add them in Setup.
          </p>
        )}

        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {siloDerivedStates.map((silo) => (
            <Canister
              key={silo.siloNumber}
              silo={silo}
              sandTypes={sandTypes}
              compact
              showPull={false}
              onClick={() => onNavigateTab('board')}
            />
          ))}
        </div>
      </div>

      {/* ------------------------------------------- two-column body --- */}
      <div className="grid grid-cols-1 items-start gap-5 min-[900px]:grid-cols-2">
        <div className="flex flex-col gap-5">
          {/* ------------------------------- 1. on-hand position --- */}
          <div className="card">
            <div className="card-hd">
              <div>
                <div className="eyebrow">Section 1</div>
                <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
                  <Boxes className="size-4 text-muted" /> On-hand position
                </h2>
              </div>
              <span className="eyebrow-aside">
                {sandTypes.length} sand {sandTypes.length === 1 ? 'type' : 'types'}
              </span>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="tbl">
                <thead>
                  <tr>
                    <th className="w-44">Metric</th>
                    {onHandPositions.map((pos) => {
                      const tone = sandClasses(pos.sandType.name, sandTypes);
                      return (
                        <th key={pos.sandType.id} className={cn('n', tone.text)}>
                          {pos.sandType.name}
                        </th>
                      );
                    })}
                    <th className="n text-fg">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="text-muted">Delivered (lbs)</td>
                    {onHandPositions.map((pos) => (
                      <td key={pos.sandType.id} className="n">
                        {formatLbsNumber(pos.deliveredLbs)}
                      </td>
                    ))}
                    <td className="n font-semibold">
                      {formatLbsNumber(totals.totalDeliveredLbs)}
                    </td>
                  </tr>

                  <tr>
                    <td className="text-muted">Delivered (tons)</td>
                    {onHandPositions.map((pos) => (
                      <td key={pos.sandType.id} className="n text-muted">
                        {pos.deliveredTons.toFixed(1)} t
                      </td>
                    ))}
                    <td className="n">{totals.totalDeliveredTons.toFixed(1)} t</td>
                  </tr>

                  <tr>
                    <td className="text-muted">Delivered (loads)</td>
                    {onHandPositions.map((pos) => (
                      <td key={pos.sandType.id} className="n text-muted">
                        {pos.deliveredLoads}
                        <span className="text-subtle">
                          {' '}
                          ({pos.deliveredTruckloadsEquiv.toFixed(1)} tl)
                        </span>
                      </td>
                    ))}
                    <td className="n">
                      {totals.totalDeliveredLoads}
                      <span className="text-subtle">
                        {' '}
                        ({totals.totalDeliveredTruckloadsEquiv.toFixed(1)} tl)
                      </span>
                    </td>
                  </tr>

                  <tr>
                    <td className="text-muted">Pumped (lbs)</td>
                    {onHandPositions.map((pos) => (
                      <td key={pos.sandType.id} className="n text-muted">
                        {formatLbsNumber(pos.pumpedLbs)}
                      </td>
                    ))}
                    <td className="n">{formatLbsNumber(totals.totalPumpedLbs)}</td>
                  </tr>

                  <tr className="bg-elevated">
                    <td className="font-medium">On hand (lbs)</td>
                    {onHandPositions.map((pos) => (
                      <td
                        key={pos.sandType.id}
                        className={cn(
                          'n font-semibold',
                          pos.onHandLbs < 0 ? 'text-danger' : 'text-fg'
                        )}
                      >
                        {formatLbsNumber(pos.onHandLbs)}
                      </td>
                    ))}
                    <td className="n font-semibold text-accent">
                      {formatLbsNumber(totals.totalOnHandLbs)}
                    </td>
                  </tr>

                  <tr className="bg-elevated">
                    <td className="text-muted">On hand (tons)</td>
                    {onHandPositions.map((pos) => (
                      <td
                        key={pos.sandType.id}
                        className={cn('n', pos.onHandTons < 0 ? 'text-danger' : 'text-fg')}
                      >
                        {pos.onHandTons.toFixed(1)} t
                      </td>
                    ))}
                    <td className="n text-accent">{totals.totalOnHandTons.toFixed(1)} t</td>
                  </tr>

                  <tr>
                    <td className="text-muted">Stages of sand on hand</td>
                    {onHandPositions.map((pos) => (
                      <td
                        key={pos.sandType.id}
                        className={cn(
                          'n',
                          pos.stagesOnHand < reorderThresholdStages
                            ? 'text-danger'
                            : 'text-ok'
                        )}
                      >
                        {pos.stagesOnHand.toFixed(1)} stg
                      </td>
                    ))}
                    <td className="n">{totals.totalStagesOnHand.toFixed(1)} stg</td>
                  </tr>

                  <tr>
                    <td className="text-muted">Last delivery received</td>
                    {onHandPositions.map((pos) => (
                      <td key={pos.sandType.id} className="n text-muted">
                        {pos.lastDeliveryDate}
                      </td>
                    ))}
                    <td className="n text-muted">{totals.lastDeliveryDate}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* ------------------------------------ 2. sand runway --- */}
          <div className="card">
            <div className="card-hd">
              <div>
                <div className="eyebrow">Section 2</div>
                <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
                  <Gauge className="size-4 text-muted" /> Sand runway
                </h2>
              </div>
              <span className="eyebrow-aside">
                Reorder line {reorderThresholdStages}.0 stages
              </span>
            </div>

            <div className="flex flex-col gap-3">
              {runway.rows.map((item) => {
                const tone = sandClasses(item.sandType.name, sandTypes);
                const barPct = Math.min(
                  100,
                  Math.max(0, (item.stagesOnHand / runway.maxScale) * 100)
                );
                const markPct = Math.min(100, (item.threshold / runway.maxScale) * 100);
                const barColor =
                  item.tone === 'danger'
                    ? 'bg-danger'
                    : item.tone === 'warn'
                      ? 'bg-warn'
                      : 'bg-ok';

                return (
                  <div
                    key={item.sandType.id}
                    className="rounded-md bg-elevated p-3 ring-border"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className={cn('text-sm font-medium', tone.text)}>
                          {item.sandType.name}
                        </span>
                        <span className="num text-xs text-muted">
                          {formatLbsNumber(item.sandType.perStageDesignLbs)} lbs/stage
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span
                          className={cn(
                            'badge',
                            item.tone === 'danger'
                              ? 'badge-danger'
                              : item.tone === 'warn'
                                ? 'badge-warn'
                                : 'badge-ok'
                          )}
                        >
                          {item.label}
                        </span>
                        <span className="num text-sm font-semibold">
                          {item.stagesOnHand.toFixed(1)}
                          <span className="ml-1 text-[11px] font-normal text-muted">stg</span>
                        </span>
                      </div>
                    </div>

                    <div className="relative mt-3 h-5 overflow-visible rounded-sm bg-bg">
                      <div
                        className={cn(
                          'h-full rounded-sm transition-[width] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]',
                          barColor
                        )}
                        style={{ width: `${barPct}%` }}
                      />
                      <div
                        className="absolute inset-y-0 w-px bg-fg/60"
                        style={{ left: `${markPct}%` }}
                        title={`Reorder threshold: ${item.threshold} stages`}
                      />
                    </div>

                    <div className="mt-1.5 flex items-center justify-between text-[11px] text-subtle">
                      <span className="num">0 stg</span>
                      <span>
                        {item.projectedEmptyDate
                          ? `Empty about ${item.projectedEmptyDate}`
                          : 'No burn recorded yet'}
                      </span>
                      <span className="num">{runway.maxScale} stg</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* --------------------------------- 3. stage progress --- */}
          <div className="card">
            <div className="card-hd">
              <div>
                <div className="eyebrow">Section 3</div>
                <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
                  <Layers className="size-4 text-muted" /> Stage progress
                </h2>
              </div>
              <span className="num shrink-0 text-xs text-muted">
                {stageTotals.done} / {stageTotals.planned} ({stageTotals.pct}%)
              </span>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>Well</th>
                    <th className="n">Planned</th>
                    <th className="n">Pumped</th>
                    <th className="n">Left</th>
                    <th className="w-32">Complete</th>
                  </tr>
                </thead>
                <tbody>
                  {wellProgress.map((wp) => (
                    <tr key={wp.well.id}>
                      <td className="max-w-[140px] truncate font-medium">{wp.well.name}</td>
                      <td className="n text-muted">{wp.planned}</td>
                      <td className="n">{wp.completed}</td>
                      <td className="n text-muted">{wp.remaining}</td>
                      <td>
                        <div className="flex items-center gap-2">
                          <div className="meter flex-1">
                            <span style={{ width: `${Math.round(wp.pct)}%` }} />
                          </div>
                          <span className="num w-9 text-right text-[11px] text-muted">
                            {Math.round(wp.pct)}%
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}

                  <tr className="bg-elevated">
                    <td className="font-medium">Pad total</td>
                    <td className="n">{stageTotals.planned}</td>
                    <td className="n font-semibold text-accent">{stageTotals.done}</td>
                    <td className="n">{stageTotals.left}</td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="meter flex-1">
                          <span style={{ width: `${stageTotals.pct}%` }} />
                        </div>
                        <span className="num w-9 text-right text-[11px] font-semibold text-accent">
                          {stageTotals.pct}%
                        </span>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-5">
          {/* --------------------------- 4. job plan vs delivered --- */}
          <div className="card">
            <div className="card-hd">
              <div>
                <div className="eyebrow">Section 4</div>
                <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
                  <FileSpreadsheet className="size-4 text-muted" /> Job plan vs delivered
                </h2>
              </div>
              <span className="eyebrow-aside">Cross-check flags at &gt;2% drift</span>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="tbl">
                <thead>
                  <tr>
                    <th className="w-48">Job design metric</th>
                    {jobMetrics.map((m) => {
                      const tone = sandClasses(m.sandType.name, sandTypes);
                      return (
                        <th key={m.sandType.id} className={cn('n', tone.text)}>
                          {m.sandType.name}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td className="text-muted">Job design total (lbs)</td>
                    {jobMetrics.map((m) => (
                      <td key={m.sandType.id} className="n">
                        {formatLbsNumber(m.jobDesignTotalLbs)}
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="text-muted">Still to deliver (lbs)</td>
                    {jobMetrics.map((m) => (
                      <td
                        key={m.sandType.id}
                        className={cn(
                          'n font-semibold',
                          m.stillToDeliverLbs < 0 ? 'text-danger' : 'text-fg'
                        )}
                      >
                        {formatLbsNumber(m.stillToDeliverLbs)}
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="text-muted">Truckloads still needed</td>
                    {jobMetrics.map((m) => (
                      <td key={m.sandType.id} className="n text-muted">
                        {m.truckloadsStillNeeded.toFixed(1)} loads
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="text-muted">Stages in design</td>
                    {jobMetrics.map((m) => (
                      <td key={m.sandType.id} className="n text-muted">
                        {m.stagesInDesign.toFixed(1)} stg
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="text-muted">Stages pumped so far</td>
                    {jobMetrics.map((m) => (
                      <td key={m.sandType.id} className="n text-muted">
                        {m.stagesPumpedSoFar.toFixed(1)} stg
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="text-muted">Stages of sand left in design</td>
                    {jobMetrics.map((m) => (
                      <td key={m.sandType.id} className="n">
                        {m.stagesOfSandLeftInDesign.toFixed(1)} stg
                      </td>
                    ))}
                  </tr>

                  <tr>
                    <td className="text-muted">Design check (stages × per-stage)</td>
                    {jobMetrics.map((m) => (
                      <td key={m.sandType.id} className="n text-muted">
                        {formatLbsNumber(m.plannedStagesSumLbs)} lbs
                      </td>
                    ))}
                  </tr>

                  <tr className="bg-elevated">
                    <td className="text-muted">Difference vs job design total</td>
                    {jobMetrics.map((m) => (
                      <td
                        key={m.sandType.id}
                        className={cn(
                          'n font-semibold',
                          m.hasCrossCheckFlag ? 'text-warn' : 'text-ok'
                        )}
                      >
                        {m.plannedCrossCheckDiffLbs > 0 ? '+' : ''}
                        {formatLbsNumber(m.plannedCrossCheckDiffLbs)} lbs (
                        {m.plannedCrossCheckDiffPercent.toFixed(1)}%)
                        {m.hasCrossCheckFlag && (
                          <span className="badge badge-warn mt-1 flex w-fit">
                            <AlertTriangle className="size-3" /> &gt;2% variance
                          </span>
                        )}
                      </td>
                    ))}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* ------------------------------- 5. on hand by silo --- */}
          <div className="card">
            <div className="card-hd">
              <div>
                <div className="eyebrow">Section 5</div>
                <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
                  <Factory className="size-4 text-muted" /> On hand by silo
                </h2>
              </div>
              <span className="eyebrow-aside">{silos.length} silos</span>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>Silo</th>
                    <th>Sand</th>
                    <th className="n">Delivered</th>
                    <th className="n">Run to date</th>
                    <th className="n">On hand</th>
                    <th className="n">% full</th>
                  </tr>
                </thead>
                <tbody>
                  {siloTableData.map((row) => {
                    const tone = sandClasses(row.silo.sandType, sandTypes);
                    return (
                      <tr key={row.silo.siloNumber}>
                        <td className="num font-medium">
                          {row.silo.name || `Silo ${row.silo.siloNumber}`}
                          {row.silo.isOutOfService && (
                            <span className="badge ml-1.5">Offline</span>
                          )}
                        </td>
                        <td>
                          {row.silo.sandType ? (
                            <span className={cn('text-xs font-medium', tone.text)}>
                              {row.silo.sandType}
                            </span>
                          ) : (
                            <span className="text-xs text-subtle">Empty</span>
                          )}
                        </td>
                        <td className="n text-muted">{formatLbsNumber(row.delivered)}</td>
                        <td className="n text-muted">{formatLbsNumber(row.runToDate)}</td>
                        <td
                          className={cn(
                            'n font-semibold',
                            row.isNegative ? 'text-danger' : 'text-fg'
                          )}
                        >
                          {formatLbsNumber(row.onHandLbs)}
                        </td>
                        <td className="n text-muted">{row.percentFull.toFixed(0)}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* --------------------------- 6. delivered by supplier --- */}
          <div className="card">
            <div className="card-hd">
              <div>
                <div className="eyebrow">Section 6</div>
                <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
                  <Users className="size-4 text-muted" /> Delivered by supplier
                </h2>
              </div>
              <span className="eyebrow-aside">
                {supplierRows.length}{' '}
                {supplierRows.length === 1 ? 'supplier' : 'suppliers'}
              </span>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="tbl">
                <thead>
                  <tr>
                    <th>Supplier</th>
                    {sandTypes.map((st) => {
                      const tone = sandClasses(st.name, sandTypes);
                      return (
                        <th key={st.id} className={cn('n', tone.text)}>
                          {st.name}
                        </th>
                      );
                    })}
                    <th className="n">Total lbs</th>
                    <th className="n">Total tons</th>
                    <th className="n">Loads</th>
                  </tr>
                </thead>
                <tbody>
                  {supplierRows.map((row) => (
                    <tr key={row.supplierName}>
                      <td className="max-w-[140px] truncate font-medium">
                        {row.supplierName}
                      </td>
                      {sandTypes.map((st) => (
                        <td key={st.id} className="n text-muted">
                          {formatLbsNumber(row.lbsPerSandType[st.name] || 0)}
                        </td>
                      ))}
                      <td className="n font-semibold text-accent">
                        {formatLbsNumber(row.totalLbs)}
                      </td>
                      <td className="n text-muted">{row.totalTons.toFixed(1)} t</td>
                      <td className="n text-muted">{row.loadCount}</td>
                    </tr>
                  ))}

                  <tr className="bg-elevated">
                    <td className="font-medium">Suppliers total</td>
                    {sandTypes.map((st) => {
                      const stTotal = supplierRows.reduce(
                        (sum, r) => sum + (r.lbsPerSandType[st.name] || 0),
                        0
                      );
                      return (
                        <td key={st.id} className="n">
                          {formatLbsNumber(stTotal)}
                        </td>
                      );
                    })}
                    <td className="n font-semibold text-accent">
                      {formatLbsNumber(totals.totalDeliveredLbs)}
                    </td>
                    <td className="n">{totals.totalDeliveredTons.toFixed(1)} t</td>
                    <td className="n">{totals.totalDeliveredLoads}</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* ------------------------------------ 7. deliveries by day --- */}
      <div className="card">
        <div className="card-hd">
          <div>
            <div className="eyebrow">Section 7</div>
            <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
              <Calendar className="size-4 text-muted" /> Deliveries by day — last 14
            </h2>
            <p className="mt-1 text-sm text-muted">
              Delivered against pumped, in klbs, bucketed by operational date and counted
              back from the last day of activity{windowEnd ? ` (${windowEnd})` : ''}. A
              quiet day is a zero bar, not a gap.
            </p>
          </div>
          <div className="shrink-0 text-right">
            <div className="eyebrow">14-day net</div>
            <div
              className={cn(
                'num text-sm font-semibold',
                dailyTotals.deliveredLbs - dailyTotals.pumpedLbs < 0
                  ? 'text-warn'
                  : 'text-ok'
              )}
            >
              {dailyTotals.deliveredLbs - dailyTotals.pumpedLbs > 0 ? '+' : ''}
              {formatLbsNumber(dailyTotals.deliveredLbs - dailyTotals.pumpedLbs)} lbs
            </div>
          </div>
        </div>

        <div className="mb-3 flex items-center gap-4 text-[11px] text-muted">
          <span className="flex items-center gap-1.5">
            <span
              className="inline-block size-2.5 rounded-xs"
              style={{ background: 'var(--color-accent)' }}
            />
            Delivered
          </span>
          <span className="flex items-center gap-1.5">
            <span
              className="inline-block size-2.5 rounded-xs"
              style={{ background: 'var(--color-warn)' }}
            />
            Pumped
          </span>
        </div>

        <div className="h-56 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              barGap={2}
              margin={{ top: 4, right: 4, bottom: 0, left: 0 }}
            >
              <XAxis
                dataKey="day"
                tickLine={false}
                axisLine={false}
                tick={{ fill: 'var(--color-muted)', fontSize: 11 }}
                interval={0}
                minTickGap={0}
              />
              <YAxis
                tickLine={false}
                axisLine={false}
                width={44}
                tick={{ fill: 'var(--color-muted)', fontSize: 11 }}
                tickFormatter={(v: number) => `${v}k`}
              />
              <Tooltip
                cursor={{ fill: 'var(--color-elevated)' }}
                contentStyle={{
                  background: 'var(--color-surface)',
                  border: 'none',
                  borderRadius: 'var(--radius-sm)',
                  boxShadow: 'var(--shadow-border)',
                  fontSize: 12,
                }}
                labelStyle={{ color: 'var(--color-muted)' }}
                itemStyle={{ color: 'var(--color-fg)' }}
                formatter={(v: number, name: string) => [`${v} klbs`, name]}
              />
              <Bar
                dataKey="delivered"
                name="Delivered"
                fill="var(--color-accent)"
                radius={[2, 2, 0, 0]}
              />
              <Bar
                dataKey="pumped"
                name="Pumped"
                fill="var(--color-warn)"
                radius={[2, 2, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* The chart shows the shape; a company man still signs off on the
            exact pounds, so they stay one disclosure away. */}
        <details className="mt-4">
          <summary className="eyebrow cursor-pointer select-none py-2">
            Exact daily numbers
          </summary>

          <div className="overflow-x-auto no-scrollbar">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Day</th>
                  {sandTypes.map((st) => {
                    const tone = sandClasses(st.name, sandTypes);
                    return (
                      <th key={st.id} className={cn('n', tone.text)}>
                        {st.name}
                      </th>
                    );
                  })}
                  <th className="n">Delivered</th>
                  <th className="n">Pumped</th>
                  <th className="n">Loads</th>
                </tr>
              </thead>
              <tbody>
                {daily.map((point) => {
                  const quiet = point.deliveredLbs === 0 && point.pumpedLbs === 0;
                  const perSand = dailyBySand.get(point.date) || {};
                  return (
                    <tr key={point.date} className={quiet ? 'text-subtle' : undefined}>
                      <td className="num">{point.date}</td>
                      <td className="text-muted">{fmtWeekday(point.date)}</td>
                      {sandTypes.map((st) => (
                        <td key={st.id} className="n">
                          {perSand[st.name] ? formatLbsNumber(perSand[st.name]) : '—'}
                        </td>
                      ))}
                      <td className={cn('n', !quiet && 'font-semibold text-accent')}>
                        {point.deliveredLbs ? formatLbsNumber(point.deliveredLbs) : '—'}
                      </td>
                      <td className={cn('n', !quiet && 'text-warn')}>
                        {point.pumpedLbs ? formatLbsNumber(point.pumpedLbs) : '—'}
                      </td>
                      <td className="n text-muted">{point.loadsIn || '—'}</td>
                    </tr>
                  );
                })}

                <tr className="bg-elevated">
                  <td className="font-medium" colSpan={2}>
                    14-day total
                  </td>
                  {sandTypes.map((st) => (
                    <td key={st.id} className="n">
                      {formatLbsNumber(dailyTotals.perSand[st.name] || 0)}
                    </td>
                  ))}
                  <td className="n font-semibold text-accent">
                    {formatLbsNumber(dailyTotals.deliveredLbs)}
                  </td>
                  <td className="n text-warn">{formatLbsNumber(dailyTotals.pumpedLbs)}</td>
                  <td className="n">{dailyTotals.loads}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </details>
      </div>

      <PadRecoveryModal
        isOpen={isRecoveryOpen}
        onClose={() => setIsRecoveryOpen(false)}
        state={state}
        onSelectPad={onSelectPad}
      />
    </div>
  );
}

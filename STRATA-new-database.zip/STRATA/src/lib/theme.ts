/**
 * Sand type identity colors — THE single source of truth.
 *
 * The previous build inferred sand colors from name substrings in three
 * different files with three different rulesets, so 40/70 rendered blue on the
 * dashboard and emerald on the pull sheet. Same sand, different color, same
 * screen session. That is a real safety problem on a pull sheet.
 *
 * Rule: an explicit `colorCategory` on the SandTypeSpec always wins. Only when
 * a sand type has no configured color do we fall back to mesh-name sniffing.
 * Nothing else in the app may map a sand name to a color.
 */

import type { SandTypeSpec } from '../types';

export type SandTone = 'amber' | 'blue' | 'emerald' | 'violet' | 'slate';

const LEGACY_TONE_ALIASES: Record<string, SandTone> = {
  amber: 'amber',
  orange: 'amber',
  blue: 'blue',
  emerald: 'emerald',
  green: 'emerald',
  violet: 'violet',
  purple: 'violet',
  slate: 'slate',
};

/** Mesh-name fallback. Only used when a sand type has no configured color. */
function toneFromName(name?: string | null): SandTone {
  const lower = (name || '').toLowerCase();
  if (lower.includes('100')) return 'amber';
  if (lower.includes('40/70') || lower.includes('4070') || lower.includes('70')) return 'blue';
  if (lower.includes('30/50') || lower.includes('3050')) return 'violet';
  if (lower.includes('20/40') || lower.includes('2040')) return 'emerald';
  if (lower.includes('40')) return 'blue';
  if (lower.includes('30') || lower.includes('50')) return 'violet';
  return 'slate';
}

/**
 * Resolve a sand type name to its tone using the pad's configured sand types.
 * Always pass the config's sandTypes so an explicit colorCategory wins.
 */
export function sandTone(name?: string | null, sandTypes?: SandTypeSpec[]): SandTone {
  if (!name) return 'slate';
  if (sandTypes && sandTypes.length) {
    const spec = sandTypes.find(
      (s) => s.name?.trim().toLowerCase() === name.trim().toLowerCase()
    );
    if (spec?.colorCategory) {
      const mapped = LEGACY_TONE_ALIASES[String(spec.colorCategory).toLowerCase()];
      if (mapped) return mapped;
    }
  }
  return toneFromName(name);
}

export interface ToneClasses {
  /** Solid fill — canister sand, bar fills. */
  fill: string;
  /** Foreground text in the sand color. */
  text: string;
  /** Low-contrast chip background. */
  dim: string;
  /** 1px ring in the sand color. */
  ring: string;
  /** CSS var reference, for inline styles and charts. */
  cssVar: string;
  /** Print-safe hex — @media print forces white ground. */
  printHex: string;
}

export const TONE: Record<SandTone, ToneClasses> = {
  amber: {
    fill: 'bg-sand-amber',
    text: 'text-sand-amber',
    dim: 'bg-sand-amber/15',
    ring: 'shadow-[0_0_0_1px_var(--color-sand-amber)]',
    cssVar: 'var(--color-sand-amber)',
    printHex: '#8a6d2f',
  },
  blue: {
    fill: 'bg-sand-blue',
    text: 'text-sand-blue',
    dim: 'bg-sand-blue/15',
    ring: 'shadow-[0_0_0_1px_var(--color-sand-blue)]',
    cssVar: 'var(--color-sand-blue)',
    printHex: '#3f5f7d',
  },
  emerald: {
    fill: 'bg-sand-emerald',
    text: 'text-sand-emerald',
    dim: 'bg-sand-emerald/15',
    ring: 'shadow-[0_0_0_1px_var(--color-sand-emerald)]',
    cssVar: 'var(--color-sand-emerald)',
    printHex: '#2f6b3e',
  },
  violet: {
    fill: 'bg-sand-violet',
    text: 'text-sand-violet',
    dim: 'bg-sand-violet/15',
    ring: 'shadow-[0_0_0_1px_var(--color-sand-violet)]',
    cssVar: 'var(--color-sand-violet)',
    printHex: '#5c4a8a',
  },
  slate: {
    fill: 'bg-sand-slate',
    text: 'text-sand-slate',
    dim: 'bg-sand-slate/15',
    ring: 'shadow-[0_0_0_1px_var(--color-sand-slate)]',
    cssVar: 'var(--color-sand-slate)',
    printHex: '#4b4f47',
  },
};

/** One call: name in, classes out. */
export function sandClasses(name?: string | null, sandTypes?: SandTypeSpec[]): ToneClasses {
  return TONE[sandTone(name, sandTypes)];
}

/** Ordered palette for charts that need one color per sand type. */
export const CHART_TONES: string[] = [
  'var(--color-sand-amber)',
  'var(--color-sand-blue)',
  'var(--color-sand-emerald)',
  'var(--color-sand-violet)',
  'var(--color-sand-slate)',
];

/** Tailwind-safe class join. */
export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(' ');
}

/**
 * Quick entry — the ?mode=entry kiosk.
 *
 * One job, one screen, one thumb: a gate guard scans the BOL, picks the can,
 * and saves. The scan button and the save button are the two largest targets
 * on the page and nothing competes with them.
 *
 * The silo is the one field a barcode can never supply — no QR on a sand
 * ticket knows which can the driver will blow into — so after a scan the
 * picker is raised to the critical channel until it is answered. That is the
 * only critical element on this screen, on purpose.
 *
 * No alert() anywhere: a blocking browser dialog on a tablet in the sun,
 * behind a driver waiting at the gate, is a dead kiosk.
 */

import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  Plus,
  QrCode,
  Save,
  Sparkles,
  Tag,
  Truck,
} from 'lucide-react';
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { getSiloDerivedStates, formatLbs, formatTons } from '../lib/sandRules';
import { suggestSiloForDelivery } from '../lib/analytics';
import {
  findDuplicateDelivery,
  normalizeTicketNumber,
  getLastUsedSupplier,
  setLastUsedSupplier,
  ParsedTicketScan,
} from '../lib/ticketUtils';
import { getOperationalDate, getOperationalTime } from '../lib/dateUtils';
import { sandClasses, cn } from '../lib/theme';
import { AppState, DeliveryTicket } from '../types';
import { Wordmark } from './ui/Mark';
import Numpad from './Numpad';
import TicketScannerModal, { ScanResult } from './TicketScannerModal';
import DuplicateWarningModal from './DuplicateWarningModal';
import ScanConfirmationModal from './ScanConfirmationModal';

interface QuickEntryProps {
  state: AppState;
  onAddDelivery: (delivery: {
    ticketNumber: string;
    siloNumber: number;
    sandType: string;
    lbs: number;
    supplier: string;
    date: string;
    timeOfDay?: string;
    carrier?: string;
    truck?: string;
    poNumber?: string;
    productCode?: string;
    supervisorOverride?: boolean;
    overrideReason?: string;
    scanMetadata?: any;
  }) => Promise<void> | void;
  onSaveProductCodeMapping?: (mineCode: string, sandType: string) => Promise<void> | void;
  onNavigateToSetup?: () => void;
  /**
   * App-level toast. Replaces the three native alert() calls this kiosk used
   * to make in its save path. Falls back to the in-page notice when absent.
   */
  onToast?: (msg: string, tone?: 'ok' | 'warn' | 'danger') => void;
}

export default function QuickEntry({
  state,
  onAddDelivery,
  onSaveProductCodeMapping,
  onNavigateToSetup,
  onToast,
}: QuickEntryProps) {
  const ticketInputRef = useRef<HTMLInputElement | null>(null);
  /** Origin of the scan currently being confirmed — 'camera' or 'photo'. */
  const lastScanMethodRef = useRef<'camera' | 'photo'>('camera');

  /* The expensive derive. Keyed on the ledger slices it reads so a keystroke
     in the weight field does not replay every ticket on the pad. */
  const siloDerivedStates = useMemo(
    () => getSiloDerivedStates(state),
    [state.config, state.deliveries, state.runs]
  );

  const defaultSiloNum = state.config.silos[0]?.siloNumber || 1;
  const initialSiloObj = state.config.silos.find((s) => s.siloNumber === defaultSiloNum);

  const todayStr = getOperationalDate();

  // Persistent session state for quick consecutive logging
  const [ticketNumber, setTicketNumber] = useState('');
  const [siloNumber, setSiloNumber] = useState<number>(defaultSiloNum);
  const [sandType, setSandType] = useState<string>(
    initialSiloObj?.sandType || state.config.sandTypes[0]?.name || '100 Mesh'
  );
  const [lbs, setLbs] = useState<string>('');

  const supplierList = state.config.suppliers || [];

  const getInitialSupplierConfig = () => {
    if (supplierList.length === 1) {
      return { opt: supplierList[0], custom: '', val: supplierList[0] };
    }
    if (supplierList.length > 1) {
      const last = getLastUsedSupplier();
      if (last && supplierList.includes(last)) {
        return { opt: last, custom: '', val: last };
      }
      const recent = state.deliveries[0]?.supplier;
      if (recent && supplierList.includes(recent)) {
        return { opt: recent, custom: '', val: recent };
      }
      return { opt: supplierList[0], custom: '', val: supplierList[0] };
    }
    return { opt: '', custom: '', val: '' };
  };

  const initialSupplierConfig = getInitialSupplierConfig();
  const [selectedSupplierOpt, setSelectedSupplierOpt] = useState<string>(initialSupplierConfig.opt);
  const [customSupplier, setCustomSupplier] = useState<string>(initialSupplierConfig.custom);
  const [supplier, setSupplier] = useState<string>(initialSupplierConfig.val);

  useEffect(() => {
    if (supplierList.length === 1) {
      setSelectedSupplierOpt(supplierList[0]);
      setSupplier(supplierList[0]);
    } else if (supplierList.length > 1) {
      if (
        !selectedSupplierOpt ||
        (!supplierList.includes(selectedSupplierOpt) && selectedSupplierOpt !== '__OTHER__')
      ) {
        const last = getLastUsedSupplier();
        const choice =
          last && supplierList.includes(last)
            ? last
            : state.deliveries[0]?.supplier && supplierList.includes(state.deliveries[0]?.supplier)
              ? state.deliveries[0]?.supplier
              : supplierList[0];
        setSelectedSupplierOpt(choice);
        setSupplier(choice);
      }
    }
  }, [state.config.suppliers]);

  // Extra fields from the Atlas 6-part QR
  const [truck, setTruck] = useState<string>('');
  const [poNumber, setPoNumber] = useState<string>('');
  const [productCode, setProductCode] = useState<string>('');
  const [unrecognizedProductCode, setUnrecognizedProductCode] = useState<string | null>(null);

  // Silo picker escalation after a scan
  const [highlightSilo, setHighlightSilo] = useState<boolean>(false);

  const [sessionTickets, setSessionTickets] = useState<DeliveryTicket[]>([]);

  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedInfo, setScannedInfo] = useState<{
    rawValue: string;
    format: string;
    parser?: string;
    confidence?: string;
    winningScale?: string;
    engine?: string;
    /* How the number was actually obtained. Was hardcoded 'camera' below for
       every path, including a still photo and a vision OCR read. */
    method?: 'camera' | 'photo';
  } | null>(null);

  const [isConfirmationModalOpen, setIsConfirmationModalOpen] = useState(false);
  const [pendingScan, setPendingScan] = useState<ParsedTicketScan | null>(null);
  const [scanCandidates, setScanCandidates] = useState<ParsedTicketScan[]>([]);

  const [justSavedFlash, setJustSavedFlash] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  /** In-page stand-in for a toast when App has not wired onToast. */
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    ticketInputRef.current?.focus();
  }, []);

  /** The only user-facing message path. Never alert(). */
  const notify = (msg: string, tone: 'ok' | 'warn' | 'danger' = 'warn') => {
    if (onToast) {
      onToast(msg, tone);
      return;
    }
    setNotice(msg);
    setTimeout(() => setNotice(null), 4000);
  };

  const handleSiloChange = (num: number) => {
    setSiloNumber(num);
    setHighlightSilo(false);
    const siloObj = state.config.silos.find((s) => s.siloNumber === num);
    if (siloObj && siloObj.sandType) {
      setSandType(siloObj.sandType);
    }
  };

  // Target silo derived info
  const selectedSiloDerived = siloDerivedStates.find((s) => s.siloNumber === siloNumber);
  const lbsPerTon = state.config.lbsPerTon || 2000;
  const lbsPerTruckload = state.config.lbsPerTruckload || 57000;
  const onHandLbs = selectedSiloDerived?.onHandLbs || 0;
  const maxCapacityLbs = selectedSiloDerived?.maxCapacityLbs || 350000;
  const percentFull = Math.min(100, Math.max(0, Math.round((onHandLbs / maxCapacityLbs) * 100)));
  const onHandTons = onHandLbs / lbsPerTon;
  const maxTons = maxCapacityLbs / lbsPerTon;
  const weightLbsLive = parseInt(lbs, 10) || 0;
  const tone = sandClasses(sandType, state.config.sandTypes);

  const suggestion = useMemo(
    () =>
      sandType && weightLbsLive > 0
        ? suggestSiloForDelivery(state, sandType, weightLbsLive)
        : null,
    [state.config, state.deliveries, state.runs, sandType, weightLbsLive]
  );

  // Duplicate ticket check across all deliveries on this pad
  const duplicateDelivery = findDuplicateDelivery(ticketNumber, state.deliveries);
  const [isDuplicateModalOpen, setIsDuplicateModalOpen] = useState(false);

  const handleCloseDuplicateModal = () => {
    setIsDuplicateModalOpen(false);
    setTimeout(() => {
      ticketInputRef.current?.focus();
    }, 100);
  };

  const applyParsedTicket = (parsed: ParsedTicketScan) => {
    if (parsed.ticketNumber) setTicketNumber(parsed.ticketNumber);
    if (parsed.lbs) setLbs(parsed.lbs.toString());
    if (parsed.carrier) {
      const carrier = parsed.carrier.trim();
      if (supplierList.includes(carrier)) {
        setSelectedSupplierOpt(carrier);
        setSupplier(carrier);
        setCustomSupplier('');
      } else if (carrier) {
        setSelectedSupplierOpt('__OTHER__');
        setCustomSupplier(carrier);
        setSupplier(carrier);
      }
    }
    if (parsed.truck) setTruck(parsed.truck);
    if (parsed.poNumber) setPoNumber(parsed.poNumber);
    if (parsed.productCode) setProductCode(parsed.productCode);

    if (parsed.matchedSandType) {
      setSandType(parsed.matchedSandType);
      setUnrecognizedProductCode(null);
    } else if (parsed.productCode) {
      setUnrecognizedProductCode(parsed.productCode);
    } else {
      setUnrecognizedProductCode(null);
    }

    // The silo is NOT in the QR code — raise the picker.
    setHighlightSilo(true);

    if (parsed.ticketNumber) {
      const norm = normalizeTicketNumber(parsed.ticketNumber);
      const dup = findDuplicateDelivery(norm, state.deliveries);
      if (dup) {
        setIsDuplicateModalOpen(true);
      }
    }

    setTimeout(() => {
      ticketInputRef.current?.focus();
    }, 100);
  };

  const handleScanSuccess = (result: ScanResult) => {
    setIsScannerOpen(false);
    const { rawValue, format, parsed, candidates, isAmbiguous, winningScale, engine, method } =
      result;
    lastScanMethodRef.current = method || 'camera';

    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(100);
      } catch (e) {
        // ignore
      }
    }

    if (isAmbiguous || parsed.confidence !== 'confirmed') {
      setPendingScan(parsed);
      setScanCandidates(candidates || [parsed]);
      setIsConfirmationModalOpen(true);
    } else {
      setScannedInfo({
        rawValue,
        format,
        parser: parsed.parser,
        confidence: parsed.confidence,
        winningScale,
        engine,
        method: method || 'camera',
      });
      applyParsedTicket(parsed);
    }
  };

  const handleConfirmScan = (confirmed: ParsedTicketScan) => {
    setIsConfirmationModalOpen(false);
    setScannedInfo({
      rawValue: confirmed.rawValue,
      format: confirmed.format || 'QR_CODE',
      parser: confirmed.parser,
      confidence: confirmed.confidence,
      method: lastScanMethodRef.current,
    });
    applyParsedTicket(confirmed);
  };

  const handleRememberProductCodePairing = async () => {
    if (!unrecognizedProductCode || !sandType || !onSaveProductCodeMapping) return;
    try {
      await onSaveProductCodeMapping(unrecognizedProductCode, sandType);
      const code = unrecognizedProductCode;
      setUnrecognizedProductCode(null);
      setJustSavedFlash(`Saved product code ${code} to ${sandType}`);
      setTimeout(() => setJustSavedFlash(null), 3000);
    } catch (err) {
      console.error('Failed to save mapping:', err);
      notify('Could not save that product code pairing.', 'danger');
    }
  };

  const executeSaveTicket = async (opts?: {
    supervisorOverride?: boolean;
    overrideReason?: string;
  }) => {
    const cleanTicket = normalizeTicketNumber(ticketNumber);
    if (!cleanTicket) {
      notify('Enter or scan a ticket number first.', 'warn');
      ticketInputRef.current?.focus();
      return;
    }

    const weightLbs = parseInt(lbs, 10);
    if (isNaN(weightLbs) || weightLbs <= 0) {
      notify('Enter the load weight in lbs.', 'warn');
      return;
    }

    setIsSubmitting(true);
    if (supplier.trim()) {
      setLastUsedSupplier(supplier.trim());
    }
    const nowTimeStr = getOperationalTime();

    const newTicketRecord: DeliveryTicket = {
      id: `session-${Date.now()}`,
      ticketNumber: cleanTicket,
      siloNumber,
      sandType,
      lbs: weightLbs,
      supplier,
      date: todayStr,
      timeOfDay: nowTimeStr,
      createdAt: Date.now(),
      carrier: supplier,
      truck: truck || undefined,
      poNumber: poNumber || undefined,
      productCode: productCode || undefined,
      supervisorOverride: opts?.supervisorOverride,
      overrideReason: opts?.overrideReason,
    };

    try {
      await onAddDelivery({
        ticketNumber: cleanTicket,
        siloNumber,
        sandType,
        lbs: weightLbs,
        supplier,
        date: todayStr,
        timeOfDay: nowTimeStr,
        carrier: supplier,
        truck: truck || undefined,
        poNumber: poNumber || undefined,
        productCode: productCode || undefined,
        supervisorOverride: opts?.supervisorOverride,
        overrideReason: opts?.overrideReason,
        scanMetadata: scannedInfo
          ? {
              method: scannedInfo.method || 'camera',
              format: scannedInfo.format,
              parser: scannedInfo.parser as any,
              confidence: scannedInfo.confidence as any,
              rawValue: scannedInfo.rawValue,
              winningScale: scannedInfo.winningScale,
              engine: scannedInfo.engine,
              scannedAt: Date.now(),
            }
          : undefined,
      });

      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([100, 50, 100]);
        } catch (e) {
          // ignore
        }
      }

      setSessionTickets((prev) => [newTicketRecord, ...prev].slice(0, 5));

      setJustSavedFlash(
        `Ticket #${cleanTicket} saved · ${weightLbs.toLocaleString()} lbs to Silo ${siloNumber}`
      );
      setTimeout(() => setJustSavedFlash(null), 3500);

      // Clear the ticket, keep the silo selected for the next load
      setTicketNumber('');
      setLbs('');
      setTruck('');
      setPoNumber('');
      setProductCode('');
      setUnrecognizedProductCode(null);
      setScannedInfo(null);
      setHighlightSilo(false);
      setSaveError(null);

      setTimeout(() => {
        ticketInputRef.current?.focus();
      }, 150);
    } catch (err: any) {
      console.error('Error saving quick ticket:', err);
      const msg = err?.message || 'Failed to save the ticket.';
      setSaveError(msg);
      notify(`Ticket not saved: ${msg}`, 'danger');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveError(null);
    const cleanTicket = normalizeTicketNumber(ticketNumber);
    if (!cleanTicket) {
      notify('Enter or scan a ticket number first.', 'warn');
      ticketInputRef.current?.focus();
      return;
    }

    const weightLbs = parseInt(lbs, 10);
    if (isNaN(weightLbs) || weightLbs <= 0) {
      notify('Enter the load weight in lbs.', 'warn');
      return;
    }

    const dup = findDuplicateDelivery(cleanTicket, state.deliveries);
    if (dup) {
      setIsDuplicateModalOpen(true);
      return;
    }

    await executeSaveTicket();
  };

  const formattedToday = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });

  const fillTone =
    percentFull >= 90 ? 'bg-danger' : percentFull >= 75 ? 'bg-warn' : 'bg-accent';

  return (
    <div className="min-h-screen bg-bg text-fg">
      <div className="mx-auto flex w-full max-w-xl flex-col gap-4 p-4 pb-28">
        {/* ------------------------------------------- pad + date strip --- */}
        <div className="card-flush flex items-center justify-between gap-3 p-3">
          <Wordmark subtitle={state.config.padName || 'Pad'} markClass="size-7" />
          <div className="text-right">
            <div className="eyebrow">Gate entry</div>
            <div className="num text-xs text-muted">{formattedToday}</div>
          </div>
        </div>

        {/* ------------------------------------------------------ notices --- */}
        {notice ? (
          <div className="card flex items-center gap-2 ring-warn-1">
            <AlertTriangle className="size-5 shrink-0 text-warn" />
            <span className="text-sm">{notice}</span>
          </div>
        ) : null}

        {saveError ? (
          <div className="card flex items-center gap-2 ring-danger-1">
            <AlertTriangle className="size-5 shrink-0 text-danger" />
            <span className="text-sm">Save failed: {saveError}</span>
          </div>
        ) : null}

        {justSavedFlash ? (
          <div className="card flex items-center gap-2 ring-accent-1">
            <CheckCircle2 className="size-5 shrink-0 text-accent" />
            <span className="text-sm">{justSavedFlash}</span>
          </div>
        ) : null}

        {/* --------------------------------------------- the scan button --- */}
        <button
          type="button"
          onClick={() => setIsScannerOpen(true)}
          className="btn btn-accent btn-xl h-24 w-full flex-col gap-1"
        >
          <span className="flex items-center gap-3 text-2xl font-semibold">
            <QrCode className="size-8" />
            Scan ticket
          </span>
          <span className="text-xs font-normal opacity-80">
            1D barcode or 2D code on the freight BOL
          </span>
        </button>

        {/* --------------------------------------------- scanned banner --- */}
        {scannedInfo ? (
          <div className="card space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="eyebrow flex items-center gap-1.5">
                <QrCode className="size-4 text-accent" /> Scanned ticket code
              </span>
              <div className="flex flex-wrap items-center gap-1.5">
                {scannedInfo.winningScale ? (
                  <span className="badge badge-ok num" title="Winning decode ladder rung">
                    {scannedInfo.winningScale}
                  </span>
                ) : null}
                <span className="badge badge-accent">{scannedInfo.format}</span>
              </div>
            </div>

            <div className="num break-all rounded-sm bg-elevated p-2.5 text-xs ring-border">
              {scannedInfo.rawValue}
            </div>

            {truck || poNumber || productCode ? (
              <>
                <div className="divider" />
                <div className="flex flex-wrap gap-2">
                  {truck ? (
                    <span className="badge">
                      Truck <span className="num text-fg">{truck}</span>
                    </span>
                  ) : null}
                  {poNumber ? (
                    <span className="badge">
                      PO <span className="num text-fg">{poNumber}</span>
                    </span>
                  ) : null}
                  {productCode ? (
                    <span className="badge badge-accent">
                      Mine code <span className="num">{productCode}</span>
                    </span>
                  ) : null}
                </div>
              </>
            ) : null}
          </div>
        ) : null}

        {/* ------------------------------------ unknown product code ------ */}
        {unrecognizedProductCode ? (
          <div className="card space-y-2 ring-warn-1">
            <div className="flex items-start gap-2 text-sm">
              <Tag className="mt-0.5 size-4 shrink-0 text-warn" />
              <span>
                Unknown product code{' '}
                <span className="num font-semibold">{unrecognizedProductCode}</span> — pick the
                sand type and it will be remembered for the next load.
              </span>
            </div>
            {onSaveProductCodeMapping ? (
              <button
                type="button"
                onClick={handleRememberProductCodePairing}
                className="btn btn-lg w-full"
              >
                <Plus className="size-4" />
                <span>
                  Save pairing: {unrecognizedProductCode} to {sandType}
                </span>
              </button>
            ) : null}
          </div>
        ) : null}

        {/* ------------------------------------------------------- form --- */}
        <form onSubmit={handleSave} className="card space-y-4">
          {/* ticket number */}
          <div>
            <div className="mb-1.5 flex items-center justify-between gap-2">
              <label className="eyebrow" htmlFor="qe-ticket">
                Ticket number
              </label>
              {duplicateDelivery ? (
                <button
                  type="button"
                  onClick={() => setIsDuplicateModalOpen(true)}
                  className="badge badge-danger"
                >
                  <AlertTriangle className="size-3" />
                  Already recorded — review
                </button>
              ) : null}
            </div>
            <input
              id="qe-ticket"
              ref={ticketInputRef}
              type="text"
              inputMode="numeric"
              placeholder="1049823"
              value={ticketNumber}
              onChange={(e) => setTicketNumber(e.target.value)}
              className={cn(
                'input input-lg num text-lg',
                duplicateDelivery ? 'shadow-[0_0_0_1px_var(--color-danger)]' : null
              )}
              required
            />
          </div>

          {/* target silo — the one field a barcode can never supply */}
          <div
            className={cn(
              'space-y-1.5',
              highlightSilo && 'rounded-md bg-critical-dim p-3 ring-critical-1'
            )}
          >
            {highlightSilo ? (
              <div className="mb-1.5 flex animate-pulse items-center gap-1.5 rounded-sm bg-critical px-3 py-1.5 text-xs font-semibold uppercase tracking-wider text-bg">
                <ArrowRight className="size-4 shrink-0" />
                <span>Select target silo — manual pick required, not in QR code</span>
              </div>
            ) : null}

            <label className="eyebrow" htmlFor="qe-silo">
              Target silo
            </label>
            <select
              id="qe-silo"
              value={siloNumber}
              onChange={(e) => handleSiloChange(parseInt(e.target.value, 10))}
              className={cn('select input-lg', highlightSilo && 'ring-critical-1 text-critical')}
            >
              {state.config.silos.map((s) => (
                <option key={s.siloNumber} value={s.siloNumber}>
                  {s.name || `Silo ${s.siloNumber}`} (side {s.side || 'A'}) —{' '}
                  {s.sandType || 'unassigned'}
                  {s.isOutOfService ? ' [offline]' : ''}
                </option>
              ))}
            </select>

            {/* live on-hand + fill */}
            <div className="mt-2.5 space-y-2 rounded-md bg-elevated p-3 ring-border">
              <div className="flex items-center justify-between gap-2">
                <span className="eyebrow">Silo {siloNumber} on hand</span>
                <span className="num text-sm font-semibold">
                  {formatLbs(onHandLbs)}{' '}
                  <span className="text-xs font-normal text-muted">
                    {formatTons(onHandTons)}
                  </span>
                </span>
              </div>

              <div className="h-3 w-full overflow-hidden rounded-full bg-surface ring-border">
                <div
                  className={cn(
                    'h-full transition-[width] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]',
                    fillTone
                  )}
                  style={{ width: `${percentFull}%` }}
                />
              </div>

              <div className="flex items-center justify-between text-[11px] text-muted">
                <span className="num">
                  Capacity {maxCapacityLbs.toLocaleString()} lbs · {formatTons(maxTons)}
                </span>
                <span
                  className={cn(
                    'num font-semibold',
                    percentFull >= 90 ? 'text-danger' : 'text-fg'
                  )}
                >
                  {percentFull}% full
                </span>
              </div>
            </div>
          </div>

          {/* weight */}
          <div>
            <label className="eyebrow" htmlFor="qe-lbs">
              Amount (lbs)
            </label>
            <div className="relative mt-1.5">
              <input
                id="qe-lbs"
                type="number"
                inputMode="numeric"
                placeholder="lbs"
                value={lbs}
                onChange={(e) => setLbs(e.target.value)}
                className="input input-lg input-num pr-24 text-lg"
                required
              />
              <span className="num absolute right-4 top-1/2 -translate-y-1/2 text-xs text-muted">
                {weightLbsLive > 0 ? formatTons(weightLbsLive / lbsPerTon) : ''}
              </span>
            </div>

            {/* The kiosk types weight on the pad, not the OS keyboard. */}
            <div className="mt-2">
              <Numpad
                value={lbs}
                onChange={setLbs}
                onAddAmount={() => setSaveError(null)}
                label="Weight keypad"
                lbsPerTruckload={lbsPerTruckload}
              />
            </div>
          </div>

          {/* supplier */}
          <div>
            <label className="eyebrow">Supplier</label>
            {supplierList.length === 1 ? (
              <div className="input input-lg mt-1.5 flex items-center justify-between">
                <span className="text-sm font-medium">{supplierList[0]}</span>
                <span className="badge">Configured</span>
              </div>
            ) : supplierList.length > 1 ? (
              <div className="mt-1.5 space-y-2">
                <select
                  value={selectedSupplierOpt}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSelectedSupplierOpt(val);
                    setSupplier(val === '__OTHER__' ? customSupplier : val);
                  }}
                  className="select input-lg"
                >
                  {supplierList.map((sup) => (
                    <option key={sup} value={sup}>
                      {sup}
                    </option>
                  ))}
                  <option value="__OTHER__">+ Other (type it)</option>
                </select>

                {selectedSupplierOpt === '__OTHER__' ? (
                  <input
                    type="text"
                    placeholder="One-off supplier or hauler"
                    value={customSupplier}
                    onChange={(e) => {
                      setCustomSupplier(e.target.value);
                      setSupplier(e.target.value);
                    }}
                    className="input ring-accent-1"
                    required
                  />
                ) : null}
              </div>
            ) : (
              <div className="mt-1.5 space-y-2 rounded-md bg-elevated p-3 ring-border">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-warn">No suppliers set up</span>
                  {onNavigateToSetup ? (
                    <button
                      type="button"
                      onClick={onNavigateToSetup}
                      className="btn btn-ghost h-9 px-2 text-xs"
                    >
                      Go to setup
                    </button>
                  ) : null}
                </div>
                <input
                  type="text"
                  placeholder="Type supplier name"
                  value={customSupplier}
                  onChange={(e) => {
                    setCustomSupplier(e.target.value);
                    setSupplier(e.target.value);
                  }}
                  className="input"
                />
              </div>
            )}
          </div>

          {/* sand type */}
          <div>
            <label className="eyebrow" htmlFor="qe-sand">
              Sand type
            </label>
            <select
              id="qe-sand"
              value={sandType}
              onChange={(e) => setSandType(e.target.value)}
              className={cn('select input-lg mt-1.5', tone.text)}
            >
              {state.config.sandTypes.map((st) => (
                <option key={st.id} value={st.name}>
                  {st.name}
                </option>
              ))}
            </select>
          </div>

          {/* suggestion — the answer, the reason and the fix in one tap */}
          {suggestion ? (
            <button
              type="button"
              onClick={() => {
                setSiloNumber(suggestion.siloNumber);
                setHighlightSilo(false);
              }}
              className="flex w-full items-center gap-2 rounded-sm bg-accent-dim px-3 py-2 text-left text-sm text-accent"
            >
              <Sparkles className="size-4" />
              {suggestion.reason} · {formatLbs(suggestion.headroomLbs)} headroom
            </button>
          ) : null}

          {/* save */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="btn btn-accent btn-xl w-full"
          >
            <Save className="size-6" />
            <span>{isSubmitting ? 'Saving ticket' : 'Save ticket'}</span>
          </button>
        </form>

        {/* ---------------------------------------- last 5 this session --- */}
        <div className="card">
          <div className="card-hd">
            <div className="eyebrow flex items-center gap-1.5">
              <Truck className="size-4 text-accent" /> Last 5 tickets this session
            </div>
            <span className="badge">
              <span className="num">{sessionTickets.length}</span> saved
            </span>
          </div>

          {sessionTickets.length === 0 ? (
            <div className="py-6 text-center text-xs text-subtle">
              No tickets logged in this session yet.
            </div>
          ) : (
            <div className="space-y-2">
              {sessionTickets.map((t) => {
                const rowTone = sandClasses(t.sandType, state.config.sandTypes);
                return (
                  <div
                    key={t.id}
                    className="flex items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-border"
                  >
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="num text-sm font-semibold text-accent">
                          #{t.ticketNumber}
                        </span>
                        <span className="badge">
                          Silo <span className="num">{t.siloNumber}</span>
                        </span>
                        <span className={cn('badge', rowTone.dim, rowTone.text)}>
                          {t.sandType}
                        </span>
                      </div>
                      <div className="mt-0.5 text-[11px] text-muted">
                        Supplier <span className="text-fg">{t.supplier || 'not recorded'}</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="num text-sm font-semibold">{formatLbs(t.lbs)}</div>
                      <div className="num text-[11px] text-muted">
                        {formatTons(t.lbs / lbsPerTon)}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* -------------------------------------------------------- modals --- */}
      {isDuplicateModalOpen && duplicateDelivery ? (
        <DuplicateWarningModal
          duplicate={duplicateDelivery}
          lbsPerTon={state.config.lbsPerTon}
          scannedTicketNumber={ticketNumber}
          rawScanValue={scannedInfo?.rawValue}
          onClose={handleCloseDuplicateModal}
          onRescan={() => {
            handleCloseDuplicateModal();
            setIsScannerOpen(true);
          }}
          onSupervisorOverride={async (reason) => {
            await executeSaveTicket({
              supervisorOverride: true,
              overrideReason: reason,
            });
            handleCloseDuplicateModal();
          }}
        />
      ) : null}

      {isConfirmationModalOpen && pendingScan ? (
        <ScanConfirmationModal
          parsed={pendingScan}
          candidates={scanCandidates}
          onConfirm={handleConfirmScan}
          onEdit={(edited) => handleConfirmScan(edited)}
          onRescan={() => {
            setIsConfirmationModalOpen(false);
            setIsScannerOpen(true);
          }}
          onCancel={() => setIsConfirmationModalOpen(false)}
        />
      ) : null}

      <TicketScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleScanSuccess}
        title="SCAN SAND DELIVERY TICKET"
        mappings={state.config.productCodeMappings || []}
      />
    </div>
  );
}

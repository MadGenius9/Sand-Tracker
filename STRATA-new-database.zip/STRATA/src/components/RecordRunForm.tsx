/**
 * Record run — the allocation form.
 *
 * Shared by the full-page Record run tab and the modal. The pad's draw
 * strategy proposes which cans to pull and how much; the crew corrects the
 * actual lbs that went downhole. Everything reconciles live against the stage
 * design so a short or over stage is visible before it is written, not after.
 */

import {
  CheckCircle2,
  ArrowRight,
  Plus,
  Trash2,
  AlertTriangle,
  Scale,
  Lock,
} from 'lucide-react';
import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import {
  formatLbs,
  formatTons,
  getPadSummary,
  getSiloDerivedStates,
} from '../lib/sandRules';
import { getOperationalDate } from '../lib/dateUtils';
import { cn, sandClasses } from '../lib/theme';
import { AppState } from '../types';

export interface RecordRunPayload {
  wellId: string;
  stageNumber: number;
  siloNumber: number;
  sandType: string;
  lbsPulled: number;
  date: string;
}

export interface RecordRunFormProps {
  state: AppState;
  initialWellId?: string;
  initialStageNumber?: number;
  initialStageLbsOverride?: number;
  initialDate?: string;
  fixedTarget?: boolean;
  title?: string;
  subtitle?: string;
  submitButtonLabel?: string;
  onRecordRun: (records: RecordRunPayload[]) => Promise<void> | void;
  onCancel?: () => void;
  onSuccess?: () => void;
  isModal?: boolean;
}

export default function RecordRunForm({
  state,
  initialWellId,
  initialStageNumber,
  initialStageLbsOverride,
  initialDate,
  fixedTarget = false,
  submitButtonLabel,
  onRecordRun,
  onCancel,
  onSuccess,
}: RecordRunFormProps) {
  const { config, runs, deliveries } = state;
  const lbsPerTon = config.lbsPerTon || 2000;

  /* getPadSummary walks every ticket and run on the pad. */
  const padSummary = useMemo(() => getPadSummary(state), [config, runs, deliveries]);

  const defaultWell = config.wells[0] || { id: 'w-1', name: 'Well 1H', plannedStages: 40 };

  const [wellId, setWellId] = useState<string>(
    initialWellId || padSummary.activeWellId || defaultWell.id
  );
  const [stageNumber, setStageNumber] = useState<number>(
    initialStageNumber !== undefined ? initialStageNumber : padSummary.nextStageNumber
  );
  const [stageLbsOverride, setStageLbsOverride] = useState<number | undefined>(
    initialStageLbsOverride
  );
  const [date, setDate] = useState<string>(initialDate || getOperationalDate());
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (initialWellId) setWellId(initialWellId);
  }, [initialWellId]);

  useEffect(() => {
    if (initialStageNumber !== undefined) setStageNumber(initialStageNumber);
  }, [initialStageNumber]);

  useEffect(() => {
    if (initialStageLbsOverride !== undefined) setStageLbsOverride(initialStageLbsOverride);
  }, [initialStageLbsOverride]);

  /* The expensive one: replays deliveries and runs per silo, then computes the
     whole run order. Legitimately depends on the stage override. */
  const siloDerivedStates = useMemo(
    () => getSiloDerivedStates(state, wellId, stageNumber, stageLbsOverride),
    [config, runs, deliveries, wellId, stageNumber, stageLbsOverride]
  );

  const [includedSiloNumbers, setIncludedSiloNumbers] = useState<number[]>([]);
  const [customPulls, setCustomPulls] = useState<Record<number, number>>({});
  const [selectedAddSiloNumber, setSelectedAddSiloNumber] = useState<string>('');

  // Re-seed the allocation whenever the target moves.
  useEffect(() => {
    const plannedSilos = siloDerivedStates
      .filter((s) => s.plannedPullLbs > 0)
      .map((s) => s.siloNumber);

    const initialList =
      plannedSilos.length > 0
        ? plannedSilos
        : siloDerivedStates.filter((s) => !s.isOutOfService && s.sandType).map((s) => s.siloNumber);

    setIncludedSiloNumbers(initialList);

    const initialPulls: Record<number, number> = {};
    siloDerivedStates.forEach((s) => {
      if (s.plannedPullLbs > 0) {
        initialPulls[s.siloNumber] = s.plannedPullLbs;
      }
    });
    setCustomPulls(initialPulls);
    setSelectedAddSiloNumber('');
  }, [wellId, stageNumber, siloDerivedStates]);

  const selectedWellObj = config.wells.find((w) => w.id === wellId) || defaultWell;

  const availableToAddSilos = useMemo(
    () => siloDerivedStates.filter((s) => !includedSiloNumbers.includes(s.siloNumber)),
    [siloDerivedStates, includedSiloNumbers]
  );

  const getPullAmount = useCallback(
    (siloNum: number): number => {
      if (customPulls[siloNum] !== undefined) return customPulls[siloNum];
      return siloDerivedStates.find((s) => s.siloNumber === siloNum)?.plannedPullLbs || 0;
    },
    [customPulls, siloDerivedStates]
  );

  const handlePullChange = (siloNum: number, val: string) => {
    const num = val === '' ? 0 : parseInt(val, 10);
    setCustomPulls((prev) => ({ ...prev, [siloNum]: isNaN(num) ? 0 : num }));
  };

  const handleAddSilo = (siloNumToAdd: number) => {
    if (!includedSiloNumbers.includes(siloNumToAdd)) {
      setIncludedSiloNumbers((prev) => [...prev, siloNumToAdd]);
      setCustomPulls((prev) => ({ ...prev, [siloNumToAdd]: prev[siloNumToAdd] ?? 0 }));
    }
    setSelectedAddSiloNumber('');
  };

  const handleRemoveSilo = (siloNumToRemove: number) => {
    setIncludedSiloNumbers((prev) => prev.filter((num) => num !== siloNumToRemove));
    setCustomPulls((prev) => {
      const updated = { ...prev };
      delete updated[siloNumToRemove];
      return updated;
    });
  };

  // ------------------------------------------- design reconciliation ---

  const stageDesignTotalLbs = useMemo(() => {
    if (stageLbsOverride !== undefined) return stageLbsOverride;
    return config.sandTypes.reduce((sum, st) => sum + (st.perStageDesignLbs || 0), 0);
  }, [config.sandTypes, stageLbsOverride]);

  const totalActualPulledLbs = useMemo(
    () => includedSiloNumbers.reduce((sum, siloNum) => sum + (getPullAmount(siloNum) || 0), 0),
    [includedSiloNumbers, getPullAmount]
  );

  const totalVarianceLbs = totalActualPulledLbs - stageDesignTotalLbs;
  const variancePercentage =
    stageDesignTotalLbs > 0 ? (totalVarianceLbs / stageDesignTotalLbs) * 100 : 0;

  const sandTypeBreakdown = useMemo(() => {
    return config.sandTypes.map((st) => {
      const designLbs = st.perStageDesignLbs || 0;
      const actualLbs = includedSiloNumbers
        .filter((siloNum) => {
          const silo = siloDerivedStates.find((s) => s.siloNumber === siloNum);
          return silo?.sandType === st.name;
        })
        .reduce((sum, siloNum) => sum + (getPullAmount(siloNum) || 0), 0);

      return {
        sandType: st.name,
        designLbs,
        actualLbs,
        diffLbs: actualLbs - designLbs,
      };
    });
  }, [config.sandTypes, includedSiloNumbers, siloDerivedStates, getPullAmount]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setErrorMessage(null);

    const recordsToSave: RecordRunPayload[] = [];

    includedSiloNumbers.forEach((siloNum) => {
      const silo = siloDerivedStates.find((s) => s.siloNumber === siloNum);
      const pull = getPullAmount(siloNum);
      if (pull > 0 && silo && silo.sandType) {
        recordsToSave.push({
          wellId,
          stageNumber,
          siloNumber: silo.siloNumber,
          sandType: silo.sandType,
          lbsPulled: pull,
          date,
        });
      }
    });

    if (recordsToSave.length === 0) {
      setErrorMessage('Enter at least one silo pull weight above zero.');
      return;
    }

    try {
      setIsSubmitting(true);
      await onRecordRun(recordsToSave);
      if (onSuccess) onSuccess();
    } catch (err: any) {
      console.error('Failed to record run:', err);
      setErrorMessage(err?.message || 'Failed to record stage run');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-5">
      {/* ---------------------------------------------- run target --- */}
      {fixedTarget ? (
        <div className="flex flex-col gap-3 rounded-md bg-elevated p-3 ring-accent-1 sm:flex-row sm:items-end sm:justify-between">
          <div className="min-w-0">
            <div className="eyebrow">Target stage</div>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              <span className="text-lg font-medium">{selectedWellObj.name}</span>
              <span className="badge badge-accent">
                Stage <span className="num">{stageNumber}</span>
              </span>
              {selectedWellObj.customerName && (
                <span className="text-xs text-muted">{selectedWellObj.customerName}</span>
              )}
            </div>
          </div>

          <label className="block shrink-0">
            <span className="eyebrow">Run date</span>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="input num mt-1"
            />
          </label>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <label className="block">
            <span className="eyebrow">Target well</span>
            <select
              value={wellId}
              onChange={(e) => {
                const newWellId = e.target.value;
                setWellId(newWellId);
                const lastRunForWell = (runs || [])
                  .filter((r) => !r.deleted && r.wellId === newWellId)
                  .sort((a, b) => b.stageNumber - a.stageNumber)[0];
                setStageNumber(lastRunForWell ? lastRunForWell.stageNumber + 1 : 1);
              }}
              className="select mt-1"
            >
              {config.wells.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name} ({w.plannedStages} stages)
                </option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="eyebrow">Stage number</span>
            <input
              type="number"
              inputMode="numeric"
              value={stageNumber}
              onChange={(e) => setStageNumber(parseInt(e.target.value, 10) || 1)}
              min={1}
              className="input input-num mt-1"
            />
          </label>

          <label className="block">
            <span className="eyebrow">Stage lbs override</span>
            <input
              type="number"
              inputMode="numeric"
              placeholder="Auto design"
              value={stageLbsOverride ?? ''}
              onChange={(e) => {
                const val = e.target.value;
                setStageLbsOverride(val === '' ? undefined : parseInt(val, 10) || 0);
              }}
              className="input input-num mt-1"
            />
          </label>

          <label className="block">
            <span className="eyebrow">Run date</span>
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="input num mt-1"
            />
          </label>
        </div>
      )}

      {errorMessage && (
        <div className="flex items-start gap-2 rounded-md bg-elevated p-3 text-sm text-danger ring-danger-1">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* ------------------------------------------ silo allocation --- */}
      <div className="flex flex-col gap-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="eyebrow">
            Pull allocation · <span className="num">{includedSiloNumbers.length}</span> can
            {includedSiloNumbers.length === 1 ? '' : 's'} in this run
          </div>
          <div className="eyebrow">Edit the actual lbs that went downhole</div>
        </div>

        {includedSiloNumbers.length === 0 ? (
          <div className="rounded-md bg-elevated p-6 text-center ring-border">
            <div className="text-sm text-fg">No cans allocated for this run.</div>
            <div className="mt-1 text-xs text-muted">Add one with the selector below.</div>
          </div>
        ) : (
          <div className="flex flex-col gap-2">
            {includedSiloNumbers.map((siloNum) => {
              const s = siloDerivedStates.find((ds) => ds.siloNumber === siloNum);
              if (!s) return null;

              const currentPull = getPullAmount(siloNum);
              const isOverPulling = s.onHandLbs > 0 && currentPull > s.onHandLbs;
              const willRunEmpty = currentPull >= s.onHandLbs && s.onHandLbs > 0;
              const tone = sandClasses(s.sandType, config.sandTypes);
              const isLocked = s.manualPriority !== null && s.manualPriority !== undefined;

              return (
                <div
                  key={siloNum}
                  className={cn(
                    'flex flex-col justify-between gap-3 rounded-md bg-elevated p-3 sm:flex-row sm:items-center',
                    s.isOutOfService
                      ? 'opacity-60 ring-border'
                      : isOverPulling
                        ? 'ring-danger-1'
                        : currentPull > 0
                          ? 'ring-accent-1'
                          : 'ring-border'
                  )}
                >
                  <div className="flex min-w-0 items-start gap-3">
                    <span className="num flex size-10 shrink-0 items-center justify-center rounded-sm bg-surface text-sm font-semibold ring-border">
                      {s.siloNumber}
                    </span>

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-medium">
                          {s.name || `Silo #${s.siloNumber}`}
                        </span>
                        {s.sandType && (
                          <span className="flex items-center gap-1.5 text-xs text-muted">
                            <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                            {s.sandType}
                          </span>
                        )}
                        {s.runOrder !== null && (
                          <span className={cn('badge', isLocked ? 'badge-locked' : 'badge-accent')}>
                            {isLocked && <Lock className="size-3" />} Order{' '}
                            <span className="num">#{s.runOrder}</span>
                          </span>
                        )}
                        {s.isOutOfService && <span className="badge badge-danger">Offline</span>}
                        {willRunEmpty && !isOverPulling && (
                          <span className="badge badge-warn">Runs dry</span>
                        )}
                      </div>

                      <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted">
                        <span>
                          On hand <span className="num text-fg">{formatLbs(s.onHandLbs)}</span> ·{' '}
                          <span className="num">{formatTons(s.onHandLbs / lbsPerTon)}</span>
                        </span>
                        {s.plannedPullLbs > 0 && (
                          <span>
                            Plan <span className="num text-fg">{formatLbs(s.plannedPullLbs)}</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex shrink-0 items-end justify-end gap-2">
                    <label className="block">
                      <span className="eyebrow">Actual pull (lbs)</span>
                      <input
                        type="number"
                        inputMode="numeric"
                        disabled={s.isOutOfService}
                        value={
                          currentPull === 0 && customPulls[siloNum] === undefined ? 0 : currentPull
                        }
                        onChange={(e) => handlePullChange(siloNum, e.target.value)}
                        className={cn(
                          'input input-lg input-num mt-1 w-40',
                          isOverPulling && 'ring-danger-1 text-danger'
                        )}
                      />
                      <span className="mt-1 block text-right text-xs text-muted">
                        {isOverPulling ? (
                          <span className="text-danger">
                            Exceeds on hand by{' '}
                            <span className="num">{formatLbs(currentPull - s.onHandLbs)}</span>
                          </span>
                        ) : (
                          <span className="num">{formatTons(currentPull / lbsPerTon)}</span>
                        )}
                      </span>
                    </label>

                    <button
                      type="button"
                      title={`Remove silo #${s.siloNumber} from this run`}
                      aria-label={`Remove silo ${s.siloNumber} from this run`}
                      onClick={() => handleRemoveSilo(siloNum)}
                      className="btn btn-ghost tap mb-6 px-2.5"
                    >
                      <Trash2 className="size-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {availableToAddSilos.length > 0 && (
          <div className="flex flex-col items-stretch justify-between gap-2 rounded-md bg-elevated p-3 ring-border sm:flex-row sm:items-center">
            <div className="flex items-center gap-2 text-sm text-muted">
              <Plus className="size-4 shrink-0 text-accent" />
              <span>Pulled from a can that was not in the plan?</span>
            </div>

            <div className="flex items-center gap-2">
              <select
                value={selectedAddSiloNumber}
                onChange={(e) => setSelectedAddSiloNumber(e.target.value)}
                className="select flex-1 sm:w-72 sm:flex-none"
              >
                <option value="">Choose a silo to add</option>
                {availableToAddSilos.map((s) => (
                  <option key={s.siloNumber} value={s.siloNumber}>
                    Silo #{s.siloNumber} ({s.sandType || 'No sand'}) — {formatLbs(s.onHandLbs)} on
                    hand
                  </option>
                ))}
              </select>

              <button
                type="button"
                disabled={!selectedAddSiloNumber}
                onClick={() => {
                  if (selectedAddSiloNumber) handleAddSilo(parseInt(selectedAddSiloNumber, 10));
                }}
                className="btn tap shrink-0"
              >
                <Plus className="size-4" /> Add
              </button>
            </div>
          </div>
        )}
      </div>

      {/* --------------------------------- stage design reconciliation --- */}
      <div className="card-flush p-4">
        <div className="flex flex-wrap items-center justify-between gap-2 pb-3">
          <div className="flex items-center gap-2">
            <Scale className="size-4 shrink-0 text-accent" />
            <span className="eyebrow">Stage design reconciliation</span>
          </div>

          {totalVarianceLbs < 0 ? (
            <span className="badge badge-danger">
              Short <span className="num">{formatLbs(Math.abs(totalVarianceLbs))}</span> ·{' '}
              <span className="num">{Math.abs(variancePercentage).toFixed(1)}%</span>
            </span>
          ) : totalVarianceLbs > 0 ? (
            <span className="badge badge-warn">
              Over <span className="num">+{formatLbs(totalVarianceLbs)}</span> ·{' '}
              <span className="num">+{variancePercentage.toFixed(1)}%</span>
            </span>
          ) : (
            <span className="badge badge-ok">Exactly on design</span>
          )}
        </div>

        <div className="divider" />

        <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Stage design</div>
            <div className="stat-v mt-1">{formatLbs(stageDesignTotalLbs)}</div>
            <div className="num text-xs text-muted">
              {formatTons(stageDesignTotalLbs / lbsPerTon)}
            </div>
          </div>

          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="eyebrow">Total recorded pull</div>
            <div className="stat-v mt-1">{formatLbs(totalActualPulledLbs)}</div>
            <div className="num text-xs text-muted">
              {formatTons(totalActualPulledLbs / lbsPerTon)}
            </div>
          </div>

          <div
            className={cn(
              'rounded-md bg-elevated p-3',
              totalVarianceLbs < 0
                ? 'ring-danger-1'
                : totalVarianceLbs > 0
                  ? 'ring-warn-1'
                  : 'ring-border'
            )}
          >
            <div className="eyebrow">Stage variance</div>
            <div
              className={cn(
                'stat-v mt-1',
                totalVarianceLbs < 0
                  ? 'text-danger'
                  : totalVarianceLbs > 0
                    ? 'text-warn'
                    : 'text-ok'
              )}
            >
              {totalVarianceLbs > 0 ? `+${formatLbs(totalVarianceLbs)}` : formatLbs(totalVarianceLbs)}
            </div>
            <div className="num text-xs text-muted">
              {stageDesignTotalLbs > 0
                ? `${((totalActualPulledLbs / stageDesignTotalLbs) * 100).toFixed(1)}% of design`
                : '—'}
            </div>
          </div>
        </div>

        {sandTypeBreakdown.length > 1 && (
          <div className="mt-3 grid grid-cols-1 gap-2 border-t border-border pt-3 sm:grid-cols-2">
            {sandTypeBreakdown.map((st) => {
              const tone = sandClasses(st.sandType, config.sandTypes);
              return (
                <div
                  key={st.sandType}
                  className="flex items-center justify-between gap-2 rounded-sm bg-elevated px-3 py-2"
                >
                  <div className="flex min-w-0 items-center gap-2 text-sm">
                    <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                    <span className="truncate">{st.sandType}</span>
                    <span className="num text-muted">
                      {formatLbs(st.actualLbs)} / {formatLbs(st.designLbs)}
                    </span>
                  </div>
                  <span
                    className={cn(
                      'num shrink-0 text-xs font-semibold',
                      st.diffLbs < 0 ? 'text-danger' : st.diffLbs > 0 ? 'text-warn' : 'text-ok'
                    )}
                  >
                    {st.diffLbs > 0 ? `+${formatLbs(st.diffLbs)}` : formatLbs(st.diffLbs)}
                  </span>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* --------------------------------------------------- footer --- */}
      <div className="flex flex-col-reverse items-stretch justify-end gap-2 sm:flex-row sm:items-center">
        {onCancel && (
          <button type="button" disabled={isSubmitting} onClick={onCancel} className="btn btn-lg tap">
            Cancel
          </button>
        )}

        <button type="submit" disabled={isSubmitting} className="btn btn-accent btn-lg tap">
          {isSubmitting ? (
            'Recording run'
          ) : (
            <>
              <CheckCircle2 className="size-5" />
              <span>
                {submitButtonLabel ||
                  `Record run — ${selectedWellObj.name} stage ${stageNumber}`}
              </span>
              <ArrowRight className="size-4" />
            </>
          )}
        </button>
      </div>
    </form>
  );
}

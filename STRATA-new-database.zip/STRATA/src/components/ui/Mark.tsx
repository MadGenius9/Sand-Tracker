/**
 * STRATA mark — a silo silhouette with a filled base.
 *
 * Deliberately the same visual idea as the canister at 32px, so the brand and
 * the primary data object are the same shape. Gradient ids are scoped per
 * instance because the previous logo's unscoped ids collided whenever two
 * variants rendered on one page (header + print sheet).
 */

import { useId } from 'react';

export function Mark({ className = 'size-8' }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <rect width="32" height="32" rx="6" className="fill-elevated" />
      <path
        d="M10 8h12l2 3v16H8V11l2-3z"
        className="fill-bg stroke-accent"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      <path d="M10 22h12v5H10z" className="fill-accent" />
      <path d="M9 15.5h14" className="stroke-border-strong" strokeWidth="1" />
      <path d="M9 18.75h14" className="stroke-border-strong" strokeWidth="1" />
    </svg>
  );
}

/** Mark + wordmark. Header, loading screen, print header. */
export function Wordmark({
  className = '',
  subtitle = 'Sand command',
  markClass = 'size-8',
}: {
  className?: string;
  subtitle?: string | null;
  markClass?: string;
}) {
  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <Mark className={markClass} />
      <div className="leading-none">
        <div className="text-[15px] font-semibold tracking-[0.18em] text-fg">STRATA</div>
        {subtitle ? <div className="eyebrow mt-1">{subtitle}</div> : null}
      </div>
    </div>
  );
}

/**
 * Print-only mark. The screen version relies on theme tokens that @media print
 * overrides to white, so the paper sheet gets explicit ink colors.
 */
export function PrintMark({ className = 'w-8 h-8' }: { className?: string }) {
  const id = useId();
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <rect width="32" height="32" rx="6" fill="#f0efe9" stroke={`url(#${id})`} />
      <defs>
        <linearGradient id={id}>
          <stop offset="0%" stopColor="#3a5c4e" />
          <stop offset="100%" stopColor="#3a5c4e" />
        </linearGradient>
      </defs>
      <path d="M10 8h12l2 3v16H8V11l2-3z" fill="#ffffff" stroke="#3a5c4e" strokeWidth="1.6" />
      <path d="M10 22h12v5H10z" fill="#3a5c4e" />
    </svg>
  );
}

export default Mark;

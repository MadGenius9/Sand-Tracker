import { calculateJobDesignMetrics, calculateDeliveredBySupplier, calculateSandDesignForWell, calculateSandPumpedForWell } from './sandRules';
import { getOperationalDate } from './dateUtils';
import { AppState, PadConfig, DeliveryTicket, RunRecord } from '../types';
import { JobImportPackage } from '../types/import';

/**
 * CSV field escaping.
 *
 * The old code inlined `.replace(/"/g, '""')` at every call site and handled
 * nothing else. A ticket note containing a newline — which is what a BOL
 * reference pasted off a phone looks like — split one ledger row into two,
 * silently shifting every column of the second half and corrupting the export
 * a coordinator hands to accounting. Newlines and carriage returns are folded
 * to a space; quotes are doubled; everything is quoted.
 */
function csv(value: unknown): string {
  if (value === null || value === undefined) return '""';
  const s = String(value).replace(/\r\n|\r|\n/g, ' ').replace(/"/g, '""');
  return `"${s}"`;
}

/** One CSV row from an array of raw values. */
function csvRow(values: unknown[]): string {
  return values.map(csv).join(',') + '\n';
}

export function generatePadCSV(state: AppState): string {
  const { config, deliveries, runs } = state;
  const lbsPerTon = config.lbsPerTon || 2000;

  const jobMetrics = calculateJobDesignMetrics(state);
  const supplierRows = calculateDeliveredBySupplier(state);

  // Pad Totals
  const totalDeliveredLbs = deliveries.reduce((sum, d) => sum + (d.lbs || 0), 0);
  const totalDeliveredTons = totalDeliveredLbs / lbsPerTon;

  const totalPumpedLbs = runs.reduce((sum, r) => sum + (r.lbsPulled || 0), 0);
  const totalPumpedTons = totalPumpedLbs / lbsPerTon;

  const totalOnHandLbs = config.silos.reduce((sum, s) => {
    const delivered = deliveries.filter((d) => d.siloNumber === s.siloNumber).reduce((a, b) => a + (b.lbs || 0), 0);
    const pumped = runs.filter((r) => r.siloNumber === s.siloNumber).reduce((a, b) => a + (b.lbsPulled || 0), 0);
    return sum + (s.startingBalanceLbs || 0) + delivered - pumped;
  }, 0);
  const totalOnHandTons = totalOnHandLbs / lbsPerTon;

  let csv = '';

  // Header Metadata
  csv += csvRow(['PYTHON SAND TRACKER - END OF JOB SUMMARY REPORT']);
  csv += csvRow(['Pad Name', config.padName]);
  csv += csvRow(['Report Generated', new Date().toLocaleString()]);
  csv += csvRow(['Total Sand Delivered (Lbs)', totalDeliveredLbs]);
  csv += csvRow(['Total Sand Delivered (Tons)', totalDeliveredTons.toFixed(2)]);
  csv += csvRow(['Total Sand Pumped (Lbs)', totalPumpedLbs]);
  csv += csvRow(['Total Sand Pumped (Tons)', totalPumpedTons.toFixed(2)]);
  csv += csvRow(['Current On-Hand Balance (Lbs)', totalOnHandLbs]);
  csv += csvRow(['Current On-Hand Balance (Tons)', totalOnHandTons.toFixed(2)]);
  csv += `\n`;

  // Section 1: Whole-Job Frac Design & Cross-Check Summary
  csv += csvRow(['=== WHOLE-JOB FRAC DESIGN & CROSS-CHECK SUMMARY ===']);
  csv += csvRow([
    'Sand Type', 'Job Design Total (Lbs)', 'Job Design Total (Tons)', 'Delivered So Far (Lbs)',
    'Still To Deliver (Lbs)', 'Truckloads Needed', 'Pumped So Far (Lbs)',
    'Remaining In Design (Lbs)', 'Planned Sum (Lbs)', 'Cross-Check Diff (Lbs)',
    'Cross-Check Diff (%)', 'Cross-Check Flag',
  ]);
  jobMetrics.forEach((m) => {
    csv += csvRow([
      m.sandType.name,
      m.jobDesignTotalLbs,
      m.jobDesignTotalTons.toFixed(2),
      m.deliveredSoFarLbs,
      m.stillToDeliverLbs,
      m.truckloadsStillNeeded.toFixed(1),
      m.pumpedSoFarLbs,
      m.remainingInDesignLbs,
      m.plannedStagesSumLbs,
      m.plannedCrossCheckDiffLbs,
      `${m.plannedCrossCheckDiffPercent.toFixed(1)}%`,
      m.hasCrossCheckFlag ? 'FLAGGED (>2%)' : 'OK',
    ]);
  });
  csv += `\n`;

  // Section 2: Wells & Per-Sand Type Design vs Pumped Breakdown
  csv += csvRow(['=== PER-WELL SAND DESIGN VS PUMPED BREAKDOWN ===']);
  csv += csvRow([
    'Well Name', 'Planned Stages', 'Pumped Stages', 'Sand Type', 'Per-Stage Design (Lbs)',
    'Well Design Total (Lbs)', 'Well Pumped (Lbs)', 'Variance (Lbs)',
  ]);
  config.wells.forEach((well) => {
    const wellRuns = runs.filter((r) => r.wellId === well.id);
    const pumpedStages = new Set(wellRuns.map((r) => r.stageNumber)).size;

    config.sandTypes.forEach((st) => {
      const designLbs = calculateSandDesignForWell(well, st);
      const pumpedLbs = calculateSandPumpedForWell(well.id, st.name, state);
      const varianceLbs = pumpedLbs - designLbs;
      csv += csvRow([
        well.name, well.plannedStages, pumpedStages, st.name,
        st.perStageDesignLbs, designLbs, pumpedLbs, varianceLbs,
      ]);
    });
  });
  csv += `\n`;

  // Section 3: Delivered by Supplier Breakdown
  csv += csvRow(['=== DELIVERED BY SUPPLIER BREAKDOWN ===']);
  csv += csvRow([
    'Supplier Name',
    ...config.sandTypes.map((st) => `${st.name} (Lbs)`),
    'Total Lbs', 'Total Tons', 'Load Count',
  ]);
  supplierRows.forEach((row) => {
    csv += csvRow([
      row.supplierName,
      ...config.sandTypes.map((st) => row.lbsPerSandType[st.name] || 0),
      row.totalLbs,
      row.totalTons.toFixed(2),
      row.loadCount,
    ]);
  });
  csv += `\n`;

  // Section 4: Delivery Tickets Ledger
  csv += csvRow(['=== DELIVERY TICKETS LEDGER ===']);
  csv += csvRow([
    'Ticket Number', 'Date', 'Time', 'Entered Timestamp', 'Silo Number', 'Sand Type',
    'Supplier', 'Driver Name', 'Weight (Lbs)', 'Weight (Tons)', 'Notes',
  ]);
  deliveries.forEach((d) => {
    csv += csvRow([
      d.ticketNumber,
      d.date,
      d.timeOfDay || '',
      d.createdAt ? new Date(d.createdAt).toLocaleString() : '',
      `Silo #${d.siloNumber}`,
      d.sandType,
      d.supplier,
      d.driverName || '',
      d.lbs,
      (d.lbs / lbsPerTon).toFixed(2),
      d.notes || '',
    ]);
  });
  csv += `\n`;

  // Section 5: Stage Run Records Ledger
  csv += csvRow(['=== STAGE RUN RECORDS LEDGER ===']);
  csv += csvRow([
    'Date', 'Entered Timestamp', 'Well', 'Stage Number', 'Silo Number', 'Sand Type',
    'Weight Pulled (Lbs)', 'Weight Pulled (Tons)',
  ]);
  runs.forEach((r) => {
    const wellObj = config.wells.find((w) => w.id === r.wellId);
    csv += csvRow([
      r.date,
      r.createdAt ? new Date(r.createdAt).toLocaleString() : '',
      wellObj ? wellObj.name : 'Well',
      r.stageNumber,
      `Silo #${r.siloNumber}`,
      r.sandType,
      r.lbsPulled,
      (r.lbsPulled / lbsPerTon).toFixed(2),
    ]);
  });

  return csv;
}

function safePadSlug(padName: string): string {
  return (padName || 'pad').toLowerCase().replace(/[^a-z0-9]/g, '_') || 'pad';
}

function triggerDownload(content: string, mimeType: string, filename: string) {
  const blob = new Blob([content], { type: mimeType });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

export function downloadPadCSV(state: AppState) {
  triggerDownload(
    generatePadCSV(state),
    'text/csv;charset=utf-8;',
    `sand_tracker_job_export_${safePadSlug(state.config.padName)}_${getOperationalDate()}.csv`
  );
}

/* ------------------------------------------------------------ JSON backup -- */

/**
 * A job package that `importService.importJobPackage` can read back.
 *
 * The CSV is a report — it is shaped for a human and for accounting, and it
 * cannot be re-imported. Until now that was the ONLY export, so a job could be
 * imported but never backed up and restored: the "Import backup package"
 * button on the pad manager accepted a file format nothing in the app could
 * produce. This closes that loop.
 *
 * Soft-deleted tickets and runs are INCLUDED. They carry `deleted: true` and
 * their reason and author, they are what an audit is reconstructed from, and
 * dropping them would make a restore quietly lossy.
 */
export function generateJobPackage(state: AppState): JobImportPackage {
  const deliveries: DeliveryTicket[] = [
    ...(state.deliveries || []),
    ...(state.deletedDeliveries || []),
  ];
  const runs: RunRecord[] = [...(state.runs || []), ...(state.deletedRuns || [])];

  const config: PadConfig = state.config;

  return {
    version: 1,
    source: `STRATA job export — ${config.padName || 'pad'}`,
    exportedAt: new Date().toISOString(),
    padId: state.padId || `pad-${safePadSlug(config.padName)}`,
    config,
    // Oldest first: an import replays in order, and a restored ledger that
    // reads chronologically is far easier to diff against the original.
    deliveries: deliveries
      .slice()
      .sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)),
    runs: runs.slice().sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0)),
  };
}

export function downloadJobPackage(state: AppState) {
  const pkg = generateJobPackage(state);
  triggerDownload(
    JSON.stringify(pkg, null, 2),
    'application/json;charset=utf-8;',
    `strata_job_package_${safePadSlug(state.config.padName)}_${getOperationalDate()}.json`
  );
}

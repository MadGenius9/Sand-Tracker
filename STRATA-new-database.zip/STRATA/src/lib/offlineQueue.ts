/**
 * Offline write queue.
 *
 * A pad loses signal constantly. Everything the crew does while it is down is
 * parked here in localStorage and replayed when the connection returns.
 *
 * Three things this module is responsible for that it previously was not:
 *
 *  1. FLUSHING ITSELF. The queue used to drain only when a component that
 *     happened to be mounted (OfflineBanner) decided to drain it. A kiosk left
 *     on the ?mode=entry screen, or a tab whose banner had been dismissed by a
 *     re-render, held tickets indefinitely. Now the module owns an 'online'
 *     listener and a backed-off interval of its own, driven by an executor the
 *     data layer registers at import time.
 *
 *  2. NOT LOSING WRITES SILENTLY. An item that exhausts its retries, or that
 *     fails for a reason retrying can never fix (a duplicate ticket number),
 *     used to be console.warn'd out of existence. It is now recorded as a
 *     permanent failure, surfaced to listeners, and kept until acknowledged.
 *
 *  3. BEING SAFE TO CALL FROM ANYWHERE. `flushOfflineQueue` is re-entrancy
 *     guarded; the auto-flush, OfflineBanner's own 'online' handler and the
 *     Sync now button can all fire at once without double-posting.
 */

import { OfflineQueueItem, QueueActionType } from '../types';

const QUEUE_STORAGE_KEY = 'python_sandtracker_offline_queue_v1';
const FAILURE_STORAGE_KEY = 'python_sandtracker_offline_failures_v1';

/** Retries before an item is given up on and recorded as a permanent failure. */
export const MAX_QUEUE_RETRIES = 5;

/**
 * A queued write that will never land. Kept so the banner can name the ticket
 * the crew is about to discover is missing, instead of a console line nobody
 * on a pad will ever read.
 */
export interface QueuePermanentFailure {
  id: string;
  type: QueueActionType;
  padId: string;
  /** Human label — "Ticket #M30134835", "Stage run", "Silo 3 change". */
  label: string;
  reason: string;
  retries: number;
  failedAt: number;
  /** The original payload, so the entry can be re-entered by hand. */
  payload?: any;
}

type OfflineListener = (
  isOnline: boolean,
  queue: OfflineQueueItem[],
  permanentFailures: QueuePermanentFailure[]
) => void;
const listeners = new Set<OfflineListener>();

export function isOnline(): boolean {
  if (typeof navigator !== 'undefined' && typeof navigator.onLine === 'boolean') {
    return navigator.onLine;
  }
  return true;
}

export function getOfflineQueue(padId?: string): OfflineQueueItem[] {
  if (typeof window === 'undefined' || !window.localStorage) {
    return [];
  }
  try {
    const raw = localStorage.getItem(QUEUE_STORAGE_KEY);
    if (!raw) return [];
    const parsed: OfflineQueueItem[] = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    if (padId) {
      return parsed.filter((item) => item.padId === padId);
    }
    return parsed;
  } catch (err) {
    console.error('Failed to read offline queue from localStorage:', err);
    return [];
  }
}

function saveOfflineQueue(queue: OfflineQueueItem[]) {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    localStorage.setItem(QUEUE_STORAGE_KEY, JSON.stringify(queue));
    notifyListeners();
  } catch (err) {
    console.error('Failed to write offline queue to localStorage:', err);
  }
}

/* ---------------------------------------------------- permanent failures --- */

export function getPermanentFailures(padId?: string): QueuePermanentFailure[] {
  if (typeof window === 'undefined' || !window.localStorage) return [];
  try {
    const raw = localStorage.getItem(FAILURE_STORAGE_KEY);
    if (!raw) return [];
    const parsed: QueuePermanentFailure[] = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return padId ? parsed.filter((f) => f.padId === padId) : parsed;
  } catch (err) {
    console.error('Failed to read offline failure log:', err);
    return [];
  }
}

function savePermanentFailures(failures: QueuePermanentFailure[]) {
  if (typeof window === 'undefined' || !window.localStorage) return;
  try {
    // Keep the log bounded; the oldest lost ticket is the least actionable.
    localStorage.setItem(FAILURE_STORAGE_KEY, JSON.stringify(failures.slice(-50)));
    notifyListeners();
  } catch (err) {
    console.error('Failed to write offline failure log:', err);
  }
}

/** A short human label for a queued mutation, used in the failure banner. */
export function describeQueueItem(item: OfflineQueueItem): string {
  const p = item.payload || {};
  switch (item.type) {
    case 'ADD_DELIVERY':
      return `Ticket #${p.ticketNumber || '(no number)'}${
        p.lbs ? ` · ${Number(p.lbs).toLocaleString()} lbs` : ''
      }${p.siloNumber !== undefined ? ` · silo ${p.siloNumber}` : ''}`;
    case 'UPDATE_DELIVERY':
      return `Edit of ticket ${p.ticketId || ''}`;
    case 'DELETE_DELIVERY':
      return `Deletion of ticket ${p.ticketId || ''}`;
    case 'RESTORE_DELIVERY':
      return `Restore of ticket ${p.ticketId || ''}`;
    case 'ADD_RUNS': {
      const records = p.records || [];
      const first = records[0];
      return first
        ? `Stage ${first.stageNumber} run${records.length > 1 ? `s (${records.length})` : ''}`
        : 'Stage run';
    }
    case 'UPDATE_RUN':
      return `Edit of stage run ${p.runId || ''}`;
    case 'DELETE_RUN':
      return `Deletion of stage run ${p.runId || ''}`;
    case 'RESTORE_RUN':
      return `Restore of stage run ${p.runId || ''}`;
    case 'UPDATE_SILO':
      return `Silo ${p.siloNumber} configuration change`;
    case 'UPDATE_SILOS':
      return `Silo configuration change (${(p.silos || []).length} silos)`;
    case 'SAVE_PAD_CONFIG':
      return 'Pad setup change';
    case 'CREATE_PAD':
      return 'New pad';
    default:
      return item.type;
  }
}

/**
 * Record a write that is never going to land. Called for retry exhaustion,
 * for permanently-fatal errors (a duplicate ticket number), and by the data
 * layer when it drops a mutation against a pad that no longer exists.
 */
export function recordPermanentFailure(item: OfflineQueueItem, reason: string) {
  const failures = getPermanentFailures();
  if (failures.some((f) => f.id === item.id)) return;
  failures.push({
    id: item.id,
    type: item.type,
    padId: item.padId,
    label: describeQueueItem(item),
    reason,
    retries: item.retries || 0,
    failedAt: Date.now(),
    payload: item.payload,
  });
  console.error(`[OFFLINE QUEUE LOST] ${item.type} — ${describeQueueItem(item)}: ${reason}`);
  savePermanentFailures(failures);
}

/** Dismiss one recorded failure (the operator has re-entered it by hand). */
export function acknowledgePermanentFailure(id: string) {
  savePermanentFailures(getPermanentFailures().filter((f) => f.id !== id));
}

/** Dismiss every recorded failure, optionally only for one pad. */
export function clearPermanentFailures(padId?: string) {
  if (padId) {
    savePermanentFailures(getPermanentFailures().filter((f) => f.padId !== padId));
  } else {
    savePermanentFailures([]);
  }
}

/* -------------------------------------------------------------- listeners --- */

function notifyListeners() {
  const online = isOnline();
  const queue = getOfflineQueue();
  const failures = getPermanentFailures();
  listeners.forEach((listener) => {
    try {
      listener(online, queue, failures);
    } catch (e) {
      console.error('Error in offline queue listener:', e);
    }
  });
}

export function subscribeOfflineState(listener: OfflineListener): () => void {
  listeners.add(listener);
  // Emit initial state
  listener(isOnline(), getOfflineQueue(), getPermanentFailures());
  return () => {
    listeners.delete(listener);
  };
}

/* ------------------------------------------------------------ enqueue/edit --- */

export function enqueueOfflineAction(
  padId: string,
  type: QueueActionType,
  payload: any
): OfflineQueueItem {
  const currentQueue = getOfflineQueue();
  const newItem: OfflineQueueItem = {
    id: `queue_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
    type,
    padId,
    payload,
    createdAt: Date.now(),
    retries: 0,
    status: 'pending',
  };

  const updated = [...currentQueue, newItem];
  saveOfflineQueue(updated);
  // Something is waiting now — make sure the timer is running.
  scheduleAutoFlush(AUTO_FLUSH_BASE_MS);
  return newItem;
}

export function removeQueueItem(id: string) {
  const current = getOfflineQueue();
  const updated = current.filter((item) => item.id !== id);
  saveOfflineQueue(updated);
}

export function updateQueueItem(id: string, updates: Partial<OfflineQueueItem>) {
  const current = getOfflineQueue();
  const updated = current.map((item) => (item.id === id ? { ...item, ...updates } : item));
  saveOfflineQueue(updated);
}

export function clearOfflineQueue(padId?: string) {
  if (padId) {
    const current = getOfflineQueue();
    const updated = current.filter((item) => item.padId !== padId);
    saveOfflineQueue(updated);
  } else {
    saveOfflineQueue([]);
  }
}

/* ------------------------------------------------------------------ flush --- */

export type QueueExecutor = (item: OfflineQueueItem) => Promise<void>;

let isSyncing = false;

/** True while a flush is in flight, from any caller. */
export function isQueueSyncing(): boolean {
  return isSyncing;
}

/**
 * An error a retry can never fix. Thrown by the data layer for a duplicate
 * ticket number: replaying the write a sixth time will not make the number
 * less taken, and the operator needs to be told, not spun on.
 */
export function isPermanentQueueError(err: any): boolean {
  if (!err) return false;
  if (err.permanent === true) return true;
  const msg = String(err.message || '');
  return msg.includes('DUPLICATE TICKET') || msg.includes('PERMANENT:');
}

export async function flushOfflineQueue(
  executor: QueueExecutor,
  padId?: string
): Promise<{ processed: number; failed: number; lost: number }> {
  if (isSyncing) return { processed: 0, failed: 0, lost: 0 };
  if (!isOnline()) return { processed: 0, failed: 0, lost: 0 };

  isSyncing = true;
  let processed = 0;
  let failed = 0;
  let lost = 0;

  try {
    const queue = getOfflineQueue(padId);
    if (queue.length === 0) {
      return { processed: 0, failed: 0, lost: 0 };
    }

    for (const item of queue) {
      // Connection can drop mid-drain; stop rather than burning retries.
      if (!isOnline()) break;

      try {
        updateQueueItem(item.id, { status: 'syncing' });
        await executor(item);
        removeQueueItem(item.id);
        processed++;
      } catch (err: any) {
        console.error(`Failed to sync queued item ${item.id} (${item.type}):`, err);
        const nextRetries = (item.retries || 0) + 1;
        const permanent = isPermanentQueueError(err);

        updateQueueItem(item.id, {
          status: 'failed',
          retries: nextRetries,
          error: err?.message || 'Sync failed',
        });
        failed++;

        if (permanent || nextRetries > MAX_QUEUE_RETRIES) {
          recordPermanentFailure(
            { ...item, retries: nextRetries },
            permanent
              ? err?.message || 'This write can never succeed.'
              : `Gave up after ${MAX_QUEUE_RETRIES} retries: ${err?.message || 'unknown error'}`
          );
          removeQueueItem(item.id);
          lost++;
        }
      }
    }
  } finally {
    isSyncing = false;
    notifyListeners();
  }

  return { processed, failed, lost };
}

/* ------------------------------------------------------------ auto-flush --- */

/**
 * The data layer registers `executeQueueItem` here at import time. The queue
 * cannot import firestoreService directly — firestoreService imports this
 * module — so inversion is the only way the queue can drain on its own.
 */
let registeredExecutor: QueueExecutor | null = null;

export function registerQueueExecutor(executor: QueueExecutor) {
  registeredExecutor = executor;
  // A tab that opens online with a stale queue drains without a tap.
  if (getOfflineQueue().length > 0) scheduleAutoFlush(2000);
}

const AUTO_FLUSH_BASE_MS = 15_000;
const AUTO_FLUSH_MAX_MS = 5 * 60_000;

let autoFlushTimer: ReturnType<typeof setTimeout> | null = null;
let autoFlushBackoffMs = AUTO_FLUSH_BASE_MS;

function scheduleAutoFlush(delayMs: number) {
  if (typeof window === 'undefined') return;
  if (!registeredExecutor) return;
  if (autoFlushTimer) return; // one timer, ever
  autoFlushTimer = setTimeout(() => {
    autoFlushTimer = null;
    void runAutoFlush();
  }, Math.max(1000, delayMs));
}

async function runAutoFlush() {
  const executor = registeredExecutor;
  if (!executor) return;

  if (getOfflineQueue().length === 0) {
    autoFlushBackoffMs = AUTO_FLUSH_BASE_MS;
    return; // nothing pending — stop the interval entirely
  }

  if (!isOnline()) {
    // Offline: idle until the 'online' event wakes us, but keep a slow poll
    // for the case where navigator.onLine lies (captive portal, VPN).
    scheduleAutoFlush(AUTO_FLUSH_MAX_MS);
    return;
  }

  if (isSyncing) {
    scheduleAutoFlush(AUTO_FLUSH_BASE_MS);
    return;
  }

  try {
    const { processed, failed } = await flushOfflineQueue(executor);
    if (failed > 0 && processed === 0) {
      autoFlushBackoffMs = Math.min(AUTO_FLUSH_MAX_MS, autoFlushBackoffMs * 2);
    } else {
      autoFlushBackoffMs = AUTO_FLUSH_BASE_MS;
    }
  } catch (err) {
    console.error('Automatic offline queue flush failed:', err);
    autoFlushBackoffMs = Math.min(AUTO_FLUSH_MAX_MS, autoFlushBackoffMs * 2);
  }

  if (getOfflineQueue().length > 0) {
    scheduleAutoFlush(autoFlushBackoffMs);
  } else {
    autoFlushBackoffMs = AUTO_FLUSH_BASE_MS;
  }
}

/** Force an immediate auto-flush attempt (used by the 'online' event). */
export function requestQueueFlush(delayMs = 1000) {
  autoFlushBackoffMs = AUTO_FLUSH_BASE_MS;
  scheduleAutoFlush(delayMs);
}

// Global browser online/offline listeners
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    notifyListeners();
    // Back in coverage: drain without waiting for a component to notice.
    // flushOfflineQueue is re-entrancy guarded, so OfflineBanner's own
    // 'online' handler racing this one cannot double-post anything.
    requestQueueFlush(1000);
  });
  window.addEventListener('offline', () => {
    notifyListeners();
  });
}

/**
 * Client side of the Gemini proxy.
 *
 * Every call goes through our own server so GEMINI_API_KEY stays server-side.
 * Nothing here writes data — a vision read always returns a candidate that the
 * operator confirms, and Ask the Pad is read-only by construction.
 */

import type { AppState } from '../types';
import {
  getPadSummary,
  getSiloDerivedStates,
  calculateJobDesignMetrics,
  formatLbs,
} from './sandRules';
import { getForecast, getShiftReport, getPadAlerts, getWellProgress } from './analytics';
import { getOperationalDate } from './dateUtils';

let availability: boolean | null = null;

/** Is Gemini configured on the server? Cached — the answer can't change at runtime. */
export async function isGeminiAvailable(): Promise<boolean> {
  if (availability !== null) return availability;
  try {
    const res = await fetch('/api/gemini/status');
    if (!res.ok) {
      availability = false;
      return false;
    }
    const data = await res.json();
    availability = Boolean(data?.available);
  } catch {
    availability = false;
  }
  return availability;
}

/* ------------------------------------------------------------ ticket OCR -- */

export interface VisionTicketRead {
  ticketNumber?: string;
  weightLbs?: number;
  productCode?: string;
  sandDescription?: string;
  supplier?: string;
  carrier?: string;
  truck?: string;
  poNumber?: string;
  date?: string;
  driverName?: string;
  confidence: 'high' | 'medium' | 'low';
  notes?: string;
}

/**
 * Read a photographed ticket with Gemini Vision.
 *
 * This is the fallback for the case the barcode ladder genuinely cannot solve:
 * no barcode, or one destroyed by heat, folding or sun. The result is always
 * treated as unconfirmed and routed to the operator.
 */
export async function readTicketFromImage(
  imageBase64: string,
  mimeType = 'image/jpeg'
): Promise<VisionTicketRead> {
  const res = await fetch('/api/gemini/read-ticket', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ imageBase64, mimeType }),
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error || `Ticket read failed (${res.status}).`);
  }

  const data = (await res.json()) as VisionTicketRead;

  // Trust nothing. A model that says "high" on a 4,000 lb load is wrong about
  // something, so we downgrade anything implausible before it reaches the UI.
  if (data.weightLbs && (data.weightLbs < 5000 || data.weightLbs > 120000)) {
    data.confidence = 'low';
    data.notes = [data.notes, `Weight ${formatLbs(data.weightLbs)} is outside a normal load — verify.`]
      .filter(Boolean)
      .join(' ');
  }
  if (!data.ticketNumber) {
    data.confidence = 'low';
  }
  return data;
}

/* ---------------------------------------------------------- ask the pad --- */

/**
 * The snapshot Gemini reasons over.
 *
 * Deliberately NOT the raw ledger. We send figures the deterministic engine
 * already computed, so a model answer can never contradict the pull sheet, and
 * a 700-ticket pad still fits comfortably in one request.
 */
export function buildPadSnapshot(state: AppState) {
  const summary = getPadSummary(state);
  const silos = getSiloDerivedStates(state);
  const forecast = getForecast(state);
  const design = calculateJobDesignMetrics(state);
  const shift = getShiftReport(state);
  const alerts = getPadAlerts(state);
  const wells = getWellProgress(state);

  const round = (n: number) => Math.round(n || 0);

  return {
    asOf: getOperationalDate(),
    pad: {
      name: state.config.padName,
      customer: summary.activeWellCustomerName || state.config.customerName || null,
      lbsPerTruckload: state.config.lbsPerTruckload,
      drawStrategy: state.config.drawStrategy,
      reorderThresholdStages: state.config.reorderThresholdStages,
    },
    nextPull: {
      well: summary.nextWellName,
      stage: summary.nextStageNumber,
    },
    onHand: {
      totalLbs: round(summary.totalPadOnHandLbs),
      totalTons: round(summary.totalPadOnHandLbs / (state.config.lbsPerTon || 2000)),
      bySandType: summary.sandTypeSummaries.map((s) => ({
        sandType: s.sandType,
        lbs: round(s.onHandLbs),
        tons: round(s.onHandTons),
        stagesOfCover: Number(s.stagesLeft.toFixed(2)),
        perStageDesignLbs: round(s.perStageDesignLbs),
        belowReorderThreshold: s.isBelowReorderThreshold,
        nextStageShortfallLbs: round(s.stageShortfallLbs),
      })),
    },
    silos: silos.map((s) => ({
      silo: s.siloNumber,
      name: s.name || null,
      side: s.side,
      sandType: s.sandType,
      onHandLbs: round(s.onHandLbs),
      percentFull: Math.round(s.percentFull),
      status: s.status,
      pullOrderForNextStage: s.runOrder,
      plannedPullLbs: round(s.plannedPullLbs),
      outOfService: s.isOutOfService,
      manuallyPinned: s.manualPriority !== null,
    })),
    forecast: {
      burnLbsPerDay: round(forecast.burnLbsPerDay),
      stagesPerDay: Number(forecast.stagesPerDay.toFixed(2)),
      loadsInPerDay: Number(forecast.loadsPerDay.toFixed(1)),
      loadsPerDayRequiredToKeepUp: Number(forecast.loadsPerDayRequired.toFixed(1)),
      daysOfSandLeft:
        forecast.daysOfSandLeft !== null ? Number(forecast.daysOfSandLeft.toFixed(1)) : null,
      projectedEmptyDate: forecast.projectedEmptyDate,
      stagesRemainingInJob: forecast.stagesRemainingInJob,
      daysToFinishJob:
        forecast.daysToFinishJob !== null ? Number(forecast.daysToFinishJob.toFixed(1)) : null,
      projectedJobFinishDate: forecast.projectedJobFinishDate,
      lbsStillNeededBeyondOnHand: round(forecast.shortfallToFinishLbs),
      loadsStillNeeded: Number(forecast.truckloadsStillNeeded.toFixed(1)),
      burnBasedOnPumpingDays: `${forecast.samplePumpingDays} of the last ${forecast.sampleWindowDays} days`,
      perSandType: forecast.sandTypeRows.map((r) => ({
        sandType: r.sandType,
        onHandLbs: round(r.onHandLbs),
        daysOfCover: r.daysOfCover !== null ? Number(r.daysOfCover.toFixed(1)) : null,
        projectedEmptyDate: r.projectedEmptyDate,
        remainingInDesignLbs: round(r.remainingInDesignLbs),
        loadsStillNeeded: Number((r.truckloadsNeeded || 0).toFixed(1)),
      })),
    },
    jobDesign: design.map((d) => ({
      sandType: d.sandType.name,
      jobDesignTotalLbs: round(d.jobDesignTotalLbs),
      deliveredLbs: round(d.deliveredSoFarLbs),
      pumpedLbs: round(d.pumpedSoFarLbs),
      stillToDeliverLbs: round(d.stillToDeliverLbs),
      loadsStillToDeliver: Number((d.truckloadsStillNeeded || 0).toFixed(1)),
      remainingInDesignLbs: round(d.remainingInDesignLbs),
      crossCheckFlagged: d.hasCrossCheckFlag,
    })),
    wells: wells.map((w) => ({
      name: w.well.name,
      plannedStages: w.planned,
      completedStages: w.completed,
      remainingStages: w.remaining,
      pumpedLbs: round(w.pumpedLbs),
    })),
    today: {
      date: shift.date,
      loadsIn: shift.loadsIn,
      deliveredLbs: round(shift.deliveredLbs),
      stagesPumped: shift.stagesRecorded,
      pumpedLbs: round(shift.pumpedLbs),
      netLbs: round(shift.netLbs),
      suppliers: shift.suppliers,
    },
    alerts: alerts.map((a) => `${a.tone.toUpperCase()}: ${a.message}`),
    counts: {
      deliveryTickets: state.deliveries.filter((d) => !d.deleted).length,
      runRecords: state.runs.filter((r) => !r.deleted).length,
    },
  };
}

export async function askThePad(state: AppState, question: string): Promise<string> {
  const res = await fetch('/api/gemini/ask', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ question, snapshot: buildPadSnapshot(state) }),
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.error || `Question failed (${res.status}).`);
  }
  const data = await res.json();
  return String(data?.answer || '').trim();
}

/** Starter questions shown when the box is empty. */
export const SUGGESTED_QUESTIONS = [
  'How many loads do I need to order today to keep up?',
  'Which sand runs out first, and when?',
  'What is the pull order for the next stage and why?',
  'Are we on track to finish the job with the sand on hand?',
  'What came in and what went downhole today?',
  'Anything wrong with the pad right now?',
];

/**
 * Record run — modal wrapper around the shared allocation form, with the well
 * and stage fixed by the caller.
 */

import { X } from 'lucide-react';
import { useEffect } from 'react';
import RecordRunForm, { RecordRunPayload } from './RecordRunForm';
import { AppState } from '../types';

export interface RecordRunModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  wellId: string;
  stageNumber: number;
  onRecordRun: (records: RecordRunPayload[]) => Promise<void> | void;
  onSuccess?: () => void;
}

export default function RecordRunModal({
  isOpen,
  onClose,
  state,
  wellId,
  stageNumber,
  onRecordRun,
  onSuccess,
}: RecordRunModalProps) {
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const wellObj = state.config.wells.find((w) => w.id === wellId);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="card my-auto max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-xl p-5"
        role="dialog"
        aria-modal="true"
        aria-labelledby="record-run-modal-title"
      >
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow">Record run</div>
            <h2 id="record-run-modal-title" className="text-xl font-medium tracking-tight">
              {wellObj?.name || 'Well'} · stage <span className="num">{stageNumber}</span>
            </h2>
            <p className="text-sm text-muted">
              Log the actual lbs pulled from each can. The totals reconcile against this stage's
              design as you type.
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="btn btn-ghost tap shrink-0 px-2"
          >
            <X className="size-5" />
          </button>
        </div>

        <RecordRunForm
          state={state}
          initialWellId={wellId}
          initialStageNumber={stageNumber}
          fixedTarget={true}
          isModal={true}
          onRecordRun={onRecordRun}
          onCancel={onClose}
          onSuccess={() => {
            if (onSuccess) onSuccess();
            onClose();
          }}
          submitButtonLabel={`Record run — ${wellObj?.name || 'well'} stage ${stageNumber}`}
        />
      </div>
    </div>
  );
}

/**
 * Jobs and well pads manager.
 *
 * Retiring a job ARCHIVES it. The security rules forbid client deletes
 * outright, so nothing on this screen can destroy a customer's ledger: the pad
 * is flagged archived and drops off the list, and every ticket and stage run
 * stays in the database, exportable, and restorable from the console. The
 * dialog still states the counts and still requires the pad's name typed back
 * exactly — archiving a live job mid-frac is disruptive even when it is
 * reversible.
 *
 * Nothing here uses a blocking browser dialog — failures land in an inline
 * banner (and the toast, when the host wires one).
 */

import { useState, useEffect, useMemo, ChangeEvent } from 'react';
import {
  Briefcase,
  Archive,
  Download,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  ArrowRight,
  ShieldAlert,
  UploadCloud,
  RefreshCw,
  X,
} from 'lucide-react';
import {
  PadSummaryInfo,
  listPadsWithDetails,
  archivePad,
  fetchPadFullState,
} from '../lib/firestoreService';
import { restoreUniversity40E, UNIVERSITY_40E_PAD_ID, importJobPackage } from '../lib/importService';
import { downloadPadCSV } from '../lib/exportUtils';
import { cn } from '../lib/theme';
import { AppState } from '../types';
import { JobImportPackage } from '../types/import';

interface JobManagementProps {
  currentPadId: string;
  currentState?: AppState | null;
  onSelectPad: (padId: string) => void;
  onPadListUpdated?: () => void;
  onSuccessMessage?: (msg: string) => void;
  /** Optional host toast. Without it, messages still show in the inline banner. */
  onToast?: (msg: string, tone?: 'ok' | 'warn' | 'danger') => void;
}

export default function JobManagement({
  currentPadId,
  currentState,
  onSelectPad,
  onPadListUpdated,
  onSuccessMessage,
  onToast,
}: JobManagementProps) {
  const [padSummaries, setPadSummaries] = useState<PadSummaryInfo[]>([]);
  const [loading, setLoading] = useState(true);

  // Inline notice — replaces the four native alert() calls this screen used.
  const [notice, setNotice] = useState<{ msg: string; tone: 'ok' | 'warn' | 'danger' } | null>(null);

  const [isRestoring, setIsRestoring] = useState(false);
  const [restoreProgressText, setRestoreProgressText] = useState('');
  const [restoreProgressPct, setRestoreProgressPct] = useState(0);

  const [padToDelete, setPadToDelete] = useState<PadSummaryInfo | null>(null);
  const [confirmNameInput, setConfirmNameInput] = useState('');
  const [isDeleting, setIsDeleting] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [exportDone, setExportDone] = useState(false);

  const announce = (msg: string, tone: 'ok' | 'warn' | 'danger' = 'ok') => {
    setNotice({ msg, tone });
    if (onToast) onToast(msg, tone);
    if (tone === 'ok' && onSuccessMessage) onSuccessMessage(msg);
  };

  const fetchSummaries = async () => {
    setLoading(true);
    try {
      const list = await listPadsWithDetails();
      setPadSummaries(list);
    } catch (err) {
      console.error('Error fetching pad details:', err);
      announce('Could not read the pad list from the database.', 'danger');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSummaries();
  }, [currentPadId]);

  const totals = useMemo(
    () => ({
      pads: padSummaries.length,
      deliveries: padSummaries.reduce((sum, p) => sum + (p.deliveryCount || 0), 0),
      runs: padSummaries.reduce((sum, p) => sum + (p.runCount || 0), 0),
    }),
    [padSummaries]
  );

  const handleRestoreUniversity40E = async () => {
    setIsRestoring(true);
    setNotice(null);
    setRestoreProgressText('Preparing staged records');
    setRestoreProgressPct(5);
    try {
      const result = await restoreUniversity40E((msg, pct) => {
        setRestoreProgressText(msg);
        setRestoreProgressPct(pct);
      });
      announce(
        `Restored University 40E — ${result.deliveriesCount} deliveries and ${result.runsCount} stage runs imported.`
      );
      await fetchSummaries();
      if (onPadListUpdated) onPadListUpdated();
      onSelectPad(UNIVERSITY_40E_PAD_ID);
    } catch (err) {
      console.error('Error restoring University 40E data:', err);
      announce('Could not restore University 40E. Check the connection and try again.', 'danger');
    } finally {
      setIsRestoring(false);
      setRestoreProgressText('');
      setRestoreProgressPct(0);
    }
  };

  const handleImportJsonFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setNotice(null);
    try {
      const text = await file.text();
      const pkg = JSON.parse(text) as JobImportPackage;
      if (!pkg.config || !pkg.deliveries || !pkg.runs) {
        announce(
          'That file is not a job package — it needs config, deliveries and runs at the top level.',
          'danger'
        );
        e.target.value = '';
        return;
      }

      setIsRestoring(true);
      const result = await importJobPackage(pkg, (msg, pct) => {
        setRestoreProgressText(msg);
        setRestoreProgressPct(pct);
      });

      announce(
        `Imported "${pkg.config.padName}" — ${result.deliveriesCount} deliveries and ${result.runsCount} runs.`
      );
      await fetchSummaries();
      if (onPadListUpdated) onPadListUpdated();
      onSelectPad(result.padId);
    } catch (err) {
      console.error('Error parsing or importing JSON package:', err);
      announce('Could not import that file. It is not valid JSON or the shape is wrong.', 'danger');
    } finally {
      setIsRestoring(false);
      setRestoreProgressText('');
      setRestoreProgressPct(0);
      e.target.value = '';
    }
  };

  const openDeleteModal = (pad: PadSummaryInfo) => {
    setPadToDelete(pad);
    setConfirmNameInput('');
    setExportDone(false);
  };

  const closeDeleteModal = () => {
    if (isDeleting) return;
    setPadToDelete(null);
    setConfirmNameInput('');
    setExportDone(false);
  };

  const handleExportBeforeDelete = async () => {
    if (!padToDelete) return;
    setIsExporting(true);
    try {
      let stateToExport: AppState | null = null;
      if (currentState && currentState.padId === padToDelete.id) {
        stateToExport = currentState;
      } else {
        stateToExport = await fetchPadFullState(padToDelete.id);
      }
      if (!stateToExport) {
        announce(`Could not read "${padToDelete.name}" for export.`, 'danger');
        return;
      }
      downloadPadCSV(stateToExport);
      setExportDone(true);
      announce(`CSV exported for "${padToDelete.name}".`);
    } catch (err) {
      console.error('Failed to export pad before delete:', err);
      announce('Export failed. Nothing has been deleted.', 'danger');
    } finally {
      setIsExporting(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!padToDelete) return;
    if (confirmNameInput.trim() !== padToDelete.name.trim()) return;

    const isCurrentActive = padToDelete.id === currentPadId;
    setIsDeleting(true);
    try {
      const result = await archivePad(padToDelete.id);
      announce(
        `Archived "${padToDelete.name}" — ${result.deliveryCount.toLocaleString()} tickets and ${result.runCount.toLocaleString()} stage runs were retained, not deleted.`,
        'warn'
      );
      closeDeleteModal();
      await fetchSummaries();
      if (onPadListUpdated) onPadListUpdated();
      if (isCurrentActive) onSelectPad('');
    } catch (err) {
      console.error('Error archiving pad:', err);
      announce('Archive failed. The pad is unchanged — check the connection.', 'danger');
    } finally {
      setIsDeleting(false);
    }
  };

  const isNameMatch = padToDelete
    ? confirmNameInput.trim() === padToDelete.name.trim()
    : false;

  return (
    <div className="card flex flex-col gap-5">
      {/* ------------------------------------------------- header --- */}
      <div className="card-hd mb-0">
        <div className="flex min-w-0 items-start gap-3">
          <Briefcase className="mt-0.5 size-5 shrink-0 text-accent" />
          <div className="min-w-0">
            <div className="eyebrow">Jobs and well pads</div>
            <h3 className="text-lg font-medium tracking-tight">Pad manager</h3>
            <p className="text-sm text-muted">
              Counts are live subcollection sizes, not cached. Switch the active job, import a
              backup, or archive a finished one — archiving keeps every record.
            </p>
          </div>
        </div>

        <button type="button" onClick={fetchSummaries} className="btn tap shrink-0">
          <RefreshCw className={cn('size-4', loading && 'animate-spin')} />
          {loading ? 'Refreshing' : 'Refresh counts'}
        </button>
      </div>

      {notice && (
        <div
          className={cn(
            'flex items-start justify-between gap-3 rounded-md bg-elevated p-3',
            notice.tone === 'danger'
              ? 'ring-danger-1'
              : notice.tone === 'warn'
                ? 'ring-warn-1'
                : 'ring-accent-1'
          )}
        >
          <div className="flex items-start gap-2">
            {notice.tone === 'ok' ? (
              <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-ok" />
            ) : (
              <AlertTriangle
                className={cn(
                  'mt-0.5 size-4 shrink-0',
                  notice.tone === 'danger' ? 'text-danger' : 'text-warn'
                )}
              />
            )}
            <span className="text-sm text-fg">{notice.msg}</span>
          </div>
          <button
            type="button"
            onClick={() => setNotice(null)}
            className="btn btn-ghost tap shrink-0 px-2"
            aria-label="Dismiss"
          >
            <X className="size-4" />
          </button>
        </div>
      )}

      {/* --------------------------------------------- pad table --- */}
      {loading && padSummaries.length === 0 ? (
        <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted">
          <Loader2 className="size-4 animate-spin text-accent" />
          Loading pad records and database counts.
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead>
              <tr>
                <th>Job / pad</th>
                <th>Status</th>
                <th className="n">Tickets</th>
                <th className="n">Runs</th>
                <th className="n">Actions</th>
              </tr>
            </thead>
            <tbody>
              {padSummaries.map((pad) => {
                const isActive = pad.id === currentPadId;
                return (
                  <tr key={pad.id}>
                    <td>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium">{pad.name}</span>
                        {isActive && <span className="badge badge-accent">Active</span>}
                      </div>
                      <div className="num mt-0.5 text-xs text-subtle">{pad.id}</div>
                    </td>

                    <td>
                      {isActive ? (
                        <span className="badge badge-ok">
                          <CheckCircle2 className="size-3" /> Current job
                        </span>
                      ) : (
                        <button
                          type="button"
                          onClick={() => onSelectPad(pad.id)}
                          className="btn btn-ghost tap"
                        >
                          Switch <ArrowRight className="size-3.5" />
                        </button>
                      )}
                    </td>

                    <td className="n">{pad.deliveryCount.toLocaleString()}</td>
                    <td className="n">{pad.runCount.toLocaleString()}</td>

                    <td className="n">
                      <button
                        type="button"
                        onClick={() => openDeleteModal(pad)}
                        className="btn btn-danger tap"
                      >
                        <Archive className="size-3.5" /> Archive
                      </button>
                    </td>
                  </tr>
                );
              })}

              {padSummaries.length === 0 && (
                <tr>
                  <td colSpan={5} className="text-subtle">
                    No well pads registered in the database yet.
                  </td>
                </tr>
              )}
            </tbody>
            {padSummaries.length > 0 && (
              <tfoot>
                <tr>
                  <td colSpan={2} className="eyebrow">
                    <span className="num">{totals.pads}</span> pad{totals.pads === 1 ? '' : 's'}
                  </td>
                  <td className="n text-muted">{totals.deliveries.toLocaleString()}</td>
                  <td className="n text-muted">{totals.runs.toLocaleString()}</td>
                  <td />
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      )}

      {/* --------------------------------------- restore and import --- */}
      <div className="border-t border-border pt-5">
        <div className="eyebrow mb-3 flex items-center gap-2">
          <UploadCloud className="size-4 text-accent" /> Restore and import pad data
        </div>

        <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
          {/* one-click restore */}
          <div className="flex flex-col justify-between gap-3 rounded-md bg-elevated p-3 ring-accent-1">
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="eyebrow text-accent">Restore University 40E</span>
                <span className="badge badge-accent">
                  <span className="num">688</span> tickets · <span className="num">184</span> runs
                </span>
              </div>
              <p className="mt-1.5 text-sm text-muted">
                Rebuilds the whole job — wells 1803WB and 1803WC, silos 1 through 6, 100 mesh and
                40/70, and every logged ticket and stage pull.
              </p>
            </div>

            {isRestoring && restoreProgressText && (
              <div className="rounded-sm bg-surface p-2.5">
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="text-fg">{restoreProgressText}</span>
                  <span className="num text-muted">{restoreProgressPct}%</span>
                </div>
                <div className="meter mt-1.5">
                  <span style={{ width: `${restoreProgressPct}%` }} />
                </div>
              </div>
            )}

            <button
              type="button"
              onClick={handleRestoreUniversity40E}
              disabled={isRestoring}
              className="btn btn-accent tap w-full"
            >
              {isRestoring ? (
                <>
                  <Loader2 className="size-4 animate-spin" /> Writing records
                </>
              ) : (
                <>
                  <RefreshCw className="size-4" /> One-click restore
                </>
              )}
            </button>
          </div>

          {/* JSON import */}
          <div className="flex flex-col justify-between gap-3 rounded-md bg-elevated p-3 ring-border">
            <div>
              <span className="eyebrow">Import backup package (JSON)</span>
              <p className="mt-1.5 text-sm text-muted">
                Any exported job package restores as a new pad — config, wells, sand types and the
                full delivery history.
              </p>
            </div>

            <label
              className={cn(
                'btn tap w-full',
                isRestoring ? 'pointer-events-none opacity-45' : 'cursor-pointer'
              )}
            >
              <UploadCloud className="size-4" />
              <span>Select .json backup</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportJsonFile}
                disabled={isRestoring}
                className="hidden"
              />
            </label>
          </div>
        </div>
      </div>

      {/* ------------------------------------------- delete dialog --- */}
      {padToDelete && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
          aria-labelledby="delete-pad-title"
        >
          <div className="card my-auto max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-xl p-5 ring-danger-1">
            <div className="card-hd">
              <div className="flex min-w-0 items-start gap-3">
                <ShieldAlert className="mt-0.5 size-5 shrink-0 text-danger" />
                <div className="min-w-0">
                  <div className="eyebrow text-danger">Take this job off the board</div>
                  <h3 id="delete-pad-title" className="text-xl font-medium tracking-tight">
                    Archive job
                  </h3>
                  <p className="text-sm text-muted">
                    The pad drops off the job list and stops accepting writes. Every delivery
                    ticket, stage run and audit record under it is <strong>retained</strong> — this
                    is reversible, and nothing is deleted from the database.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={closeDeleteModal}
                disabled={isDeleting}
                className="btn btn-ghost tap shrink-0 px-2"
                aria-label="Close"
              >
                <X className="size-5" />
              </button>
            </div>

            <div className="flex flex-col gap-4">
              <div className="rounded-md bg-elevated p-3 ring-danger-1">
                <div className="eyebrow">You are about to archive</div>
                <div className="mt-1 text-base font-medium">{padToDelete.name}</div>

                <div className="mt-3 grid grid-cols-2 gap-2">
                  <div className="rounded-sm bg-surface p-2 text-center">
                    <div className="eyebrow">Delivery tickets kept</div>
                    <div className="num mt-0.5 text-lg font-semibold">
                      {padToDelete.deliveryCount.toLocaleString()}
                    </div>
                  </div>
                  <div className="rounded-sm bg-surface p-2 text-center">
                    <div className="eyebrow">Stage runs kept</div>
                    <div className="num mt-0.5 text-lg font-semibold">
                      {padToDelete.runCount.toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>

              {/* export first */}
              <div className="flex flex-col items-stretch justify-between gap-2 rounded-md bg-elevated p-3 ring-border sm:flex-row sm:items-center">
                <div>
                  <div className="eyebrow">Take a local copy anyway</div>
                  <p className="text-sm text-muted">Full CSV of this pad, on this device.</p>
                </div>
                <button
                  type="button"
                  onClick={handleExportBeforeDelete}
                  disabled={isExporting}
                  className="btn tap shrink-0"
                >
                  {isExporting ? (
                    <>
                      <Loader2 className="size-4 animate-spin" /> Exporting
                    </>
                  ) : exportDone ? (
                    <>
                      <CheckCircle2 className="size-4 text-ok" /> Exported
                    </>
                  ) : (
                    <>
                      <Download className="size-4" /> Download CSV
                    </>
                  )}
                </button>
              </div>

              <label className="block">
                <span className="eyebrow">
                  Type the pad name to confirm: {padToDelete.name}
                </span>
                <input
                  type="text"
                  value={confirmNameInput}
                  onChange={(e) => setConfirmNameInput(e.target.value)}
                  placeholder={padToDelete.name}
                  disabled={isDeleting}
                  className={cn('input mt-1', confirmNameInput && !isNameMatch && 'ring-danger-1')}
                />
              </label>

              <div className="flex flex-col-reverse items-stretch justify-end gap-2 sm:flex-row sm:items-center">
                <button
                  type="button"
                  onClick={closeDeleteModal}
                  disabled={isDeleting}
                  className="btn tap"
                >
                  Cancel
                </button>

                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  disabled={!isNameMatch || isDeleting}
                  className="btn btn-danger tap"
                >
                  {isDeleting ? (
                    <>
                      <Loader2 className="size-4 animate-spin" /> Archiving job
                    </>
                  ) : (
                    <>
                      <Archive className="size-4" /> Archive job
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

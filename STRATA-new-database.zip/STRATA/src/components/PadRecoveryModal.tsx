/**
 * Well and sand data recovery.
 *
 * Four ways back from a lost or mangled pad config, in the order they are
 * usually needed:
 *
 *  1. Auto-reconstruct — the tickets and runs are the real record of what was
 *     on this pad, so the config can be rebuilt from them.
 *  2. Quick editor — type the wells and sand types back in as plain text.
 *  3. All database pads — the data may simply be sitting under another pad id.
 *  4. Device backups — snapshots this browser wrote on previous setup saves.
 *
 * Every path writes through `savePadConfig`, so a restore is a normal config
 * save with the normal local backup behind it.
 */

import { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Database,
  RotateCcw,
  Sparkles,
  Layers,
  HardDrive,
  ArrowRight,
  X,
} from 'lucide-react';
import { AppState, PadConfig, WellConfig, SandTypeSpec } from '../types';
import {
  reconstructPadConfigFromHistory,
  getAllLocalPadBackups,
  savePadConfig,
  listPadsWithDetails,
  PadSummaryInfo,
} from '../lib/firestoreService';
import { cn, sandClasses } from '../lib/theme';

export interface LocalBackupItem {
  name: string;
  customer?: string;
  savedAt: number;
  wells: string[];
  sandTypes: string[];
  config: PadConfig;
}

type SubTab = 'auto_reconstruct' | 'manual_quick_fix' | 'all_pads' | 'device_backups';

export interface PadRecoveryModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  onSelectPad?: (padId: string) => void;
}

export default function PadRecoveryModal({
  isOpen,
  onClose,
  state,
  onSelectPad,
}: PadRecoveryModalProps) {
  const { padId, config, deliveries, runs } = state;

  const [activeSubTab, setActiveSubTab] = useState<SubTab>('auto_reconstruct');
  const [isApplying, setIsApplying] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [allPads, setAllPads] = useState<PadSummaryInfo[]>([]);
  const [localBackups, setLocalBackups] = useState<Record<string, LocalBackupItem>>({});

  // Quick manual editor state
  const [quickPadName, setQuickPadName] = useState(config.padName || '');
  const [quickCustomer, setQuickCustomer] = useState(config.customerName || '');
  const [quickWellsText, setQuickWellsText] = useState(
    config.wells.map((w) => `${w.name} (${w.plannedStages} stages)`).join(', ')
  );
  const [quickSandText, setQuickSandText] = useState(config.sandTypes.map((s) => s.name).join(', '));

  useEffect(() => {
    if (isOpen) {
      setLocalBackups(getAllLocalPadBackups());
      listPadsWithDetails().then(setAllPads).catch(console.error);
      setSuccessMessage(null);
      setErrorMessage(null);
      setQuickPadName(config.padName || '');
      setQuickCustomer(config.customerName || '');
      setQuickWellsText(config.wells.map((w) => `${w.name} (${w.plannedStages} stages)`).join(', '));
      setQuickSandText(config.sandTypes.map((s) => s.name).join(', '));
    }
  }, [isOpen, config]);

  /* Reconstruction walks the whole ledger. Keyed on the three slices it reads
     so switching tabs or typing in the quick editor is free. */
  const reconstructedConfig = useMemo(
    () => reconstructPadConfigFromHistory(state),
    [config, deliveries, runs]
  );

  const detected = useMemo(() => {
    const allDeliveriesCount = deliveries.length + (state.deletedDeliveries?.length || 0);
    const allRunsCount = runs.length + (state.deletedRuns?.length || 0);

    const sandInDeliveries = deliveries.map((d) => d.sandType).filter(Boolean);
    const sandInRuns = runs.map((r) => r.sandType).filter(Boolean);
    const allDetectedSand = Array.from(new Set([...sandInDeliveries, ...sandInRuns]));
    const detectedWellIdsInRuns = Array.from(new Set(runs.map((r) => r.wellId).filter(Boolean)));

    return { allDeliveriesCount, allRunsCount, allDetectedSand, detectedWellIdsInRuns };
  }, [deliveries, runs, state.deletedDeliveries, state.deletedRuns]);

  if (!isOpen) return null;

  const applyConfig = async (newConfig: PadConfig, message: string) => {
    setIsApplying(true);
    setErrorMessage(null);
    try {
      await savePadConfig(padId, newConfig);
      setSuccessMessage(message);
      setTimeout(() => {
        onClose();
      }, 1500);
    } catch (err: any) {
      console.error('Recovery write failed:', err);
      setErrorMessage(err?.message || 'Could not write the configuration. Nothing was changed.');
    } finally {
      setIsApplying(false);
    }
  };

  const handleApplyReconstruction = () =>
    applyConfig(
      reconstructedConfig,
      'Configuration rebuilt from the logged delivery and run history.'
    );

  const handleRestoreBackup = (backupConfig: PadConfig) =>
    applyConfig(backupConfig, `Restored the snapshot for ${backupConfig.padName}.`);

  const handleApplyQuickManual = () => {
    const wellParts = quickWellsText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    const parsedWells: WellConfig[] = wellParts.map((raw, idx) => {
      const match = raw.match(/^(.*?)(?:\s*\(([0-9]+)\s*stages?\))?$/i);
      const name = match ? match[1].trim() : raw;
      const stages = match && match[2] ? parseInt(match[2], 10) : 45;
      return {
        id: `w-${idx + 1}`,
        name: name || `Well ${idx + 1}`,
        plannedStages: isNaN(stages) ? 45 : stages,
        customerName: quickCustomer,
      };
    });

    const sandParts = quickSandText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean);

    // Colors cycle through the five identity tones so two sands are never the
    // same color on the board. They stay editable in Setup.
    const colorCats: SandTypeSpec['colorCategory'][] = [
      'amber',
      'blue',
      'emerald',
      'slate',
      'orange',
    ];

    const parsedSandTypes: SandTypeSpec[] = sandParts.map((name, idx) => {
      const existing = config.sandTypes.find(
        (s) => s.name.trim().toLowerCase() === name.toLowerCase()
      );
      return {
        id: existing?.id || `st-${idx + 1}`,
        name,
        perStageDesignLbs: existing?.perStageDesignLbs || 150000,
        jobDesignTotalLbs: existing?.jobDesignTotalLbs || 10000000,
        colorCategory: existing?.colorCategory || colorCats[idx % colorCats.length],
      };
    });

    const updatedSilos = config.silos.map((s, idx) => ({
      ...s,
      sandType:
        parsedSandTypes.length > 0 ? parsedSandTypes[idx % parsedSandTypes.length].name : null,
    }));

    const newConfig: PadConfig = {
      ...config,
      padName: quickPadName.trim() || 'Well Pad',
      customerName: quickCustomer.trim(),
      wells: parsedWells.length > 0 ? parsedWells : config.wells,
      sandTypes: parsedSandTypes.length > 0 ? parsedSandTypes : config.sandTypes,
      silos: updatedSilos,
    };

    return applyConfig(newConfig, 'Pad, wells and sand configuration updated.');
  };

  const TABS: { key: SubTab; label: string; count?: number; icon: typeof Sparkles }[] = [
    {
      key: 'auto_reconstruct',
      label: 'Auto-reconstruct',
      count: detected.allDeliveriesCount,
      icon: Sparkles,
    },
    { key: 'manual_quick_fix', label: 'Quick editor', icon: Layers },
    { key: 'all_pads', label: 'All database pads', count: allPads.length, icon: Database },
    {
      key: 'device_backups',
      label: 'Device backups',
      count: Object.keys(localBackups).length,
      icon: HardDrive,
    },
  ];

  return (
    <div
      id="pad-recovery-modal-overlay"
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="pad-recovery-title"
    >
      <div
        id="pad-recovery-modal-container"
        className="card my-auto flex max-h-[92vh] w-full max-w-4xl flex-col overflow-hidden rounded-xl p-5"
      >
        {/* --------------------------------------------- header --- */}
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow">Data recovery</div>
            <h2 id="pad-recovery-title" className="text-xl font-medium tracking-tight">
              Wells and sand types
            </h2>
            <p className="text-sm text-muted">
              Rebuild the pad config from what the ledger already proves — every ticket and run
              names the silo and sand it moved.
            </p>
          </div>

          <button type="button" onClick={onClose} className="btn btn-ghost tap shrink-0 px-2" aria-label="Close">
            <X className="size-5" />
          </button>
        </div>

        {successMessage && (
          <div className="mb-3 flex items-start gap-2 rounded-md bg-elevated p-3 ring-accent-1">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-ok" />
            <span className="text-sm text-fg">{successMessage}</span>
          </div>
        )}

        {errorMessage && (
          <div className="mb-3 flex items-start gap-2 rounded-md bg-elevated p-3 ring-danger-1">
            <AlertTriangle className="mt-0.5 size-4 shrink-0 text-danger" />
            <span className="text-sm text-fg">{errorMessage}</span>
          </div>
        )}

        {/* ----------------------------------------------- tabs --- */}
        <div className="no-scrollbar -mx-1 mb-4 flex items-center gap-1.5 overflow-x-auto px-1 pb-1">
          {TABS.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeSubTab === tab.key;
            return (
              <button
                key={tab.key}
                type="button"
                onClick={() => setActiveSubTab(tab.key)}
                className={cn(
                  'tap inline-flex h-10 shrink-0 items-center gap-2 rounded-sm px-3 text-sm font-medium transition-colors duration-150',
                  isActive ? 'bg-panel text-fg' : 'bg-elevated text-muted hover:text-fg'
                )}
              >
                <Icon className={cn('size-4', isActive && 'text-accent')} />
                {tab.label}
                {tab.count !== undefined && (
                  <span className="badge">
                    <span className="num">{tab.count}</span>
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* ----------------------------------------------- body --- */}
        <div className="no-scrollbar flex-1 overflow-y-auto">
          {/* ------------------------------------ auto reconstruct --- */}
          {activeSubTab === 'auto_reconstruct' && (
            <div className="flex flex-col gap-4">
              <div className="rounded-md bg-elevated p-3 ring-accent-1">
                <div className="eyebrow text-accent">Discovered from the ledger</div>
                <p className="mt-1 text-sm text-fg">
                  Scanned <span className="num">{deliveries.length}</span> active delivery ticket
                  {deliveries.length === 1 ? '' : 's'} and{' '}
                  <span className="num">{runs.length}</span> stage pull
                  {runs.length === 1 ? '' : 's'} (
                  <span className="num">{detected.allDeliveriesCount}</span> and{' '}
                  <span className="num">{detected.allRunsCount}</span> including deleted). The
                  proposal below is what that history says was on the pad.
                </p>
              </div>

              <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">
                    Detected sand types · <span className="num">{detected.allDetectedSand.length}</span>
                  </div>
                  {detected.allDetectedSand.length > 0 ? (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {detected.allDetectedSand.map((sand) => {
                        const tone = sandClasses(sand, reconstructedConfig.sandTypes);
                        return (
                          <span key={sand} className="badge">
                            <span className={cn('size-2 rounded-full', tone.fill)} />
                            {sand}
                          </span>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="mt-2 text-sm text-subtle">
                      No tickets or runs have been recorded on this pad yet.
                    </p>
                  )}
                </div>

                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">
                    Detected wells in runs ·{' '}
                    <span className="num">{detected.detectedWellIdsInRuns.length}</span>
                  </div>
                  {detected.detectedWellIdsInRuns.length > 0 ? (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {detected.detectedWellIdsInRuns.map((wId) => {
                        const well = config.wells.find((w) => w.id === wId);
                        return (
                          <span key={wId} className="badge badge-accent">
                            {well?.name || wId}
                          </span>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {config.wells.map((w) => (
                        <span key={w.id} className="badge">
                          {w.name} · <span className="num">{w.plannedStages}</span> stages
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="rounded-md bg-elevated p-3 ring-border">
                <div className="eyebrow">Reconstructed silo assignments</div>
                <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-6">
                  {reconstructedConfig.silos.map((silo) => {
                    const tone = sandClasses(silo.sandType, reconstructedConfig.sandTypes);
                    return (
                      <div
                        key={silo.siloNumber}
                        className="rounded-sm bg-surface p-2 text-center ring-border"
                      >
                        <div className="eyebrow">
                          <span className="num">#{silo.siloNumber}</span> · {silo.side}
                        </div>
                        <div className="mt-1 flex items-center justify-center gap-1.5">
                          <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                          <span className="truncate text-xs font-medium">
                            {silo.sandType || <span className="text-subtle">Empty</span>}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  disabled={isApplying}
                  onClick={handleApplyReconstruction}
                  className="btn btn-accent btn-lg tap"
                >
                  <Sparkles className="size-4" />
                  {isApplying ? 'Applying' : 'Apply reconstructed setup'}
                </button>
              </div>
            </div>
          )}

          {/* ------------------------------------------ quick editor --- */}
          {activeSubTab === 'manual_quick_fix' && (
            <div className="flex flex-col gap-4">
              <div className="flex flex-col gap-3 rounded-md bg-elevated p-3 ring-border">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                  <label className="block">
                    <span className="eyebrow">Pad / location name</span>
                    <input
                      type="text"
                      value={quickPadName}
                      onChange={(e) => setQuickPadName(e.target.value)}
                      placeholder="Red Hills Pad 1-4H"
                      className="input mt-1"
                    />
                  </label>

                  <label className="block">
                    <span className="eyebrow">Customer / operator</span>
                    <input
                      type="text"
                      value={quickCustomer}
                      onChange={(e) => setQuickCustomer(e.target.value)}
                      placeholder="Operator name"
                      className="input mt-1"
                    />
                  </label>
                </div>

                <label className="block">
                  <span className="eyebrow">Well names (comma separated)</span>
                  <input
                    type="text"
                    value={quickWellsText}
                    onChange={(e) => setQuickWellsText(e.target.value)}
                    placeholder="Well 1H (45 stages), Well 2H (42 stages)"
                    className="input num mt-1"
                  />
                  <span className="mt-1 block text-xs text-muted">
                    Stage counts in parentheses are parsed; anything without one defaults to 45.
                  </span>
                </label>

                <label className="block">
                  <span className="eyebrow">Sand types on pad (comma separated)</span>
                  <input
                    type="text"
                    value={quickSandText}
                    onChange={(e) => setQuickSandText(e.target.value)}
                    placeholder="100 Mesh, 40/70"
                    className="input num mt-1"
                  />
                  <span className="mt-1 block text-xs text-muted">
                    Sands are dealt round-robin across the existing cans. A name that already
                    exists keeps its design figures and color.
                  </span>
                </label>
              </div>

              <div className="flex justify-end">
                <button
                  type="button"
                  disabled={isApplying}
                  onClick={handleApplyQuickManual}
                  className="btn btn-accent btn-lg tap"
                >
                  <CheckCircle2 className="size-4" />
                  {isApplying ? 'Saving' : 'Save and update pad setup'}
                </button>
              </div>
            </div>
          )}

          {/* --------------------------------------- all database pads --- */}
          {activeSubTab === 'all_pads' && (
            <div className="flex flex-col gap-3">
              <p className="text-sm text-muted">
                Every pad registered in the database. If the history you are missing lives under
                another id, switch to it rather than rebuilding.
              </p>

              <div className="flex flex-col gap-2">
                {allPads.map((pad) => {
                  const isCurrent = pad.id === padId;
                  return (
                    <div
                      key={pad.id}
                      className={cn(
                        'flex flex-col justify-between gap-3 rounded-md bg-elevated p-3 sm:flex-row sm:items-center',
                        isCurrent ? 'ring-accent-1' : 'ring-border'
                      )}
                    >
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium">{pad.name}</span>
                          {isCurrent && <span className="badge badge-accent">Active pad</span>}
                        </div>
                        <div className="num mt-0.5 text-xs text-muted">
                          {pad.id} · {pad.deliveryCount} deliveries · {pad.runCount} runs
                        </div>
                      </div>

                      {!isCurrent && onSelectPad && (
                        <button
                          type="button"
                          onClick={() => {
                            onSelectPad(pad.id);
                            onClose();
                          }}
                          className="btn tap shrink-0"
                        >
                          Switch to this pad <ArrowRight className="size-4" />
                        </button>
                      )}
                    </div>
                  );
                })}

                {allPads.length === 0 && (
                  <div className="rounded-md bg-elevated p-6 text-center text-sm text-subtle ring-border">
                    No other pads found in the database.
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ------------------------------------------ device backups --- */}
          {activeSubTab === 'device_backups' && (
            <div className="flex flex-col gap-3">
              <p className="text-sm text-muted">
                Snapshots this browser wrote on previous setup saves. They live on this device
                only — another tablet will not have them.
              </p>

              {Object.keys(localBackups).length > 0 ? (
                <div className="flex flex-col gap-2">
                  {(Object.entries(localBackups) as [string, LocalBackupItem][]).map(
                    ([bId, bData]) => (
                      <div
                        key={bId}
                        className="flex flex-col justify-between gap-3 rounded-md bg-elevated p-3 ring-border sm:flex-row sm:items-center"
                      >
                        <div className="min-w-0">
                          <div className="font-medium">{bData.name}</div>
                          <div className="mt-0.5 text-xs text-muted">
                            <span className="num">
                              {new Date(bData.savedAt).toLocaleString()}
                            </span>
                            {bData.wells.length > 0 && <> · Wells: {bData.wells.join(', ')}</>}
                            {bData.sandTypes.length > 0 && <> · Sand: {bData.sandTypes.join(', ')}</>}
                          </div>
                        </div>

                        <button
                          type="button"
                          disabled={isApplying}
                          onClick={() => handleRestoreBackup(bData.config)}
                          className="btn tap shrink-0"
                        >
                          <RotateCcw className="size-4" /> Restore snapshot
                        </button>
                      </div>
                    )
                  )}
                </div>
              ) : (
                <div className="rounded-md bg-elevated p-6 text-center text-sm text-subtle ring-border">
                  No local snapshots on this device yet.
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * Weight keypad.
 *
 * A gloved thumb on a tablet mounted in a truck cab cannot reliably hit a
 * 32px key, and the OS numeric keyboard steals half the screen and hides the
 * silo readout the operator is typing against. So weight gets its own pad:
 * 56px keys, mono readout, and the two amounts that are actually typed on a
 * frac pad as one-tap adds.
 *
 * The truckload quick-add reads the pad's CONFIGURED lbsPerTruckload — a pad
 * running 47,000 lb loads must never be offered a 57,000 lb button.
 */

import { Delete, RotateCcw } from 'lucide-react';
import { cn } from '../lib/theme';

export interface NumpadProps {
  /** Current raw digit string. '' and '0' both render as zero. */
  value: string;
  onChange: (newValue: string) => void;
  /**
   * Fired with the amount whenever a quick-add key is tapped, alongside the
   * onChange carrying the new total. Lets a caller log or flash the add
   * without diffing two weights.
   */
  onAddAmount?: (amount: number) => void;
  label?: string;
  /** Pad config lbsPerTruckload. Drives the "1 load" quick-add. */
  lbsPerTruckload: number;
}

const DIGITS = ['7', '8', '9', '4', '5', '6', '1', '2', '3'];

/** 56px minimum — this is sized for a gloved thumb, not a mouse. */
const KEY =
  'tap flex h-14 items-center justify-center rounded-sm bg-elevated text-2xl font-medium ' +
  'text-fg ring-border transition-[background-color,box-shadow] duration-150 ' +
  'ease-[cubic-bezier(0.22,1,0.36,1)] hover:bg-panel active:bg-accent active:text-accent-fg';

export default function Numpad({
  value,
  onChange,
  onAddAmount,
  label,
  lbsPerTruckload,
}: NumpadProps) {
  const current = parseInt(value, 10) || 0;
  const loadLbs = lbsPerTruckload > 0 ? lbsPerTruckload : 57000;

  const handleDigit = (digit: string) => {
    if (!value || value === '0') {
      onChange(digit);
    } else {
      onChange(value + digit);
    }
  };

  const handleBackspace = () => {
    if (value.length <= 1) {
      onChange('0');
    } else {
      onChange(value.slice(0, -1));
    }
  };

  const handleClear = () => onChange('0');

  const handleAddQuick = (amount: number) => {
    onChange((current + amount).toString());
    onAddAmount?.(amount);
  };

  return (
    <div className="card-flush select-none space-y-3 p-3">
      {label ? <div className="eyebrow">{label}</div> : null}

      {/* Readout */}
      <div className="rounded-sm bg-elevated px-3 py-2.5 text-right ring-border">
        <span className="num text-3xl font-semibold tracking-tight text-fg">
          {current.toLocaleString()}
        </span>
        <span className="ml-1.5 text-xs text-muted">lbs</span>
        <div className="num mt-0.5 text-xs text-muted">
          {(current / 2000).toFixed(2)} t · {(current / loadLbs).toFixed(2)} loads
        </div>
      </div>

      {/* Quick adds — the two amounts a coordinator actually types. */}
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => handleAddQuick(10000)}
          className="btn"
        >
          <span className="num">+10,000</span>
          <span className="text-muted">lbs</span>
        </button>
        <button
          type="button"
          onClick={() => handleAddQuick(loadLbs)}
          className="btn"
        >
          <span className="num">+{loadLbs.toLocaleString()}</span>
          <span className="text-muted">1 load</span>
        </button>
      </div>

      {/* Keys */}
      <div className="grid grid-cols-3 gap-2">
        {DIGITS.map((digit) => (
          <button
            key={digit}
            type="button"
            onClick={() => handleDigit(digit)}
            className={cn(KEY, 'num')}
          >
            {digit}
          </button>
        ))}

        <button
          type="button"
          onClick={handleClear}
          className={cn(
            KEY,
            'flex-col gap-0.5 text-[11px] uppercase tracking-wider text-danger active:bg-danger active:text-bg'
          )}
        >
          <RotateCcw className="size-5" />
          Clear
        </button>

        <button
          type="button"
          onClick={() => handleDigit('0')}
          className={cn(KEY, 'num')}
        >
          0
        </button>

        <button
          type="button"
          onClick={handleBackspace}
          className={cn(
            KEY,
            'flex-col gap-0.5 text-[11px] uppercase tracking-wider text-muted'
          )}
        >
          <Delete className="size-5" />
          Delete
        </button>
      </div>
    </div>
  );
}

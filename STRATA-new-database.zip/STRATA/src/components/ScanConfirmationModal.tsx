/**
 * Scan confirmation.
 *
 * A barcode read is a suggestion, never a save. This dialog shows what the
 * parser extracted, which parser produced it and how confident it is, keeps
 * the raw payload visible for the cases where a PO code got read instead of a
 * ticket number, and lets the operator correct the two fields that matter
 * (ticket number and net weight) before anything is applied.
 */

import { AlertTriangle, Check, Camera, X, HelpCircle, Layers } from 'lucide-react';
import { useState } from 'react';
import { ParsedTicketScan, normalizeTicketNumber, validateTicketFields } from '../lib/ticketUtils';
import { cn } from '../lib/theme';

interface ScanConfirmationModalProps {
  parsed: ParsedTicketScan;
  candidates?: ParsedTicketScan[];
  onConfirm: (confirmed: ParsedTicketScan) => void;
  onEdit: (current: ParsedTicketScan) => void;
  onRescan: () => void;
  onCancel: () => void;
}

const PARSER_LABEL: Record<string, string> = {
  atlas: 'Atlas 6-part',
  'atlas-partial': 'Atlas partial',
  known_supplier: 'Known supplier',
  generic_labeled: 'Labeled fields',
  unknown: 'Unrecognized',
};

export default function ScanConfirmationModal({
  parsed: initialParsed,
  candidates = [],
  onConfirm,
  onEdit,
  onRescan,
  onCancel,
}: ScanConfirmationModalProps) {
  const [selectedCandidate, setSelectedCandidate] = useState<ParsedTicketScan>(initialParsed);
  const [ticketInput, setTicketInput] = useState(selectedCandidate.ticketNumber || '');
  const [weightInput, setWeightInput] = useState(
    selectedCandidate.weightLbs ? String(selectedCandidate.weightLbs) : ''
  );

  const isMultipleCodes = candidates.length > 1;

  const currentParsed: ParsedTicketScan = {
    ...selectedCandidate,
    ticketNumber: ticketInput ? normalizeTicketNumber(ticketInput) : undefined,
    weightLbs: weightInput ? parseInt(weightInput.replace(/\D/g, ''), 10) : undefined,
  };

  const validation = validateTicketFields({
    ticketNumber: currentParsed.ticketNumber,
    weightLbs: currentParsed.weightLbs,
  });

  const handleSelectCandidate = (cand: ParsedTicketScan) => {
    setSelectedCandidate(cand);
    setTicketInput(cand.ticketNumber || '');
    setWeightInput(cand.weightLbs ? String(cand.weightLbs) : '');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="scan-confirm-title"
    >
      <div className="card my-auto max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-xl p-5 ring-accent-1">
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow">
              {isMultipleCodes ? 'Several codes in frame' : 'Scanned ticket'}
            </div>
            <h2 id="scan-confirm-title" className="flex items-center gap-2 text-xl font-medium tracking-tight">
              {isMultipleCodes ? <Layers className="size-5 text-accent" /> : null}
              {isMultipleCodes ? 'Pick the right code' : 'Confirm before applying'}
            </h2>
            <p className="text-sm text-muted">
              {selectedCandidate.confidence === 'confirmed'
                ? 'Parsed with high confidence — check the two numbers and apply.'
                : 'Low confidence read. Confirm the ticket number and weight against the paper.'}
            </p>
          </div>
          <button type="button" onClick={onCancel} className="btn btn-ghost tap shrink-0 px-2" aria-label="Cancel">
            <X className="size-5" />
          </button>
        </div>

        <div className="flex flex-col gap-4">
          {/* ------------------------------------ candidate selector --- */}
          {isMultipleCodes && (
            <div>
              <div className="eyebrow">Select the correct ticket code</div>
              <div className="no-scrollbar mt-2 flex max-h-52 flex-col gap-2 overflow-y-auto">
                {candidates.map((cand, idx) => {
                  const isSelected =
                    normalizeTicketNumber(cand.ticketNumber || '') ===
                      normalizeTicketNumber(selectedCandidate.ticketNumber || '') &&
                    cand.rawValue === selectedCandidate.rawValue;

                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectCandidate(cand)}
                      className={cn(
                        'tap flex w-full items-center justify-between gap-2.5 rounded-sm bg-elevated p-3 text-left transition-[box-shadow] duration-150',
                        isSelected ? 'ring-accent-1' : 'ring-border hover:shadow-[var(--shadow-border-hover)]'
                      )}
                    >
                      <div className="min-w-0">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="num text-sm font-semibold text-fg">
                            {cand.ticketNumber ? `#${cand.ticketNumber}` : 'No ticket number'}
                          </span>
                          <span
                            className={cn(
                              'badge',
                              cand.confidence === 'confirmed'
                                ? 'badge-ok'
                                : cand.confidence === 'probable'
                                  ? 'badge-warn'
                                  : 'badge'
                            )}
                          >
                            {PARSER_LABEL[cand.parser || 'unknown'] || cand.confidence}
                          </span>
                        </div>
                        <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted">
                          {cand.weightLbs ? (
                            <span className="num text-fg">{cand.weightLbs.toLocaleString()} lbs</span>
                          ) : null}
                          {cand.matchedSandType && <span>{cand.matchedSandType}</span>}
                          {cand.poNumber && <span>PO {cand.poNumber}</span>}
                        </div>
                      </div>
                      {isSelected && <Check className="size-5 shrink-0 text-accent" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* -------------------------------------------- warnings --- */}
          {validation.warnings.length > 0 && (
            <div className="rounded-md bg-elevated p-3 ring-warn-1">
              <div className="flex items-center gap-2">
                <AlertTriangle className="size-4 shrink-0 text-warn" />
                <span className="eyebrow text-warn">Plausibility notice</span>
              </div>
              <div className="mt-1 flex flex-col gap-1">
                {validation.warnings.map((w, i) => (
                  <p key={i} className="text-sm text-fg">
                    {w}
                  </p>
                ))}
              </div>
            </div>
          )}

          {/* --------------------------------------- editable fields --- */}
          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="eyebrow">Extracted values</span>
              <span className="badge">
                {PARSER_LABEL[selectedCandidate.parser || 'unknown'] || 'Parser'} ·{' '}
                {selectedCandidate.confidence}
              </span>
            </div>

            <label className="mt-3 block">
              <span className="eyebrow">Ticket number</span>
              <input
                type="text"
                inputMode="numeric"
                value={ticketInput}
                onChange={(e) => setTicketInput(e.target.value)}
                placeholder="M30134835"
                className="input input-lg num mt-1 uppercase"
              />
            </label>

            <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2">
              <label className="block">
                <span className="eyebrow">Net weight (lbs)</span>
                <input
                  type="text"
                  inputMode="numeric"
                  value={weightInput}
                  onChange={(e) => setWeightInput(e.target.value)}
                  placeholder="52380"
                  className="input input-num mt-1"
                />
              </label>

              <div>
                <span className="eyebrow">Sand type / product</span>
                <div className="input mt-1 flex items-center truncate">
                  {selectedCandidate.matchedSandType ||
                    selectedCandidate.productCode ||
                    'None detected'}
                </div>
              </div>
            </div>

            {(selectedCandidate.carrier ||
              selectedCandidate.truck ||
              selectedCandidate.poNumber) && (
              <div className="mt-3 grid grid-cols-3 gap-2 border-t border-border pt-3">
                {selectedCandidate.poNumber && (
                  <div className="min-w-0">
                    <div className="eyebrow">PO</div>
                    <div className="num truncate text-sm">{selectedCandidate.poNumber}</div>
                  </div>
                )}
                {selectedCandidate.truck && (
                  <div className="min-w-0">
                    <div className="eyebrow">Truck</div>
                    <div className="num truncate text-sm">{selectedCandidate.truck}</div>
                  </div>
                )}
                {selectedCandidate.carrier && (
                  <div className="min-w-0">
                    <div className="eyebrow">Carrier</div>
                    <div className="truncate text-sm">{selectedCandidate.carrier}</div>
                  </div>
                )}
              </div>
            )}

            <div className="mt-3 border-t border-border pt-3">
              <div className="eyebrow flex items-center gap-1.5">
                <HelpCircle className="size-3.5" /> Raw scanned payload
              </div>
              <div className="num mt-1 select-all break-all rounded-sm bg-surface p-2 text-xs text-muted">
                {selectedCandidate.rawValue}
              </div>
            </div>
          </div>

          {/* --------------------------------------------- footer --- */}
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            <button type="button" onClick={onRescan} className="btn btn-lg tap w-full">
              <Camera className="size-4" /> Rescan
            </button>

            <button
              type="button"
              onClick={() => onConfirm(currentParsed)}
              disabled={!validation.isValid}
              className="btn btn-accent btn-lg tap w-full"
            >
              <Check className="size-4" /> Apply
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

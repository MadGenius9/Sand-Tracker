/**
 * Stage pull sheet — the document a crew works from.
 *
 * Two renders live in this file and they are deliberately different documents:
 *
 *  1. The SCREEN sheet: dark, interactive, one number in the critical channel.
 *     PULL LBS is the only thing on the page wearing `critical`, and it is the
 *     largest type on the page. Everything else is fg / muted / danger / warn.
 *  2. The PRINT schematic (`print-only`): one landscape page, black ink on
 *     white, sand identity carried by `tone.printHex` because the screen
 *     tokens are overridden to white ground under @media print.
 *
 * All print CSS lives in src/index.css. This file ships none — it only uses
 * the hooks: `stage-pull-sheet`, `print-only`, `screen-only`, `no-print`,
 * `page-break-inside-avoid`, `summary-strip`. No button carries `print-allow`,
 * which is what stops the PRINT SHEET button from printing itself.
 */

import {
  Copy,
  Share2,
  Check,
  AlertTriangle,
  FileText,
  Boxes,
  Layers,
  ArrowLeft,
  ArrowRight,
  Printer,
  MapPin,
  Workflow,
  Lock,
  RotateCcw,
  CheckCircle2,
  History,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import RecordPullConfirmModal from './RecordPullConfirmModal';
import { Wordmark, PrintMark } from './ui/Mark';
import {
  getSiloDerivedStates,
  formatLbs,
  formatLbsNumber,
  getEffectivePerStageDesign,
  sortStageRunsByActualSequence,
  calculateSandTypeTotalOnHand,
  getNextWellAndStage,
} from '../lib/sandRules';
import { sandClasses, cn } from '../lib/theme';
import { AppState } from '../types';

interface StagePullSheetProps {
  state: AppState;
  initialWellId?: string;
  initialStageNumber?: number;
  targetWellId?: string;
  targetStageNumber?: number;
  isPinned?: boolean;
  onSuccessMessage?: (msg: string) => void;
  resetSignal?: number;
  lastRanWellId?: string;
  onRecordRun?: (
    records: any[],
    options?: { clearManualOverrides?: boolean }
  ) => Promise<void> | void;
  onClearAllSiloPriorities?: () => void;
}

export default function StagePullSheet({
  state,
  initialWellId,
  initialStageNumber,
  targetWellId,
  targetStageNumber,
  isPinned = false,
  onSuccessMessage,
  resetSignal,
  lastRanWellId,
  onRecordRun,
  onClearAllSiloPriorities,
}: StagePullSheetProps) {
  const { config, runs, deliveries } = state;
  const lbsPerTon = config.lbsPerTon || 2000;

  const wells = useMemo(
    () =>
      config.wells.length > 0
        ? config.wells
        : [{ id: 'w-1', name: 'Well 1H', plannedStages: 40 }],
    [config.wells]
  );

  // Compute next target from zipper / furthest behind
  const nextTarget = useMemo(() => getNextWellAndStage(state), [config.wells, runs]);
  const fallbackWellId = nextTarget?.wellId || wells[0]?.id || 'w-1';
  const fallbackStageNumber = nextTarget?.stageNumber || 1;

  // Track if the user manually changed well or stage on the pull sheet
  const [isManuallyOverridden, setIsManuallyOverridden] = useState<boolean>(false);
  const [isRecordRunModalOpen, setIsRecordRunModalOpen] = useState<boolean>(false);

  // Selected Well state (initializes from pinned prop or target or getNextWellAndStage)
  const [selectedWellId, setSelectedWellId] = useState<string>(
    initialWellId || targetWellId || fallbackWellId
  );

  // Selected Stage Number state (initializes from pinned prop or target or getNextWellAndStage)
  const [stageNumber, setStageNumber] = useState<number>(
    initialStageNumber || targetStageNumber || fallbackStageNumber
  );

  const activeWell = wells.find((w) => w.id === selectedWellId) || wells[0];

  // Determine default next stage for active well
  const lastRunForWell = useMemo(
    () =>
      (runs || [])
        .filter((r) => !r.deleted && r.wellId === activeWell.id)
        .sort((a, b) => b.stageNumber - a.stageNumber)[0],
    [runs, activeWell.id]
  );

  const defaultStageNumber = lastRunForWell ? lastRunForWell.stageNumber + 1 : 1;

  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [copiedText, setCopiedText] = useState<boolean>(false);

  /* ---------------------------------------------------------------------- */
  /* TARGET RECONCILIATION — four effects, unchanged. Do not touch.         */
  /* ---------------------------------------------------------------------- */

  // 1. Sync state if pinned initial props change (URL parameters)
  useEffect(() => {
    if (isPinned && initialWellId) {
      setSelectedWellId(initialWellId);
      setIsManuallyOverridden(false);
    }
    if (isPinned && initialStageNumber) {
      setStageNumber(initialStageNumber);
      setIsManuallyOverridden(false);
    }
  }, [isPinned, initialWellId, initialStageNumber]);

  // 2. Direct target updates from auto-advance
  useEffect(() => {
    if (targetWellId && targetStageNumber) {
      setSelectedWellId(targetWellId);
      setStageNumber(targetStageNumber);
      setIsManuallyOverridden(false);
    }
  }, [targetWellId, targetStageNumber, resetSignal]);

  // 3. Reset manual override when a run is recorded locally (resetSignal)
  useEffect(() => {
    if (resetSignal && !targetWellId) {
      setIsManuallyOverridden(false);
      const next = getNextWellAndStage(state, lastRanWellId);
      if (next) {
        setSelectedWellId(next.wellId);
        setStageNumber(next.stageNumber);
      }
    }
  }, [resetSignal, lastRanWellId, targetWellId]);

  // 4. When runs land from another phone (state.runs updates in Firestore):
  // Recompute next well and stage to follow along IF not pinned by URL, not manually overridden, and not targeted
  useEffect(() => {
    if (!isPinned && !isManuallyOverridden && !targetWellId) {
      const next = getNextWellAndStage(state);
      if (next) {
        setSelectedWellId(next.wellId);
        setStageNumber(next.stageNumber);
      }
    }
  }, [state.runs, state.config.wells, isPinned, isManuallyOverridden, targetWellId]);

  /* ---------------------------------------------------------------------- */
  /* DERIVED MODEL — every figure below is memoized on the slices it reads.  */
  /* getSiloDerivedStates replays every ticket and run per can and then      */
  /* computes the whole pad's run order; before this it ran on every render, */
  /* including one per keystroke anywhere on the screen.                     */
  /* ---------------------------------------------------------------------- */

  const derivedSilos = useMemo(
    () => getSiloDerivedStates(state, activeWell?.id, stageNumber),
    [config, runs, deliveries, activeWell?.id, stageNumber]
  );

  // Silos that actually pull for this stage, in global run order, each carrying
  // its running per-sand-type total and its post-pull balance.
  const pullItems = useMemo(() => {
    const ordered = derivedSilos
      .filter((s) => s.plannedPullLbs > 0)
      .sort((a, b) => (a.runOrder || 99) - (b.runOrder || 99));

    const runningTotalBySandType = new Map<string, number>();

    return ordered.map((s) => {
      const sType = s.sandType || 'Unassigned';
      const prevSandTotal = runningTotalBySandType.get(sType) || 0;
      const currentSandRunningTotalLbs = prevSandTotal + s.plannedPullLbs;
      runningTotalBySandType.set(sType, currentSandRunningTotalLbs);

      const onHandAfterLbs = Math.max(0, s.onHandLbs - s.plannedPullLbs);
      const runsDry = s.onHandLbs <= s.plannedPullLbs || onHandAfterLbs <= 0;

      return {
        ...s,
        sandTypeLabel: sType,
        runningTotalLbs: currentSandRunningTotalLbs,
        runningTotalTons: currentSandRunningTotalLbs / lbsPerTon,
        plannedPullTons: s.plannedPullLbs / lbsPerTon,
        onHandAfterLbs,
        onHandAfterTons: onHandAfterLbs / lbsPerTon,
        runsDry,
      };
    });
  }, [derivedSilos, lbsPerTon]);

  const stageTotals = useMemo(() => {
    const startingLbs = pullItems.reduce((sum, item) => sum + item.onHandLbs, 0);
    const pullLbs = pullItems.reduce((sum, item) => sum + item.plannedPullLbs, 0);
    const endingLbs = pullItems.reduce((sum, item) => sum + item.onHandAfterLbs, 0);
    return { startingLbs, pullLbs, pullTons: pullLbs / lbsPerTon, endingLbs };
  }, [pullItems, lbsPerTon]);

  // Per-sand-type downhole totals for THIS STAGE, using the per-well design.
  const thisStageSandTotals = useMemo(
    () =>
      config.sandTypes.map((st) => {
        const pulledLbs = pullItems
          .filter((item) => item.sandTypeLabel === st.name)
          .reduce((sum, item) => sum + item.plannedPullLbs, 0);
        return {
          sandType: st.name,
          pulledLbs,
          pulledTons: pulledLbs / lbsPerTon,
          designLbs: getEffectivePerStageDesign(activeWell, st),
        };
      }),
    [config.sandTypes, pullItems, activeWell, lbsPerTon]
  );

  // Runs already logged against this well+stage, so a partially pumped stage
  // reports what is STILL required rather than the full design.
  const alreadyLoggedForThisStage = useMemo(
    () =>
      (runs || []).filter(
        (r) => !r.deleted && r.wellId === activeWell?.id && r.stageNumber === stageNumber
      ),
    [runs, activeWell?.id, stageNumber]
  );

  /* Shortage is remaining-required vs what ONLINE silos actually hold. An
     offline can full of 100 mesh does not cover a 100 mesh shortfall. */
  const shortages = useMemo(
    () =>
      config.sandTypes
        .map((st) => {
          const fullDesign = getEffectivePerStageDesign(activeWell, st);
          const alreadyPumped = alreadyLoggedForThisStage
            .filter((r) => r.sandType === st.name)
            .reduce((sum, r) => sum + (r.lbsPulled || 0), 0);
          const requiredForStage = Math.max(0, fullDesign - alreadyPumped);

          const availableInActiveSilos = config.silos
            .filter((s) => s.sandType === st.name && !s.isOutOfService)
            .reduce((sum, s) => {
              const siloOnHand =
                derivedSilos.find((ds) => ds.siloNumber === s.siloNumber)?.onHandLbs || 0;
              return sum + Math.max(0, siloOnHand);
            }, 0);

          const shortfallLbs = Math.max(0, requiredForStage - availableInActiveSilos);
          return {
            sandType: st.name,
            requiredForStage,
            fullDesign,
            alreadyPumped,
            availableInActiveSilos,
            shortfallLbs,
            shortfallTons: shortfallLbs / lbsPerTon,
          };
        })
        .filter((s) => s.shortfallLbs > 0),
    [config.sandTypes, config.silos, activeWell, alreadyLoggedForThisStage, derivedSilos, lbsPerTon]
  );

  const dryCans = useMemo(() => pullItems.filter((item) => item.runsDry), [pullItems]);

  const hasManualOrder = useMemo(
    () =>
      config.silos.some(
        (s) => s.manualPriority !== null && s.manualPriority !== undefined && !s.isOutOfService
      ),
    [config.silos]
  );

  const pinnedSilos = useMemo(
    () => config.silos.filter((s) => s.manualPriority !== null && s.manualPriority !== undefined),
    [config.silos]
  );

  const postStageBalances = useMemo(
    () =>
      config.sandTypes.map((st) => {
        const currentOnHand = calculateSandTypeTotalOnHand(st.name, state);
        const pulledThisStage = pullItems
          .filter((item) => item.sandTypeLabel === st.name)
          .reduce((sum, item) => sum + item.plannedPullLbs, 0);

        const remainingOnHandLbs = Math.max(0, currentOnHand - pulledThisStage);
        return {
          sandType: st.name,
          remainingOnHandLbs,
          remainingOnHandTons: remainingOnHandLbs / lbsPerTon,
        };
      }),
    [config, runs, deliveries, pullItems, lbsPerTon]
  );

  const totalPostStageOnHandLbs = postStageBalances.reduce(
    (sum, b) => sum + b.remainingOnHandLbs,
    0
  );
  const totalPostStageOnHandTons = totalPostStageOnHandLbs / lbsPerTon;

  /* ------------------------------------------------ previous stage ------ */

  const prevStageNumber = stageNumber > 1 ? stageNumber - 1 : null;

  const prevStageRuns = useMemo(
    () =>
      prevStageNumber
        ? (runs || []).filter(
            (r) => !r.deleted && r.wellId === activeWell?.id && r.stageNumber === prevStageNumber
          )
        : [],
    [runs, activeWell?.id, prevStageNumber]
  );

  const prevStageTotalPulledLbs = prevStageRuns.reduce((sum, r) => sum + (r.lbsPulled || 0), 0);
  const prevStageTotalPulledTons = prevStageTotalPulledLbs / lbsPerTon;

  const prevStageBySandType = useMemo(
    () =>
      config.sandTypes
        .map((st) => {
          const pulledLbs = prevStageRuns
            .filter((r) => r.sandType === st.name)
            .reduce((sum, r) => sum + (r.lbsPulled || 0), 0);
          return { sandType: st.name, pulledLbs, pulledTons: pulledLbs / lbsPerTon };
        })
        .filter((st) => st.pulledLbs > 0),
    [config.sandTypes, prevStageRuns, lbsPerTon]
  );

  /* sortStageRunsByActualSequence walks the run log; it is the previous
     stage's execution chain, so it only changes when those runs change. */
  const prevStageBySilo = useMemo(
    () =>
      sortStageRunsByActualSequence(prevStageRuns).map((r, idx) => ({
        order: r.runSequence || idx + 1,
        siloNumber: r.siloNumber,
        sandType: r.sandType,
        lbsPulled: r.lbsPulled,
        tonsPulled: r.lbsPulled / lbsPerTon,
        date: r.date,
      })),
    [prevStageRuns, lbsPerTon]
  );

  /* ------------------------------------------------------ pad sides ----- */

  /* The schematic is a physical map: Side A down the left, Side B down the
     right, conveyor between them. A pad that never set `side` still gets a
     map — we split the cans in half rather than dropping the diagram. */
  const { sideASilos, sideBSilos } = useMemo(() => {
    let a = derivedSilos.filter((s) => s.side === 'A');
    let b = derivedSilos.filter((s) => s.side === 'B');

    if (a.length === 0 && b.length === 0) {
      const half = Math.ceil(derivedSilos.length / 2);
      a = derivedSilos.slice(0, half);
      b = derivedSilos.slice(half);
    } else if (b.length === 0 && a.length > 1) {
      const half = Math.ceil(a.length / 2);
      b = a.slice(half);
      a = a.slice(0, half);
    }
    return { sideASilos: a, sideBSilos: b };
  }, [derivedSilos]);

  // Stamped once when the sheet mounts — this is the document's generated-on.
  const dateGenerated = useMemo(
    () =>
      new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      }),
    []
  );

  /* --------------------------------------------------------- sharing ---- */

  const getShareableUrl = () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const pathname = typeof window !== 'undefined' ? window.location.pathname : '';
    return `${origin}${pathname}?pad=${encodeURIComponent(state.padId)}&well=${encodeURIComponent(activeWell.id)}&stage=${stageNumber}`;
  };

  const handleCopyLink = async () => {
    const url = getShareableUrl();
    try {
      await navigator.clipboard.writeText(url);
      setCopiedLink(true);
      if (onSuccessMessage) {
        onSuccessMessage(`Pinned link for ${activeWell.name} stage ${stageNumber} copied.`);
      }
      setTimeout(() => setCopiedLink(false), 3000);
    } catch (err) {
      console.error('Failed to copy link:', err);
    }
  };

  /** SMS-safe plaintext. No markup, no emoji — it gets pasted into a text. */
  const generateTextSummary = (): string => {
    let text = `STAGE PULL SHEET\n`;
    text += `Pad: ${config.padName}\n`;
    text += `Well: ${activeWell.name} | Stage #${stageNumber}\n`;
    text += `Date: ${dateGenerated}\n`;
    if (hasManualOrder) {
      text += `NOTICE: Run order was set manually.\n`;
    }
    text += `----------------------------------------\n`;

    if (shortages.length > 0) {
      shortages.forEach((s) => {
        text += `SHORT BY ${formatLbs(s.shortfallLbs)} (${s.shortfallTons.toFixed(1)} T) OF ${s.sandType.toUpperCase()}\n`;
      });
      text += `----------------------------------------\n`;
    }

    text += `PULL TABLE:\n`;
    if (pullItems.length === 0) {
      text += `No sand planned for this stage.\n`;
    } else {
      pullItems.forEach((item, index) => {
        text += `Order #${item.runOrder ?? index + 1} | SILO #${item.siloNumber} (${item.sandTypeLabel})\n`;
        text += `  Starting: ${formatLbs(item.onHandLbs)} lbs\n`;
        text += `  Pull: ${formatLbs(item.plannedPullLbs)} (${item.plannedPullTons.toFixed(1)} T)\n`;
        text += `  Ending: ${formatLbs(item.onHandAfterLbs)} lbs${item.runsDry ? ' — RUNS DRY' : ''}\n\n`;
      });
    }

    text += `----------------------------------------\n`;
    text += `1. THIS STAGE DOWNHOLE:\n`;
    thisStageSandTotals.forEach((st) => {
      text += `  - ${st.sandType}: ${formatLbs(st.pulledLbs)} (${st.pulledTons.toFixed(1)} T)\n`;
    });

    text += `\n2. RUNS DRY - RELOAD AFTER THIS STAGE:\n`;
    if (dryCans.length > 0) {
      dryCans.forEach((c) => {
        text += `  - SILO #${c.siloNumber} (${c.sandTypeLabel})\n`;
      });
    } else {
      text += `  - None\n`;
    }

    text += `\n3. ON LOCATION AFTER THIS STAGE:\n`;
    postStageBalances.forEach((b) => {
      text += `  - ${b.sandType}: ${formatLbs(b.remainingOnHandLbs)} (${b.remainingOnHandTons.toFixed(1)} T)\n`;
    });

    text += `----------------------------------------\n`;
    text += `Pull them in the order shown. Run each silo dry before moving to the next.\n`;
    text += `Link: ${getShareableUrl()}`;

    return text;
  };

  const handleCopyText = async () => {
    const txt = generateTextSummary();
    try {
      await navigator.clipboard.writeText(txt);
      setCopiedText(true);
      if (onSuccessMessage) {
        onSuccessMessage('Pull sheet text copied to clipboard.');
      }
      setTimeout(() => setCopiedText(false), 3000);
    } catch (err) {
      console.error('Failed to copy text:', err);
    }
  };

  /* ------------------------------------------------- screen schematic --- */

  const renderSiloBox = (silo: (typeof derivedSilos)[0], side: 'A' | 'B') => {
    const pullItem = pullItems.find((p) => p.siloNumber === silo.siloNumber);
    const isInRun = Boolean(pullItem && pullItem.plannedPullLbs > 0);
    const pullLbs = pullItem ? pullItem.plannedPullLbs : 0;
    const pullTons = pullLbs / lbsPerTon;
    const onHandAfterLbs = pullItem ? pullItem.onHandAfterLbs : silo.onHandLbs;
    const runsDry = Boolean(pullItem && pullItem.runsDry);
    const runOrder = pullItem ? pullItem.runOrder || pullItems.indexOf(pullItem) + 1 : null;
    const tone = sandClasses(silo.sandType, config.sandTypes);

    const arrow = (
      <div className="flex shrink-0 flex-col items-center gap-1">
        <span className="num flex size-6 items-center justify-center rounded-full bg-accent text-xs font-semibold text-accent-fg">
          {runOrder}
        </span>
        {side === 'A' ? (
          <ArrowRight className="size-4 text-accent" />
        ) : (
          <ArrowLeft className="size-4 text-accent" />
        )}
      </div>
    );

    return (
      <div
        key={silo.siloNumber}
        className="page-break-inside-avoid flex items-center gap-2"
      >
        {side === 'B' && isInRun && arrow}

        <div
          className={cn(
            'flex-1 rounded-md bg-elevated p-3',
            runsDry ? 'ring-danger-1' : isInRun ? 'ring-border' : 'ring-border opacity-60'
          )}
        >
          <div className="flex items-center justify-between gap-2">
            <span className="num text-sm font-semibold">
              {silo.name || `Silo ${silo.siloNumber}`}
            </span>
            <span className={cn('truncate text-xs font-medium', tone.text)}>
              {silo.sandType || <span className="text-subtle">Unassigned</span>}
            </span>
          </div>

          {isInRun ? (
            <>
              <div className="mt-1.5 flex items-baseline justify-between gap-2">
                <span className="num text-xl font-semibold">{formatLbsNumber(pullLbs)}</span>
                <span className="num text-xs text-muted">{pullTons.toFixed(1)} t</span>
              </div>
              <div className="mt-1 flex items-center justify-between text-[11px] text-muted">
                <span className="num">Start {formatLbsNumber(silo.onHandLbs)}</span>
                <span className={cn('num', runsDry ? 'text-danger' : 'text-fg')}>
                  End {formatLbsNumber(onHandAfterLbs)}
                </span>
              </div>
              {runsDry && (
                <div className="mt-1.5 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.04em] text-danger">
                  <AlertTriangle className="size-3.5 shrink-0" /> Runs dry — reload
                </div>
              )}
            </>
          ) : (
            <div className="mt-1.5 flex items-center justify-between text-[11px] text-muted">
              <span className="badge">No pull</span>
              <span className="num">{formatLbsNumber(silo.onHandLbs)} lbs on hand</span>
            </div>
          )}
        </div>

        {side === 'A' && isInRun && arrow}
      </div>
    );
  };

  /* ---------------------------------------------------- print schematic - */

  const renderPrintSiloRow = (silo: (typeof derivedSilos)[0], side: 'A' | 'B') => {
    const pull = pullItems.find((p) => p.siloNumber === silo.siloNumber);
    const isInRun = Boolean(pull && pull.plannedPullLbs > 0);
    const tone = sandClasses(silo.sandType, config.sandTypes);

    const identity = (
      <span className="flex shrink-0 items-center gap-1.5">
        <span className="num text-sm font-semibold">#{silo.siloNumber}</span>
        <span className="text-[10px] font-semibold uppercase" style={{ color: tone.printHex }}>
          {silo.sandType || 'Unassigned'}
        </span>
      </span>
    );

    const figures = isInRun ? (
      <span className="flex items-center gap-1.5">
        <span className="num border border-border px-1 text-[10px] font-semibold">
          RUN #{pull!.runOrder}
        </span>
        <span className="num text-sm font-semibold">
          {formatLbsNumber(pull!.plannedPullLbs)}
          <span className="text-[10px] font-normal"> lbs</span>
        </span>
        {pull!.runsDry ? (
          <span className="border border-border px-1 text-[10px] font-semibold uppercase">
            Dry
          </span>
        ) : (
          <span className="num text-[10px]">End {formatLbsNumber(pull!.onHandAfterLbs)}</span>
        )}
      </span>
    ) : (
      <span className="text-[10px]">
        No pull <span className="num">({formatLbsNumber(silo.onHandLbs)})</span>
      </span>
    );

    return (
      <div
        key={silo.siloNumber}
        className={cn(
          'flex items-center justify-between gap-1.5 border px-1.5 py-1 text-xs',
          isInRun ? 'border-border' : 'border-border/50'
        )}
      >
        {side === 'A' ? identity : figures}
        {side === 'A' ? figures : identity}
      </div>
    );
  };

  /* ====================================================================== */

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 pb-12">
      {/* ================================================================== */}
      {/* PRINT: one landscape page. Black ink, sand identity via printHex.  */}
      {/* ================================================================== */}
      <div className="stage-pull-sheet print-only hidden text-xs">
        {/* header */}
        <div className="mb-1.5 flex items-start justify-between gap-3 border-b-2 border-border pb-1.5">
          <div className="flex items-center gap-2">
            <PrintMark className="size-8 shrink-0" />
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-[0.18em]">STRATA</div>
              <div className="num mt-0.5 flex flex-wrap items-center gap-1.5 text-base font-semibold">
                {(activeWell.customerName || config.customerName) && (
                  <>
                    <span>{activeWell.customerName || config.customerName}</span>
                    <span>·</span>
                  </>
                )}
                <span>{config.padName}</span>
                <span>·</span>
                <span>Well {activeWell.name}</span>
                <span>·</span>
                <span className="border-2 border-border px-1.5 py-0.5 text-lg font-semibold">
                  STAGE #{stageNumber}
                </span>
              </div>
            </div>
          </div>

          <div className="shrink-0 text-right text-[11px] leading-tight">
            <div className="text-sm font-semibold uppercase tracking-[0.08em]">
              Stage pull schematic
            </div>
            <div className="num">Date: {dateGenerated}</div>
            {hasManualOrder && (
              <div className="mt-0.5 inline-block border border-border px-1.5 py-0.5 text-[10px] font-semibold uppercase">
                Manual order
              </div>
            )}
          </div>
        </div>

        {/* shortage callout */}
        {shortages.length > 0 && (
          <div className="page-break-inside-avoid mb-1.5 flex flex-wrap items-center justify-between gap-2 border-2 border-border px-2 py-1">
            <span className="text-xs font-semibold uppercase tracking-[0.08em]">
              Shortage detected
            </span>
            {shortages.map((s) => (
              <span key={s.sandType} className="num text-sm font-semibold">
                Short by {formatLbsNumber(s.shortfallLbs)} lbs ({s.shortfallTons.toFixed(1)} T) of{' '}
                {s.sandType.toUpperCase()}
              </span>
            ))}
          </div>
        )}

        {/* pad layout */}
        <div className="page-break-inside-avoid mb-1.5 border border-border p-1.5">
          <div className="mb-1 flex items-center justify-between border-b border-border pb-0.5 text-[10px] font-semibold uppercase tracking-[0.08em]">
            <span>Side A silos</span>
            <span>Pad schematic &amp; rotation</span>
            <span>Side B silos</span>
          </div>

          <div className="grid grid-cols-11 items-center gap-1.5">
            <div className="col-span-5 flex flex-col gap-1">
              {sideASilos.map((silo) => renderPrintSiloRow(silo, 'A'))}
            </div>

            <div className="col-span-1 flex h-full min-h-[55px] flex-col items-center justify-center border-2 border-border p-1 text-center text-[9px] font-semibold uppercase leading-tight">
              <span>Sand</span>
              <span>Conveyor</span>
              <span className="mt-1 border border-border px-1">Down</span>
            </div>

            <div className="col-span-5 flex flex-col gap-1">
              {sideBSilos.map((silo) => renderPrintSiloRow(silo, 'B'))}
            </div>
          </div>
        </div>

        {/* pull sequence table */}
        <div className="page-break-inside-avoid mb-1.5">
          <div className="mb-0.5 flex items-center justify-between text-[10px] font-semibold uppercase tracking-[0.08em]">
            <span>
              Silo pull sequence ({pullItems.length} silos in rotation)
            </span>
            <span>Tabular field view</span>
          </div>
          <table className="w-full border-collapse border-2 border-border text-left text-xs">
            <thead>
              <tr className="border-b-2 border-border text-[10px] uppercase tracking-[0.06em]">
                <th className="w-12 border-r border-border px-2 py-1 text-center font-semibold">
                  Order
                </th>
                <th className="border-r border-border px-2 py-1 font-semibold">Silo</th>
                <th className="border-r border-border px-2 py-1 font-semibold">Sand type</th>
                <th className="border-r border-border px-2 py-1 text-right font-semibold">
                  Starting (lbs)
                </th>
                <th className="border-r border-border px-2 py-1 text-right font-semibold">
                  Pull (lbs)
                </th>
                <th className="border-r border-border px-2 py-1 text-right font-semibold">
                  Pull (tons)
                </th>
                <th className="px-2 py-1 text-right font-semibold">Ending (lbs)</th>
              </tr>
            </thead>
            <tbody>
              {pullItems.map((item, idx) => {
                const tone = sandClasses(item.sandTypeLabel, config.sandTypes);
                return (
                  <tr key={item.siloNumber} className="border-b border-border">
                    <td className="num border-r border-border px-2 py-1 text-center text-sm font-semibold">
                      #{item.runOrder ?? idx + 1}
                    </td>
                    <td className="num border-r border-border px-2 py-1 text-sm font-semibold">
                      Silo #{item.siloNumber}
                    </td>
                    <td
                      className="border-r border-border px-2 py-1 text-xs font-semibold"
                      style={{ color: tone.printHex }}
                    >
                      {item.sandTypeLabel}
                    </td>
                    <td className="num border-r border-border px-2 py-1 text-right text-sm">
                      {formatLbsNumber(item.onHandLbs)}
                    </td>
                    <td className="num border-r border-border px-2 py-1 text-right text-base font-semibold">
                      {formatLbsNumber(item.plannedPullLbs)}
                      <span className="text-[10px] font-normal"> lbs</span>
                    </td>
                    <td className="num border-r border-border px-2 py-1 text-right text-xs">
                      {item.plannedPullTons.toFixed(1)} t
                    </td>
                    <td className="num px-2 py-1 text-right text-sm font-semibold">
                      {formatLbsNumber(item.onHandAfterLbs)}
                      {item.runsDry ? (
                        <span className="text-[10px] font-semibold uppercase"> · dry</span>
                      ) : (
                        <span className="text-[10px] font-normal"> lbs</span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-border text-xs font-semibold">
                <td
                  colSpan={3}
                  className="border-r border-border px-2 py-1 uppercase tracking-[0.06em]"
                >
                  Total stage pull
                </td>
                <td className="num border-r border-border px-2 py-1 text-right text-sm">
                  {formatLbsNumber(stageTotals.startingLbs)}
                </td>
                <td className="num border-r border-border px-2 py-1 text-right text-lg">
                  {formatLbsNumber(stageTotals.pullLbs)}
                  <span className="text-[10px] font-normal"> lbs</span>
                </td>
                <td className="num border-r border-border px-2 py-1 text-right text-xs">
                  {stageTotals.pullTons.toFixed(1)} t
                </td>
                <td className="num px-2 py-1 text-right text-sm">
                  {formatLbsNumber(stageTotals.endingLbs)} lbs
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* three summary strips */}
        <div className="summary-strip page-break-inside-avoid mb-1.5 grid grid-cols-3 gap-2 border-2 border-border p-2 text-xs">
          <div>
            <div className="mb-1 border-b border-border pb-0.5 text-[11px] font-semibold uppercase tracking-[0.06em]">
              1 · Downhole requirement
            </div>
            <div className="flex flex-col gap-0.5">
              {thisStageSandTotals.map((st) => {
                const tone = sandClasses(st.sandType, config.sandTypes);
                return (
                  <div key={st.sandType} className="num leading-tight">
                    <span style={{ color: tone.printHex }}>{st.sandType}</span>:{' '}
                    <span className="font-semibold">{formatLbsNumber(st.pulledLbs)} lbs</span>{' '}
                    <span className="text-[10px]">({st.pulledTons.toFixed(1)}t)</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div>
            <div className="mb-1 border-b border-border pb-0.5 text-[11px] font-semibold uppercase tracking-[0.06em]">
              2 · Reload after stage
            </div>
            {dryCans.length > 0 ? (
              <div className="flex flex-col gap-0.5">
                <div className="flex flex-wrap gap-1">
                  {dryCans.map((c) => (
                    <span
                      key={c.siloNumber}
                      className="num border-2 border-border px-1 text-[11px] font-semibold"
                    >
                      Silo #{c.siloNumber} ({c.sandTypeLabel})
                    </span>
                  ))}
                </div>
                <div className="text-[10px] font-semibold uppercase tracking-[0.06em]">
                  Requires immediate reload
                </div>
              </div>
            ) : (
              <div className="text-[11px] font-semibold">None — all cans keep a balance</div>
            )}
          </div>

          <div>
            <div className="mb-1 border-b border-border pb-0.5 text-[11px] font-semibold uppercase tracking-[0.06em]">
              3 · On location remaining
            </div>
            <div className="flex flex-col gap-0.5">
              {postStageBalances.map((b) => {
                const tone = sandClasses(b.sandType, config.sandTypes);
                return (
                  <div key={b.sandType} className="num leading-tight">
                    <span style={{ color: tone.printHex }}>{b.sandType}</span>:{' '}
                    <span className="font-semibold">
                      {formatLbsNumber(b.remainingOnHandLbs)} lbs
                    </span>
                  </div>
                );
              })}
              <div className="num mt-0.5 border-t border-border pt-0.5 font-semibold">
                Total pad: {formatLbsNumber(totalPostStageOnHandLbs)} lbs{' '}
                <span className="text-[10px] font-normal">
                  ({totalPostStageOnHandTons.toFixed(1)}t)
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* previous stage strip */}
        {prevStageNumber && (
          <div className="summary-strip page-break-inside-avoid mb-1.5 flex flex-wrap items-center justify-between gap-x-3 gap-y-1 border border-border px-2 py-1 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <span className="num border border-border px-1.5 py-0.5 text-[11px] font-semibold uppercase">
                Prev stage #{prevStageNumber} ({activeWell.name})
              </span>
              {prevStageRuns.length > 0 ? (
                <>
                  <span className="num">
                    Total:{' '}
                    <span className="font-semibold">
                      {formatLbsNumber(prevStageTotalPulledLbs)} lbs
                    </span>{' '}
                    ({prevStageTotalPulledTons.toFixed(1)}t)
                  </span>
                  <span>·</span>
                  <span className="num text-[11px]">
                    {prevStageBySandType
                      .map((st) => `${st.sandType}: ${formatLbsNumber(st.pulledLbs)} lbs`)
                      .join(' | ')}
                  </span>
                </>
              ) : (
                <span className="text-[11px] italic">
                  No recorded run logged for stage #{prevStageNumber} yet
                </span>
              )}
            </div>
            {prevStageRuns.length > 0 && (
              <div className="num text-[11px] font-semibold">
                <span className="font-normal uppercase">Run: </span>
                {prevStageBySilo
                  .map((s) => `#${s.order} S${s.siloNumber} (${formatLbsNumber(s.lbsPulled)})`)
                  .join(' → ')}
              </div>
            )}
          </div>
        )}

        {/* field notes / sign-off */}
        <div className="page-break-inside-avoid mb-1.5 flex min-h-[58px] flex-col justify-between border border-dashed border-border p-2 text-xs">
          <div className="italic">
            Field notes / stage remarks:
            ______________________________________________________________________________________________
          </div>
          <div className="num mt-1 flex items-end justify-between border-t border-border pt-1 text-xs font-semibold">
            <span>Operator sign-off: ___________________________________</span>
            <span>Date / time: ________________________</span>
          </div>
        </div>

        {/* footer instruction */}
        <div className="page-break-inside-avoid border-2 border-border px-3 py-1 text-center text-xs font-semibold uppercase tracking-[0.08em]">
          Pull silos in the order shown. Run each silo dry before switching to the next.
        </div>
      </div>

      {/* ================================================================== */}
      {/* SCREEN                                                             */}
      {/* ================================================================== */}
      <div className="screen-only flex flex-col gap-5">
        {/* ------------------------------------------------- view header --- */}
        <div className="card">
          <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
            <div className="min-w-0">
              <div className="eyebrow flex items-center gap-1.5">
                <FileText className="size-3.5" /> Stage pull sheet
                {(activeWell.customerName || config.customerName) &&
                  ` · ${activeWell.customerName || config.customerName}`}
              </div>
              <h1 className="text-2xl font-medium tracking-tight">{config.padName}</h1>
              <div className="mt-1 flex flex-wrap items-center gap-2">
                <span className="text-base font-medium">{activeWell.name}</span>
                <span className="badge badge-accent">
                  Stage <span className="num">{stageNumber}</span>
                </span>
                {hasManualOrder && (
                  <span className="badge badge-locked">
                    <Lock className="size-3" /> Manual run order
                  </span>
                )}
                {isPinned && <span className="badge">Pinned · read only</span>}
              </div>
              <p className="mt-1 max-w-2xl text-sm text-muted">
                Pull lbs is the per-stage design split across the online cans holding that sand,
                in run order. A can flags RUNS DRY when the pull meets or exceeds what it holds.
                Generated <span className="num">{dateGenerated}</span>.
              </p>
            </div>

            <Wordmark className="shrink-0" subtitle="Sand command" />
          </div>

          {/* ------------------------------------------ well / stage bar --- */}
          {!isPinned && (
            <div className="no-print mt-4 flex flex-col gap-3 border-t border-border pt-4 xl:flex-row xl:items-end xl:justify-between">
              <div className="flex flex-wrap items-end gap-3">
                <label className="min-w-[12rem]">
                  <span className="eyebrow">Well</span>
                  <select
                    value={selectedWellId}
                    onChange={(e) => {
                      setIsManuallyOverridden(true);
                      const newWellId = e.target.value;
                      setSelectedWellId(newWellId);
                      const wObj = wells.find((w) => w.id === newWellId);
                      if (wObj) {
                        const lastR = (state.runs || [])
                          .filter((r) => !r.deleted && r.wellId === wObj.id)
                          .sort((a, b) => b.stageNumber - a.stageNumber)[0];
                        setStageNumber(lastR ? lastR.stageNumber + 1 : 1);
                      }
                    }}
                    className="select mt-1"
                  >
                    {wells.map((w) => (
                      <option key={w.id} value={w.id}>
                        {w.name} ({w.plannedStages} stages)
                      </option>
                    ))}
                  </select>
                </label>

                <label className="w-28">
                  <span className="eyebrow">Stage</span>
                  <input
                    type="number"
                    inputMode="numeric"
                    min={1}
                    max={200}
                    value={stageNumber}
                    onChange={(e) => {
                      setIsManuallyOverridden(true);
                      setStageNumber(Math.max(1, parseInt(e.target.value, 10) || 1));
                    }}
                    className="input input-num mt-1"
                  />
                </label>

                <button
                  type="button"
                  onClick={() => {
                    setIsManuallyOverridden(false);
                    const next = getNextWellAndStage(state);
                    if (next) {
                      setSelectedWellId(next.wellId);
                      setStageNumber(next.stageNumber);
                    } else {
                      setStageNumber(defaultStageNumber);
                    }
                  }}
                  className={cn('btn tap', isManuallyOverridden && 'btn-accent')}
                  title={
                    isManuallyOverridden
                      ? 'Reset to the automatic next well and stage'
                      : 'Jump to the next stage'
                  }
                >
                  {isManuallyOverridden ? (
                    <>
                      <RotateCcw className="size-4" /> Reset to auto
                    </>
                  ) : (
                    <>
                      Auto next ·{' '}
                      <span className="num">
                        {nextTarget
                          ? `${wells.find((w) => w.id === nextTarget.wellId)?.name || 'Well'} #${nextTarget.stageNumber}`
                          : `#${defaultStageNumber}`}
                      </span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {onRecordRun && (
                  <button
                    type="button"
                    onClick={() => setIsRecordRunModalOpen(true)}
                    className="btn btn-accent tap"
                  >
                    <CheckCircle2 className="size-4" /> Record this pull
                  </button>
                )}

                <button type="button" onClick={() => window.print()} className="btn tap">
                  <Printer className="size-4" /> Print sheet
                </button>

                <button type="button" onClick={handleCopyLink} className="btn tap">
                  {copiedLink ? (
                    <>
                      <Check className="size-4 text-ok" /> Link copied
                    </>
                  ) : (
                    <>
                      <Share2 className="size-4" /> Copy pinned link
                    </>
                  )}
                </button>

                <button type="button" onClick={handleCopyText} className="btn tap">
                  {copiedText ? <Check className="size-4 text-ok" /> : <Copy className="size-4" />}
                  Text summary
                </button>
              </div>
            </div>
          )}
        </div>

        {/* ------------------------------------------- manual override --- */}
        {hasManualOrder && (
          <div className="page-break-inside-avoid card flex flex-col gap-3 ring-locked-1 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-start gap-3">
              <Lock className="mt-0.5 size-5 shrink-0 text-locked" />
              <div>
                <div className="eyebrow text-locked">Manual run-order overrides active</div>
                <div className="mt-1 text-sm text-fg">
                  Run sequence is pinned for{' '}
                  <span className="num">
                    {pinnedSilos
                      .map((s) => `Silo #${s.siloNumber} (slot #${s.manualPriority})`)
                      .join(', ')}
                  </span>
                  .
                </div>
              </div>
            </div>

            {onClearAllSiloPriorities && (
              <button
                type="button"
                onClick={onClearAllSiloPriorities}
                className="btn tap shrink-0"
              >
                <RotateCcw className="size-4" /> Reset to auto carousel
              </button>
            )}
          </div>
        )}

        {/* --------------------------------------------- shortage alert --- */}
        {shortages.length > 0 && (
          <div className="page-break-inside-avoid flex flex-col gap-3">
            {shortages.map((s) => (
              <div key={s.sandType} className="card flex items-start gap-3 ring-danger-1">
                <AlertTriangle className="mt-0.5 size-6 shrink-0 text-danger" />
                <div className="min-w-0">
                  <div className="eyebrow text-danger">Stage shortage</div>
                  <div className="num mt-1 text-xl font-semibold text-danger">
                    Short by {formatLbs(s.shortfallLbs)} ({s.shortfallTons.toFixed(1)} tons) of{' '}
                    {s.sandType}
                  </div>
                  <div className="mt-1 text-sm text-muted">
                    This stage still needs{' '}
                    <span className="num">{formatLbs(s.requiredForStage)}</span> and only{' '}
                    <span className="num">{formatLbs(s.availableInActiveSilos)}</span> sits in
                    online silos on location.
                    {s.alreadyPumped > 0 && (
                      <>
                        {' '}
                        <span className="num">{formatLbs(s.alreadyPumped)}</span> of the{' '}
                        <span className="num">{formatLbs(s.fullDesign)}</span> design is already
                        logged.
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* --------------------------------------------- pad schematic --- */}
        <div className="page-break-inside-avoid card">
          <div className="card-hd">
            <div>
              <div className="eyebrow flex items-center gap-1.5">
                <MapPin className="size-3.5" /> Pad layout
              </div>
              <h2 className="text-lg font-medium tracking-tight">Stage schematic</h2>
              <p className="text-sm text-muted">
                Physical silo orientation. Arrows point at the conveyor; the number on the arrow
                is the pull order.
              </p>
            </div>
            <span className="eyebrow-aside">Side A ► ◄ Side B</span>
          </div>

          <div className="grid grid-cols-1 items-center gap-3 md:grid-cols-11">
            <div className="flex flex-col gap-2 md:col-span-5">
              <div className="eyebrow text-center">Side A silos</div>
              {sideASilos.map((silo) => renderSiloBox(silo, 'A'))}
            </div>

            <div className="flex h-full min-h-[140px] flex-col items-center justify-center gap-1.5 rounded-md bg-elevated p-2 text-center ring-border md:col-span-1">
              <Workflow className="size-5 text-accent" />
              <div className="eyebrow">Sand conveyor</div>
              <div className="badge badge-accent">Downhole</div>
            </div>

            <div className="flex flex-col gap-2 md:col-span-5">
              <div className="eyebrow text-center">Side B silos</div>
              {sideBSilos.map((silo) => renderSiloBox(silo, 'B'))}
            </div>
          </div>
        </div>

        {/* ------------------------------------------- pull sequence ----- */}
        <div className="page-break-inside-avoid card-flush">
          <div className="card-hd p-4 pb-0">
            <div>
              <div className="eyebrow flex items-center gap-1.5">
                <Layers className="size-3.5" /> Run order
              </div>
              <h2 className="text-lg font-medium tracking-tight">
                Silo pull sequence ·{' '}
                <span className="num">{pullItems.length}</span>{' '}
                {pullItems.length === 1 ? 'silo' : 'silos'}
              </h2>
              <p className="text-sm text-muted">
                Pull lbs is the number to work from. Run each can dry before moving on.
              </p>
            </div>
          </div>

          {pullItems.length === 0 ? (
            <div className="p-8 text-center">
              <Boxes className="mx-auto mb-2 size-8 text-subtle" />
              <div className="text-base font-medium">No sand planned for this stage</div>
              <p className="mt-1 text-sm text-muted">
                Confirm the stage design or check the stage number.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto p-4 pt-3">
              <table className="tbl">
                <thead>
                  <tr>
                    <th className="text-center">Order</th>
                    <th>Silo</th>
                    <th>Sand</th>
                    <th className="n">Starting lbs</th>
                    <th className="n">Pull lbs</th>
                    <th className="n">Pull tons</th>
                    <th className="n">Ending lbs</th>
                  </tr>
                </thead>
                <tbody>
                  {pullItems.map((item, index) => {
                    const tone = sandClasses(item.sandTypeLabel, config.sandTypes);
                    return (
                      <tr key={item.siloNumber}>
                        <td className="text-center">
                          <span className="num inline-flex size-8 items-center justify-center rounded-full bg-accent text-sm font-semibold text-accent-fg">
                            {item.runOrder ?? index + 1}
                          </span>
                        </td>

                        <td>
                          <div className="num whitespace-nowrap text-base font-semibold">
                            Silo #{item.siloNumber}
                          </div>
                          <div className="eyebrow">Side {item.side}</div>
                        </td>

                        <td>
                          <span
                            className={cn('whitespace-nowrap text-sm font-medium', tone.text)}
                          >
                            {item.sandTypeLabel}
                          </span>
                        </td>

                        <td className="n whitespace-nowrap text-base">
                          {formatLbsNumber(item.onHandLbs)}
                        </td>

                        {/* The number the crew acts on. Only critical on this page. */}
                        <td className="n whitespace-nowrap">
                          <span className="text-3xl font-semibold leading-none text-critical">
                            {formatLbsNumber(item.plannedPullLbs)}
                          </span>
                          <span className="ml-1 text-xs text-muted">lbs</span>
                        </td>

                        <td className="n whitespace-nowrap text-sm text-muted">
                          {item.plannedPullTons.toFixed(1)} t
                        </td>

                        <td className="n whitespace-nowrap">
                          <div
                            className={cn(
                              'text-base font-semibold',
                              item.runsDry ? 'text-danger' : 'text-fg'
                            )}
                          >
                            {formatLbsNumber(item.onHandAfterLbs)}
                            {!item.runsDry && <span className="ml-1 text-xs text-muted">lbs</span>}
                          </div>
                          {item.runsDry && (
                            <div className="mt-0.5 flex items-center justify-end gap-1 text-[11px] font-semibold uppercase tracking-[0.04em] text-danger">
                              <AlertTriangle className="size-3.5" /> Runs dry
                            </div>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>

                <tfoot>
                  <tr>
                    <td colSpan={3} className="eyebrow pt-3">
                      Total stage pull
                    </td>
                    <td className="n pt-3 text-base">
                      {formatLbsNumber(stageTotals.startingLbs)}
                    </td>
                    <td className="n whitespace-nowrap pt-3">
                      <span className="text-2xl font-semibold leading-none text-critical">
                        {formatLbsNumber(stageTotals.pullLbs)}
                      </span>
                      <span className="ml-1 text-xs text-muted">lbs</span>
                    </td>
                    <td className="n pt-3 text-sm text-muted">
                      {stageTotals.pullTons.toFixed(1)} t
                    </td>
                    <td className="n pt-3 text-base font-semibold">
                      {formatLbsNumber(stageTotals.endingLbs)}
                      <span className="ml-1 text-xs text-muted">lbs</span>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          )}
        </div>

        {/* -------------------------------------------- summary strips --- */}
        <div className="summary-strip page-break-inside-avoid card">
          <div className="card-hd">
            <div>
              <div className="eyebrow">Strip 1</div>
              <h2 className="text-lg font-medium tracking-tight">This stage downhole</h2>
            </div>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {thisStageSandTotals.map((st) => {
              const tone = sandClasses(st.sandType, config.sandTypes);
              return (
                <div
                  key={st.sandType}
                  className="flex items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-border"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                      <span className="eyebrow truncate">{st.sandType}</span>
                    </div>
                    <div className="stat-v mt-1">{formatLbsNumber(st.pulledLbs)}</div>
                    <div className="text-xs text-muted">
                      <span className="num">{st.pulledTons.toFixed(1)}</span> tons · design{' '}
                      <span className="num">{formatLbsNumber(st.designLbs)}</span> lbs
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="summary-strip page-break-inside-avoid card">
          <div className="card-hd">
            <div>
              <div className="eyebrow">Strip 2</div>
              <h2 className="text-lg font-medium tracking-tight">Reload after this stage</h2>
            </div>
          </div>

          {dryCans.length > 0 ? (
            <div className="rounded-md bg-danger-dim p-3 ring-danger-1">
              <div className="text-sm font-medium text-danger">
                These cans end at zero and need reloading before the next stage.
              </div>
              <div className="mt-2 flex flex-wrap items-center gap-2">
                {dryCans.map((c) => (
                  <span
                    key={c.siloNumber}
                    className="num inline-flex items-center gap-2 rounded-sm bg-surface px-3 py-2 text-base font-semibold text-danger ring-danger-1"
                  >
                    <AlertTriangle className="size-4 shrink-0" />
                    Silo #{c.siloNumber}
                    <span className="text-xs font-normal text-muted">{c.sandTypeLabel}</span>
                  </span>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 rounded-md bg-elevated p-3 text-sm text-ok ring-border">
              <Check className="size-5 shrink-0" />
              None — every can keeps a balance after this stage.
            </div>
          )}
        </div>

        <div className="summary-strip page-break-inside-avoid card">
          <div className="card-hd">
            <div>
              <div className="eyebrow">Strip 3</div>
              <h2 className="text-lg font-medium tracking-tight">On location after this stage</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {postStageBalances.map((b) => {
              const tone = sandClasses(b.sandType, config.sandTypes);
              return (
                <div key={b.sandType} className="rounded-md bg-elevated p-3 ring-border">
                  <div className="flex items-center gap-1.5">
                    <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                    <span className="eyebrow truncate">{b.sandType} remaining</span>
                  </div>
                  <div className="stat-v mt-1">{formatLbsNumber(b.remainingOnHandLbs)}</div>
                  <div className="text-xs text-muted">
                    <span className="num">{b.remainingOnHandTons.toFixed(1)}</span> tons
                  </div>
                </div>
              );
            })}

            <div className="rounded-md bg-elevated p-3 ring-accent-1">
              <div className="eyebrow">Total pad remaining</div>
              <div className="stat-v mt-1 text-accent">
                {formatLbsNumber(totalPostStageOnHandLbs)}
              </div>
              <div className="text-xs text-muted">
                <span className="num">{totalPostStageOnHandTons.toFixed(1)}</span> tons
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------------------------- previous stage ---- */}
        {prevStageNumber && (
          <div className="summary-strip page-break-inside-avoid card">
            <div className="card-hd">
              <div>
                <div className="eyebrow flex items-center gap-1.5">
                  <History className="size-3.5" /> Prior stage reference
                </div>
                <h2 className="text-lg font-medium tracking-tight">
                  Stage <span className="num">{prevStageNumber}</span> totals · {activeWell.name}
                </h2>
                <p className="text-sm text-muted">
                  Read from the run log, in the order the runs were actually recorded.
                </p>
              </div>
            </div>

            {prevStageRuns.length > 0 ? (
              <div className="flex flex-col gap-3">
                <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <div className="rounded-md bg-elevated p-3 ring-accent-1">
                    <div className="eyebrow">Total previous pull</div>
                    <div className="stat-v mt-1">
                      {formatLbsNumber(prevStageTotalPulledLbs)}
                    </div>
                    <div className="text-xs text-muted">
                      <span className="num">{prevStageTotalPulledTons.toFixed(1)}</span> tons
                    </div>
                  </div>

                  {prevStageBySandType.map((st) => {
                    const tone = sandClasses(st.sandType, config.sandTypes);
                    return (
                      <div key={st.sandType} className="rounded-md bg-elevated p-3 ring-border">
                        <div className="flex items-center gap-1.5">
                          <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                          <span className="eyebrow truncate">{st.sandType} pulled</span>
                        </div>
                        <div className="stat-v mt-1">{formatLbsNumber(st.pulledLbs)}</div>
                        <div className="text-xs text-muted">
                          <span className="num">{st.pulledTons.toFixed(1)}</span> tons
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow">Silo breakdown · stage {prevStageNumber}</div>
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    {prevStageBySilo.map((s) => (
                      <div
                        key={`${s.siloNumber}-${s.sandType}-${s.order}`}
                        className="num flex items-center gap-2 rounded-sm bg-surface px-3 py-2 text-sm ring-border"
                      >
                        <span className="font-semibold text-accent">
                          #{s.order} Silo {s.siloNumber}
                        </span>
                        <span className="text-xs text-muted">{s.sandType}</span>
                        <span className="font-semibold">{formatLbsNumber(s.lbsPulled)} lbs</span>
                        <span className="text-xs text-muted">({s.tonsPulled.toFixed(1)}t)</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <div className="rounded-md bg-elevated p-3 text-sm text-muted ring-border">
                No recorded runs for {activeWell.name} stage{' '}
                <span className="num">{prevStageNumber}</span> in the run log yet.
              </div>
            )}
          </div>
        )}

        {/* --------------------------------------------- record action --- */}
        {!isPinned && onRecordRun && (
          <button
            type="button"
            onClick={() => setIsRecordRunModalOpen(true)}
            className="btn btn-accent btn-xl tap no-print w-full"
          >
            <CheckCircle2 className="size-6" />
            Record run · {activeWell?.name || 'Well'} stage{' '}
            <span className="num">{stageNumber}</span>
            <ArrowRight className="size-5" />
          </button>
        )}

        {/* ------------------------------------------------ field notes --- */}
        <div className="page-break-inside-avoid card">
          <div className="card-hd">
            <div>
              <div className="eyebrow flex items-center gap-1.5">
                <FileText className="size-3.5" /> Paper trail
              </div>
              <h2 className="text-lg font-medium tracking-tight">
                Field notes &amp; operator sign-off
              </h2>
            </div>
          </div>
          <div className="flex min-h-[130px] items-start rounded-md border border-dashed border-border p-4">
            <span className="text-sm text-subtle">
              Handwritten notes, stage deviations, or supervisor sign-off.
            </span>
          </div>
        </div>

        {/* ---------------------------------------------------- footer --- */}
        <div className="page-break-inside-avoid card text-center ring-accent-1">
          <p className="text-base font-medium text-accent">
            Pull them in the order shown. Run each silo dry before moving to the next.
          </p>
        </div>
      </div>

      {/* --------------------------------------------------- record modal --- */}
      {isRecordRunModalOpen && onRecordRun && (
        <RecordPullConfirmModal
          isOpen={isRecordRunModalOpen}
          onClose={() => setIsRecordRunModalOpen(false)}
          state={state}
          wellId={activeWell.id}
          stageNumber={stageNumber}
          onRecordRun={async (records, options) => {
            await onRecordRun(records, options);
          }}
          onSuccess={() => {
            setIsRecordRunModalOpen(false);
            setIsManuallyOverridden(false);
            if (onSuccessMessage) {
              onSuccessMessage(`Stage ${stageNumber} pull logged.`);
            }
            const next = getNextWellAndStage(state, activeWell.id);
            if (next) {
              setSelectedWellId(next.wellId);
              setStageNumber(next.stageNumber);
            }
          }}
        />
      )}
    </div>
  );
}

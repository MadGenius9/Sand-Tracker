/**
 * Analytics layer — derived, time-series and heuristic figures.
 *
 * sandRules.ts is domain truth (what is on hand, what to pull, in what order).
 * This module sits above it and answers the forward-looking questions:
 * how fast are we burning, when do we run out, what happened this shift,
 * where should this truck dump.
 *
 * Nothing here is allowed to disagree with sandRules — every quantity comes
 * from getPadSummary / getSiloDerivedStates / calculateJobDesignMetrics rather
 * than being recomputed. The CSV export and the screens both call these, so
 * the report can never contradict the dashboard.
 */

import type {
  AppState,
  DeliveryTicket,
  RunRecord,
  WellConfig,
} from '../types';
import {
  getPadSummary,
  getSiloDerivedStates,
  getEffectivePerStageDesign,
  calculateJobDesignMetrics,
  isStageComplete,
} from './sandRules';
import { getOperationalDate } from './dateUtils';

/* ---------------------------------------------------------------- series -- */

export interface DailyPoint {
  date: string; // YYYY-MM-DD
  deliveredLbs: number;
  pumpedLbs: number;
  netLbs: number;
  loadsIn: number;
  stagesPumped: number;
}

/**
 * Delivered vs pumped, bucketed by operational date.
 *
 * Pre-seeds every day in the window so a quiet Sunday renders as a zero bar
 * rather than vanishing and compressing the axis.
 */
export function getDailySeries(state: AppState, days = 14, endDate?: string): DailyPoint[] {
  const end = endDate || getOperationalDate();
  const map = new Map<string, DailyPoint>();

  const anchor = new Date(`${end}T12:00:00`);
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(anchor);
    d.setDate(d.getDate() - i);
    const key = d.toISOString().slice(0, 10);
    map.set(key, {
      date: key,
      deliveredLbs: 0,
      pumpedLbs: 0,
      netLbs: 0,
      loadsIn: 0,
      stagesPumped: 0,
    });
  }

  for (const del of state.deliveries) {
    if (del.deleted) continue;
    const row = map.get(del.date);
    if (!row) continue;
    row.deliveredLbs += del.lbs || 0;
    row.loadsIn += 1;
  }

  const stagesByDate = new Map<string, Set<string>>();
  for (const run of state.runs) {
    if (run.deleted) continue;
    const row = map.get(run.date);
    if (!row) continue;
    row.pumpedLbs += run.lbsPulled || 0;
    if (!stagesByDate.has(run.date)) stagesByDate.set(run.date, new Set());
    stagesByDate.get(run.date)!.add(`${run.wellId}:${run.stageNumber}`);
  }

  for (const [date, set] of stagesByDate) {
    const row = map.get(date);
    if (row) row.stagesPumped = set.size;
  }

  const out = Array.from(map.values());
  for (const row of out) row.netLbs = row.deliveredLbs - row.pumpedLbs;
  return out;
}

/* -------------------------------------------------------------- forecast -- */

export interface ForecastSandRow {
  sandType: string;
  onHandLbs: number;
  stagesLeft: number;
  remainingInDesignLbs: number;
  truckloadsNeeded: number;
  isReorder: boolean;
  shortfallLbs: number;
  /** Days until this specific sand type runs out at current burn. */
  daysOfCover: number | null;
  projectedEmptyDate: string | null;
}

export interface ForecastReport {
  onHandLbs: number;
  stagesLeftOnHand: number;
  stagesRemainingInJob: number;
  lbsRemainingInJob: number;
  truckloadsStillNeeded: number;
  burnLbsPerDay: number;
  stagesPerDay: number;
  loadsPerDay: number;
  daysOfSandLeft: number | null;
  projectedEmptyDate: string | null;
  daysToFinishJob: number | null;
  projectedJobFinishDate: string | null;
  shortfallToFinishLbs: number;
  /** Loads per day required to keep up with the burn. The reorder number. */
  loadsPerDayRequired: number;
  /** Are we delivering fast enough? Positive = gaining ground. */
  netLbsPerDay: number;
  sandTypeRows: ForecastSandRow[];
  daily: DailyPoint[];
  /** How many distinct days actually pumped, out of the window. Confidence. */
  samplePumpingDays: number;
  sampleWindowDays: number;
  /**
   * How much weight the burn-derived figures deserve.
   *
   *   none - nothing pumped in the window. There is no rate.
   *   low  - one or two pumping days. That is an observation, not a rate:
   *          a single heavy catch-up day can read as 60 stages/day and put a
   *          "you run out today" banner in front of a coordinator who is fine.
   *   ok   - three or more pumping days.
   *
   * The UI must not present a `low` figure as a hard number. Being wrong about
   * this costs a wrong sand order, which is a six-figure mistake.
   */
  burnConfidence: 'none' | 'low' | 'ok';
}

function addDays(dateStr: string, n: number): string {
  const d = new Date(`${dateStr}T12:00:00`);
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

export function getForecast(state: AppState, windowDays = 14): ForecastReport {
  const summary = getPadSummary(state);
  const design = calculateJobDesignMetrics(state);
  const daily = getDailySeries(state, windowDays);
  const lbsPerTruck = state.config.lbsPerTruckload || 57000;

  // Burn is averaged over days that ACTUALLY PUMPED, not over calendar days.
  // A pad that sat down on Sunday shouldn't report a 14% lower burn rate — we
  // want "how fast do we go when we're going", which is what a reorder
  // decision actually depends on.
  const recent = daily.slice(-7);
  const pumpedDays = recent.filter((d) => d.pumpedLbs > 0);
  const deliveredDays = recent.filter((d) => d.deliveredLbs > 0);

  const burnLbsPerDay = pumpedDays.length
    ? pumpedDays.reduce((s, d) => s + d.pumpedLbs, 0) / pumpedDays.length
    : 0;

  const deliveredLbsPerDay = deliveredDays.length
    ? deliveredDays.reduce((s, d) => s + d.deliveredLbs, 0) / deliveredDays.length
    : 0;
  const loadsPerDay = deliveredLbsPerDay / lbsPerTruck;

  const activeWell = state.config.wells.find((w) => w.id === summary.activeWellId);
  const perStageTotal = state.config.sandTypes.reduce(
    (sum, st) => sum + getEffectivePerStageDesign(activeWell, st),
    0
  );

  // Count remaining stages honestly, stage by stage, rather than trusting a
  // counter that can drift when runs are edited or restored.
  let stagesRemainingInJob = 0;
  for (const w of state.config.wells) {
    const planned = w.plannedStages || 0;
    let completed = 0;
    for (let stg = 1; stg <= planned; stg++) {
      if (isStageComplete(state, w.id, stg)) completed++;
    }
    stagesRemainingInJob += Math.max(0, planned - completed);
  }

  const onHandLbs = summary.totalPadOnHandLbs;
  const lbsRemainingInJob = design.reduce(
    (s, d) => s + Math.max(0, d.remainingInDesignLbs || 0),
    0
  );

  const stagesPerDay =
    perStageTotal > 0 && burnLbsPerDay > 0 ? burnLbsPerDay / perStageTotal : 0;
  const stagesLeftOnHand = perStageTotal > 0 ? onHandLbs / perStageTotal : 0;
  const daysOfSandLeft = burnLbsPerDay > 0 ? onHandLbs / burnLbsPerDay : null;
  const daysToFinishJob = stagesPerDay > 0 ? stagesRemainingInJob / stagesPerDay : null;
  const shortfallToFinishLbs = Math.max(0, lbsRemainingInJob - onHandLbs);
  const loadsPerDayRequired = burnLbsPerDay > 0 ? burnLbsPerDay / lbsPerTruck : 0;

  const today = getOperationalDate();
  const projectedEmptyDate =
    daysOfSandLeft !== null && isFinite(daysOfSandLeft)
      ? addDays(today, Math.floor(daysOfSandLeft))
      : null;
  const projectedJobFinishDate =
    daysToFinishJob !== null && isFinite(daysToFinishJob)
      ? addDays(today, Math.ceil(daysToFinishJob))
      : null;

  // Per-sand-type cover. Split the burn proportionally by each sand's share of
  // the per-stage design — a pad running 100 mesh and 40/70 does not burn them
  // at the same rate, and a single pad-wide "days left" hides the one that
  // runs out first.
  const sandTypeRows: ForecastSandRow[] = summary.sandTypeSummaries.map((s) => {
    // JobDesignSandTypeMetrics.sandType is the full SandTypeSpec, not a name.
    const d = design.find((x) => x.sandType.name === s.sandType);
    const spec = state.config.sandTypes.find((st) => st.name === s.sandType);
    const perStage = spec ? getEffectivePerStageDesign(activeWell, spec) : 0;
    const share = perStageTotal > 0 ? perStage / perStageTotal : 0;
    const sandBurn = burnLbsPerDay * share;
    const daysOfCover = sandBurn > 0 ? s.onHandLbs / sandBurn : null;

    return {
      sandType: s.sandType,
      onHandLbs: s.onHandLbs,
      stagesLeft: s.stagesLeft,
      remainingInDesignLbs: d?.remainingInDesignLbs ?? 0,
      truckloadsNeeded: d?.truckloadsStillNeeded ?? 0,
      isReorder: s.isBelowReorderThreshold,
      shortfallLbs: s.stageShortfallLbs,
      daysOfCover,
      projectedEmptyDate:
        daysOfCover !== null && isFinite(daysOfCover)
          ? addDays(today, Math.floor(daysOfCover))
          : null,
    };
  });

  return {
    onHandLbs,
    stagesLeftOnHand,
    stagesRemainingInJob,
    lbsRemainingInJob,
    truckloadsStillNeeded: lbsPerTruck > 0 ? shortfallToFinishLbs / lbsPerTruck : 0,
    burnLbsPerDay,
    stagesPerDay,
    loadsPerDay,
    daysOfSandLeft,
    projectedEmptyDate,
    daysToFinishJob,
    projectedJobFinishDate,
    shortfallToFinishLbs,
    loadsPerDayRequired,
    netLbsPerDay: deliveredLbsPerDay - burnLbsPerDay,
    sandTypeRows,
    daily,
    samplePumpingDays: pumpedDays.length,
    sampleWindowDays: recent.length,
    burnConfidence: pumpedDays.length === 0 ? 'none' : pumpedDays.length < 3 ? 'low' : 'ok',
  };
}

/* ------------------------------------------------------------ shift log --- */

export interface ShiftReport {
  date: string;
  loadsIn: number;
  deliveredLbs: number;
  stagesRecorded: number;
  pumpedLbs: number;
  netLbs: number;
  tickets: DeliveryTicket[];
  runs: RunRecord[];
  /** Per sand type, what came in and what went downhole today. */
  bySandType: Array<{ sandType: string; deliveredLbs: number; pumpedLbs: number }>;
  suppliers: Array<{ supplier: string; loads: number; lbs: number }>;
}

export function getShiftReport(state: AppState, date?: string): ShiftReport {
  const day = date || getOperationalDate();
  const tickets = state.deliveries.filter((d) => !d.deleted && d.date === day);
  const runs = state.runs.filter((r) => !r.deleted && r.date === day);

  const deliveredLbs = tickets.reduce((s, t) => s + (t.lbs || 0), 0);
  const pumpedLbs = runs.reduce((s, r) => s + (r.lbsPulled || 0), 0);

  const sandMap = new Map<string, { deliveredLbs: number; pumpedLbs: number }>();
  for (const t of tickets) {
    const e = sandMap.get(t.sandType) || { deliveredLbs: 0, pumpedLbs: 0 };
    e.deliveredLbs += t.lbs || 0;
    sandMap.set(t.sandType, e);
  }
  for (const r of runs) {
    const e = sandMap.get(r.sandType) || { deliveredLbs: 0, pumpedLbs: 0 };
    e.pumpedLbs += r.lbsPulled || 0;
    sandMap.set(r.sandType, e);
  }

  const supMap = new Map<string, { loads: number; lbs: number }>();
  for (const t of tickets) {
    const key = t.supplier || 'Unspecified';
    const e = supMap.get(key) || { loads: 0, lbs: 0 };
    e.loads += 1;
    e.lbs += t.lbs || 0;
    supMap.set(key, e);
  }

  return {
    date: day,
    loadsIn: tickets.length,
    deliveredLbs,
    // Stages TOUCHED today, deduped — a stage pulled from four silos is one
    // stage, not four.
    stagesRecorded: new Set(runs.map((r) => `${r.wellId}:${r.stageNumber}`)).size,
    pumpedLbs,
    netLbs: deliveredLbs - pumpedLbs,
    tickets,
    runs,
    bySandType: Array.from(sandMap.entries())
      .map(([sandType, v]) => ({ sandType, ...v }))
      .sort((a, b) => b.deliveredLbs + b.pumpedLbs - (a.deliveredLbs + a.pumpedLbs)),
    suppliers: Array.from(supMap.entries())
      .map(([supplier, v]) => ({ supplier, ...v }))
      .sort((a, b) => b.lbs - a.lbs),
  };
}

/* ------------------------------------------------------ silo suggestion --- */

export interface SiloSuggestion {
  siloNumber: number;
  headroomLbs: number;
  reason: string;
}

/**
 * Where should this load go?
 *
 * Returns the reason as a sentence so the UI never has to compose an
 * explanation — the model layer owns both the answer and why.
 *
 * `incomingLbs` lets us avoid suggesting a can that this specific truck
 * would overfill.
 */
export function suggestSiloForDelivery(
  state: AppState,
  sandType: string,
  incomingLbs?: number
): SiloSuggestion | null {
  if (!sandType) return null;
  const derived = getSiloDerivedStates(state);
  const load = incomingLbs && incomingLbs > 0 ? incomingLbs : 0;

  const matching = derived
    .filter((s) => !s.isOutOfService && s.sandType === sandType)
    .map((s) => ({
      siloNumber: s.siloNumber,
      headroomLbs: Math.max(0, s.maxCapacityLbs - s.onHandLbs),
    }))
    .sort((a, b) => b.headroomLbs - a.headroomLbs);

  // Prefer a can that fits the whole load.
  const fits = matching.filter((s) => s.headroomLbs >= load && s.headroomLbs > 10000);
  if (fits.length) {
    const best = fits[0];
    return {
      ...best,
      reason: `Most headroom on ${sandType} — Silo ${best.siloNumber}`,
    };
  }

  // Nothing fits cleanly: fall back to an empty, unassigned in-service can.
  const empty = derived
    .filter((s) => !s.isOutOfService && (!s.sandType || s.onHandLbs <= 0))
    .sort((a, b) => a.siloNumber - b.siloNumber)[0];
  if (empty) {
    return {
      siloNumber: empty.siloNumber,
      headroomLbs: Math.max(0, empty.maxCapacityLbs - empty.onHandLbs),
      reason: `Silo ${empty.siloNumber} is empty — assign ${sandType}`,
    };
  }

  // Everything is tight. Return the roomiest anyway, and say so.
  if (matching.length) {
    const best = matching[0];
    return {
      ...best,
      reason: `All ${sandType} cans are tight — Silo ${best.siloNumber} has the most room`,
    };
  }
  return null;
}

/* -------------------------------------------------------- well progress --- */

export interface WellProgress {
  well: WellConfig;
  planned: number;
  completed: number;
  remaining: number;
  pct: number;
  pumpedLbs: number;
  stages: Array<{ stage: number; complete: boolean; pumpedLbs: number; pct: number }>;
}

export function getWellProgress(state: AppState): WellProgress[] {
  return state.config.wells.map((well) => {
    const planned = well.plannedStages || 0;
    const activeSpecs = state.config.sandTypes;
    const perStageTotal = activeSpecs.reduce(
      (s, st) => s + getEffectivePerStageDesign(well, st),
      0
    );

    const pumpedByStage = new Map<number, number>();
    let pumpedLbs = 0;
    for (const run of state.runs) {
      if (run.deleted || run.wellId !== well.id) continue;
      pumpedByStage.set(
        run.stageNumber,
        (pumpedByStage.get(run.stageNumber) || 0) + (run.lbsPulled || 0)
      );
      pumpedLbs += run.lbsPulled || 0;
    }

    const stages: WellProgress['stages'] = [];
    let completed = 0;
    for (let stg = 1; stg <= planned; stg++) {
      const complete = isStageComplete(state, well.id, stg);
      if (complete) completed++;
      const lbs = pumpedByStage.get(stg) || 0;
      stages.push({
        stage: stg,
        complete,
        pumpedLbs: lbs,
        pct: perStageTotal > 0 ? Math.min(100, (lbs / perStageTotal) * 100) : 0,
      });
    }

    return {
      well,
      planned,
      completed,
      remaining: Math.max(0, planned - completed),
      pct: planned > 0 ? (completed / planned) * 100 : 0,
      pumpedLbs,
      stages,
    };
  });
}

/* --------------------------------------------------------------- alerts --- */

export type AlertTone = 'danger' | 'warn' | 'ok';

export interface PadAlert {
  tone: AlertTone;
  message: string;
  /** Which view resolves this alert. Lets the UI deep-link the fix. */
  target?: string;
}

/**
 * Everything wrong with the pad, in priority order, as full sentences.
 *
 * Lives here rather than in a component so the CSV export, the command center
 * and the Gemini pad-Q&A context all read the same list.
 */
export function getPadAlerts(state: AppState): PadAlert[] {
  const summary = getPadSummary(state);
  const derived = getSiloDerivedStates(state);
  const forecast = getForecast(state);
  const alerts: PadAlert[] = [];

  for (const s of summary.sandTypeSummaries) {
    if (s.stageShortfallLbs > 0) {
      alerts.push({
        tone: 'danger',
        message: `Short ${Math.round(s.stageShortfallLbs).toLocaleString()} lbs of ${s.sandType} for ${summary.nextWellName} stage ${summary.nextStageNumber}.`,
        target: 'board',
      });
    }
  }

  for (const s of summary.sandTypeSummaries) {
    if (s.isBelowReorderThreshold && s.stageShortfallLbs <= 0) {
      const row = forecast.sandTypeRows.find((r) => r.sandType === s.sandType);
      // Only quote a date when the burn rate is actually worth quoting.
      const when =
        forecast.burnConfidence === 'ok' && row?.projectedEmptyDate
          ? ` — empty about ${row.projectedEmptyDate}`
          : '';
      alerts.push({
        tone: 'warn',
        message: `${s.sandType} is below reorder threshold at ${s.stagesLeft.toFixed(1)} stages of cover${when}.`,
        target: 'forecast',
      });
    }
  }

  for (const s of derived) {
    if (s.isNegative) {
      alerts.push({
        tone: 'danger',
        message: `Silo ${s.siloNumber} shows a negative balance of ${Math.round(s.onHandLbs).toLocaleString()} lbs — a ticket or run is wrong.`,
        target: 'diagnostics',
      });
    }
  }

  for (const s of derived) {
    if (s.isOverCapacity) {
      alerts.push({
        tone: 'warn',
        message: `Silo ${s.siloNumber} is over capacity at ${Math.round(s.percentFull)}% full.`,
        target: 'board',
      });
    }
  }

  const unassigned = derived.filter((s) => !s.sandType && !s.isOutOfService);
  if (unassigned.length) {
    alerts.push({
      tone: 'warn',
      message: `${unassigned.length} silo${unassigned.length > 1 ? 's have' : ' has'} no sand type assigned (${unassigned.map((s) => s.siloNumber).join(', ')}).`,
      target: 'setup',
    });
  }

  if (!alerts.length) {
    alerts.push({
      tone: 'ok',
      message: 'Pad is clear — no shortfall, no reorder flags, no integrity issues.',
    });
  }

  return alerts;
}

/* ---------------------------------------------------------------- misc ---- */

/** Loads still needed today to break even against the burn. */
export function loadsNeededToday(state: AppState): number {
  const f = getForecast(state);
  const shift = getShiftReport(state);
  const lbsPerTruck = state.config.lbsPerTruckload || 57000;
  const deficit = f.burnLbsPerDay - shift.deliveredLbs;
  return deficit > 0 ? deficit / lbsPerTruck : 0;
}

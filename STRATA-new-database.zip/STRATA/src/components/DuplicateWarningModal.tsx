/**
 * Duplicate ticket number stop.
 *
 * A ticket number is the only unique key a mine gives us, so a repeat almost
 * always means the load was already counted — double-counting it is a real
 * inventory error. The dialog shows the existing record in full so the
 * operator can tell "already entered" from "the scanner read the PO number",
 * and the supervisor override stays gated behind a mandatory reason.
 */

import {
  AlertTriangle,
  X,
  Check,
  Camera,
  ExternalLink,
  HelpCircle,
  ShieldAlert,
  KeyRound,
} from 'lucide-react';
import { useState } from 'react';
import { cn } from '../lib/theme';
import { DeliveryTicket } from '../types';

interface DuplicateWarningModalProps {
  duplicate: DeliveryTicket;
  scannedTicketNumber?: string;
  rawScanValue?: string;
  lbsPerTon?: number;
  onClose: () => void;
  onRescan?: () => void;
  onViewExisting?: (ticket: DeliveryTicket) => void;
  onSupervisorOverride?: (reason: string) => Promise<void> | void;
}

export default function DuplicateWarningModal({
  duplicate,
  scannedTicketNumber,
  rawScanValue,
  lbsPerTon = 2000,
  onClose,
  onRescan,
  onViewExisting,
  onSupervisorOverride,
}: DuplicateWarningModalProps) {
  const [showOverrideInput, setShowOverrideInput] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');
  const [isOverriding, setIsOverriding] = useState(false);
  const [overrideError, setOverrideError] = useState<string | null>(null);

  const tons = (duplicate.lbs / lbsPerTon).toFixed(2);
  const formattedDate = duplicate.date
    ? new Date(duplicate.date + 'T00:00:00').toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric',
      })
    : duplicate.date;

  const handleConfirmOverride = async () => {
    if (!overrideReason.trim()) {
      setOverrideError('A supervisor override reason is required.');
      return;
    }
    if (!onSupervisorOverride) return;

    try {
      setIsOverriding(true);
      setOverrideError(null);
      await onSupervisorOverride(overrideReason.trim());
    } catch (err: any) {
      setOverrideError(err?.message || 'Failed to apply supervisor override.');
      setIsOverriding(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="duplicate-modal-title"
    >
      <div className="card my-auto max-h-[92vh] w-full max-w-lg overflow-y-auto rounded-xl p-5 ring-danger-1">
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow text-danger">Duplicate ticket number</div>
            <h2 id="duplicate-modal-title" className="text-xl font-medium tracking-tight">
              Already recorded
            </h2>
            <p className="text-sm text-muted">
              This number is live in the ledger. Saving it again would count the same load twice.
            </p>
          </div>
          <button type="button" onClick={onClose} className="btn btn-ghost tap shrink-0 px-2" aria-label="Close">
            <X className="size-5" />
          </button>
        </div>

        <div className="flex flex-col gap-4">
          {/* -------------------------------------------- comparison --- */}
          <div className="rounded-md bg-elevated p-3 ring-danger-1">
            <div className="flex items-center justify-between gap-3 pb-2">
              <span className="eyebrow">Scanned / new</span>
              <span className="num text-base font-semibold text-danger">
                #{scannedTicketNumber || duplicate.ticketNumber}
              </span>
            </div>
            <div className="divider" />
            <div className="flex items-center justify-between gap-3 pt-2">
              <span className="eyebrow">Matched existing</span>
              <span className="num text-base font-semibold text-fg">#{duplicate.ticketNumber}</span>
            </div>
          </div>

          {/* -------------------------------------- raw scan payload --- */}
          {rawScanValue && (
            <div className="rounded-md bg-elevated p-3 ring-border">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span className="eyebrow flex items-center gap-1.5">
                  <HelpCircle className="size-3.5" /> Raw scanned value
                </span>
                <span className="eyebrow">Verify the extracted number</span>
              </div>
              <div className="num mt-2 select-all break-all rounded-sm bg-surface p-2 text-xs text-fg">
                {rawScanValue}
              </div>
              <p className="mt-1.5 text-xs text-muted">
                If this ticket has not been entered, check whether a PO or order number was scanned
                instead of the ticket identifier.
              </p>
            </div>
          )}

          {/* ------------------------------------- existing record --- */}
          <div className="rounded-md bg-elevated p-3 ring-border">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="eyebrow">Existing record</span>
              <span className="badge badge-accent">Active in database</span>
            </div>

            <div className="mt-2 grid grid-cols-2 gap-3">
              <div>
                <div className="eyebrow">Silo assigned</div>
                <div className="num mt-0.5 text-sm font-semibold">#{duplicate.siloNumber}</div>
              </div>

              <div>
                <div className="eyebrow">Net weight</div>
                <div className="num mt-0.5 text-sm font-semibold">
                  {duplicate.lbs.toLocaleString()} lbs
                </div>
                <div className="num text-xs text-muted">{tons} tons</div>
              </div>

              <div>
                <div className="eyebrow">Sand type</div>
                <div className="mt-0.5 text-sm">{duplicate.sandType || '—'}</div>
              </div>

              <div className="min-w-0">
                <div className="eyebrow">Supplier</div>
                <div className="mt-0.5 truncate text-sm">{duplicate.supplier || '—'}</div>
              </div>

              <div className="col-span-2">
                <div className="eyebrow">Date and time</div>
                <div className="num mt-0.5 text-sm">
                  {formattedDate}
                  {duplicate.timeOfDay ? ` · ${duplicate.timeOfDay}` : ''}
                </div>
              </div>

              {(duplicate.driverName || duplicate.notes) && (
                <div className="col-span-2 flex flex-col gap-2 border-t border-border pt-2">
                  {duplicate.driverName && (
                    <div>
                      <div className="eyebrow">Driver</div>
                      <div className="mt-0.5 text-sm">{duplicate.driverName}</div>
                    </div>
                  )}
                  {duplicate.notes && (
                    <div>
                      <div className="eyebrow">Notes</div>
                      <div className="mt-0.5 text-sm text-muted">{duplicate.notes}</div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* ---------------------------------- supervisor override --- */}
          {onSupervisorOverride && (
            <div className="rounded-md bg-elevated p-3 ring-border">
              {!showOverrideInput ? (
                <button
                  type="button"
                  onClick={() => setShowOverrideInput(true)}
                  className="btn btn-ghost tap w-full"
                >
                  <KeyRound className="size-4" /> Supervisor override — reason required
                </button>
              ) : (
                <div className="flex flex-col gap-2.5">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="size-4 shrink-0 text-warn" />
                    <span className="eyebrow text-warn">Supervisor override authorization</span>
                  </div>
                  <p className="text-sm text-muted">
                    Enter the operational reason this duplicate must be saved — split load across
                    two silos, scale re-issue, and so on.
                  </p>
                  <input
                    type="text"
                    value={overrideReason}
                    onChange={(e) => {
                      setOverrideReason(e.target.value);
                      setOverrideError(null);
                    }}
                    placeholder="Reason for override"
                    className={cn('input', overrideError && 'ring-danger-1')}
                  />
                  {overrideError && <p className="text-xs text-danger">{overrideError}</p>}
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setShowOverrideInput(false)}
                      className="btn tap flex-1"
                    >
                      Cancel override
                    </button>
                    <button
                      type="button"
                      onClick={handleConfirmOverride}
                      disabled={isOverriding || !overrideReason.trim()}
                      className="btn btn-accent tap flex-1"
                    >
                      {isOverriding ? 'Saving' : 'Authorize and save'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* -------------------------------------------- footer --- */}
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {onRescan && (
              <button type="button" onClick={onRescan} className="btn btn-lg tap w-full">
                <Camera className="size-4" /> Rescan ticket
              </button>
            )}

            {onViewExisting && (
              <button
                type="button"
                onClick={() => onViewExisting(duplicate)}
                className="btn btn-lg tap w-full"
              >
                <ExternalLink className="size-4" /> View in logs
              </button>
            )}

            <button
              type="button"
              onClick={onClose}
              autoFocus
              className={cn(
                'btn btn-accent btn-lg tap w-full',
                !onRescan && !onViewExisting && 'sm:col-span-2'
              )}
            >
              <Check className="size-4" /> Return and fix ticket number
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs text-muted">
            <AlertTriangle className="size-3.5 shrink-0 text-danger" />
            <span>Nothing has been saved yet.</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Manual run order.
 *
 * Pull order is normally the draw rotation's job. Pinning it is an override,
 * so it gets the locked channel everywhere — never a warning color. Order is
 * set per sand type, because slot #1 of 100 mesh and slot #1 of 40/70 are two
 * different queues.
 */

import React, { useMemo, useState, useEffect } from 'react';
import {
  Sliders,
  RotateCcw,
  Check,
  X,
  GripVertical,
  ChevronUp,
  ChevronDown,
  Lock,
} from 'lucide-react';
import { AppState, SiloDerivedState } from '../types';
import { formatLbs, formatTons } from '../lib/sandRules';
import { cn, sandClasses } from '../lib/theme';

interface SetRunOrderModalProps {
  isOpen: boolean;
  onClose: () => void;
  state: AppState;
  siloStates: SiloDerivedState[];
  onSaveOrders: (priorityMap: Record<number, number | null>) => void;
  onClearAllOverrides: () => void;
}

export default function SetRunOrderModal({
  isOpen,
  onClose,
  state,
  siloStates,
  onSaveOrders,
  onClearAllOverrides,
}: SetRunOrderModalProps) {
  const sandTypes = state.config.sandTypes;
  const lbsPerTon = state.config.lbsPerTon || 2000;

  const [selectedSandType, setSelectedSandType] = useState<string>(
    sandTypes[0]?.name || '100 Mesh'
  );
  const [orderedSiloNumbers, setOrderedSiloNumbers] = useState<number[]>([]);
  const [draggedIdx, setDraggedIdx] = useState<number | null>(null);

  // Seed the list from the order the rotation currently produces, so opening
  // the dialog and saving without touching anything is a no-op in intent.
  useEffect(() => {
    if (!isOpen) return;

    const matchingSilos = siloStates.filter(
      (s) => s.sandType === selectedSandType && !s.isOutOfService
    );

    const sorted = [...matchingSilos].sort((a, b) => {
      if (a.runOrder !== null && b.runOrder !== null) return a.runOrder - b.runOrder;
      if (a.runOrder !== null) return -1;
      if (b.runOrder !== null) return 1;
      return a.siloNumber - b.siloNumber;
    });

    setOrderedSiloNumbers(sorted.map((s) => s.siloNumber));
  }, [isOpen, selectedSandType, siloStates]);

  const activeSilosMap = useMemo(
    () => new Map(siloStates.map((s) => [s.siloNumber, s])),
    [siloStates]
  );

  if (!isOpen) return null;

  const moveUp = (index: number) => {
    if (index <= 0) return;
    const next = [...orderedSiloNumbers];
    const temp = next[index - 1];
    next[index - 1] = next[index];
    next[index] = temp;
    setOrderedSiloNumbers(next);
  };

  const moveDown = (index: number) => {
    if (index >= orderedSiloNumbers.length - 1) return;
    const next = [...orderedSiloNumbers];
    const temp = next[index + 1];
    next[index + 1] = next[index];
    next[index] = temp;
    setOrderedSiloNumbers(next);
  };

  const handleDragStart = (index: number) => setDraggedIdx(index);

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIdx === null || draggedIdx === index) return;

    const next = [...orderedSiloNumbers];
    const item = next.splice(draggedIdx, 1)[0];
    next.splice(index, 0, item);
    setDraggedIdx(index);
    setOrderedSiloNumbers(next);
  };

  const handleDragEnd = () => setDraggedIdx(null);

  const handleSave = () => {
    const priorityMap: Record<number, number | null> = {};
    orderedSiloNumbers.forEach((siloNum, idx) => {
      priorityMap[siloNum] = idx + 1;
    });
    onSaveOrders(priorityMap);
    onClose();
  };

  const handleClearAll = () => {
    onClearAllOverrides();
    onClose();
  };

  const thresholdPct = state.config.partialThresholdPct ?? 0.75;
  const thresholdVal = thresholdPct > 1 ? thresholdPct / 100 : thresholdPct;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-bg/80 p-4 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="set-run-order-title"
    >
      <div className="card my-auto flex max-h-[90vh] w-full max-w-2xl flex-col rounded-xl p-5">
        <div className="card-hd">
          <div className="min-w-0">
            <div className="eyebrow text-locked">Manual override</div>
            <h2 id="set-run-order-title" className="text-xl font-medium tracking-tight">
              Set silo run order
            </h2>
            <p className="text-sm text-muted">
              Saving pins slots <span className="num">#1</span>–
              <span className="num">#{Math.max(orderedSiloNumbers.length, 1)}</span> for{' '}
              {selectedSandType}. Pinned cans are taken out of the draw rotation until cleared.
            </p>
          </div>
          <button type="button" onClick={onClose} className="btn btn-ghost tap shrink-0 px-2" aria-label="Close">
            <X className="size-5" />
          </button>
        </div>

        {/* -------------------------------------- sand type selector --- */}
        {sandTypes.length > 1 && (
          <div className="no-scrollbar -mx-1 mb-3 flex items-center gap-2 overflow-x-auto px-1 pb-1">
            <span className="eyebrow-aside">Sand type</span>
            {sandTypes.map((st) => {
              const tone = sandClasses(st.name, sandTypes);
              const isActive = selectedSandType === st.name;
              return (
                <button
                  key={st.id}
                  type="button"
                  onClick={() => setSelectedSandType(st.name)}
                  className={cn(
                    'tap inline-flex h-9 shrink-0 items-center gap-1.5 rounded-sm px-3 text-sm font-medium transition-colors duration-150',
                    isActive ? 'bg-panel text-fg' : 'bg-elevated text-muted hover:text-fg'
                  )}
                >
                  <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                  {st.name}
                </button>
              );
            })}
          </div>
        )}

        <div className="mb-3 flex items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-border">
          <div className="flex items-start gap-2.5">
            <Sliders className="mt-0.5 size-4 shrink-0 text-accent" />
            <div className="text-sm text-muted">
              Drag a row or use the arrows. A can under{' '}
              <span className="num">{Math.round(thresholdVal * 100)}%</span> full counts as a
              partial and is normally pulled first.
            </div>
          </div>
          <span className="badge shrink-0">
            <span className="num">{orderedSiloNumbers.length}</span> online
          </span>
        </div>

        {/* ------------------------------------------ orderable list --- */}
        <div className="no-scrollbar flex flex-1 flex-col gap-2 overflow-y-auto">
          {orderedSiloNumbers.length === 0 ? (
            <div className="rounded-md bg-elevated p-6 text-center text-sm text-muted ring-border">
              No online silos are assigned to {selectedSandType}.
            </div>
          ) : (
            orderedSiloNumbers.map((siloNum, idx) => {
              const silo = activeSilosMap.get(siloNum);
              if (!silo) return null;

              const isPartial =
                silo.maxCapacityLbs > 0 && silo.onHandLbs / silo.maxCapacityLbs < thresholdVal;
              const isDragging = draggedIdx === idx;
              const tone = sandClasses(silo.sandType, sandTypes);

              return (
                <div
                  key={siloNum}
                  draggable
                  onDragStart={() => handleDragStart(idx)}
                  onDragOver={(e) => handleDragOver(e, idx)}
                  onDragEnd={handleDragEnd}
                  className={cn(
                    'flex select-none items-center justify-between gap-3 rounded-md bg-elevated p-3 transition-[box-shadow] duration-150',
                    isDragging ? 'ring-locked-1' : 'ring-border'
                  )}
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span className="cursor-grab p-1 text-subtle active:cursor-grabbing">
                      <GripVertical className="size-5" />
                    </span>

                    <span className="num flex size-9 shrink-0 items-center justify-center rounded-sm bg-locked-dim text-sm font-semibold text-locked">
                      {idx + 1}
                    </span>

                    <div className="min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                        <span className="text-sm font-medium">
                          Silo <span className="num">#{silo.siloNumber}</span>
                        </span>
                        <span className="badge">Side {silo.side || 'A'}</span>
                        {silo.manualPriority !== null && (
                          <span className="badge badge-locked">
                            <Lock className="size-3" /> Pinned
                          </span>
                        )}
                        {isPartial && <span className="badge badge-warn">Partial</span>}
                      </div>

                      <div className="mt-1 text-xs text-muted">
                        <span className="num">{formatLbs(silo.onHandLbs)}</span> ·{' '}
                        <span className="num">{formatTons(silo.onHandLbs / lbsPerTon)}</span> ·{' '}
                        <span className="num">{silo.percentFull.toFixed(0)}%</span> full
                      </div>
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      disabled={idx === 0}
                      onClick={() => moveUp(idx)}
                      className="btn tap px-2.5"
                      title="Move up"
                      aria-label={`Move silo ${silo.siloNumber} up`}
                    >
                      <ChevronUp className="size-4" />
                    </button>
                    <button
                      type="button"
                      disabled={idx === orderedSiloNumbers.length - 1}
                      onClick={() => moveDown(idx)}
                      className="btn tap px-2.5"
                      title="Move down"
                      aria-label={`Move silo ${silo.siloNumber} down`}
                    >
                      <ChevronDown className="size-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* ----------------------------------------------- footer --- */}
        <div className="mt-4 flex flex-col items-stretch justify-between gap-2 border-t border-border pt-4 sm:flex-row sm:items-center">
          <button type="button" onClick={handleClearAll} className="btn tap">
            <RotateCcw className="size-4" /> Clear all overrides
          </button>

          <div className="flex items-center gap-2">
            <button type="button" onClick={onClose} className="btn tap flex-1 sm:flex-none">
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={orderedSiloNumbers.length === 0}
              className="btn btn-accent tap flex-1 sm:flex-none"
            >
              <Check className="size-4" /> Save run order
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

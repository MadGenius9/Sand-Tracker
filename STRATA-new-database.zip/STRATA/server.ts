/**
 * STRATA server.
 *
 * Two jobs, and only two:
 *   1. Serve the app (Vite middleware in dev, static dist in prod).
 *   2. Proxy Gemini, server-side, so GEMINI_API_KEY never reaches the browser.
 *      This is what MAJOR_CAPABILITY_SERVER_SIDE_GEMINI_API in metadata.json
 *      is for — AI Studio injects the key at runtime from the user's secrets.
 *
 * The previous build shipped a 227-line unauthenticated JSON-file store here
 * with open write and reset-demo endpoints that the client never once called.
 * All of that is gone; Firestore is the only datastore.
 */

import express from 'express';
import path from 'path';
import { GoogleGenAI } from '@google/genai';

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Ticket photos are the largest payload. 12mb covers a full-res phone JPEG.
app.use(express.json({ limit: '12mb' }));

/* ------------------------------------------------------------------ gemini */

const MODEL_CANDIDATES = [
  process.env.GEMINI_MODEL,
  'gemini-2.5-flash',
  'gemini-3-flash-preview',
  'gemini-2.0-flash',
].filter(Boolean) as string[];

let ai: GoogleGenAI | null = null;
function getAI(): GoogleGenAI | null {
  if (ai) return ai;
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  ai = new GoogleGenAI({ apiKey });
  return ai;
}

/** Try each model in turn — a preview model can disappear without notice. */
async function generate(params: Record<string, unknown>): Promise<string> {
  const client = getAI();
  if (!client) throw new Error('GEMINI_API_KEY is not configured.');

  let lastErr: unknown = null;
  for (const model of MODEL_CANDIDATES) {
    try {
      const res = await client.models.generateContent({ model, ...params } as never);
      const text = (res as { text?: string }).text;
      if (text) return text;
      lastErr = new Error(`Model ${model} returned no text.`);
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error('Gemini request failed.');
}

app.get('/api/gemini/status', (_req, res) => {
  res.json({ available: Boolean(process.env.GEMINI_API_KEY) });
});

/* -- Ticket vision OCR ------------------------------------------------------
 *
 * The barcode scale-ladder handles the great majority of tickets. What it
 * cannot do is read a ticket whose barcode is smeared, folded, sun-bleached or
 * simply absent — and those are exactly the tickets a driver is standing in
 * front of you holding. This is the honest fallback: read the printed numbers.
 *
 * Everything it returns is treated as PROBABLE and routed through the same
 * confirmation modal as an ambiguous barcode. It never writes a ticket
 * unattended.
 */
const TICKET_SCHEMA = {
  type: 'object',
  properties: {
    ticketNumber: {
      type: 'string',
      description:
        'The delivery/BOL ticket number. NOT the PO number, NOT the truck number. Empty string if not clearly legible.',
    },
    weightLbs: {
      type: 'number',
      description:
        'Net weight of sand in POUNDS. If the ticket shows tons, multiply by 2000. If it shows gross/tare/net, use NET. 0 if not legible.',
    },
    productCode: {
      type: 'string',
      description: 'Mine/product code as printed, e.g. "100M", "4070". Empty string if absent.',
    },
    sandDescription: {
      type: 'string',
      description:
        'Sand mesh description as printed, e.g. "100 Mesh", "40/70". Empty string if absent.',
    },
    supplier: { type: 'string', description: 'Supplier or mine name. Empty string if absent.' },
    carrier: { type: 'string', description: 'Trucking company / hauler. Empty string if absent.' },
    truck: { type: 'string', description: 'Truck or unit number. Empty string if absent.' },
    poNumber: { type: 'string', description: 'PO / order number. Empty string if absent.' },
    date: { type: 'string', description: 'Ticket date as YYYY-MM-DD. Empty string if not legible.' },
    driverName: { type: 'string', description: 'Driver name. Empty string if absent.' },
    confidence: {
      type: 'string',
      enum: ['high', 'medium', 'low'],
      description:
        'high = ticket number AND weight both clearly legible. medium = one is clear. low = guessing.',
    },
    notes: {
      type: 'string',
      description:
        'One short sentence for the operator if anything is ambiguous or unreadable. Empty string if the read was clean.',
    },
  },
  required: ['ticketNumber', 'weightLbs', 'confidence'],
} as const;

const TICKET_PROMPT = `You are reading a frac sand delivery ticket (a bill of lading) photographed at a well pad. Conditions are poor: thermal paper, curled edges, dust, glare, a gloved thumb over one corner.

Extract only what you can actually SEE. Rules:
- NEVER invent or complete a partially visible number. If you cannot read every character of the ticket number, return an empty string for it.
- The ticket number is the delivery/BOL number. Do NOT return the PO number, order number, seal number, or truck number in that field — they are commonly printed larger and more prominently.
- Weight must be NET sand weight in POUNDS. A ticket showing GROSS / TARE / NET means you want NET. A weight in tons must be multiplied by 2000. A plausible load is 20,000-60,000 lbs; if your reading is far outside that, lower your confidence.
- Set confidence honestly. An operator will be shown your reading and asked to confirm it, so "low" costs nothing and a wrong "high" costs a wrong silo balance.`;

app.post('/api/gemini/read-ticket', async (req, res) => {
  try {
    const { imageBase64, mimeType } = req.body ?? {};
    if (!imageBase64 || typeof imageBase64 !== 'string') {
      return res.status(400).json({ error: 'imageBase64 is required.' });
    }
    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({
        error: 'Gemini is not configured. Add GEMINI_API_KEY in the AI Studio Secrets panel.',
      });
    }

    // Accept a full data URL or a bare base64 payload.
    const data = imageBase64.includes(',') ? imageBase64.split(',')[1] : imageBase64;

    const text = await generate({
      contents: [{ inlineData: { data, mimeType: mimeType || 'image/jpeg' } }, TICKET_PROMPT],
      config: {
        responseMimeType: 'application/json',
        responseJsonSchema: TICKET_SCHEMA,
        temperature: 0,
      },
    });

    res.json(JSON.parse(text));
  } catch (err) {
    console.error('[gemini/read-ticket]', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Ticket read failed.' });
  }
});

/* -- Ask the pad ------------------------------------------------------------
 *
 * A natural-language question answered against a compact snapshot of live pad
 * state that the CLIENT computes from sandRules/analytics and sends up. The
 * model does not do arithmetic on raw tickets — it reads figures the
 * deterministic engine already produced, so an answer here can never disagree
 * with the pull sheet.
 */
const ASK_PROMPT = `You are STRATA, the sand-tracking assistant for a hydraulic fracturing pad. You are answering a sand coordinator or company man who is standing on location, probably on a phone, probably in a hurry.

You will be given a JSON snapshot of the pad's CURRENT state, already computed by the app's deterministic rules engine. Answer strictly from it.

Rules:
- Be brief. Two or three sentences. This is read on a phone in the sun.
- Lead with the number they asked for.
- Use the exact figures in the snapshot. Do NOT recompute totals from raw records and do NOT round in a way that changes a decision.
- Give lbs with a "loads" or "tons" equivalent when talking about ordering sand — that is the unit trucks are dispatched in.
- If the snapshot does not contain the answer, say exactly what is missing and which screen has it. Never guess.
- If something in the snapshot is dangerous — a shortfall for the next stage, a negative silo balance, sand running out before the job finishes — say so even if they did not ask.
- No preamble, no markdown headers, no bullet lists unless you are listing three or more silos.`;

app.post('/api/gemini/ask', async (req, res) => {
  try {
    const { question, snapshot } = req.body ?? {};
    if (!question || typeof question !== 'string') {
      return res.status(400).json({ error: 'question is required.' });
    }
    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({
        error: 'Gemini is not configured. Add GEMINI_API_KEY in the AI Studio Secrets panel.',
      });
    }

    const text = await generate({
      contents: [
        `${ASK_PROMPT}\n\nPAD SNAPSHOT:\n${JSON.stringify(snapshot ?? {}, null, 1)}\n\nQUESTION: ${question}`,
      ],
      config: { temperature: 0.2 },
    });

    res.json({ answer: text.trim() });
  } catch (err) {
    console.error('[gemini/ask]', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Question failed.' });
  }
});

/* ------------------------------------------------------------------ static */

async function start() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => res.sendFile(path.join(distPath, 'index.html')));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`STRATA listening on :${PORT}`);
    console.log(
      process.env.GEMINI_API_KEY
        ? '  Gemini: enabled'
        : '  Gemini: no GEMINI_API_KEY — ticket OCR and Ask the Pad will report as unavailable.'
    );
  });
}

start();

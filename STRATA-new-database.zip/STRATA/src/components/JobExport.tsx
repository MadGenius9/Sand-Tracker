/**
 * End-of-job export.
 *
 * The CSV is the artifact the office actually keeps, so the screen shows the
 * same three ledgers the file contains — wells, sand types, suppliers — with
 * the totals computed exactly the way `exportUtils` computes them. What you
 * read here is what lands in the spreadsheet.
 */

import { Download, Copy, Check, Table } from 'lucide-react';
import { useMemo, useState } from 'react';
import { generatePadCSV, downloadPadCSV } from '../lib/exportUtils';
import {
  formatLbs,
  formatTons,
  calculateDeliveredBySupplier,
} from '../lib/sandRules';
import { cn, sandClasses } from '../lib/theme';
import { AppState } from '../types';

interface JobExportProps {
  state: AppState;
  onSuccessMessage?: (msg: string) => void;
}

export default function JobExport({ state, onSuccessMessage }: JobExportProps) {
  const { config, deliveries, runs } = state;
  const lbsPerTon = config.lbsPerTon || 2000;
  const [copied, setCopied] = useState(false);

  /* Every figure below is a full-ledger reduce. One memo, three slices. */
  const totals = useMemo(() => {
    const totalDeliveredLbs = deliveries.reduce((sum, d) => sum + (d.lbs || 0), 0);
    const totalPumpedLbs = runs.reduce((sum, r) => sum + (r.lbsPulled || 0), 0);

    const totalOnHandLbs = config.silos.reduce((sum, s) => {
      const delivered = deliveries
        .filter((d) => d.siloNumber === s.siloNumber)
        .reduce((a, b) => a + (b.lbs || 0), 0);
      const pumped = runs
        .filter((r) => r.siloNumber === s.siloNumber)
        .reduce((a, b) => a + (b.lbsPulled || 0), 0);
      return sum + (s.startingBalanceLbs || 0) + delivered - pumped;
    }, 0);

    return {
      totalDeliveredLbs,
      totalDeliveredTons: totalDeliveredLbs / lbsPerTon,
      totalPumpedLbs,
      totalPumpedTons: totalPumpedLbs / lbsPerTon,
      totalOnHandLbs,
      totalOnHandTons: totalOnHandLbs / lbsPerTon,
    };
  }, [config.silos, deliveries, runs, lbsPerTon]);

  const wellRows = useMemo(
    () =>
      config.wells.map((well) => {
        const wellRuns = runs.filter((r) => r.wellId === well.id);
        const pumped = new Set(wellRuns.map((r) => r.stageNumber)).size;
        return {
          id: well.id,
          name: well.name,
          plannedStages: well.plannedStages,
          pumpedStages: pumped,
          remainingStages: Math.max(0, well.plannedStages - pumped),
          lbsPumped: wellRuns.reduce((sum, r) => sum + (r.lbsPulled || 0), 0),
        };
      }),
    [config.wells, runs]
  );

  const sandRows = useMemo(
    () =>
      config.sandTypes.map((st) => ({
        id: st.id,
        name: st.name,
        perStageDesignLbs: st.perStageDesignLbs || 0,
        deliveredLbs: deliveries
          .filter((d) => d.sandType === st.name)
          .reduce((sum, d) => sum + (d.lbs || 0), 0),
        pumpedLbs: runs
          .filter((r) => r.sandType === st.name)
          .reduce((sum, r) => sum + (r.lbsPulled || 0), 0),
      })),
    [config.sandTypes, deliveries, runs]
  );

  const supplierRows = useMemo(() => calculateDeliveredBySupplier(state), [config, deliveries, runs]);

  const handleDownloadCSV = () => {
    downloadPadCSV(state);
    if (onSuccessMessage) {
      onSuccessMessage('Spreadsheet CSV exported.');
    }
  };

  const handleCopyCSV = async () => {
    const csvContent = generatePadCSV(state);
    try {
      await navigator.clipboard.writeText(csvContent);
      setCopied(true);
      if (onSuccessMessage) {
        onSuccessMessage('CSV data copied to the clipboard.');
      }
      setTimeout(() => setCopied(false), 3000);
    } catch (err) {
      console.error('Failed to copy CSV:', err);
      if (onSuccessMessage) {
        onSuccessMessage('Could not reach the clipboard — use Download .csv instead.');
      }
    }
  };

  return (
    <div className="flex flex-col gap-5">
      {/* ------------------------------------------------- header --- */}
      <div className="card flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
        <div className="min-w-0">
          <div className="eyebrow">Job reporting and archiving</div>
          <h2 className="text-xl font-medium tracking-tight">End-of-job spreadsheet export</h2>
          <p className="max-w-2xl text-sm text-muted">
            One CSV: pad summary, the full ticket ledger and every stage run. On-hand is starting
            balance plus deliveries minus pulls, per can.
          </p>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <button type="button" onClick={handleDownloadCSV} className="btn btn-accent tap">
            <Download className="size-4" /> Download .csv
          </button>

          <button type="button" onClick={handleCopyCSV} className="btn tap">
            {copied ? (
              <>
                <Check className="size-4 text-ok" /> Copied
              </>
            ) : (
              <>
                <Copy className="size-4" /> Copy CSV
              </>
            )}
          </button>
        </div>
      </div>

      {/* --------------------------------------------------- KPIs --- */}
      <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
        <div className="card">
          <div className="eyebrow">Delivery tickets logged</div>
          <div className="stat-v mt-1">{deliveries.length.toLocaleString()}</div>
          <div className="num mt-1 text-xs text-muted">
            {formatLbs(totals.totalDeliveredLbs)} · {formatTons(totals.totalDeliveredTons)}
          </div>
        </div>

        <div className="card">
          <div className="eyebrow">Stage runs logged</div>
          <div className="stat-v mt-1">{runs.length.toLocaleString()}</div>
          <div className="num mt-1 text-xs text-muted">
            {formatLbs(totals.totalPumpedLbs)} · {formatTons(totals.totalPumpedTons)}
          </div>
        </div>

        <div className="card">
          <div className="eyebrow">Current on-hand balance</div>
          <div className="stat-v mt-1">{formatLbs(totals.totalOnHandLbs)}</div>
          <div className="num mt-1 text-xs text-muted">
            {formatTons(totals.totalOnHandTons)} on pad
          </div>
        </div>
      </div>

      {/* ------------------------------------------ dataset preview --- */}
      <div className="card flex flex-col gap-5">
        <div className="card-hd mb-0">
          <div className="flex items-center gap-2">
            <Table className="size-4 shrink-0 text-accent" />
            <div>
              <div className="eyebrow">Export dataset preview</div>
              <div className="text-sm font-medium">{config.padName || 'Pad'}</div>
            </div>
          </div>
          <span className="badge shrink-0">Ready for Excel or Sheets</span>
        </div>

        {/* wells */}
        <div>
          <div className="eyebrow mb-2">1 · Wells and stage summary</div>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Well</th>
                  <th className="n">Planned stages</th>
                  <th className="n">Pumped</th>
                  <th className="n">Remaining</th>
                  <th className="n">Sand pumped</th>
                </tr>
              </thead>
              <tbody>
                {wellRows.map((w) => (
                  <tr key={w.id}>
                    <td className="font-medium">{w.name}</td>
                    <td className="n">{w.plannedStages}</td>
                    <td className="n text-ok">{w.pumpedStages}</td>
                    <td className="n text-muted">{w.remainingStages}</td>
                    <td className="n">{formatLbs(w.lbsPumped)}</td>
                  </tr>
                ))}
                {wellRows.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-subtle">
                      No wells configured on this pad.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* sand types */}
        <div>
          <div className="eyebrow mb-2">2 · Sand type totals</div>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Sand type</th>
                  <th className="n">Design per stage</th>
                  <th className="n">Total delivered</th>
                  <th className="n">Total pumped</th>
                </tr>
              </thead>
              <tbody>
                {sandRows.map((st) => {
                  const tone = sandClasses(st.name, config.sandTypes);
                  return (
                    <tr key={st.id}>
                      <td>
                        <span className="flex items-center gap-2">
                          <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                          <span className="font-medium">{st.name}</span>
                        </span>
                      </td>
                      <td className="n text-muted">{formatLbs(st.perStageDesignLbs)}</td>
                      <td className="n">{formatLbs(st.deliveredLbs)}</td>
                      <td className="n text-ok">{formatLbs(st.pumpedLbs)}</td>
                    </tr>
                  );
                })}
                {sandRows.length === 0 && (
                  <tr>
                    <td colSpan={4} className="text-subtle">
                      No sand types configured on this pad.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* suppliers */}
        <div>
          <div className="eyebrow mb-2">3 · Delivered by supplier</div>
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Supplier</th>
                  <th className="n">Loads</th>
                  <th className="n">Total delivered</th>
                  <th className="n">Tons</th>
                </tr>
              </thead>
              <tbody>
                {supplierRows.map((row) => (
                  <tr key={row.supplierName}>
                    <td className="font-medium">{row.supplierName}</td>
                    <td className="n">{row.loadCount}</td>
                    <td className="n">{formatLbs(row.totalLbs)}</td>
                    <td className="n text-muted">{row.totalTons.toFixed(1)}</td>
                  </tr>
                ))}
                {supplierRows.length === 0 && (
                  <tr>
                    <td colSpan={4} className="text-subtle">
                      No delivery tickets logged yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

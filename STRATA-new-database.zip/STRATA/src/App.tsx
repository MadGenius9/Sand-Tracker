/**
 * STRATA — application shell.
 *
 * Desktop gets a fixed left rail; a phone gets a floating bottom bar with the
 * four things a crew touches (Command, Silos, Pull, Intake) plus a More sheet.
 * ⌘K opens the palette, which also answers questions about the pad.
 *
 * The startup state machine, the pad subscription with its late-snapshot guard,
 * and the pull-sheet auto-advance reconciliation are carried over unchanged —
 * they encode real field bugs and are not worth relitigating for a restyle.
 */

import {
  Boxes,
  Truck,
  Layers,
  History,
  Settings,
  Stethoscope,
  AlertTriangle,
  FileText,
  Activity,
  FileSpreadsheet,
  LayoutDashboard,
  Loader2,
  RefreshCw,
  TrendingUp,
  Command as CommandIcon,
  Menu,
  X,
  ChevronDown,
  CheckCircle2,
  Info,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import AddDelivery from './components/AddDelivery';
import Dashboard from './components/Dashboard';
import Diagnostics from './components/Diagnostics';
import Forecast from './components/Forecast';
import JobDesign from './components/JobDesign';
import Logs from './components/Logs';
import OfflineBanner from './components/OfflineBanner';
import RecordRun from './components/RecordRun';
import Setup from './components/Setup';
import SiloBoard from './components/SiloBoard';
import StageProgress from './components/StageProgress';
import StagePullSheet from './components/StagePullSheet';
import QuickEntry from './components/QuickEntry';
import { Wordmark, Mark } from './components/ui/Mark';
import CommandPalette, { type PaletteItem } from './components/ui/CommandPalette';
import { onFirebaseError, waitForFirebaseAuth } from './lib/firebase';
import { getNextWellAndStage, isStageComplete, getPadSummary } from './lib/sandRules';
import { isGeminiAvailable } from './lib/gemini';
import { getOperationalDate, getOperationalTime } from './lib/dateUtils';
import { cn } from './lib/theme';
import {
  addDeliveryTicket,
  addRunRecords,
  deleteDeliveryTicket,
  restoreDeliveryTicket,
  deleteRunRecord,
  restoreRunRecord,
  updateDeliveryTicket,
  updateRunRecord,
  listPads,
  savePadConfig,
  subscribeToPad,
  updateSiloInPad,
  updateSilosInPad,
} from './lib/firestoreService';
import { AppState, PadConfig, StartupStatus } from './types';

const ACTIVE_PAD_STORAGE_KEY = 'sandtracker_active_pad_id';

type Tab =
  | 'dashboard'
  | 'board'
  | 'pullsheet'
  | 'delivery'
  | 'run'
  | 'progress'
  | 'job_design'
  | 'forecast'
  | 'logs'
  | 'diagnostics'
  | 'setup';

interface NavEntry {
  id: Tab;
  /** One word, for the rail and the bottom bar. */
  label: string;
  /** Full name, for the palette. */
  title: string;
  /** Doubles as palette search keywords. */
  hint: string;
  icon: LucideIcon;
  primary?: boolean;
}

const NAV: NavEntry[] = [
  { id: 'dashboard', label: 'Command', title: 'Command center', hint: 'Pad status', icon: LayoutDashboard, primary: true },
  { id: 'board', label: 'Silos', title: 'Silo board', hint: 'Canister levels', icon: Boxes, primary: true },
  { id: 'pullsheet', label: 'Pull', title: 'Stage pull sheet', hint: 'Record a stage', icon: FileText, primary: true },
  { id: 'delivery', label: 'Intake', title: 'Ticket entry', hint: 'Log a load', icon: Truck, primary: true },
  { id: 'run', label: 'Run', title: 'Record run', hint: 'Manual stage entry', icon: Layers },
  { id: 'progress', label: 'Stages', title: 'Stage progress', hint: 'Zipper wells', icon: Activity },
  { id: 'job_design', label: 'Design', title: 'Job design', hint: 'Cross-check', icon: FileSpreadsheet },
  { id: 'forecast', label: 'Forecast', title: 'Forecast', hint: 'Burn & reorder', icon: TrendingUp },
  { id: 'logs', label: 'Log', title: 'Activity log', hint: 'Tickets & runs', icon: History },
  { id: 'diagnostics', label: 'Health', title: 'Diagnostics', hint: 'Integrity', icon: Stethoscope },
  { id: 'setup', label: 'Setup', title: 'Pad setup', hint: 'Config', icon: Settings },
];

type ToastTone = 'ok' | 'warn' | 'danger' | 'info';
interface Toast {
  id: number;
  message: string;
  tone: ToastTone;
}

const TOAST_ICON: Record<ToastTone, LucideIcon> = {
  ok: CheckCircle2,
  warn: AlertTriangle,
  danger: AlertTriangle,
  info: Info,
};

const TOAST_CLS: Record<ToastTone, string> = {
  ok: 'ring-accent-1 text-accent',
  warn: 'ring-warn-1 text-warn',
  danger: 'ring-danger-1 text-danger',
  info: 'ring-border text-fg',
};

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('dashboard');

  const [currentPadId, setCurrentPadId] = useState<string | null>(() => {
    if (typeof window === 'undefined') return null;
    const params = new URLSearchParams(window.location.search);
    const urlPad = params.get('pad');
    if (urlPad) return urlPad;
    try {
      const stored = localStorage.getItem(ACTIVE_PAD_STORAGE_KEY);
      if (stored) return stored;
    } catch {
      /* ignore */
    }
    return null;
  });

  const [isAuthReady, setIsAuthReady] = useState(false);
  const [startupStatus, setStartupStatus] = useState<StartupStatus>('initializing_auth');
  const [startupError, setStartupError] = useState<string | null>(null);
  const [retryTrigger, setRetryTrigger] = useState(0);
  const [padList, setPadList] = useState<{ id: string; name: string }[]>([]);
  const [state, setState] = useState<AppState | null>(null);

  // Guards writes and late snapshots against a pad switch mid-flight.
  const activePadIdRef = useRef<string | null>(currentPadId);
  useEffect(() => {
    activePadIdRef.current = currentPadId;
  }, [currentPadId]);

  const [deliveryInitialSilo, setDeliveryInitialSilo] = useState<number | undefined>(undefined);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [firebaseError, setFirebaseError] = useState<string | null>(null);

  // Shell chrome
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const [padMenuOpen, setPadMenuOpen] = useState(false);
  const [geminiOn, setGeminiOn] = useState(false);
  const [clock, setClock] = useState(() => getOperationalTime());

  const [pinnedUrlParams] = useState<{ wellId: string | null; stageNumber: number | null }>(() => {
    if (typeof window === 'undefined') return { wellId: null, stageNumber: null };
    const params = new URLSearchParams(window.location.search);
    const well = params.get('well');
    const stage = params.get('stage') ? parseInt(params.get('stage')!, 10) : null;
    if (well && stage) return { wellId: well, stageNumber: stage };
    return { wellId: null, stageNumber: null };
  });
  const isPinnedReadOnly = Boolean(pinnedUrlParams.wellId && pinnedUrlParams.stageNumber);

  const [pullSheetTarget, setPullSheetTarget] = useState<{
    wellId: string;
    stageNumber: number;
  } | null>(null);
  const [pullSheetResetSignal, setPullSheetResetSignal] = useState(0);
  const [lastRanWellId, setLastRanWellId] = useState<string | undefined>(undefined);

  /* ------------------------------------------------------------- toasts -- */

  const toastId = useRef(0);
  const showToast = useCallback((msg: string, tone: ToastTone = 'ok') => {
    const id = ++toastId.current;
    // A message that already reads as an error is one, whatever the caller said.
    const inferred: ToastTone = /^(error|failed|unable|could not)/i.test(msg) ? 'danger' : tone;
    setToasts((t) => [...t.slice(-3), { id, message: msg, tone: inferred }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 5000);
  }, []);

  /* -------------------------------------------------------- shell wiring -- */

  useEffect(() => {
    if (currentPadId) {
      try {
        localStorage.setItem(ACTIVE_PAD_STORAGE_KEY, currentPadId);
      } catch (e) {
        console.warn('Unable to persist padId to localStorage:', e);
      }
    }
  }, [currentPadId]);

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
    document.documentElement.scrollTop = 0;
    document.body.scrollTop = 0;
  }, [activeTab, deliveryInitialSilo]);

  useEffect(() => onFirebaseError((err) => setFirebaseError(err)), []);

  useEffect(() => {
    void isGeminiAvailable().then(setGeminiOn);
  }, []);

  useEffect(() => {
    const t = setInterval(() => setClock(getOperationalTime()), 30000);
    return () => clearInterval(t);
  }, []);

  // ⌘K / Ctrl-K
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setPaletteOpen((o) => !o);
      }
    }
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  /* ------------------------------------------------------------- startup -- */

  useEffect(() => {
    let isMounted = true;
    setStartupStatus('initializing_auth');
    setStartupError(null);

    async function initializeAuth() {
      try {
        await waitForFirebaseAuth();
        if (!isMounted) return;
        setIsAuthReady(true);

        listPads()
          .then((pads) => {
            if (isMounted && pads?.length) setPadList(pads);
          })
          .catch((err) => console.warn('Background pad list fetch warning:', err));

        if (!currentPadId) setStartupStatus('no_pad_selected');
      } catch (err: any) {
        if (!isMounted) return;
        console.error('Firebase Auth Gate failed:', err);
        setStartupStatus('connection_error');
        setStartupError(err?.message || 'Failed to authenticate with database');
      }
    }

    initializeAuth();
    return () => {
      isMounted = false;
    };
  }, [retryTrigger]);

  // The pad list used to be refetched inside every Firestore snapshot — a
  // getDocs over the whole collection on every ticket, run and config change.
  // It only needs to change when a pad is added or removed, so it is throttled
  // to once a minute and refreshed explicitly at the points that matter.
  const lastPadListFetch = useRef(0);
  const refreshPadList = useCallback((force = false) => {
    const now = Date.now();
    if (!force && now - lastPadListFetch.current < 60000) return;
    lastPadListFetch.current = now;
    listPads()
      .then((pads) => {
        if (pads?.length) setPadList(pads);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!isAuthReady || !currentPadId) {
      if (!currentPadId && isAuthReady) {
        activePadIdRef.current = null;
        setState(null);
        setStartupStatus('no_pad_selected');
      }
      return;
    }

    activePadIdRef.current = currentPadId;
    if (!state || state.padId !== currentPadId) setStartupStatus('loading_pad');

    const unsub = subscribeToPad(
      currentPadId,
      (updatedState) => {
        // Discard a snapshot from a pad we have already navigated away from.
        if (updatedState.padId !== activePadIdRef.current) return;

        setState(updatedState);

        if (updatedState.status === 'ready') {
          setStartupStatus('ready');
          setStartupError(null);
        } else if (updatedState.status === 'not_found') {
          setStartupStatus('pad_not_found');
        }

        refreshPadList();
      },
      (err: any) => {
        console.error('Error in pad subscription:', err);
        if (!state || state.padId !== currentPadId) {
          setStartupStatus('connection_error');
          setStartupError(err?.message || 'Unable to connect to database');
        } else {
          setStartupStatus('offline_cached');
        }
      }
    );

    return () => unsub();
  }, [isAuthReady, currentPadId, retryTrigger, refreshPadList]);

  // Clear the optimistic pull-sheet target once live runs agree with it.
  useEffect(() => {
    if (!pullSheetTarget || !state?.runs) return;
    const next = getNextWellAndStage(state, lastRanWellId);
    if (
      next &&
      next.wellId === pullSheetTarget.wellId &&
      next.stageNumber === pullSheetTarget.stageNumber
    ) {
      setPullSheetTarget(null);
    }
  }, [state?.runs, pullSheetTarget, lastRanWellId]);

  /* ------------------------------------------------------------ handlers -- */

  const handleReturnToJobList = useCallback(() => {
    try {
      localStorage.removeItem(ACTIVE_PAD_STORAGE_KEY);
    } catch {
      /* ignore */
    }
    const url = new URL(window.location.href);
    url.searchParams.delete('pad');
    url.searchParams.delete('well');
    url.searchParams.delete('stage');
    window.history.replaceState({}, '', url.pathname + (url.search || ''));

    activePadIdRef.current = null;
    setCurrentPadId(null);
    setState(null);
    setPullSheetTarget(null);
    setStartupStatus('no_pad_selected');
    setActiveTab('setup');
    refreshPadList(true);
  }, [refreshPadList]);

  const writable = useCallback(
    () => Boolean(currentPadId && currentPadId === activePadIdRef.current),
    [currentPadId]
  );

  const handleChangeSiloSand = async (siloNumber: number, sandType: string | null) => {
    if (!writable()) return;
    try {
      await updateSiloInPad(currentPadId!, siloNumber, (s) => ({ ...s, sandType }));
      showToast(`Silo ${siloNumber} set to ${sandType || 'empty'}`);
    } catch (err: any) {
      showToast(err?.message || 'Could not change sand type', 'danger');
    }
  };

  const handleChangeSiloPriority = async (siloNumber: number, priority: number | null) => {
    if (!writable()) return;
    try {
      await updateSiloInPad(currentPadId!, siloNumber, (s) => ({ ...s, manualPriority: priority }));
      showToast(
        priority !== null
          ? `Silo ${siloNumber} pinned to pull slot ${priority}`
          : `Silo ${siloNumber} back to automatic pull order`
      );
    } catch (err: any) {
      showToast(err?.message || 'Could not change pull order', 'danger');
    }
  };

  const handleClearAllSiloPriorities = async () => {
    if (!writable()) return;
    try {
      await updateSilosInPad(currentPadId!, (silos) =>
        silos.map((s) => ({ ...s, manualPriority: null }))
      );
      showToast('All manual pull-order pins cleared');
    } catch (err: any) {
      showToast(err?.message || 'Could not clear pull order', 'danger');
    }
  };

  const handleSetAllSiloPriorities = async (priorityMap: Record<number, number | null>) => {
    if (!writable()) return;
    try {
      await updateSilosInPad(currentPadId!, (silos) =>
        silos.map((s) =>
          s.siloNumber in priorityMap ? { ...s, manualPriority: priorityMap[s.siloNumber] } : s
        )
      );
      showToast('Pull sequence saved');
    } catch (err: any) {
      showToast(err?.message || 'Could not save pull sequence', 'danger');
    }
  };

  const handleToggleSiloMaintenance = async (siloNumber: number, isOutOfService: boolean) => {
    if (!writable()) return;
    try {
      await updateSiloInPad(currentPadId!, siloNumber, (s) => ({ ...s, isOutOfService }));
      showToast(
        isOutOfService
          ? `Silo ${siloNumber} marked out of service`
          : `Silo ${siloNumber} back in service`,
        isOutOfService ? 'warn' : 'ok'
      );
    } catch (err: any) {
      showToast(err?.message || 'Could not change silo status', 'danger');
    }
  };

  const handleAddDelivery = async (deliveryData: any) => {
    if (!writable()) return;
    try {
      // reassignSiloSand is a UI-only flag from the mismatch modal. The old
      // build wrote it into every delivery document — junk in a ledger that is
      // meant to be auditable for the life of the job.
      const { supervisorOverride, overrideReason, reassignSiloSand, ...ticketFields } =
        deliveryData;
      void reassignSiloSand;
      await addDeliveryTicket(currentPadId!, ticketFields, {
        supervisorOverride: !!supervisorOverride,
        overrideReason,
      });
      showToast(`Ticket ${deliveryData.ticketNumber} logged to silo ${deliveryData.siloNumber}`);
    } catch (err: any) {
      showToast(err?.message || 'Failed to add delivery ticket', 'danger');
      throw err;
    }
  };

  const handleDeleteDelivery = async (id: string, reason?: string) => {
    if (!writable()) return;
    try {
      await deleteDeliveryTicket(currentPadId!, id, reason);
      showToast('Ticket moved to the deleted log — restorable from Log → Deleted', 'warn');
    } catch (err: any) {
      showToast(err?.message || 'Failed to delete delivery ticket', 'danger');
    }
  };

  const handleRestoreDelivery = async (id: string) => {
    if (!writable()) return;
    try {
      await restoreDeliveryTicket(currentPadId!, id);
      showToast('Ticket restored to inventory');
    } catch (err: any) {
      showToast(err?.message || 'Failed to restore delivery ticket', 'danger');
    }
  };

  const handleUpdateDelivery = async (id: string, updates: any) => {
    if (!writable()) return;
    try {
      await updateDeliveryTicket(currentPadId!, id, updates);
      showToast('Ticket updated');
    } catch (err: any) {
      showToast(err?.message || 'Failed to update delivery ticket', 'danger');
      throw err;
    }
  };

  const handleRecordRun = async (records: any[], options?: { clearManualOverrides?: boolean }) => {
    if (!writable() || !state) return;
    try {
      const created = await addRunRecords(currentPadId!, records);
      const justRan = records[0]?.wellId;
      setLastRanWellId(justRan);

      const optimisticState: AppState = {
        ...state,
        runs: [...(state.runs || []), ...(created || records)],
      };

      const wellId = records[0]?.wellId;
      const stageNum = records[0]?.stageNumber;
      const isComplete =
        wellId && stageNum ? isStageComplete(optimisticState, wellId, stageNum) : true;

      const hasOverrides = state.config.silos.some(
        (s) => s.manualPriority !== null && s.manualPriority !== undefined
      );
      const shouldClear =
        options?.clearManualOverrides !== undefined
          ? options.clearManualOverrides
          : (state.config.clearManualPriorityAfterStage ?? true);

      // Stage-specific pins only clear once the stage is genuinely complete —
      // a partial pull must keep its pins or the carousel jumps mid-stage.
      if (isComplete && shouldClear && hasOverrides) {
        await updateSilosInPad(currentPadId!, (silos) =>
          silos.map((s) => ({ ...s, manualPriority: null }))
        );
      }

      if (state.config.autoAdvanceWellStage ?? true) {
        const next = getNextWellAndStage(optimisticState, justRan);
        if (next) setPullSheetTarget({ wellId: next.wellId, stageNumber: next.stageNumber });
      }

      showToast(`Stage ${records[0]?.stageNumber} recorded`);
      setPullSheetResetSignal(Date.now());
      setActiveTab('pullsheet');
    } catch (err: any) {
      showToast(err?.message || 'Failed to record stage run', 'danger');
      throw err;
    }
  };

  const handleDeleteRun = async (id: string, reason?: string) => {
    if (!writable()) return;
    try {
      await deleteRunRecord(currentPadId!, id, reason);
      showToast('Run moved to the deleted log — restorable from Log → Deleted', 'warn');
    } catch (err: any) {
      showToast(err?.message || 'Failed to delete stage run', 'danger');
    }
  };

  const handleRestoreRun = async (id: string) => {
    if (!writable()) return;
    try {
      await restoreRunRecord(currentPadId!, id);
      showToast('Run restored to calculations');
    } catch (err: any) {
      showToast(err?.message || 'Failed to restore stage run', 'danger');
    }
  };

  const handleUpdateRun = async (id: string, updates: any) => {
    if (!writable()) return;
    try {
      await updateRunRecord(currentPadId!, id, updates);
      showToast('Run updated');
    } catch (err: any) {
      showToast(err?.message || 'Failed to update stage run', 'danger');
      throw err;
    }
  };

  const handleUpdateConfig = async (newConfig: PadConfig) => {
    if (!writable()) return;
    try {
      await savePadConfig(currentPadId!, newConfig);
      showToast('Pad setup saved');
    } catch (err: any) {
      showToast(err?.message || 'Could not save pad setup', 'danger');
    }
  };

  const handleSaveProductCodeMapping = async (mineCode: string, sandType: string) => {
    if (!writable() || !state) return;
    const currentMappings = state.config.productCodeMappings || [];
    const cleanCode = mineCode.trim().toUpperCase();
    const existingIdx = currentMappings.findIndex(
      (m) => m.mineCode.trim().toUpperCase() === cleanCode
    );
    const updatedMappings = [...currentMappings];
    if (existingIdx >= 0) updatedMappings[existingIdx] = { mineCode: cleanCode, sandType };
    else updatedMappings.push({ mineCode: cleanCode, sandType });

    await savePadConfig(currentPadId!, { ...state.config, productCodeMappings: updatedMappings });
    showToast(`Product code ${cleanCode} now maps to ${sandType}`);
  };

  const navigate = useCallback((tab: Tab, opts?: { siloNumber?: number }) => {
    if (opts?.siloNumber !== undefined) setDeliveryInitialSilo(opts.siloNumber);
    setActiveTab(tab);
    setMoreOpen(false);
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, []);

  /* --------------------------------------------------------- derived UI --- */

  const summary = useMemo(
    () => (state && state.status !== 'not_found' ? getPadSummary(state) : null),
    [state?.config, state?.deliveries, state?.runs]
  );

  const effectivePadList = useMemo(() => {
    if (padList.some((p) => p.id === currentPadId)) return padList;
    if (currentPadId && state)
      return [...padList, { id: currentPadId, name: state.config?.padName || currentPadId }];
    return padList;
  }, [padList, currentPadId, state?.config?.padName]);

  const paletteItems: PaletteItem[] = useMemo(
    () =>
      NAV.map((n) => ({
        id: n.id,
        label: n.title,
        hint: n.hint,
        icon: n.icon,
        run: () => navigate(n.id),
      })),
    [navigate]
  );

  /* ------------------------------------------------------------ chrome ---- */

  const errorBanner = firebaseError ? (
    <div className="flex items-center justify-center gap-2 bg-danger-dim px-4 py-2.5 text-center text-sm text-danger ring-danger-1">
      <AlertTriangle className="size-4 shrink-0" />
      <span>{firebaseError}</span>
    </div>
  ) : null;

  const toastStack = toasts.length ? (
    <div className="pointer-events-none fixed inset-x-3 top-3 z-[90] flex flex-col items-end gap-2 sm:inset-x-auto sm:right-4">
      {toasts.map((t) => {
        const Icon = TOAST_ICON[t.tone];
        return (
          <div
            key={t.id}
            role="status"
            className={cn(
              'pointer-events-auto flex max-w-sm items-start gap-2.5 rounded-md bg-surface px-3.5 py-2.5 text-sm shadow-lg',
              TOAST_CLS[t.tone]
            )}
          >
            <Icon className="mt-0.5 size-4 shrink-0" />
            <span className="text-fg">{t.message}</span>
          </div>
        );
      })}
    </div>
  ) : null;

  /* --------------------------------------------------- 1. pinned sheet ---- */

  if (isPinnedReadOnly && state && state.status !== 'not_found') {
    return (
      <div className="min-h-dvh bg-bg text-fg">
        {errorBanner}
        {toastStack}
        <div className="mx-auto max-w-5xl px-4 pt-4 no-print">
          <div className="card flex items-center justify-between gap-3">
            <Wordmark subtitle={state.config.padName || 'Pad'} />
            <span className="badge">Read-only</span>
          </div>
        </div>
        <main className="mx-auto max-w-7xl px-4 py-4">
          <StagePullSheet
            state={state}
            initialWellId={pinnedUrlParams.wellId || undefined}
            initialStageNumber={pinnedUrlParams.stageNumber || undefined}
            isPinned
            onSuccessMessage={showToast}
          />
        </main>
      </div>
    );
  }

  /* ----------------------------------------------------- 2. kiosk mode ---- */

  const isQuickEntryMode =
    typeof window !== 'undefined' &&
    new URLSearchParams(window.location.search).get('mode') === 'entry';

  if (isQuickEntryMode && state && state.status !== 'not_found') {
    return (
      <div className="min-h-dvh bg-bg text-fg">
        {errorBanner}
        {toastStack}
        <QuickEntry
          state={state}
          onAddDelivery={async (deliveryData) => {
            await addDeliveryTicket(currentPadId!, deliveryData);
            showToast(`Ticket ${deliveryData.ticketNumber} logged to silo ${deliveryData.siloNumber}`);
          }}
          onSaveProductCodeMapping={handleSaveProductCodeMapping}
          onToast={showToast}
          onNavigateToSetup={() => {
            const url = new URL(window.location.href);
            url.searchParams.delete('mode');
            window.history.pushState({}, '', url.pathname + url.search);
            setActiveTab('setup');
          }}
        />
      </div>
    );
  }

  /* ------------------------------------------------------- 3. not found --- */

  if (state?.status === 'not_found' || startupStatus === 'pad_not_found') {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg p-4 text-fg">
        <div className="card w-full max-w-md space-y-5 text-center ring-danger-1">
          <div className="mx-auto flex size-14 items-center justify-center rounded-lg bg-danger-dim text-danger">
            <AlertTriangle className="size-6" />
          </div>
          <div className="space-y-1.5">
            <h1 className="text-lg font-medium">This job no longer exists</h1>
            <p className="text-sm text-muted">
              The pad was confirmed missing in the database. It may have been archived or removed.
            </p>
          </div>
          <button type="button" onClick={handleReturnToJobList} className="btn btn-accent w-full">
            Back to job list
          </button>
        </div>
      </div>
    );
  }

  /* --------------------------------------------------------- 4. loading --- */

  if (startupStatus === 'initializing_auth' || (startupStatus === 'loading_pad' && !state)) {
    return (
      <div className="flex min-h-dvh flex-col items-center justify-center gap-4 bg-bg p-4 text-fg">
        <Mark className="size-10" />
        <div className="text-[15px] font-semibold tracking-[0.18em]">STRATA</div>
        <div className="flex items-center gap-2 text-sm text-muted">
          <Loader2 className="size-4 animate-spin" />
          Connecting to the pad…
        </div>
        {currentPadId ? <div className="num text-xs text-subtle">{currentPadId}</div> : null}
      </div>
    );
  }

  /* ------------------------------------------------- 5. connection error -- */

  if (startupStatus === 'connection_error' && !state) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-bg p-4 text-fg">
        <div className="card w-full max-w-md space-y-5 text-center ring-warn-1">
          <div className="mx-auto flex size-14 items-center justify-center rounded-lg bg-warn-dim text-warn">
            <AlertTriangle className="size-6" />
          </div>
          <div className="space-y-1.5">
            <h1 className="text-lg font-medium">Unable to connect</h1>
            <p className="text-sm text-muted">
              {currentPadId
                ? 'Your saved job is preserved and nothing has been lost. Waiting for the database.'
                : 'Cannot reach the database. Check the connection.'}
            </p>
            {startupError ? (
              <p className="num mt-2 break-words rounded-sm bg-elevated p-2.5 text-xs text-danger">
                {startupError}
              </p>
            ) : null}
          </div>
          <div className="flex flex-col gap-2 sm:flex-row">
            <button
              type="button"
              onClick={() => {
                setStartupStatus('initializing_auth');
                setRetryTrigger((c) => c + 1);
              }}
              className="btn btn-accent flex-1"
            >
              <RefreshCw className="size-4" /> Retry
            </button>
            <button type="button" onClick={handleReturnToJobList} className="btn flex-1">
              Job list
            </button>
          </div>
        </div>
      </div>
    );
  }

  /* ------------------------------------------------------- 6. job list ---- */

  if (!currentPadId || !state) {
    return (
      <div className="min-h-dvh bg-bg text-fg">
        {errorBanner}
        {toastStack}
        <header className="sticky top-0 z-30 border-b border-border bg-bg/95 backdrop-blur-sm">
          <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3">
            <Wordmark />
            <span className="eyebrow">Job list</span>
          </div>
        </header>
        <main className="mx-auto max-w-5xl px-4 py-6">
          <Setup
            state={null}
            config={null}
            currentPadId=""
            padList={effectivePadList}
            onSelectPad={(padId) => {
              setCurrentPadId(padId);
              setActiveTab('dashboard');
            }}
            onRefreshPadList={() => refreshPadList(true)}
            onUpdateConfig={handleUpdateConfig}
            onSuccessMessage={showToast}
            onToast={showToast}
          />
        </main>
      </div>
    );
  }

  /* ------------------------------------------------------------ 7. app ---- */

  const activeEntry = NAV.find((n) => n.id === activeTab);
  const customer = state.config.wells?.[0]?.customerName || state.config.customerName;

  return (
    <div className="min-h-dvh bg-bg text-fg">
      {toastStack}

      <CommandPalette
        open={paletteOpen}
        onClose={() => setPaletteOpen(false)}
        items={paletteItems}
        state={state}
        geminiAvailable={geminiOn}
      />

      {/* desktop rail */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-[220px] flex-col border-r border-border bg-surface lg:flex no-print">
        <div className="px-4 py-4">
          <Wordmark />
        </div>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-2 pb-4">
          {NAV.map((n) => {
            const Icon = n.icon;
            const active = activeTab === n.id;
            return (
              <button
                key={n.id}
                type="button"
                onClick={() => navigate(n.id)}
                className={cn(
                  'flex h-11 w-full items-center gap-3 rounded-sm px-3 text-sm',
                  active ? 'bg-elevated text-fg' : 'text-muted hover:bg-elevated/60 hover:text-fg'
                )}
              >
                <Icon className="size-4 shrink-0" />
                <span className="flex-1 text-left">{n.title}</span>
                {n.id === 'forecast' && summary?.hasReorderAlert ? (
                  <span className="size-1.5 rounded-full bg-warn" />
                ) : null}
              </button>
            );
          })}
        </nav>
        <div className="border-t border-border px-4 py-3">
          <div className="num text-[11px] text-subtle">
            {getOperationalDate()} · {clock} CT
          </div>
        </div>
      </aside>

      <div className="lg:pl-[220px]">
        {errorBanner}

        {/* header */}
        <header className="sticky top-0 z-20 border-b border-border bg-bg/95 backdrop-blur-sm no-print">
          <div className="flex items-center gap-3 px-3 py-2.5 sm:px-5">
            <button
              type="button"
              onClick={() => setMoreOpen(true)}
              className="btn btn-ghost size-11 shrink-0 !px-0 lg:hidden"
              aria-label="Open menu"
            >
              <Menu className="size-5" />
            </button>

            <div className="min-w-0 flex-1">
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setPadMenuOpen((o) => !o)}
                  className="flex max-w-full items-center gap-1.5 text-left"
                >
                  <span className="truncate text-base font-medium">
                    {state.config.padName || 'Pad'}
                  </span>
                  {effectivePadList.length > 1 ? (
                    <ChevronDown className="size-4 shrink-0 text-muted" />
                  ) : null}
                  {summary?.hasReorderAlert ? (
                    <span className="badge badge-warn ml-1 shrink-0">Reorder</span>
                  ) : null}
                </button>

                {padMenuOpen && effectivePadList.length > 1 ? (
                  <>
                    <div
                      className="fixed inset-0 z-10"
                      onClick={() => setPadMenuOpen(false)}
                      aria-hidden
                    />
                    <div className="card-flush absolute left-0 top-full z-20 mt-1 max-h-72 w-64 overflow-auto p-1">
                      {effectivePadList.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() => {
                            setCurrentPadId(p.id);
                            setPadMenuOpen(false);
                          }}
                          className={cn(
                            'flex h-10 w-full items-center rounded-sm px-3 text-left text-sm',
                            p.id === currentPadId
                              ? 'bg-elevated text-fg'
                              : 'text-muted hover:bg-elevated/60 hover:text-fg'
                          )}
                        >
                          <span className="truncate">{p.name}</span>
                        </button>
                      ))}
                    </div>
                  </>
                ) : null}
              </div>

              <div className="truncate text-xs text-muted">
                {customer ? `${customer} · ` : ''}
                {summary ? `Next: ${summary.nextWellName} stage ${summary.nextStageNumber}` : ''}
              </div>
            </div>

            <button
              type="button"
              onClick={() => setPaletteOpen(true)}
              className="btn btn-ghost size-11 shrink-0 !px-0"
              aria-label="Open command palette"
              title="Command palette (⌘K)"
            >
              <CommandIcon className="size-5" />
            </button>
          </div>
        </header>

        <OfflineBanner
          padId={currentPadId}
          onSyncComplete={(count) =>
            showToast(`Synced ${count} queued item${count === 1 ? '' : 's'}`)
          }
        />

        <main className="mx-auto w-full max-w-7xl px-3 pb-28 pt-4 sm:px-5 lg:pb-8">
          {activeTab === 'dashboard' && (
            <Dashboard
              state={state}
              onNavigateTab={(tab, opts) => navigate(tab as Tab, opts)}
              onSelectPad={(padId) => setCurrentPadId(padId)}
            />
          )}

          {activeTab === 'board' && (
            <SiloBoard
              state={state}
              onChangeSiloSand={handleChangeSiloSand}
              onChangeSiloPriority={handleChangeSiloPriority}
              onClearAllSiloPriorities={handleClearAllSiloPriorities}
              onSetAllSiloPriorities={handleSetAllSiloPriorities}
              onToggleSiloMaintenance={handleToggleSiloMaintenance}
              onNavigateToDelivery={(siloNum) => navigate('delivery', { siloNumber: siloNum })}
              onNavigateToRun={() => navigate('run')}
              onNavigateToPullSheet={() => navigate('pullsheet')}
              onSuccessMessage={showToast}
            />
          )}

          {activeTab === 'pullsheet' && (
            <StagePullSheet
              state={state}
              targetWellId={pullSheetTarget?.wellId}
              targetStageNumber={pullSheetTarget?.stageNumber}
              onSuccessMessage={showToast}
              resetSignal={pullSheetResetSignal}
              lastRanWellId={lastRanWellId}
              onRecordRun={handleRecordRun}
              onClearAllSiloPriorities={handleClearAllSiloPriorities}
            />
          )}

          {activeTab === 'job_design' && <JobDesign state={state} />}

          {activeTab === 'progress' && <StageProgress state={state} />}

          {activeTab === 'forecast' && (
            <Forecast state={state} onNavigateTab={(tab) => navigate(tab as Tab)} />
          )}

          {activeTab === 'delivery' && (
            <AddDelivery
              state={state}
              initialSiloNumber={deliveryInitialSilo}
              onAddDelivery={handleAddDelivery}
              onDeleteDelivery={handleDeleteDelivery}
              onSaveProductCodeMapping={handleSaveProductCodeMapping}
              onChangeSiloSand={handleChangeSiloSand}
              onNavigateToSetup={() => navigate('setup')}
              onToast={showToast}
              onDone={() => navigate('board')}
              onCancel={() => navigate('board')}
            />
          )}

          {activeTab === 'run' && (
            <RecordRun state={state} onRecordRun={handleRecordRun} onCancel={() => navigate('board')} />
          )}

          {activeTab === 'logs' && (
            <Logs
              state={state}
              onDeleteDelivery={handleDeleteDelivery}
              onRestoreDelivery={handleRestoreDelivery}
              onUpdateDelivery={handleUpdateDelivery}
              onDeleteRun={handleDeleteRun}
              onRestoreRun={handleRestoreRun}
              onUpdateRun={handleUpdateRun}
              onSuccessMessage={showToast}
            />
          )}

          {activeTab === 'diagnostics' && (
            <Diagnostics state={state} onSelectPad={(padId) => setCurrentPadId(padId)} />
          )}

          {activeTab === 'setup' && (
            <Setup
              state={state}
              config={state.config}
              currentPadId={currentPadId}
              padList={padList}
              onSelectPad={(padId) => setCurrentPadId(padId)}
              onRefreshPadList={() => refreshPadList(true)}
              onUpdateConfig={handleUpdateConfig}
              onSuccessMessage={showToast}
              onToast={showToast}
            />
          )}
        </main>
      </div>

      {/* mobile bottom bar */}
      <nav className="fixed inset-x-3 bottom-3 z-30 grid grid-cols-5 rounded-lg bg-surface/95 shadow-[var(--shadow-border)] backdrop-blur-sm lg:hidden no-print">
        {NAV.filter((n) => n.primary).map((n) => {
          const Icon = n.icon;
          const active = activeTab === n.id;
          return (
            <button
              key={n.id}
              type="button"
              onClick={() => navigate(n.id)}
              className={cn(
                'flex h-16 flex-col items-center justify-center gap-1 text-[11px]',
                active ? 'text-accent' : 'text-muted'
              )}
            >
              <Icon className="size-5" />
              {n.label}
            </button>
          );
        })}
        <button
          type="button"
          onClick={() => setMoreOpen(true)}
          className={cn(
            'flex h-16 flex-col items-center justify-center gap-1 text-[11px]',
            moreOpen || !activeEntry?.primary ? 'text-accent' : 'text-muted'
          )}
        >
          <Menu className="size-5" />
          More
        </button>
      </nav>

      {/* more sheet */}
      {moreOpen && (
        <div
          className="fixed inset-0 z-40 flex items-end bg-bg/80 backdrop-blur-sm lg:hidden"
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) setMoreOpen(false);
          }}
        >
          <div className="card-flush w-full rounded-b-none p-4">
            <div className="mb-3 flex items-center justify-between">
              <Wordmark subtitle={null} markClass="size-7" />
              <button
                type="button"
                onClick={() => setMoreOpen(false)}
                className="btn btn-ghost size-10 !px-0"
                aria-label="Close"
              >
                <X className="size-5" />
              </button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {NAV.map((n) => {
                const Icon = n.icon;
                const active = activeTab === n.id;
                return (
                  <button
                    key={n.id}
                    type="button"
                    onClick={() => navigate(n.id)}
                    className={cn(
                      'flex h-20 flex-col items-center justify-center gap-1.5 rounded-sm bg-elevated text-xs',
                      active ? 'text-accent ring-accent-1' : 'text-muted'
                    )}
                  >
                    <Icon className="size-5" />
                    {n.label}
                  </button>
                );
              })}
            </div>
            <button
              type="button"
              onClick={() => {
                setMoreOpen(false);
                setPaletteOpen(true);
              }}
              className="btn mt-3 w-full"
            >
              <CommandIcon className="size-4" />
              {geminiOn ? 'Search or ask about the pad' : 'Search views'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

/**
 * Forecast — burn rate, days of cover, and the reorder decision.
 *
 * This is the screen that answers the only question a sand coordinator is
 * actually judged on: do I have enough sand, and if not, how many trucks do I
 * call and when.
 *
 * The model is disclosed on screen because a forecast nobody understands is a
 * forecast nobody trusts: burn is averaged over days that actually pumped, not
 * over calendar days, so a Sunday down doesn't quietly flatter the number.
 */

import { useMemo } from 'react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
  ReferenceLine,
} from 'recharts';
import { TrendingUp, TrendingDown, Truck, AlertTriangle, CalendarClock } from 'lucide-react';
import type { AppState } from '../types';
import { getForecast, getShiftReport } from '../lib/analytics';
import { formatLbs, formatTons } from '../lib/sandRules';
import { formatOperationalDateDisplay } from '../lib/dateUtils';
import { sandClasses, cn } from '../lib/theme';

interface Props {
  state: AppState;
  onNavigateTab?: (tab: string) => void;
}

function Stat({
  label,
  value,
  hint,
  tone,
  provisional,
}: {
  label: string;
  value: string;
  hint?: string;
  tone?: 'ok' | 'warn' | 'danger' | 'critical';
  /** Derived from too thin a sample to act on. Shown, but marked. */
  provisional?: boolean;
}) {
  return (
    <div className="card">
      <div className="flex items-center justify-between gap-2">
        <div className="eyebrow">{label}</div>
        {provisional ? <span className="badge badge-warn">Rough</span> : null}
      </div>
      <div
        className={cn(
          'stat-v mt-1.5',
          provisional && 'text-muted',
          tone === 'ok' && 'text-ok',
          tone === 'warn' && 'text-warn',
          tone === 'danger' && 'text-danger',
          tone === 'critical' && 'text-critical'
        )}
      >
        {value}
      </div>
      {hint ? <div className="mt-1 text-xs text-muted">{hint}</div> : null}
    </div>
  );
}

export default function Forecast({ state, onNavigateTab }: Props) {
  const forecast = useMemo(() => getForecast(state), [state.config, state.deliveries, state.runs]);
  const shift = useMemo(() => getShiftReport(state), [state.deliveries, state.runs]);

  const lbsPerTon = state.config.lbsPerTon || 2000;
  const lbsPerTruck = state.config.lbsPerTruckload || 57000;

  const chartData = useMemo(
    () =>
      forecast.daily.map((d) => ({
        date: d.date.slice(5),
        delivered: Math.round(d.deliveredLbs / lbsPerTon),
        pumped: Math.round(d.pumpedLbs / lbsPerTon),
      })),
    [forecast.daily, lbsPerTon]
  );

  // A burn rate from one or two pumping days is an observation, not a rate.
  // The sample job's runs all land on a couple of dates, which reads as
  // "62 stages/day, empty today" — a number that would send someone ordering
  // 600 trucks. Below three pumping days we show the figures as provisional
  // and refuse to render a projected-empty date at all.
  const confidence = forecast.burnConfidence;
  const hasBurn = forecast.burnLbsPerDay > 0;
  const trustBurn = confidence === 'ok';
  const gaining = forecast.netLbsPerDay >= 0;

  // Will the sand on hand outlast the job? The single most important comparison
  // on the page, so it gets stated as a sentence rather than left as two stats.
  const finishesOnHand =
    forecast.daysToFinishJob !== null &&
    forecast.daysOfSandLeft !== null &&
    forecast.daysOfSandLeft >= forecast.daysToFinishJob;

  const loadsToday = shift.loadsIn;
  const loadsNeeded = Math.max(0, forecast.loadsPerDayRequired - loadsToday);

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5">
      {/* header */}
      <div>
        <div className="eyebrow">Forecast</div>
        <h1 className="text-2xl font-medium tracking-tight">
          {state.config.padName || 'Pad'} — burn &amp; reorder
        </h1>
        <p className="mt-1 text-sm text-muted">
          Burn is the average of the last seven <em>pumping</em> days, not calendar days, so a day
          down does not flatter the rate. Empty and finish dates assume that rate holds.
          {forecast.samplePumpingDays > 0 ? (
            <> Based on {forecast.samplePumpingDays} pumping day{forecast.samplePumpingDays === 1 ? '' : 's'} in the last {forecast.sampleWindowDays}.</>
          ) : (
            <> No pumping recorded yet in the last {forecast.sampleWindowDays} days, so rates read as unknown.</>
          )}
        </p>
      </div>

      {/* the verdict */}
      <div
        className={cn(
          'card flex items-start gap-3',
          !trustBurn
            ? ''
            : finishesOnHand
              ? 'ring-ok-1 bg-ok-dim/20'
              : 'ring-warn-1 bg-warn-dim/20'
        )}
      >
        {trustBurn ? (
          finishesOnHand ? (
            <TrendingUp className="mt-0.5 size-5 shrink-0 text-ok" />
          ) : (
            <AlertTriangle className="mt-0.5 size-5 shrink-0 text-warn" />
          )
        ) : (
          <CalendarClock className="mt-0.5 size-5 shrink-0 text-muted" />
        )}
        <div className="min-w-0">
          {confidence === 'none' ? (
            <p className="text-sm text-muted">
              No stage runs recorded in the last {forecast.sampleWindowDays} days, so there is no
              burn rate yet. Record a stage and the rate, days of cover and projected dates populate
              here. On-hand figures below are exact regardless.
            </p>
          ) : confidence === 'low' ? (
            <p className="text-sm text-muted">
              <span className="font-medium text-warn">Not enough history to project.</span> Only{' '}
              {forecast.samplePumpingDays} of the last {forecast.sampleWindowDays} days pumped, so a
              single catch-up day would set the whole rate. The figures below are shown as a rough
              read, not a number to order sand against — work from{' '}
              <span className="num">{forecast.stagesLeftOnHand.toFixed(1)}</span> stages of cover on
              hand instead. Two more pumping days and this becomes a real forecast.
            </p>
          ) : finishesOnHand ? (
            <p className="text-sm">
              <span className="font-medium text-ok">Sand on hand outlasts the job.</span>{' '}
              {forecast.stagesRemainingInJob} stage
              {forecast.stagesRemainingInJob === 1 ? '' : 's'} remain, about{' '}
              <span className="num">{forecast.daysToFinishJob?.toFixed(1)}</span> days at{' '}
              <span className="num">{forecast.stagesPerDay.toFixed(1)}</span> stages/day, and you
              hold <span className="num">{forecast.daysOfSandLeft?.toFixed(1)}</span> days of sand.
            </p>
          ) : (
            <p className="text-sm">
              <span className="font-medium text-warn">
                You run out before the job finishes.
              </span>{' '}
              <span className="num">{forecast.daysOfSandLeft?.toFixed(1)}</span> days of sand on
              hand against <span className="num">{forecast.daysToFinishJob?.toFixed(1)}</span> days
              of work left. Still to deliver:{' '}
              <span className="num text-critical">
                {formatLbs(forecast.shortfallToFinishLbs)}
              </span>{' '}
              — about{' '}
              <span className="num text-critical">
                {forecast.truckloadsStillNeeded.toFixed(0)} loads
              </span>
              .
            </p>
          )}
        </div>
      </div>

      {/* headline stats.
          Stages on hand comes straight off the ledger and is always exact, so
          it leads. The three burn-derived tiles are marked provisional on a
          thin sample rather than quietly presented as fact. */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat
          label="Stages on pad"
          value={forecast.stagesLeftOnHand.toFixed(1)}
          hint={`${formatLbs(forecast.onHandLbs)} on hand · ${forecast.stagesRemainingInJob} stages left in job`}
        />
        <Stat
          label="Burn per day"
          value={hasBurn ? formatLbs(forecast.burnLbsPerDay) : '—'}
          hint={
            hasBurn
              ? `${formatTons(forecast.burnLbsPerDay / lbsPerTon)} · ${forecast.stagesPerDay.toFixed(1)} stages/day`
              : 'No pumping days in window'
          }
          provisional={hasBurn && !trustBurn}
        />
        <Stat
          label="Days of sand"
          value={
            trustBurn && forecast.daysOfSandLeft !== null
              ? forecast.daysOfSandLeft.toFixed(1)
              : '—'
          }
          hint={
            trustBurn && forecast.projectedEmptyDate
              ? `Empty ${formatOperationalDateDisplay(forecast.projectedEmptyDate, { month: 'short', day: 'numeric', timeZone: 'UTC' })}`
              : 'Needs three pumping days'
          }
          tone={
            trustBurn && forecast.daysOfSandLeft !== null && forecast.daysOfSandLeft < 2
              ? 'danger'
              : trustBurn && forecast.daysOfSandLeft !== null && forecast.daysOfSandLeft < 4
                ? 'warn'
                : undefined
          }
        />
        <Stat
          label="Loads/day to keep up"
          value={hasBurn ? forecast.loadsPerDayRequired.toFixed(1) : '—'}
          hint={
            hasBurn
              ? `Running ${forecast.loadsPerDay.toFixed(1)}/day · ${gaining ? 'gaining' : 'losing'} ${formatLbs(Math.abs(forecast.netLbsPerDay))}/day`
              : undefined
          }
          tone={trustBurn && !gaining ? 'warn' : undefined}
          provisional={hasBurn && !trustBurn}
        />
      </div>

      {/* today's order call. "Order 598 more loads" off a one-day sample is
          worse than saying nothing, so this only appears on a real rate. */}
      {trustBurn && (
        <div className="card flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <Truck className="mt-0.5 size-5 shrink-0 text-muted" />
            <div>
              <div className="eyebrow">Today</div>
              <p className="mt-0.5 text-sm">
                {loadsToday} load{loadsToday === 1 ? '' : 's'} in ({formatLbs(shift.deliveredLbs)}).{' '}
                {loadsNeeded > 0.5 ? (
                  <>
                    Order about{' '}
                    <span className="num font-medium text-critical">
                      {Math.ceil(loadsNeeded)} more
                    </span>{' '}
                    to break even against today's burn.
                  </>
                ) : (
                  <span className="text-ok">Deliveries are keeping up with the burn.</span>
                )}
              </p>
            </div>
          </div>
          <button type="button" className="btn" onClick={() => onNavigateTab?.('delivery')}>
            Log a load
          </button>
        </div>
      )}

      {/* flow chart */}
      <div className="card">
        <div className="card-hd">
          <div>
            <div className="eyebrow">Delivered vs pumped</div>
            <div className="text-sm text-muted">
              Last {forecast.daily.length} days, in tons. The gap between the two areas is whether
              you are building inventory or eating it.
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-3 text-[11px]">
            <span className="flex items-center gap-1.5 text-muted">
              <span className="size-2 rounded-full bg-accent" /> Delivered
            </span>
            <span className="flex items-center gap-1.5 text-muted">
              <span className="size-2 rounded-full bg-warn" /> Pumped
            </span>
          </div>
        </div>

        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={chartData} margin={{ top: 4, right: 8, bottom: 0, left: 0 }}>
              <CartesianGrid stroke="var(--color-border)" vertical={false} />
              <XAxis
                dataKey="date"
                tick={{ fill: 'var(--color-subtle)', fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                interval={1}
              />
              <YAxis
                tick={{ fill: 'var(--color-subtle)', fontSize: 11 }}
                tickLine={false}
                axisLine={false}
                width={56}
              />
              <Tooltip
                contentStyle={{
                  background: 'var(--color-surface)',
                  border: '1px solid var(--color-border)',
                  borderRadius: 8,
                  fontSize: 12,
                }}
                labelStyle={{ color: 'var(--color-muted)' }}
                formatter={(v: number, n: string) => [`${v} t`, n === 'delivered' ? 'Delivered' : 'Pumped']}
              />
              {hasBurn && (
                <ReferenceLine
                  y={Math.round(forecast.burnLbsPerDay / lbsPerTon)}
                  stroke="var(--color-warn)"
                  strokeDasharray="3 3"
                  strokeOpacity={0.6}
                />
              )}
              <Area
                type="monotone"
                dataKey="delivered"
                stroke="var(--color-accent)"
                fill="var(--color-accent-dim)"
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="pumped"
                stroke="var(--color-warn)"
                fill="var(--color-warn-dim)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* per sand type */}
      <div>
        <div className="mb-3 flex items-baseline justify-between">
          <h2 className="text-sm font-medium">Cover by sand type</h2>
          <span className="text-xs text-muted">
            Burn is split across sand types by each one's share of the per-stage design
          </span>
        </div>

        <div className="grid gap-3 md:grid-cols-2">
          {forecast.sandTypeRows.map((row) => {
            const tone = sandClasses(row.sandType, state.config.sandTypes);
            const critical = row.shortfallLbs > 0;
            // The status badge must never contradict the days figure beside
            // it. A can that empties inside a day is not "Covered" whatever
            // the stage-based reorder threshold says.
            const emptySoon = trustBurn && row.daysOfCover !== null && row.daysOfCover < 1;
            const short = critical || emptySoon;
            const reorder = row.isReorder || (trustBurn && (row.daysOfCover ?? 99) < 2);
            return (
              <div
                key={row.sandType}
                className={cn('card', short ? 'ring-danger-1' : reorder ? 'ring-warn-1' : '')}
              >
                <div className="card-hd">
                  <div className="flex items-center gap-2">
                    <span className={cn('size-2.5 rounded-full', tone.fill)} />
                    <span className={cn('text-sm font-medium', tone.text)}>{row.sandType}</span>
                  </div>
                  <span
                    className={cn(
                      'badge',
                      short ? 'badge-danger' : reorder ? 'badge-warn' : 'badge-ok'
                    )}
                  >
                    {critical ? 'Short' : emptySoon ? 'Out today' : reorder ? 'Reorder' : 'Covered'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <div className="eyebrow">On hand</div>
                    <div className="num mt-0.5 text-xl">{formatLbs(row.onHandLbs)}</div>
                    <div className="text-xs text-muted">
                      {row.stagesLeft.toFixed(1)} stages of cover
                    </div>
                  </div>
                  <div>
                    <div className="eyebrow">Runs out</div>
                    <div className={cn('num mt-0.5 text-xl', !trustBurn && 'text-muted')}>
                      {trustBurn && row.daysOfCover !== null ? `${row.daysOfCover.toFixed(1)} d` : '—'}
                    </div>
                    <div className="text-xs text-muted">
                      {trustBurn && row.projectedEmptyDate
                        ? formatOperationalDateDisplay(row.projectedEmptyDate, {
                            weekday: 'short',
                            month: 'short',
                            day: 'numeric',
                            timeZone: 'UTC',
                          })
                        : 'Needs three pumping days'}
                    </div>
                  </div>
                </div>

                <div className="divider my-3" />

                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted">Remaining in design</span>
                  <span className="num">{formatLbs(row.remainingInDesignLbs)}</span>
                </div>
                <div className="mt-1 flex items-center justify-between text-xs">
                  <span className="text-muted">Loads still needed</span>
                  <span className="num">{row.truckloadsNeeded.toFixed(1)}</span>
                </div>

                {critical && (
                  <div className="mt-3 flex items-start gap-2 rounded-sm bg-danger-dim px-3 py-2 text-xs text-danger">
                    <AlertTriangle className="mt-0.5 size-3.5 shrink-0" />
                    <span>
                      Short {formatLbs(row.shortfallLbs)} for the next stage. That is{' '}
                      {(row.shortfallLbs / lbsPerTruck).toFixed(1)} loads, needed before the pull.
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* closing summary */}
      <div className="card">
        <div className="eyebrow mb-2">In plain terms</div>
        <p className="text-sm leading-relaxed text-muted">
          {trustBurn ? (
            <>
              This pad is burning{' '}
              <span className="num text-fg">{formatLbs(forecast.burnLbsPerDay)}</span> a day —{' '}
              <span className="num text-fg">{forecast.stagesPerDay.toFixed(1)}</span> stages, or{' '}
              <span className="num text-fg">{forecast.loadsPerDayRequired.toFixed(1)}</span> truckloads.
              You hold <span className="num text-fg">{formatLbs(forecast.onHandLbs)}</span>, which
              is <span className="num text-fg">{forecast.stagesLeftOnHand.toFixed(1)}</span> stages.
              {forecast.shortfallToFinishLbs > 0 ? (
                <>
                  {' '}
                  Finishing the job needs another{' '}
                  <span className="num text-critical">
                    {formatLbs(forecast.shortfallToFinishLbs)}
                  </span>{' '}
                  beyond what is on location —{' '}
                  <span className="num text-critical">
                    {forecast.truckloadsStillNeeded.toFixed(0)}
                  </span>{' '}
                  loads over the{' '}
                  <span className="num text-fg">
                    {forecast.daysToFinishJob?.toFixed(0) ?? '—'}
                  </span>{' '}
                  days of work remaining.
                </>
              ) : (
                <> Everything the job still needs is already on location.</>
              )}
            </>
          ) : (
            <>
              You hold <span className="num text-fg">{formatLbs(forecast.onHandLbs)}</span> on
              location, which is{' '}
              <span className="num text-fg">{forecast.stagesLeftOnHand.toFixed(1)}</span> stages
              against <span className="num text-fg">{forecast.stagesRemainingInJob}</span> still to
              pump. The whole job still needs{' '}
              <span className="num text-fg">{formatLbs(forecast.lbsRemainingInJob)}</span>
              {forecast.shortfallToFinishLbs > 0 ? (
                <>
                  , of which{' '}
                  <span className="num text-critical">
                    {formatLbs(forecast.shortfallToFinishLbs)}
                  </span>{' '}
                  is not yet on location — about{' '}
                  <span className="num text-critical">
                    {forecast.truckloadsStillNeeded.toFixed(0)}
                  </span>{' '}
                  loads
                </>
              ) : (
                <>, all of which is already here</>
              )}
              . Record{' '}
              {Math.max(1, 3 - forecast.samplePumpingDays)} more day
              {3 - forecast.samplePumpingDays === 1 ? '' : 's'} of stage runs and this paragraph
              gains the burn rate, the days of cover and a projected finish date — the version to
              read out on a call.
            </>
          )}
        </p>
      </div>
    </div>
  );
}

import {
  collection,
  doc,
  getDoc,
  getDocs,
  writeBatch,
  deleteDoc,
  setDoc,
} from 'firebase/firestore';
import { db } from './firebase';
import { JobImportPackage } from '../types/import';
import { normalizeTicketNumber } from './ticketUtils';

// The University 40E sample job is ~176 KB of TypeScript literals. It used to
// be a static import, so every crew on every pad downloaded one demo job's
// tickets and runs before the first screen painted. It loads on demand now —
// restoring the sample is a rare and deliberate action.
async function loadUniversity40E() {
  const [config, c1, c2, c3, runs] = await Promise.all([
    import('../data/university40eData'),
    import('../data/deliveriesChunk1'),
    import('../data/deliveriesChunk2'),
    import('../data/deliveriesChunk3'),
    import('../data/runsData'),
  ]);
  return {
    university40ePadConfig: config.university40ePadConfig,
    deliveries: [...c1.deliveriesChunk1, ...c2.deliveriesChunk2, ...c3.deliveriesChunk3],
    university40eRuns: runs.university40eRuns,
  };
}

export const UNIVERSITY_40E_PAD_ID = 'pad-university-40e';

export async function importJobPackage(
  pkg: JobImportPackage,
  onProgress?: (status: string, percent: number) => void
): Promise<{ padId: string; deliveriesCount: number; runsCount: number }> {
  const padId = pkg.padId || UNIVERSITY_40E_PAD_ID;
  if (onProgress) onProgress('Saving Pad Configuration...', 10);

  // Clear tombstone if previously deleted
  try {
    await deleteDoc(doc(db, 'deletedPads', padId));
  } catch (_) {}

  // 1. Explicitly create/save parent Pad Config document FIRST
  const padDocRef = doc(db, 'pads', padId);
  await setDoc(padDocRef, {
    config: pkg.config,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }, { merge: true });

  // 2. Deliveries in chunks of 200 (writing delivery doc + ticketNumbers index doc)
  const BATCH_SIZE = 200;
  const totalDeliveries = pkg.deliveries.length;
  
  if (onProgress) onProgress(`Writing ${totalDeliveries} delivery records...`, 20);

  for (let i = 0; i < totalDeliveries; i += BATCH_SIZE) {
    const chunk = pkg.deliveries.slice(i, i + BATCH_SIZE);
    const batch = writeBatch(db);

    for (const del of chunk) {
      const delDocRef = doc(db, 'pads', padId, 'deliveries', del.id);
      batch.set(delDocRef, {
        ...del,
        importedAt: Date.now(),
      });

      const norm = normalizeTicketNumber(del.ticketNumber || '');
      if (norm) {
        const tktRef = doc(db, 'pads', padId, 'ticketNumbers', norm);
        batch.set(tktRef, {
          deliveryId: del.id,
          ticketNumber: norm,
          createdAt: del.createdAt || Date.now(),
          deleted: del.deleted || false,
        });
      }
    }

    await batch.commit();
    const progressPct = 20 + Math.round(((i + chunk.length) / totalDeliveries) * 45);
    if (onProgress) onProgress(`Saved ${Math.min(i + BATCH_SIZE, totalDeliveries)} / ${totalDeliveries} deliveries...`, progressPct);
  }

  // 3. Runs in chunks of 350
  const totalRuns = pkg.runs.length;
  if (onProgress) onProgress(`Writing ${totalRuns} stage runs...`, 70);

  for (let i = 0; i < totalRuns; i += BATCH_SIZE) {
    const chunk = pkg.runs.slice(i, i + BATCH_SIZE);
    const batch = writeBatch(db);

    for (const run of chunk) {
      const runDocRef = doc(db, 'pads', padId, 'runs', run.id);
      batch.set(runDocRef, {
        ...run,
        importedAt: Date.now(),
      });
    }

    await batch.commit();
    const progressPct = 70 + Math.round(((i + chunk.length) / Math.max(totalRuns, 1)) * 25);
    if (onProgress) onProgress(`Saved ${Math.min(i + BATCH_SIZE, totalRuns)} / ${totalRuns} stage runs...`, progressPct);
  }

  if (onProgress) onProgress('Import complete!', 100);

  return {
    padId,
    deliveriesCount: totalDeliveries,
    runsCount: totalRuns,
  };
}

export async function restoreUniversity40E(
  onProgress?: (status: string, percent: number) => void
): Promise<{ padId: string; deliveriesCount: number; runsCount: number }> {
  if (onProgress) onProgress('Loading sample job data...', 4);
  const { university40ePadConfig, deliveries, university40eRuns } = await loadUniversity40E();

  const pkg: JobImportPackage = {
    version: 1,
    source: 'University 40E SandTracker Data Restore',
    exportedAt: new Date().toISOString(),
    padId: UNIVERSITY_40E_PAD_ID,
    config: university40ePadConfig,
    deliveries,
    runs: university40eRuns,
  };

  return await importJobPackage(pkg, onProgress);
}

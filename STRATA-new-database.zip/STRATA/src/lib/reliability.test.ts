import { describe, it, expect } from 'vitest';
import {
  getEffectivePerStageDesign,
  getSiloDerivedStates,
  getNextWellAndStage,
  sortStageRunsByActualSequence,
  isStageComplete,
} from './sandRules';
import { AppState, PadConfig, WellConfig, RunRecord } from '../types';

const testPadConfig: PadConfig = {
  padName: 'Reliability Pad Alpha',
  customerName: 'Permian Operator',
  siloCount: 6,
  lbsPerTruckload: 57000,
  lbsPerTon: 2000,
  drawStrategy: 'sequential_rotation',
  partialThresholdPct: 0.75,
  reorderThresholdStages: 5,
  autoAdvanceWellStage: true,
  clearManualPriorityAfterStage: true,
  sandTypes: [
    { id: 'st-1', name: '100 mesh', perStageDesignLbs: 300000, colorCategory: 'amber' },
    { id: 'st-2', name: '40/70', perStageDesignLbs: 100000, colorCategory: 'emerald' },
  ],
  wells: [
    { id: 'w-1', name: 'Well 1H', plannedStages: 40 },
    {
      id: 'w-2',
      name: 'Well 2H',
      plannedStages: 40,
      perStageDesignOverrides: {
        '100 mesh': 350000,
        '40/70': 50000,
      },
    },
  ],
  silos: [
    { siloNumber: 1, sandType: '100 mesh', side: 'A', maxCapacityLbs: 350000, startingBalanceLbs: 300000, manualPriority: null, isOutOfService: false },
    { siloNumber: 2, sandType: '100 mesh', side: 'A', maxCapacityLbs: 350000, startingBalanceLbs: 300000, manualPriority: null, isOutOfService: false },
    { siloNumber: 3, sandType: '100 mesh', side: 'A', maxCapacityLbs: 350000, startingBalanceLbs: 300000, manualPriority: null, isOutOfService: false },
    { siloNumber: 4, sandType: '40/70', side: 'B', maxCapacityLbs: 350000, startingBalanceLbs: 200000, manualPriority: null, isOutOfService: false },
    { siloNumber: 5, sandType: '40/70', side: 'B', maxCapacityLbs: 350000, startingBalanceLbs: 200000, manualPriority: null, isOutOfService: false },
    { siloNumber: 6, sandType: '40/70', side: 'B', maxCapacityLbs: 350000, startingBalanceLbs: 200000, manualPriority: null, isOutOfService: false },
  ],
};

function createMockState(overrides?: Partial<AppState>): AppState {
  return {
    padId: 'rel-pad-1',
    config: { ...testPadConfig, ...overrides?.config },
    deliveries: overrides?.deliveries || [],
    runs: overrides?.runs || [],
  };
}

describe('Reliability - Stage Partial vs Complete Logic', () => {
  it('correctly evaluates complete stage with 1 lb tolerance when total pumped reaches design', () => {
    const well = testPadConfig.wells[0]; // w-1: 300k 100 mesh, 100k 40/70
    const sandType100 = testPadConfig.sandTypes[0];
    const design = getEffectivePerStageDesign(well, sandType100);

    const totalPumpedFull = 300000;
    const isCompleteFull = totalPumpedFull >= (design - 1);
    expect(isCompleteFull).toBe(true);

    const totalPumpedSlightlyUnderTolerance = 299999;
    const isCompleteTolerance = totalPumpedSlightlyUnderTolerance >= (design - 1);
    expect(isCompleteTolerance).toBe(true);

    const totalPumpedPartial = 250000;
    const isCompletePartial = totalPumpedPartial >= (design - 1);
    expect(isCompletePartial).toBe(false);
  });

  it('handles multi-sand stage completion where both sands must satisfy their effective designs', () => {
    const well = testPadConfig.wells[1]; // w-2: 350k 100 mesh, 50k 40/70
    const sand100 = testPadConfig.sandTypes[0];
    const sand4070 = testPadConfig.sandTypes[1];

    const design100 = getEffectivePerStageDesign(well, sand100);
    const design4070 = getEffectivePerStageDesign(well, sand4070);

    expect(design100).toBe(350000);
    expect(design4070).toBe(50000);

    // Scenario A: 100 mesh met, 40/70 partial
    const pumped100A = 350000;
    const pumped4070A = 20000;
    const isAllCompleteA = (pumped100A >= design100 - 1) && (pumped4070A >= design4070 - 1);
    expect(isAllCompleteA).toBe(false);

    // Scenario B: both met
    const pumped100B = 350000;
    const pumped4070B = 50000;
    const isAllCompleteB = (pumped100B >= design100 - 1) && (pumped4070B >= design4070 - 1);
    expect(isAllCompleteB).toBe(true);
  });

  it('does not block completion if a sand type has 0 required lbs for the well', () => {
    const wellZeroSand: WellConfig = {
      id: 'w-zero',
      name: 'Zero 40/70 Well',
      plannedStages: 40,
      perStageDesignOverrides: {
        '100 mesh': 300000,
        '40/70': 0,
      },
    };

    const design100 = getEffectivePerStageDesign(wellZeroSand, testPadConfig.sandTypes[0]);
    const design4070 = getEffectivePerStageDesign(wellZeroSand, testPadConfig.sandTypes[1]);

    const pumped100 = 300000;
    const pumped4070 = 0;

    const is100Complete = design100 <= 0 || pumped100 >= (design100 - 1);
    const is4070Complete = design4070 <= 0 || pumped4070 >= (design4070 - 1);

    expect(is100Complete && is4070Complete).toBe(true);
  });
});

describe('Reliability - Run Sequence Across Multiple Partial Submissions', () => {
  it('continues runSequence across multiple partial submissions for the same well and stage', () => {
    const firstSubmissionRuns: RunRecord[] = [
      {
        id: 'run-1',
        wellId: 'w-1',
        stageNumber: 1,
        siloNumber: 2,
        sandType: '100 mesh',
        lbsPulled: 150000,
        date: '2026-08-25',
        deleted: false,
        runSequence: 1,
        submissionId: 'sub-1',
        createdAt: 1000,
      },
      {
        id: 'run-2',
        wellId: 'w-1',
        stageNumber: 1,
        siloNumber: 3,
        sandType: '100 mesh',
        lbsPulled: 50000,
        date: '2026-08-25',
        deleted: false,
        runSequence: 2,
        submissionId: 'sub-1',
        createdAt: 2000,
      },
    ];

    // Compute max sequence for next partial submission
    const existingSeqs = firstSubmissionRuns
      .map((r) => r.runSequence)
      .filter((s): s is number => typeof s === 'number');
    const maxSeq = Math.max(...existingSeqs, firstSubmissionRuns.length);
    expect(maxSeq).toBe(2);

    // Second partial submission starting at maxSeq + 1
    const secondSubmissionRuns: RunRecord[] = [
      {
        id: 'run-3',
        wellId: 'w-1',
        stageNumber: 1,
        siloNumber: 3,
        sandType: '100 mesh',
        lbsPulled: 100000,
        date: '2026-08-25',
        deleted: false,
        runSequence: maxSeq + 1,
        submissionId: 'sub-2',
        createdAt: 3000,
      },
      {
        id: 'run-4',
        wellId: 'w-1',
        stageNumber: 1,
        siloNumber: 4,
        sandType: '40/70',
        lbsPulled: 100000,
        date: '2026-08-25',
        deleted: false,
        runSequence: maxSeq + 2,
        submissionId: 'sub-2',
        createdAt: 4000,
      },
    ];

    expect(secondSubmissionRuns[0].runSequence).toBe(3);
    expect(secondSubmissionRuns[1].runSequence).toBe(4);

    const allRuns = [...firstSubmissionRuns, ...secondSubmissionRuns];
    const sorted = sortStageRunsByActualSequence(allRuns);

    expect(sorted.map((r) => r.runSequence)).toEqual([1, 2, 3, 4]);
  });

  it('correctly handles mixed legacy records and new records with explicit runSequence', () => {
    const legacyRuns: RunRecord[] = [
      {
        id: 'legacy-1',
        wellId: 'w-1',
        stageNumber: 1,
        siloNumber: 1,
        sandType: '100 mesh',
        lbsPulled: 100000,
        date: '2026-08-20',
        deleted: false,
        createdAt: 100,
      },
      {
        id: 'legacy-2',
        wellId: 'w-1',
        stageNumber: 1,
        siloNumber: 2,
        sandType: '100 mesh',
        lbsPulled: 100000,
        date: '2026-08-20',
        deleted: false,
        createdAt: 200,
      },
    ];

    const newRuns: RunRecord[] = [
      {
        id: 'new-1',
        wellId: 'w-1',
        stageNumber: 1,
        siloNumber: 3,
        sandType: '100 mesh',
        lbsPulled: 100000,
        date: '2026-08-25',
        deleted: false,
        runSequence: 3,
        createdAt: 500,
      },
    ];

    const sorted = sortStageRunsByActualSequence([...newRuns, ...legacyRuns]);
    expect(sorted[0].id).toBe('legacy-1');
    expect(sorted[1].id).toBe('legacy-2');
    expect(sorted[2].id).toBe('new-1');
  });
});

describe('Reliability - First Incomplete Stage Iteration in Zipper Order', () => {
  it('finds the first incomplete stage when stages are completed out of order or sequentially', () => {
    const state = createMockState({
      runs: [
        // Well 1H Stage 1 complete
        {
          id: 'r1',
          wellId: 'w-1',
          stageNumber: 1,
          siloNumber: 1,
          sandType: '100 mesh',
          lbsPulled: 300000,
          date: '2026-08-25',
          deleted: false,
          createdAt: 1000,
        },
        {
          id: 'r2',
          wellId: 'w-1',
          stageNumber: 1,
          siloNumber: 4,
          sandType: '40/70',
          lbsPulled: 100000,
          date: '2026-08-25',
          deleted: false,
          createdAt: 2000,
        },
        // Well 1H Stage 2 partial
        {
          id: 'r3',
          wellId: 'w-1',
          stageNumber: 2,
          siloNumber: 2,
          sandType: '100 mesh',
          lbsPulled: 150000,
          date: '2026-08-25',
          deleted: false,
          createdAt: 3000,
        },
      ],
    });

    expect(isStageComplete(state, 'w-1', 1)).toBe(true);
    expect(isStageComplete(state, 'w-1', 2)).toBe(false);

    const next = getNextWellAndStage(state);
    expect(next?.wellId).toBe('w-1');
    expect(next?.stageNumber).toBe(2);
  });
});


/**
 * Deliveries by day.
 *
 * One card per operational date, newest first, INCLUDING days with no loads —
 * a missing Sunday looks identical to a Sunday nobody logged, and only one of
 * those is a problem. Every day therefore renders, and a zero day says so.
 *
 * Sand colors come from `sandClasses` only. The old build sniffed the mesh
 * name inline here and disagreed with the board.
 */

import { Calendar, Truck, ChevronDown, ChevronUp } from 'lucide-react';
import { useMemo, useState } from 'react';
import { formatLbs, formatTons, formatTruckloads } from '../lib/sandRules';
import {
  getOperationalDate,
  formatOperationalDateDisplay,
  parseDateParts,
} from '../lib/dateUtils';
import { sandClasses, cn } from '../lib/theme';
import { AppState, DeliveryTicket } from '../types';

interface DeliveriesByDayProps {
  state: AppState;
}

const RANGES = [7, 14, 30, 90];

export default function DeliveriesByDay({ state }: DeliveriesByDayProps) {
  const { config, deliveries } = state;
  const lbsPerTon = config.lbsPerTon || 2000;
  const lbsPerTruckload = config.lbsPerTruckload || 57000;

  const [expandedDays, setExpandedDays] = useState<Record<string, boolean>>({});
  const [dayRangeFilter, setDayRangeFilter] = useState<number>(14);

  const todayStr = getOperationalDate();

  /* One pass over the ledger, keyed on the ledger. Re-expanding a day or
     switching the range must not re-bucket every ticket on the job. */
  const deliveriesByDayMap = useMemo(() => {
    const map: Record<string, DeliveryTicket[]> = {};
    for (const d of deliveries) {
      if (!map[d.date]) map[d.date] = [];
      map[d.date].push(d);
    }
    return map;
  }, [deliveries]);

  /* Date bounds + the full descending sequence. Depends on the range control,
     so it is deliberately keyed on it as well. */
  const dateList = useMemo<string[]>(() => {
    const deliveryDates = deliveries.map((d) => d.date).filter(Boolean);
    let maxDateStr = todayStr;
    let minDateStr = todayStr;

    if (deliveryDates.length > 0) {
      const sortedDates = [...deliveryDates].sort();
      if (sortedDates[sortedDates.length - 1] > maxDateStr) {
        maxDateStr = sortedDates[sortedDates.length - 1];
      }
      minDateStr = sortedDates[0];
    }

    const dates: string[] = [];
    const maxParts = parseDateParts(maxDateStr);
    const minParts = parseDateParts(minDateStr);
    if (!maxParts || !minParts) return [todayStr];

    const current = new Date(Date.UTC(maxParts.year, maxParts.month - 1, maxParts.day, 12, 0, 0));
    const start = new Date(Date.UTC(minParts.year, minParts.month - 1, minParts.day, 12, 0, 0));

    const todayParts = parseDateParts(todayStr) || maxParts;
    const filterLimitDate = new Date(
      Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day, 12, 0, 0)
    );
    filterLimitDate.setUTCDate(filterLimitDate.getUTCDate() - (dayRangeFilter - 1));

    const effectiveStartDate = start < filterLimitDate ? filterLimitDate : start;

    while (current >= effectiveStartDate) {
      const yyyy = current.getUTCFullYear();
      const mm = String(current.getUTCMonth() + 1).padStart(2, '0');
      const dd = String(current.getUTCDate()).padStart(2, '0');
      dates.push(`${yyyy}-${mm}-${dd}`);
      current.setUTCDate(current.getUTCDate() - 1);
    }

    return dates;
  }, [deliveries, dayRangeFilter, todayStr]);

  const formatDateDisplay = (dateStr: string): { main: string; relative: string } => {
    const main = formatOperationalDateDisplay(dateStr, {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });

    if (dateStr === todayStr) return { main, relative: 'Today' };

    const todayParts = parseDateParts(todayStr);
    if (todayParts) {
      const yesterday = new Date(
        Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day - 1, 12, 0, 0)
      );
      const yyyy = yesterday.getUTCFullYear();
      const mm = String(yesterday.getUTCMonth() + 1).padStart(2, '0');
      const dd = String(yesterday.getUTCDate()).padStart(2, '0');
      if (dateStr === `${yyyy}-${mm}-${dd}`) return { main, relative: 'Yesterday' };
    }

    return { main, relative: '' };
  };

  const toggleDayExpansion = (dateStr: string) => {
    setExpandedDays((prev) => ({ ...prev, [dateStr]: !prev[dateStr] }));
  };

  return (
    <div className="flex w-full flex-col gap-5">
      {/* ------------------------------------------------------- header --- */}
      <div className="card">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div className="flex items-start gap-3">
            <Calendar className="mt-1 size-5 shrink-0 text-accent" />
            <div>
              <div className="eyebrow">Sand intake</div>
              <h1 className="text-2xl font-medium tracking-tight">Deliveries by day</h1>
              <p className="max-w-2xl text-sm text-muted">
                Newest first, bucketed by operational date · a day with no loads still gets a
                row so a missed shift is visible · loads convert at{' '}
                <span className="num">{lbsPerTruckload.toLocaleString()}</span> lbs per truckload.
              </p>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-1 self-start rounded-sm bg-elevated p-1 ring-border">
            {RANGES.map((days) => (
              <button
                key={days}
                type="button"
                onClick={() => setDayRangeFilter(days)}
                className={cn(
                  'tap h-9 rounded-xs px-3 text-xs font-medium transition-colors duration-150',
                  dayRangeFilter === days
                    ? 'bg-accent text-accent-fg'
                    : 'text-muted hover:text-fg'
                )}
              >
                Past <span className="num">{days}</span>d
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ---------------------------------------------------- day cards --- */}
      <div className="flex flex-col gap-3">
        {dateList.length === 0 ? (
          <div className="card text-center">
            <Truck className="mx-auto size-8 text-subtle" />
            <p className="mt-2 text-sm font-medium">No deliveries found</p>
            <p className="text-xs text-muted">
              Record ticket entries to see daily sand intake.
            </p>
          </div>
        ) : (
          dateList.map((dateStr) => {
            const dayTickets = deliveriesByDayMap[dateStr] || [];
            const hasDeliveries = dayTickets.length > 0;
            const dayTotalLbs = dayTickets.reduce((sum, t) => sum + (t.lbs || 0), 0);
            const dayTotalTons = dayTotalLbs / lbsPerTon;
            const dayTotalLoads = dayTickets.length;
            const dateLabel = formatDateDisplay(dateStr);
            const isExpanded = !!expandedDays[dateStr];

            const sandTypeBreakdown = config.sandTypes.map((st) => {
              const typeTickets = dayTickets.filter((t) => t.sandType === st.name);
              const typeLbs = typeTickets.reduce((sum, t) => sum + (t.lbs || 0), 0);
              return {
                sandType: st.name,
                lbs: typeLbs,
                tons: typeLbs / lbsPerTon,
                loads: typeTickets.length,
              };
            });

            return (
              <div
                key={dateStr}
                className={cn(
                  'card-flush overflow-hidden',
                  !hasDeliveries && 'opacity-70'
                )}
              >
                {/* day header */}
                <div className="flex flex-col gap-4 p-4 md:flex-row md:items-center md:justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className={cn(
                        'num flex size-11 shrink-0 items-center justify-center rounded-sm text-lg font-semibold',
                        hasDeliveries ? 'bg-accent text-accent-fg' : 'bg-elevated text-subtle'
                      )}
                    >
                      {dateStr.split('-')[2]}
                    </div>

                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-base font-medium">{dateLabel.main}</span>
                        {dateLabel.relative ? (
                          <span className="badge badge-accent">{dateLabel.relative}</span>
                        ) : null}
                      </div>
                      <div className="eyebrow mt-1">
                        Date code <span className="num">{dateStr}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex shrink-0 flex-wrap items-center justify-between gap-3 md:justify-end">
                    {hasDeliveries ? (
                      <>
                        <div className="rounded-sm bg-elevated px-3 py-2 text-right ring-border">
                          <div className="eyebrow">Delivered</div>
                          <div className="num mt-0.5 text-lg font-semibold">
                            {formatLbs(dayTotalLbs)}
                          </div>
                          <div className="num text-xs text-muted">
                            {formatTons(dayTotalTons)}
                          </div>
                        </div>

                        <div className="rounded-sm bg-elevated px-3 py-2 text-right ring-border">
                          <div className="eyebrow">Loads in</div>
                          <div className="num mt-0.5 text-lg font-semibold">{dayTotalLoads}</div>
                          <div className="num text-xs text-muted">
                            {formatTruckloads(dayTotalLbs, lbsPerTruckload)}
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={() => toggleDayExpansion(dateStr)}
                          className="btn"
                        >
                          {isExpanded ? (
                            <>
                              <span>Hide tickets</span>
                              <ChevronUp className="size-4 text-accent" />
                            </>
                          ) : (
                            <>
                              <span>
                                View tickets (<span className="num">{dayTickets.length}</span>)
                              </span>
                              <ChevronDown className="size-4 text-accent" />
                            </>
                          )}
                        </button>
                      </>
                    ) : (
                      <div className="flex items-center gap-2 rounded-sm bg-elevated px-3 py-2 text-xs text-muted ring-border">
                        <span className="size-2 rounded-full bg-subtle" />
                        No deliveries logged · <span className="num">0</span> lbs ·{' '}
                        <span className="num">0</span> loads
                      </div>
                    )}
                  </div>
                </div>

                <div className="divider" />

                {/* per sand type */}
                <div className="p-4">
                  <div className="eyebrow mb-2.5">Sand type intake</div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
                    {sandTypeBreakdown.map((st) => {
                      const tone = sandClasses(st.sandType, config.sandTypes);
                      const live = st.loads > 0;
                      return (
                        <div
                          key={st.sandType}
                          className={cn(
                            'flex items-center justify-between gap-3 rounded-sm bg-elevated p-3',
                            live ? tone.ring : 'opacity-60 ring-border'
                          )}
                        >
                          <div>
                            <div className="flex items-center gap-1.5">
                              <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                              <span className={cn('text-xs font-medium', tone.text)}>
                                {st.sandType}
                              </span>
                            </div>
                            <div className="num mt-0.5 text-[11px] text-muted">
                              {st.loads} {st.loads === 1 ? 'truckload' : 'truckloads'}
                            </div>
                          </div>

                          <div className="text-right">
                            <div
                              className={cn(
                                'num text-sm font-semibold',
                                live ? 'text-fg' : 'text-subtle'
                              )}
                            >
                              {formatLbs(st.lbs)}
                            </div>
                            <div className="num text-[11px] text-muted">
                              {formatTons(st.tons)}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* expanded ticket list */}
                {hasDeliveries && isExpanded ? (
                  <>
                    <div className="divider" />
                    <div className="space-y-2 p-4">
                      <div className="eyebrow">
                        Tickets logged on <span className="num">{dateStr}</span>
                      </div>

                      {dayTickets.map((t) => {
                        const tone = sandClasses(t.sandType, config.sandTypes);
                        return (
                          <div
                            key={t.id}
                            className="flex flex-wrap items-center justify-between gap-3 rounded-sm bg-elevated p-3 text-xs ring-border"
                          >
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="num text-sm font-semibold text-accent">
                                #{t.ticketNumber}
                              </span>
                              <span className="badge">
                                Silo <span className="num">{t.siloNumber}</span>
                              </span>
                              <span className={cn('badge', tone.dim, tone.text)}>
                                {t.sandType}
                              </span>
                              <span className="text-muted">
                                {t.supplier || 'No supplier'}
                              </span>
                              {t.createdAt ? (
                                <span className="num text-[11px] text-subtle">
                                  Logged{' '}
                                  {new Date(t.createdAt).toLocaleTimeString([], {
                                    hour: 'numeric',
                                    minute: '2-digit',
                                    second: '2-digit',
                                  })}
                                </span>
                              ) : null}
                            </div>

                            <div className="num text-sm font-semibold">
                              {formatLbs(t.lbs)}{' '}
                              <span className="text-xs font-normal text-muted">
                                {formatTons(t.lbs / lbsPerTon)}
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </>
                ) : null}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}

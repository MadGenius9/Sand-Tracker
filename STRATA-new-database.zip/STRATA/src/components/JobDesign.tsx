/**
 * Job design — the whole-job frac numbers and the cross-check against them.
 *
 * Two independent statements of the same job live in the config: the whole-job
 * `jobDesignTotalLbs` from the frac design, and planned stages × per-stage
 * design (with per-well overrides). When they disagree by more than 2% one of
 * them is wrong, and a truck gets ordered against the wrong one — so the drift
 * is the headline, not a footnote.
 */

import { AlertTriangle, CheckCircle2, FileSpreadsheet, Truck } from 'lucide-react';
import { useMemo } from 'react';
import { AppState } from '../types';
import {
  calculateJobDesignMetrics,
  calculateDeliveredBySupplier,
  formatLbsNumber,
} from '../lib/sandRules';
import { sandClasses, cn } from '../lib/theme';

interface JobDesignProps {
  state: AppState;
}

export default function JobDesign({ state }: JobDesignProps) {
  const { config, deliveries, runs } = state;
  const lbsPerTon = config.lbsPerTon || 2000;
  const sandTypes = config.sandTypes || [];

  /* Both of these walk every delivery and every run. Memoized on the slices
     they read so the cards do not recompute the pad on a re-render. */
  const metrics = useMemo(
    () => calculateJobDesignMetrics(state),
    [config, deliveries, runs]
  );
  const supplierRows = useMemo(() => calculateDeliveredBySupplier(state), [config, deliveries]);

  const flaggedMetrics = useMemo(
    () => metrics.filter((m) => m.hasCrossCheckFlag),
    [metrics]
  );

  const headline = useMemo(
    () => ({
      designLbs: metrics.reduce((s, m) => s + m.jobDesignTotalLbs, 0),
      deliveredLbs: metrics.reduce((s, m) => s + m.deliveredSoFarLbs, 0),
      pumpedLbs: metrics.reduce((s, m) => s + m.pumpedSoFarLbs, 0),
    }),
    [metrics]
  );

  const supplierTotals = useMemo(
    () => ({
      lbs: supplierRows.reduce((s, r) => s + r.totalLbs, 0),
      loads: supplierRows.reduce((s, r) => s + r.loadCount, 0),
    }),
    [supplierRows]
  );

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 pb-12">
      {/* ------------------------------------------------- header --- */}
      <div className="card">
        <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
          <div>
            <div className="eyebrow">Frac job specifications</div>
            <h1 className="flex items-center gap-2 text-2xl font-medium tracking-tight">
              <FileSpreadsheet className="size-5 text-muted" /> Job design &amp; cross-check
            </h1>
            <p className="max-w-2xl text-sm text-muted">
              Whole-job sand targets against delivered and pumped totals. The cross-check
              compares planned stages × per-stage design (with per-well overrides) to the
              frac design total and flags at &gt;2% drift.
            </p>
          </div>

          <div className="grid shrink-0 grid-cols-3 gap-3">
            <div className="rounded-md bg-elevated p-3 ring-border">
              <div className="eyebrow">Job design</div>
              <div className="num mt-1 text-lg font-semibold">
                {formatLbsNumber(headline.designLbs)}
              </div>
              <div className="num text-xs text-muted">
                {(headline.designLbs / lbsPerTon).toFixed(1)} t
              </div>
            </div>
            <div className="rounded-md bg-elevated p-3 ring-border">
              <div className="eyebrow">Delivered</div>
              <div className="num mt-1 text-lg font-semibold text-accent">
                {formatLbsNumber(headline.deliveredLbs)}
              </div>
              <div className="num text-xs text-muted">
                {(headline.deliveredLbs / lbsPerTon).toFixed(1)} t
              </div>
            </div>
            <div className="rounded-md bg-elevated p-3 ring-border">
              <div className="eyebrow">Pumped</div>
              <div className="num mt-1 text-lg font-semibold">
                {formatLbsNumber(headline.pumpedLbs)}
              </div>
              <div className="num text-xs text-muted">
                {(headline.pumpedLbs / lbsPerTon).toFixed(1)} t
              </div>
            </div>
          </div>
        </div>

        {/* ------------------------------------ cross-check banner --- */}
        {flaggedMetrics.length > 0 ? (
          <div className="mt-4 rounded-md bg-warn-dim p-4 ring-warn-1">
            <div className="flex items-center gap-2 text-sm font-medium text-warn">
              <AlertTriangle className="size-4 shrink-0" />
              <span>Design cross-check variance — more than 2% difference</span>
            </div>
            <p className="mt-1 text-xs text-muted">
              Planned stages multiplied by per-stage design (accounting for per-well
              overrides) differs from the whole-job frac design total by more than 2% for
              these sand types.
            </p>
            <div className="mt-3 grid grid-cols-1 gap-2 md:grid-cols-2">
              {flaggedMetrics.map((fm) => {
                const tone = sandClasses(fm.sandType.name, sandTypes);
                return (
                  <div
                    key={fm.sandType.id}
                    className="flex items-center justify-between gap-3 rounded-sm bg-surface p-3 ring-border"
                  >
                    <div className="min-w-0 text-xs">
                      <span className={cn('font-medium', tone.text)}>
                        {fm.sandType.name}
                      </span>
                      <span className="num ml-1.5 text-muted">
                        planned {formatLbsNumber(fm.plannedStagesSumLbs)} vs job{' '}
                        {formatLbsNumber(fm.jobDesignTotalLbs)} lbs
                      </span>
                    </div>
                    <span className="badge badge-warn shrink-0">
                      {fm.plannedCrossCheckDiffPercent.toFixed(1)}% diff
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        ) : (
          <div className="mt-4 flex items-center gap-2 rounded-md bg-ok-dim p-3 text-xs text-ok ring-border">
            <CheckCircle2 className="size-4 shrink-0" />
            <span>
              Cross-check passed — per-stage planned totals agree with the whole-job frac
              design within 2% for every sand type.
            </span>
          </div>
        )}
      </div>

      {/* ------------------------------------------ per-sand cards --- */}
      <div className="flex flex-col gap-3">
        <div className="eyebrow px-1">Per-sand-type job metrics</div>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {metrics.map((m) => {
            const tone = sandClasses(m.sandType.name, sandTypes);
            const isOverDelivered = m.stillToDeliverLbs < 0;

            return (
              <div key={m.sandType.id} className="card flex flex-col gap-3">
                <div className="card-hd mb-0 items-center">
                  <div className="flex items-center gap-2">
                    <span className={cn('inline-block size-2.5 rounded-full', tone.fill)} />
                    <h2 className={cn('text-lg font-medium tracking-tight', tone.text)}>
                      {m.sandType.name}
                    </h2>
                  </div>
                  {m.hasCrossCheckFlag && (
                    <span className="badge badge-warn shrink-0">
                      <AlertTriangle className="size-3" /> Cross-check
                    </span>
                  )}
                </div>

                <div className="flex flex-col gap-2">
                  <Figure
                    label="Job design total"
                    lbs={m.jobDesignTotalLbs}
                    tons={m.jobDesignTotalTons}
                  />
                  <Figure
                    label="Delivered so far"
                    lbs={m.deliveredSoFarLbs}
                    tons={m.deliveredSoFarTons}
                    valueClass="text-accent"
                  />
                  <Figure
                    label="Still to deliver"
                    hint={isOverDelivered ? 'Over-delivered' : undefined}
                    lbs={m.stillToDeliverLbs}
                    tons={m.stillToDeliverTons}
                    valueClass={isOverDelivered ? 'text-danger' : 'text-fg'}
                    ring={isOverDelivered ? 'ring-danger-1' : undefined}
                  />

                  <div className="flex items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-border">
                    <span className="flex items-center gap-1.5 text-xs text-muted">
                      <Truck className="size-4" /> Loads still needed
                    </span>
                    <span className="num text-base font-semibold">
                      {m.truckloadsStillNeeded > 0
                        ? m.truckloadsStillNeeded.toFixed(1)
                        : '0.0'}{' '}
                      <span className="text-xs font-normal text-muted">loads</span>
                    </span>
                  </div>

                  <Figure
                    label="Pumped so far"
                    lbs={m.pumpedSoFarLbs}
                    tons={m.pumpedSoFarTons}
                  />
                  <Figure
                    label="Remaining in design"
                    lbs={m.remainingInDesignLbs}
                    tons={m.remainingInDesignTons}
                  />
                </div>

                <div className="rounded-md bg-elevated p-3 ring-border">
                  <div className="eyebrow mb-1.5">Stage math</div>
                  <div className="flex flex-col gap-1 text-xs">
                    <div className="flex justify-between">
                      <span className="text-muted">Stages in design</span>
                      <span className="num font-medium">{m.stagesInDesign.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted">Stages pumped so far</span>
                      <span className="num font-medium text-ok">
                        {m.stagesPumpedSoFar.toFixed(1)}
                      </span>
                    </div>
                    <div className="divider my-1" />
                    <div className="flex justify-between">
                      <span className="text-muted">Stages left in design</span>
                      <span className="num font-semibold text-accent">
                        {m.stagesOfSandLeftInDesign.toFixed(1)}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted">Per stage (effective)</span>
                      <span className="num font-medium">
                        {formatLbsNumber(m.effectivePerStageDesignLbs)} lbs
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ------------------------------------ delivered by supplier --- */}
      <div className="card">
        <div className="card-hd">
          <div>
            <div className="eyebrow">Logistics</div>
            <h2 className="flex items-center gap-2 text-base font-medium tracking-tight">
              <Truck className="size-4 text-muted" /> Delivered by supplier
            </h2>
            <p className="mt-1 text-sm text-muted">
              Every non-deleted ticket, grouped by hauler. Tickets with no supplier land in
              their own row rather than being dropped.
            </p>
          </div>
          <span className="eyebrow-aside">
            {supplierRows.length} {supplierRows.length === 1 ? 'supplier' : 'suppliers'}
          </span>
        </div>

        {supplierRows.length === 0 ? (
          <p className="py-8 text-center text-xs text-subtle">
            No deliveries recorded on this pad yet.
          </p>
        ) : (
          <div className="overflow-x-auto no-scrollbar">
            <table className="tbl">
              <thead>
                <tr>
                  <th>Supplier / hauler</th>
                  {sandTypes.map((st) => {
                    const tone = sandClasses(st.name, sandTypes);
                    return (
                      <th key={st.id} className={cn('n', tone.text)}>
                        {st.name} (lbs)
                      </th>
                    );
                  })}
                  <th className="n">Total lbs</th>
                  <th className="n">Total tons</th>
                  <th className="n">Load count</th>
                </tr>
              </thead>
              <tbody>
                {supplierRows.map((row) => (
                  <tr key={row.supplierName}>
                    <td className="font-medium">{row.supplierName}</td>
                    {sandTypes.map((st) => {
                      const lbs = row.lbsPerSandType[st.name] || 0;
                      return (
                        <td key={st.id} className="n text-muted">
                          {lbs > 0 ? formatLbsNumber(lbs) : '—'}
                        </td>
                      );
                    })}
                    <td className="n font-semibold text-accent">
                      {formatLbsNumber(row.totalLbs)}
                    </td>
                    <td className="n">{row.totalTons.toFixed(1)} t</td>
                    <td className="n text-muted">{row.loadCount} loads</td>
                  </tr>
                ))}

                <tr className="bg-elevated">
                  <td className="font-medium">Pad totals</td>
                  {sandTypes.map((st) => {
                    const totalLbsForType = supplierRows.reduce(
                      (sum, r) => sum + (r.lbsPerSandType[st.name] || 0),
                      0
                    );
                    return (
                      <td key={st.id} className="n">
                        {formatLbsNumber(totalLbsForType)}
                      </td>
                    );
                  })}
                  <td className="n font-semibold text-accent">
                    {formatLbsNumber(supplierTotals.lbs)}
                  </td>
                  <td className="n">{(supplierTotals.lbs / lbsPerTon).toFixed(1)} t</td>
                  <td className="n">{supplierTotals.loads} loads</td>
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

/** One label / lbs / tons row. Every number ships its second unit. */
function Figure({
  label,
  hint,
  lbs,
  tons,
  valueClass = 'text-fg',
  ring,
}: {
  label: string;
  hint?: string;
  lbs: number;
  tons: number;
  valueClass?: string;
  ring?: string;
}) {
  return (
    <div
      className={cn(
        'flex items-center justify-between gap-3 rounded-md bg-elevated p-3',
        ring || 'ring-border'
      )}
    >
      <div className="min-w-0">
        <div className="text-xs text-muted">{label}</div>
        {hint ? <div className="text-[10px] text-danger">{hint}</div> : null}
      </div>
      <div className="shrink-0 text-right">
        <div className={cn('num text-base font-semibold', valueClass)}>
          {formatLbsNumber(lbs)}
        </div>
        <div className="num text-[11px] text-muted">{tons.toFixed(1)} t</div>
      </div>
    </div>
  );
}

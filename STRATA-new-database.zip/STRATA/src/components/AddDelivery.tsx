/**
 * Ticket entry — the full delivery form.
 *
 * Built for a stack of consecutive loads: silo, supplier, sand type and date
 * survive a save, ticket number and weight clear, and focus returns to the
 * ticket field. Everything that could silently corrupt inventory — a duplicate
 * ticket, a silo whose configured sand disagrees with the ticket, a load that
 * overfills the can — stops the save and asks, rather than writing and warning.
 *
 * The target-silo monitor shows on-hand AND where this ticket lands, because
 * the question the operator is actually answering is "does this fit".
 */

import {
  AlertTriangle,
  Calculator,
  Camera,
  Check,
  CheckCircle2,
  QrCode,
  RotateCcw,
  Sparkles,
  Truck,
  Undo2,
} from 'lucide-react';
import { ChangeEvent, FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { getSiloDerivedStates, formatLbs, formatTons } from '../lib/sandRules';
import { suggestSiloForDelivery } from '../lib/analytics';
import {
  findDuplicateDelivery,
  normalizeTicketNumber,
  getLastUsedSupplier,
  setLastUsedSupplier,
  ParsedTicketScan,
} from '../lib/ticketUtils';
import { getOperationalDate, getOperationalTime } from '../lib/dateUtils';
import { sandClasses, cn } from '../lib/theme';
import { onServiceWarning } from '../lib/firestoreService';
import { AppState, DeliveryTicket } from '../types';
import Numpad from './Numpad';
import TicketScannerModal, { ScanResult } from './TicketScannerModal';
import DuplicateWarningModal from './DuplicateWarningModal';
import ScanConfirmationModal from './ScanConfirmationModal';

interface AddDeliveryProps {
  state: AppState;
  initialSiloNumber?: number;
  onAddDelivery: (delivery: {
    ticketNumber: string;
    siloNumber: number;
    sandType: string;
    lbs: number;
    supplier: string;
    date: string;
    timeOfDay?: string;
    driverName?: string;
    notes?: string;
    photoUrl?: string | null;
    carrier?: string;
    truck?: string;
    poNumber?: string;
    productCode?: string;
    reassignSiloSand?: boolean;
    supervisorOverride?: boolean;
    overrideReason?: string;
    scanMetadata?: any;
  }) => Promise<void> | void;
  onDeleteDelivery?: (id: string, reason?: string) => Promise<void> | void;
  onSaveProductCodeMapping?: (mineCode: string, sandType: string) => Promise<void> | void;
  onChangeSiloSand?: (siloNumber: number, sandType: string | null) => void;
  onNavigateToSetup?: () => void;
  onDone?: () => void;
  onCancel?: () => void;
  /** Optional app-level toast. Falls back to the in-form banner when absent. */
  onToast?: (msg: string, tone?: 'ok' | 'warn' | 'danger') => void;
}

export default function AddDelivery({
  state,
  initialSiloNumber,
  onAddDelivery,
  onDeleteDelivery,
  onSaveProductCodeMapping,
  onChangeSiloSand,
  onNavigateToSetup,
  onDone,
  onCancel,
  onToast,
}: AddDeliveryProps) {
  const ticketInputRef = useRef<HTMLInputElement | null>(null);
  /** Origin of the scan currently being confirmed — 'camera' or 'photo'. */
  const lastScanMethodRef = useRef<'camera' | 'photo'>('camera');

  /* Replays every ticket and run per silo. Keyed on the three slices it reads
     so typing a ticket number does not recompute the pad. */
  const siloDerivedStates = useMemo(
    () => getSiloDerivedStates(state),
    [state.config, state.deliveries, state.runs]
  );

  const defaultSiloNum = initialSiloNumber || state.config.silos[0]?.siloNumber || 1;
  const initialSiloObj = state.config.silos.find((s) => s.siloNumber === defaultSiloNum);

  const todayStr = getOperationalDate();
  const nowTimeStr = getOperationalTime();

  const [ticketNumber, setTicketNumber] = useState('');
  const [siloNumber, setSiloNumber] = useState<number>(defaultSiloNum);
  const [sandType, setSandType] = useState<string>(
    initialSiloObj?.sandType || state.config.sandTypes[0]?.name || '100 Mesh'
  );
  const [lbs, setLbs] = useState<string>('');
  const [showKeypad, setShowKeypad] = useState<boolean>(false);

  // Supplier logic based on state.config.suppliers
  const supplierList = state.config.suppliers || [];

  const getInitialSupplierConfig = () => {
    if (supplierList.length === 1) {
      return { opt: supplierList[0], custom: '', val: supplierList[0] };
    }
    if (supplierList.length > 1) {
      const last = getLastUsedSupplier();
      if (last && supplierList.includes(last)) {
        return { opt: last, custom: '', val: last };
      }
      const recent = state.deliveries[0]?.supplier;
      if (recent && supplierList.includes(recent)) {
        return { opt: recent, custom: '', val: recent };
      }
      return { opt: supplierList[0], custom: '', val: supplierList[0] };
    }
    return { opt: '', custom: '', val: '' };
  };

  const initialSupplierConfig = getInitialSupplierConfig();
  const [selectedSupplierOpt, setSelectedSupplierOpt] = useState<string>(initialSupplierConfig.opt);
  const [customSupplier, setCustomSupplier] = useState<string>(initialSupplierConfig.custom);
  const [supplier, setSupplier] = useState<string>(initialSupplierConfig.val);

  useEffect(() => {
    if (supplierList.length === 1) {
      setSelectedSupplierOpt(supplierList[0]);
      setSupplier(supplierList[0]);
    } else if (supplierList.length > 1) {
      if (
        !selectedSupplierOpt ||
        (!supplierList.includes(selectedSupplierOpt) && selectedSupplierOpt !== '__OTHER__')
      ) {
        const last = getLastUsedSupplier();
        const choice =
          last && supplierList.includes(last)
            ? last
            : state.deliveries[0]?.supplier && supplierList.includes(state.deliveries[0]?.supplier)
              ? state.deliveries[0]?.supplier
              : supplierList[0];
        setSelectedSupplierOpt(choice);
        setSupplier(choice);
      }
    }
  }, [state.config.suppliers]);

  const [date, setDate] = useState(todayStr);
  const [timeOfDay, setTimeOfDay] = useState(nowTimeStr);
  const [driverName, setDriverName] = useState('');
  const [notes, setNotes] = useState('');
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);

  // Extra fields from the Atlas 6-part QR
  const [truck, setTruck] = useState<string>('');
  const [poNumber, setPoNumber] = useState<string>('');
  const [productCode, setProductCode] = useState<string>('');
  const [unrecognizedProductCode, setUnrecognizedProductCode] = useState<string | null>(null);
  const [highlightSilo, setHighlightSilo] = useState<boolean>(false);

  // Scanner & scanned state
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannedInfo, setScannedInfo] = useState<{
    rawValue: string;
    format: string;
    parser?: string;
    confidence?: string;
    winningScale?: string;
    engine?: string;
    /* How the number was actually obtained. Was hardcoded 'camera' below for
       every path, including a still photo and a vision OCR read. */
    method?: 'camera' | 'photo';
  } | null>(null);

  // Scan confirmation modal state
  const [isConfirmationModalOpen, setIsConfirmationModalOpen] = useState(false);
  const [pendingScan, setPendingScan] = useState<ParsedTicketScan | null>(null);
  const [scanCandidates, setScanCandidates] = useState<ParsedTicketScan[]>([]);

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  // Flash confirmation
  const [justSavedFlash, setJustSavedFlash] = useState<string | null>(null);
  const [undoFlash, setUndoFlash] = useState<string | null>(null);

  // Last five tickets entered in this session
  const [sessionTickets, setSessionTickets] = useState<DeliveryTicket[]>([]);

  // Sand mismatch confirmation modal state
  const [isSandMismatchModalOpen, setIsSandMismatchModalOpen] = useState<boolean>(false);

  useEffect(() => {
    ticketInputRef.current?.focus();
  }, []);

  /** Toast if App wired one, otherwise the in-form error banner. */
  const notify = (msg: string, tone: 'ok' | 'warn' | 'danger' = 'ok') => {
    if (onToast) {
      onToast(msg, tone);
      return;
    }
    if (tone === 'danger') {
      setSubmitError(msg);
    } else {
      setJustSavedFlash(msg);
      setTimeout(() => setJustSavedFlash(null), 3000);
    }
  };

  /* A ticket photo is uploaded to Storage AFTER the ticket itself is safely
     written, so an upload failure can never cost the delivery. It still has to
     be said out loud, or the operator believes a photo is attached that isn't. */
  useEffect(() => onServiceWarning((msg) => notify(msg, 'warn')), []);

  // Duplicate ticket check across all active deliveries on this pad
  const duplicateDelivery = findDuplicateDelivery(ticketNumber, state.deliveries);
  const [isDuplicateModalOpen, setIsDuplicateModalOpen] = useState(false);

  const handleCloseDuplicateModal = () => {
    setIsDuplicateModalOpen(false);
    setTimeout(() => {
      ticketInputRef.current?.focus();
    }, 100);
  };

  // Live silo calculations
  const selectedSiloDerived = siloDerivedStates.find((s) => s.siloNumber === siloNumber);
  const currentSiloConfig = state.config.silos.find((s) => s.siloNumber === siloNumber);
  const currentConfiguredSand = currentSiloConfig?.sandType;
  const lbsPerTon = state.config.lbsPerTon || 2000;
  const lbsPerTruckload = state.config.lbsPerTruckload || 57000;
  const onHandLbs = selectedSiloDerived?.onHandLbs || 0;
  const maxCapacityLbs = selectedSiloDerived?.maxCapacityLbs || 350000;
  const percentFull = Math.min(100, Math.max(0, Math.round((onHandLbs / maxCapacityLbs) * 100)));
  const onHandTons = onHandLbs / lbsPerTon;
  const maxTons = maxCapacityLbs / lbsPerTon;

  const deliveryWeightLbs = parseInt(lbs, 10) || 0;
  const projectedOnHandLbs = onHandLbs + deliveryWeightLbs;
  const projectedPercentFull = Math.min(
    100,
    Math.max(0, Math.round((projectedOnHandLbs / maxCapacityLbs) * 100))
  );
  const isOverCapacityWarning = projectedOnHandLbs > maxCapacityLbs;

  const tone = sandClasses(sandType, state.config.sandTypes);

  /* Where should this load go? analytics owns both the answer and the
     sentence — this screen never composes an explanation of its own. */
  const suggestion = useMemo(
    () =>
      sandType && deliveryWeightLbs > 0
        ? suggestSiloForDelivery(state, sandType, deliveryWeightLbs)
        : null,
    [state.config, state.deliveries, state.runs, sandType, deliveryWeightLbs]
  );

  // Helper to apply a parsed ticket to the form fields
  const applyParsedTicket = (parsed: ParsedTicketScan) => {
    if (parsed.ticketNumber) {
      setTicketNumber(parsed.ticketNumber);
    }
    if (parsed.lbs) {
      setLbs(parsed.lbs.toString());
    }
    if (parsed.carrier) {
      const carrier = parsed.carrier.trim();
      if (supplierList.includes(carrier)) {
        setSelectedSupplierOpt(carrier);
        setSupplier(carrier);
        setCustomSupplier('');
      } else if (carrier) {
        setSelectedSupplierOpt('__OTHER__');
        setCustomSupplier(carrier);
        setSupplier(carrier);
      }
    }
    if (parsed.truck) setTruck(parsed.truck);
    if (parsed.poNumber) setPoNumber(parsed.poNumber);
    if (parsed.productCode) setProductCode(parsed.productCode);

    if (parsed.matchedSandType) {
      setSandType(parsed.matchedSandType);
      setUnrecognizedProductCode(null);
    } else if (parsed.productCode) {
      setUnrecognizedProductCode(parsed.productCode);
    } else {
      setUnrecognizedProductCode(null);
    }

    setHighlightSilo(true);

    if (parsed.ticketNumber) {
      const norm = normalizeTicketNumber(parsed.ticketNumber);
      const dup = findDuplicateDelivery(norm, state.deliveries);
      if (dup) {
        setIsDuplicateModalOpen(true);
      }
    }

    setTimeout(() => {
      ticketInputRef.current?.focus();
    }, 100);
  };

  const handleScanSuccess = (result: ScanResult) => {
    setIsScannerOpen(false);
    const { rawValue, format, parsed, candidates, isAmbiguous, winningScale, engine, method } =
      result;
    lastScanMethodRef.current = method || 'camera';

    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(100);
      } catch (e) {
        // ignore
      }
    }

    if (isAmbiguous || parsed.confidence !== 'confirmed') {
      setPendingScan(parsed);
      setScanCandidates(candidates || [parsed]);
      setIsConfirmationModalOpen(true);
    } else {
      setScannedInfo({
        rawValue,
        format,
        parser: parsed.parser,
        confidence: parsed.confidence,
        winningScale,
        engine,
        method: method || 'camera',
      });
      applyParsedTicket(parsed);
    }
  };

  const handleConfirmScan = (confirmed: ParsedTicketScan) => {
    setIsConfirmationModalOpen(false);
    setScannedInfo({
      rawValue: confirmed.rawValue,
      format: confirmed.format || 'QR_CODE',
      parser: confirmed.parser,
      confidence: confirmed.confidence,
      method: lastScanMethodRef.current,
    });
    applyParsedTicket(confirmed);
  };

  const handleRememberProductCodePairing = async () => {
    if (!unrecognizedProductCode || !sandType || !onSaveProductCodeMapping) return;
    try {
      await onSaveProductCodeMapping(unrecognizedProductCode, sandType);
      const code = unrecognizedProductCode;
      setUnrecognizedProductCode(null);
      notify(`Saved product code ${code} to ${sandType}`, 'ok');
    } catch (err) {
      console.error('Failed to save pairing:', err);
      notify('Could not save the product code pairing.', 'danger');
    }
  };

  const handleSiloChange = (num: number) => {
    setSiloNumber(num);
    setHighlightSilo(false);
    const siloObj = state.config.silos.find((s) => s.siloNumber === num);
    if (siloObj && siloObj.sandType) {
      setSandType(siloObj.sandType);
    }
  };

  /** Applying a suggestion moves the load, never the ticket's sand type. */
  const applySuggestion = () => {
    if (!suggestion) return;
    setSiloNumber(suggestion.siloNumber);
    setHighlightSilo(false);
  };

  const handlePhotoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const executeSaveDelivery = async (opts: {
    reassignSiloSand?: boolean;
    supervisorOverride?: boolean;
    overrideReason?: string;
  }) => {
    setIsSubmitting(true);
    setSubmitError(null);
    setIsSandMismatchModalOpen(false);

    const cleanTicket = normalizeTicketNumber(ticketNumber);
    const numericLbs = parseInt(lbs, 10);
    const timeToRecord = timeOfDay || getOperationalTime();

    try {
      if (supplier.trim()) {
        setLastUsedSupplier(supplier.trim());
      }

      await onAddDelivery({
        ticketNumber: cleanTicket,
        siloNumber,
        sandType,
        lbs: numericLbs,
        supplier: supplier.trim(),
        date,
        timeOfDay: timeToRecord,
        driverName: driverName.trim(),
        notes: notes.trim(),
        photoUrl,
        carrier: supplier.trim(),
        truck: truck || undefined,
        poNumber: poNumber || undefined,
        productCode: productCode || undefined,
        reassignSiloSand: opts.reassignSiloSand,
        supervisorOverride: opts.supervisorOverride,
        overrideReason: opts.overrideReason,
        scanMetadata: scannedInfo
          ? {
              method: scannedInfo.method || 'camera',
              format: scannedInfo.format,
              parser: scannedInfo.parser as any,
              confidence: scannedInfo.confidence as any,
              rawValue: scannedInfo.rawValue,
              winningScale: scannedInfo.winningScale,
              engine: scannedInfo.engine,
              scannedAt: Date.now(),
            }
          : undefined,
      });

      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([100, 50, 100]);
        } catch (e) {
          // ignore
        }
      }

      const newSessionRecord: DeliveryTicket = {
        id: `session-${Date.now()}-${cleanTicket}`,
        ticketNumber: cleanTicket,
        siloNumber,
        sandType,
        lbs: numericLbs,
        supplier: supplier.trim(),
        date,
        timeOfDay: timeToRecord,
        driverName: driverName.trim(),
        notes: notes.trim(),
        photoUrl,
        createdAt: Date.now(),
        supervisorOverride: opts.supervisorOverride,
        overrideReason: opts.overrideReason,
      };
      setSessionTickets((prev) => [newSessionRecord, ...prev].slice(0, 5));

      setJustSavedFlash(
        `Ticket #${cleanTicket} saved · ${numericLbs.toLocaleString()} lbs to Silo ${siloNumber}`
      );
      setTimeout(() => setJustSavedFlash(null), 3500);

      // Clear the ticket-specific fields, keep silo / supplier / sand / date
      setTicketNumber('');
      setLbs('');
      setDriverName('');
      setNotes('');
      setPhotoUrl(null);
      setTruck('');
      setPoNumber('');
      setProductCode('');
      setUnrecognizedProductCode(null);
      setScannedInfo(null);
      setHighlightSilo(false);
      setErrors({});

      setTimeout(() => {
        ticketInputRef.current?.focus();
      }, 100);
    } catch (err: any) {
      console.error('Save failed:', err);
      setSubmitError(err?.message || 'Failed to save delivery ticket. Check database connection.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitError(null);
    const errs: Record<string, string> = {};

    const cleanTicket = normalizeTicketNumber(ticketNumber);
    if (!cleanTicket) {
      errs.ticketNumber = 'Ticket number is required';
    }

    const numericLbs = parseInt(lbs, 10);
    if (!numericLbs || numericLbs <= 0) {
      errs.lbs = 'Valid sand weight in lbs is required';
    }

    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      ticketInputRef.current?.focus();
      return;
    }

    const dup = findDuplicateDelivery(cleanTicket, state.deliveries);
    if (dup) {
      setIsDuplicateModalOpen(true);
      return;
    }

    // The silo's configured sand disagrees with the ticket: ask, never assume.
    if (currentConfiguredSand && sandType && currentConfiguredSand !== sandType) {
      setIsSandMismatchModalOpen(true);
      return;
    }

    await executeSaveDelivery({ reassignSiloSand: false });
  };

  const handleUndoTicket = async (ticket: DeliveryTicket) => {
    if (!onDeleteDelivery) return;
    try {
      const matchingLive = (state.deliveries || []).find(
        (d) => !d.deleted && d.ticketNumber === ticket.ticketNumber
      );
      const targetId = matchingLive?.id || ticket.id;

      await onDeleteDelivery(targetId, 'Undone from ticket entry session');

      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate(80);
        } catch (e) {
          // ignore
        }
      }

      setSessionTickets((prev) => prev.filter((t) => t.ticketNumber !== ticket.ticketNumber));

      setUndoFlash(`Ticket #${ticket.ticketNumber} undone and removed`);
      setTimeout(() => setUndoFlash(null), 3000);

      setTimeout(() => {
        ticketInputRef.current?.focus();
      }, 100);
    } catch (err: any) {
      console.error('Error undoing ticket:', err);
      notify(`Could not undo ticket #${ticket.ticketNumber}: ${err?.message || 'unknown error'}`, 'danger');
    }
  };

  const fillTone =
    percentFull >= 95 ? 'bg-danger' : percentFull >= 80 ? 'bg-warn' : 'bg-accent';

  return (
    <div className="mx-auto flex w-full max-w-3xl flex-col gap-5 pb-20">
      {/* ------------------------------------------------------- header --- */}
      <div className="card">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex items-start gap-3">
            <Truck className="mt-1 size-5 shrink-0 text-accent" />
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="eyebrow">Ticket entry</span>
                <span className="badge badge-accent">Multi-load</span>
              </div>
              <h1 className="text-2xl font-medium tracking-tight">
                {state.config.padName || 'Pad'}
              </h1>
              <p className="max-w-xl text-sm text-muted">
                Silo, supplier, sand and date persist between tickets · the fill bar shows this
                silo's on-hand plus this ticket, against its rated capacity.
              </p>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-2 self-stretch sm:self-auto">
            <button
              type="button"
              onClick={() => setIsScannerOpen(true)}
              className="btn btn-accent btn-lg flex-1 sm:flex-none"
            >
              <QrCode className="size-5" />
              <span>Scan ticket</span>
            </button>

            {onDone || onCancel ? (
              <button
                type="button"
                onClick={onDone || onCancel}
                className="btn btn-lg flex-1 sm:flex-none"
                title="Finish this stack of tickets and return to the silo board"
              >
                <Check className="size-4 text-accent" />
                <span>Done</span>
              </button>
            ) : null}
          </div>
        </div>
      </div>

      {/* ------------------------------------------------------- flashes --- */}
      {justSavedFlash ? (
        <div className="card flex items-center gap-3 ring-accent-1">
          <CheckCircle2 className="size-5 shrink-0 text-accent" />
          <span className="text-sm text-fg">{justSavedFlash}</span>
        </div>
      ) : null}

      {undoFlash ? (
        <div className="card flex items-center gap-3 ring-warn-1">
          <Undo2 className="size-5 shrink-0 text-warn" />
          <span className="text-sm text-fg">{undoFlash}</span>
        </div>
      ) : null}

      {submitError ? (
        <div className="card flex items-start gap-3 ring-danger-1">
          <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" />
          <div>
            <div className="eyebrow text-danger">Save error</div>
            <div className="mt-1 text-sm text-fg">{submitError}</div>
          </div>
        </div>
      ) : null}

      {/* -------------------------------------------------------- modals --- */}
      {isDuplicateModalOpen && duplicateDelivery ? (
        <DuplicateWarningModal
          duplicate={duplicateDelivery}
          lbsPerTon={state.config.lbsPerTon}
          scannedTicketNumber={ticketNumber}
          rawScanValue={scannedInfo?.rawValue}
          onClose={handleCloseDuplicateModal}
          onRescan={() => {
            handleCloseDuplicateModal();
            setIsScannerOpen(true);
          }}
          onViewExisting={() => {
            handleCloseDuplicateModal();
            if (onDone) onDone();
          }}
          onSupervisorOverride={async (reason) => {
            await executeSaveDelivery({
              reassignSiloSand: false,
              supervisorOverride: true,
              overrideReason: reason,
            });
            handleCloseDuplicateModal();
          }}
        />
      ) : null}

      {isConfirmationModalOpen && pendingScan ? (
        <ScanConfirmationModal
          parsed={pendingScan}
          candidates={scanCandidates}
          onConfirm={handleConfirmScan}
          onEdit={(edited) => handleConfirmScan(edited)}
          onRescan={() => {
            setIsConfirmationModalOpen(false);
            setIsScannerOpen(true);
          }}
          onCancel={() => setIsConfirmationModalOpen(false)}
        />
      ) : null}

      {/* Sand mismatch — reassigning a can changes every later pull. */}
      {isSandMismatchModalOpen && currentConfiguredSand ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-bg/85 p-4 backdrop-blur-sm">
          <div className="card w-full max-w-lg space-y-4 ring-warn-1">
            <div className="flex items-start gap-3">
              <AlertTriangle className="mt-0.5 size-5 shrink-0 text-warn" />
              <div>
                <div className="eyebrow text-warn">Silo sand type reassignment</div>
                <h2 className="mt-1 text-lg font-medium tracking-tight">
                  Silo {siloNumber} sand type mismatch
                </h2>
              </div>
            </div>

            <div className="space-y-2 rounded-sm bg-elevated p-3 text-sm ring-border">
              <div className="text-muted">
                Silo <span className="num text-fg">{siloNumber}</span> is configured for{' '}
                <span className="font-medium text-fg">{currentConfiguredSand}</span>.
              </div>
              <div className="text-muted">
                Ticket <span className="num text-fg">#{ticketNumber.trim()}</span> specifies{' '}
                <span className={cn('font-medium', tone.text)}>{sandType}</span>.
              </div>
              <div className="text-xs text-subtle">
                Reassigning updates this silo's sand type in pad settings for every subsequent
                stage pull.
              </div>
            </div>

            <div className="space-y-2">
              <button
                type="button"
                onClick={() => executeSaveDelivery({ reassignSiloSand: true })}
                className="btn btn-accent btn-lg w-full"
              >
                <Check className="size-4" />
                <span>
                  Reassign Silo {siloNumber} to {sandType} and save
                </span>
              </button>

              <button
                type="button"
                onClick={() => executeSaveDelivery({ reassignSiloSand: false })}
                className="btn w-full"
              >
                Keep silo as {currentConfiguredSand} — save ticket only
              </button>

              <button
                type="button"
                onClick={() => setIsSandMismatchModalOpen(false)}
                className="btn btn-ghost w-full"
              >
                Cancel and review the form
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {/* ---------------------------------------------------------- form --- */}
      <form onSubmit={handleSubmit} className="card space-y-5">
        {/* live target silo monitor */}
        <div
          className={cn(
            'space-y-3 rounded-md bg-elevated p-4 transition-[box-shadow] duration-150',
            highlightSilo ? 'ring-accent-1' : 'ring-border'
          )}
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="badge badge-accent">
                Silo <span className="num">{siloNumber}</span>
              </span>
              <span className="text-xs text-muted">
                {currentSiloConfig?.name || `Silo ${siloNumber}`} · side{' '}
                {currentSiloConfig?.side || 'A'}
              </span>
              <span className={cn('badge', tone.dim, tone.text)}>{sandType}</span>
            </div>

            <div className="text-right">
              <div className="num text-sm font-semibold">{formatLbs(onHandLbs)}</div>
              <div className="num text-[11px] text-muted">
                {formatTons(onHandTons)} of {formatTons(maxTons)}
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            {/* current fill + projected overlay */}
            <div className="relative h-4 w-full overflow-hidden rounded-full bg-surface ring-border">
              <div
                className={cn(
                  'h-full transition-[width] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]',
                  fillTone
                )}
                style={{ width: `${percentFull}%` }}
              />
              {deliveryWeightLbs > 0 && projectedPercentFull > percentFull ? (
                <div
                  className={cn(
                    'absolute top-0 h-full transition-[left,width] duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]',
                    isOverCapacityWarning ? 'bg-danger/60' : 'bg-accent/45'
                  )}
                  style={{
                    left: `${percentFull}%`,
                    width: `${Math.min(100 - percentFull, projectedPercentFull - percentFull)}%`,
                  }}
                />
              ) : null}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <span className="text-muted">
                Current <span className="num text-fg">{percentFull}%</span> full
              </span>
              {deliveryWeightLbs > 0 ? (
                <span className={isOverCapacityWarning ? 'text-danger' : 'text-accent'}>
                  <span className="num">+{deliveryWeightLbs.toLocaleString()}</span> lbs to{' '}
                  <span className="num">{formatLbs(projectedOnHandLbs)}</span> (
                  <span className="num">{projectedPercentFull}%</span>)
                </span>
              ) : null}
            </div>
          </div>
        </div>

        {/* raw scanned value */}
        {scannedInfo ? (
          <div className="space-y-2 rounded-md bg-elevated p-3 ring-border">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="eyebrow flex items-center gap-1.5">
                <QrCode className="size-4 text-accent" /> Scanned code
              </span>
              <div className="flex flex-wrap items-center gap-1.5">
                {scannedInfo.winningScale ? (
                  <span className="badge badge-ok num">{scannedInfo.winningScale}</span>
                ) : null}
                <span className="badge badge-accent">Format {scannedInfo.format}</span>
              </div>
            </div>
            <div className="num break-all rounded-sm bg-surface p-3 text-sm text-fg ring-border">
              {scannedInfo.rawValue}
            </div>
          </div>
        ) : null}

        {/* capacity overfill */}
        {isOverCapacityWarning ? (
          <div className="flex items-start gap-3 rounded-md bg-warn-dim p-3 ring-warn-1">
            <AlertTriangle className="mt-0.5 size-5 shrink-0 text-warn" />
            <div className="text-xs text-fg">
              <div className="eyebrow text-warn">Silo {siloNumber} capacity</div>
              <p className="mt-1">
                Adding <span className="num">{deliveryWeightLbs.toLocaleString()}</span> lbs brings
                Silo {siloNumber} to{' '}
                <span className="num font-semibold">
                  {projectedOnHandLbs.toLocaleString()} lbs
                </span>
                , past its rated{' '}
                <span className="num">{maxCapacityLbs.toLocaleString()} lbs</span>.
              </p>
            </div>
          </div>
        ) : null}

        {/* product code pairing */}
        {unrecognizedProductCode ? (
          <div className="flex flex-col items-start justify-between gap-3 rounded-md bg-accent-dim p-3 sm:flex-row sm:items-center">
            <div className="flex items-center gap-2.5">
              <Sparkles className="size-4 shrink-0 text-accent" />
              <div className="text-xs text-fg">
                New product code{' '}
                <span className="num font-semibold">{unrecognizedProductCode}</span> — remember it
                as <span className="font-medium">{sandType}</span>?
              </div>
            </div>
            <button
              type="button"
              onClick={handleRememberProductCodePairing}
              className="btn shrink-0"
              disabled={!onSaveProductCodeMapping}
            >
              Save {unrecognizedProductCode} to {sandType}
            </button>
          </div>
        ) : null}

        {/* ticket number + silo */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <div className="mb-2 flex items-center justify-between gap-2">
              <label className="eyebrow" htmlFor="ad-ticket">
                Ticket number
              </label>
              {duplicateDelivery ? (
                <button
                  type="button"
                  onClick={() => setIsDuplicateModalOpen(true)}
                  className="badge badge-danger"
                >
                  <AlertTriangle className="size-3" />
                  Already recorded
                </button>
              ) : null}
            </div>
            <div className="relative flex items-center">
              <input
                id="ad-ticket"
                ref={ticketInputRef}
                type="text"
                inputMode="numeric"
                placeholder="1049823"
                value={ticketNumber}
                onChange={(e) => setTicketNumber(e.target.value)}
                className={cn(
                  'input input-lg num pr-14',
                  errors.ticketNumber || duplicateDelivery
                    ? 'shadow-[0_0_0_1px_var(--color-danger)]'
                    : null
                )}
              />
              <button
                type="button"
                onClick={() => setIsScannerOpen(true)}
                title="Scan ticket barcode or QR"
                className="tap absolute right-1.5 flex size-11 items-center justify-center rounded-sm bg-accent text-accent-fg"
              >
                <QrCode className="size-5" />
              </button>
            </div>
            {errors.ticketNumber ? (
              <p className="mt-1 text-xs text-danger">{errors.ticketNumber}</p>
            ) : null}
          </div>

          <div>
            <label className="eyebrow" htmlFor="ad-silo">
              Destination silo
            </label>
            <select
              id="ad-silo"
              value={siloNumber}
              onChange={(e) => handleSiloChange(parseInt(e.target.value, 10))}
              className="select input-lg mt-2"
            >
              {state.config.silos.map((s) => (
                <option key={s.siloNumber} value={s.siloNumber}>
                  {s.name || `Silo ${s.siloNumber}`} (side {s.side || 'A'}) —{' '}
                  {s.sandType || 'no sand'}
                  {s.isOutOfService ? ' [offline]' : ''}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* sand type + weight */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <label className="eyebrow" htmlFor="ad-sand">
              Sand type
            </label>
            <select
              id="ad-sand"
              value={sandType}
              onChange={(e) => setSandType(e.target.value)}
              className="select input-lg mt-2"
            >
              {state.config.sandTypes.map((st) => (
                <option key={st.id} value={st.name}>
                  {st.name}
                </option>
              ))}
            </select>

            {currentSiloConfig && currentSiloConfig.sandType !== sandType ? (
              <div className="mt-2 flex flex-wrap items-center justify-between gap-2 rounded-sm bg-elevated p-2.5 text-xs ring-warn-1">
                <span className="text-muted">
                  Silo {siloNumber} is assigned to{' '}
                  <span className="font-medium text-fg">
                    {currentSiloConfig.sandType || 'nothing'}
                  </span>
                  .
                </span>
                {onChangeSiloSand ? (
                  <button
                    type="button"
                    onClick={() => onChangeSiloSand(siloNumber, sandType)}
                    className="btn h-9 px-3 text-xs"
                  >
                    Set silo to {sandType}
                  </button>
                ) : null}
              </div>
            ) : null}
          </div>

          <div>
            <div className="mb-2 flex items-center justify-between gap-2">
              <label className="eyebrow" htmlFor="ad-lbs">
                Sand weight (lbs)
              </label>
              <button
                type="button"
                onClick={() => setShowKeypad((v) => !v)}
                aria-pressed={showKeypad}
                className={cn('btn h-9 px-3 text-xs', showKeypad && 'ring-accent-1 text-accent')}
                title="Toggle the gloved-thumb keypad"
              >
                <Calculator className="size-4" />
                <span>Keypad</span>
              </button>
            </div>
            <input
              id="ad-lbs"
              type="number"
              inputMode="numeric"
              placeholder="48200"
              value={lbs}
              onChange={(e) => setLbs(e.target.value)}
              className={cn(
                'input input-lg input-num',
                errors.lbs ? 'shadow-[0_0_0_1px_var(--color-danger)]' : null
              )}
            />
            <div className="num mt-1 text-xs text-muted">
              {formatTons(deliveryWeightLbs / lbsPerTon)} ·{' '}
              {(deliveryWeightLbs / lbsPerTruckload).toFixed(2)} loads
            </div>
            {errors.lbs ? <p className="mt-1 text-xs text-danger">{errors.lbs}</p> : null}

            {showKeypad ? (
              <div className="mt-3">
                <Numpad
                  value={lbs}
                  onChange={setLbs}
                  onAddAmount={() =>
                    setErrors((prev) => {
                      const { lbs: _drop, ...rest } = prev;
                      return rest;
                    })
                  }
                  label="Weight keypad"
                  lbsPerTruckload={lbsPerTruckload}
                />
              </div>
            ) : null}
          </div>
        </div>

        {/* supplier + date + time */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          <div>
            <label className="eyebrow">Supplier</label>
            {supplierList.length === 1 ? (
              <div className="input input-lg mt-2 flex items-center justify-between">
                <span className="text-sm font-medium">{supplierList[0]}</span>
                <span className="badge">Configured</span>
              </div>
            ) : supplierList.length > 1 ? (
              <div className="mt-2 space-y-2">
                <select
                  value={selectedSupplierOpt}
                  onChange={(e) => {
                    const val = e.target.value;
                    setSelectedSupplierOpt(val);
                    setSupplier(val === '__OTHER__' ? customSupplier : val);
                  }}
                  className="select input-lg"
                >
                  {supplierList.map((sup) => (
                    <option key={sup} value={sup}>
                      {sup}
                    </option>
                  ))}
                  <option value="__OTHER__">+ Other (type it)</option>
                </select>

                {selectedSupplierOpt === '__OTHER__' ? (
                  <input
                    type="text"
                    placeholder="One-off supplier name"
                    value={customSupplier}
                    onChange={(e) => {
                      setCustomSupplier(e.target.value);
                      setSupplier(e.target.value);
                    }}
                    className="input ring-accent-1"
                    required
                  />
                ) : null}
              </div>
            ) : (
              <div className="mt-2 space-y-2 rounded-sm bg-elevated p-3 ring-border">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs text-warn">No suppliers set up</span>
                  {onNavigateToSetup ? (
                    <button
                      type="button"
                      onClick={onNavigateToSetup}
                      className="btn btn-ghost h-9 px-2 text-xs"
                    >
                      Go to setup
                    </button>
                  ) : null}
                </div>
                <input
                  type="text"
                  placeholder="Type supplier name"
                  value={customSupplier}
                  onChange={(e) => {
                    setCustomSupplier(e.target.value);
                    setSupplier(e.target.value);
                  }}
                  className="input"
                />
              </div>
            )}
          </div>

          <div>
            <label className="eyebrow" htmlFor="ad-date">
              Delivery date
            </label>
            <input
              id="ad-date"
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="input input-lg num mt-2"
            />
          </div>

          <div>
            <label className="eyebrow" htmlFor="ad-time">
              Time of day
            </label>
            <input
              id="ad-time"
              type="time"
              value={timeOfDay}
              onChange={(e) => setTimeOfDay(e.target.value)}
              className="input input-lg num mt-2"
            />
          </div>
        </div>

        {/* driver + notes */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          <div>
            <label className="eyebrow" htmlFor="ad-driver">
              Driver name (optional)
            </label>
            <input
              id="ad-driver"
              type="text"
              placeholder="John Doe"
              value={driverName}
              onChange={(e) => setDriverName(e.target.value)}
              className="input input-lg mt-2"
            />
          </div>

          <div>
            <label className="eyebrow" htmlFor="ad-notes">
              Notes / BOL reference
            </label>
            <input
              id="ad-notes"
              type="text"
              placeholder="Bill of lading 9042"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="input input-lg mt-2"
            />
          </div>
        </div>

        {/* photo attachment */}
        <div>
          <label className="eyebrow">Ticket photo attachment</label>
          <div className="mt-2 flex flex-col items-center justify-between gap-4 rounded-md bg-elevated p-4 ring-border sm:flex-row">
            <div className="flex items-center gap-3">
              <Camera className="size-5 shrink-0 text-accent" />
              <div>
                <div className="text-sm">Attach a ticket or BOL photo</div>
                <div className="text-xs text-muted">
                  Device camera or gallery · resized on this device, then uploaded
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <label className="btn btn-accent">
                <Camera className="size-4" />
                <span>Take photo</span>
                <input
                  type="file"
                  accept="image/*"
                  capture="environment"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>

              <label className="btn">
                <span>Browse</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>

          {photoUrl ? (
            <div className="mt-3 flex items-center justify-between gap-3 rounded-md bg-elevated p-3 ring-border">
              <div className="flex items-center gap-3">
                <img
                  src={photoUrl}
                  alt="Ticket preview"
                  className="size-16 rounded-sm object-cover ring-border"
                />
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-ok">
                    <CheckCircle2 className="size-3.5" /> Ticket photo attached
                  </div>
                  <div className="text-[11px] text-muted">
                    Uploads to secure storage once the ticket saves
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setPhotoUrl(null)}
                className="btn btn-ghost text-danger"
              >
                Remove photo
              </button>
            </div>
          ) : null}
        </div>

        {/* silo suggestion — one tap is the suggestion, the reason and the fix */}
        {suggestion ? (
          <button
            type="button"
            onClick={applySuggestion}
            className="flex w-full items-center gap-2 rounded-sm bg-accent-dim px-3 py-2 text-left text-sm text-accent"
          >
            <Sparkles className="size-4" />
            {suggestion.reason} · {formatLbs(suggestion.headroomLbs)} headroom
          </button>
        ) : null}

        {/* Sticky action bar. On a phone it must clear the floating bottom nav
            (64px tall, sitting at bottom-3) or Save hides behind it — on
            exactly the device this screen exists for. Drops to a normal offset
            once the nav moves to the desktop rail. */}
        <div className="sticky bottom-[5.5rem] z-30 flex items-center justify-between gap-3 rounded-md bg-surface/95 p-3 ring-border backdrop-blur lg:bottom-4">
          {onDone || onCancel ? (
            <button type="button" onClick={onDone || onCancel} className="btn btn-lg">
              <Check className="size-4 text-accent" />
              <span>Done</span>
            </button>
          ) : (
            <div />
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="btn btn-accent btn-lg flex-1 sm:flex-none"
          >
            <CheckCircle2 className="size-5" />
            <span>{isSubmitting ? 'Saving ticket' : 'Save ticket entry'}</span>
          </button>
        </div>
      </form>

      {/* ----------------------------------------- last 5 this session --- */}
      <div className="card">
        <div className="card-hd">
          <div>
            <div className="eyebrow flex items-center gap-2">
              <Truck className="size-4 text-accent" /> Last 5 tickets this session
            </div>
            <p className="mt-1 text-xs text-muted">
              Undo removes the live ticket from inventory and leaves an audit record.
            </p>
          </div>
          <span className="badge">
            <span className="num">{sessionTickets.length}</span> entered
          </span>
        </div>

        {sessionTickets.length === 0 ? (
          <div className="py-8 text-center text-xs text-subtle">
            No tickets logged in this session yet. Consecutive entries appear here with undo.
          </div>
        ) : (
          <div className="space-y-2.5">
            {sessionTickets.map((t) => {
              const rowTone = sandClasses(t.sandType, state.config.sandTypes);
              return (
                <div
                  key={t.id}
                  className="flex flex-col justify-between gap-3 rounded-md bg-elevated p-3 ring-border sm:flex-row sm:items-center"
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="num text-sm font-semibold text-accent">
                        #{t.ticketNumber}
                      </span>
                      <span className="badge">
                        Silo <span className="num">{t.siloNumber}</span>
                      </span>
                      <span className={cn('badge', rowTone.dim, rowTone.text)}>{t.sandType}</span>
                      {t.timeOfDay ? (
                        <span className="num text-[11px] text-subtle">{t.timeOfDay}</span>
                      ) : null}
                    </div>
                    <div className="text-[11px] text-muted">
                      Supplier <span className="text-fg">{t.supplier || 'not recorded'}</span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-3 sm:justify-end">
                    <div className="text-left sm:text-right">
                      <div className="num text-sm font-semibold">{formatLbs(t.lbs)}</div>
                      <div className="num text-[11px] text-muted">
                        {formatTons(t.lbs / lbsPerTon)}
                      </div>
                    </div>

                    {onDeleteDelivery ? (
                      <button
                        type="button"
                        onClick={() => handleUndoTicket(t)}
                        className="btn"
                        title="Undo and remove this ticket entry"
                      >
                        <RotateCcw className="size-4" />
                        <span>Undo</span>
                      </button>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <TicketScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        onScan={handleScanSuccess}
        title="SCAN SAND TICKET"
        mappings={state.config.productCodeMappings || []}
      />
    </div>
  );
}

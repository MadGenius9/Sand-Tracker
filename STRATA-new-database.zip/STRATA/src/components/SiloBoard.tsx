/**
 * Silo board — the pad as equipment.
 *
 * Every can is a `Canister`: the sand type colors the fill, the status rides
 * the ring and the footer sentence, and the run-order pill is accent (auto),
 * violet (pinned) or danger (two cans fighting over one slot). The controls
 * that change the pad live in a strip UNDER each can, so tapping the can
 * itself only ever does one thing — open the sand assignment.
 *
 * Nothing here maps a sand name to a color. `sandClasses` owns that.
 */

import {
  ArrowUpDown,
  ArrowRight,
  Layers,
  AlertTriangle,
  Wrench,
  Sliders,
  FileText,
  Share2,
  Check,
  Lock,
  RotateCcw,
  Plus,
} from 'lucide-react';
import { useMemo, useState } from 'react';
import SetRunOrderModal from './SetRunOrderModal';
import Canister from './ui/Canister';
import {
  formatLbs,
  formatTons,
  formatTruckloads,
  getPadSummary,
  getSiloDerivedStates,
} from '../lib/sandRules';
import { sandClasses, cn } from '../lib/theme';
import { AppState, DrawStrategy, SiloDerivedState } from '../types';

interface SiloBoardProps {
  state: AppState;
  onChangeSiloSand: (siloNumber: number, sandType: string | null) => void;
  onChangeSiloPriority: (siloNumber: number, priority: number | null) => void;
  onClearAllSiloPriorities?: () => void;
  onSetAllSiloPriorities?: (priorityMap: Record<number, number | null>) => void;
  onToggleSiloMaintenance: (siloNumber: number, isOutOfService: boolean) => void;
  onNavigateToDelivery?: (siloNumber?: number) => void;
  onNavigateToRun?: () => void;
  onNavigateToPullSheet?: () => void;
  onSuccessMessage?: (msg: string) => void;
}

const STRATEGY_LABEL: Record<DrawStrategy, string> = {
  sequential_rotation: 'Sequential carousel',
  partials_then_rotate: 'Partials then rotate',
  least_used_first: 'Least used first',
  emptiest_first: 'Emptiest first',
  fullest_first: 'Fullest first',
};

export default function SiloBoard({
  state,
  onChangeSiloSand,
  onChangeSiloPriority,
  onClearAllSiloPriorities,
  onSetAllSiloPriorities,
  onToggleSiloMaintenance,
  onNavigateToDelivery,
  onNavigateToRun,
  onNavigateToPullSheet,
  onSuccessMessage,
}: SiloBoardProps) {
  const { config, runs, deliveries } = state;

  // Optional "need this stage" requirement. Typing here recomputes the planned
  // pulls live, so it is a dependency of the derived-state memo below.
  const [stageLbsOverride, setStageLbsOverride] = useState<number | undefined>(undefined);
  const [selectedSiloForSandChange, setSelectedSiloForSandChange] = useState<number | null>(null);
  const [isReorderModalOpen, setIsReorderModalOpen] = useState<boolean>(false);
  const [copiedShareLink, setCopiedShareLink] = useState<boolean>(false);

  /* getPadSummary walks every ticket and run on the pad. Keyed on the three
     slices it reads so a modal open or a keystroke elsewhere is free. */
  const padSummary = useMemo(() => getPadSummary(state), [config, runs, deliveries]);

  const activeWell = config.wells[0];

  /* getSiloDerivedStates is the expensive one — it replays deliveries and runs
     per silo and then computes the whole run order. It legitimately depends on
     the stage override, which is why that input is the only keystroke on this
     screen allowed to recompute it. */
  const siloStates = useMemo(
    () =>
      getSiloDerivedStates(state, activeWell?.id, padSummary.nextStageNumber, stageLbsOverride),
    [config, runs, deliveries, activeWell?.id, padSummary.nextStageNumber, stageLbsOverride]
  );

  const lockedSilos = useMemo(
    () => config.silos.filter((s) => s.manualPriority !== null && s.manualPriority !== undefined),
    [config.silos]
  );
  const hasActiveOverrides = lockedSilos.length > 0;

  /* Two ONLINE silos of the same sand pinned to the same slot is a real
     ambiguity — the rotation tie-break decides, and nobody wants that decided
     silently. Flagged per sand type, because slot #1 of 100 mesh and slot #1
     of 40/70 are different queues. */
  const duplicateLockedSilos = useMemo(() => {
    const dupes = new Set<number>();
    const bySand = new Map<string, Map<number, number[]>>();

    for (const s of siloStates) {
      if (s.manualPriority === null || s.manualPriority === undefined || s.isOutOfService) continue;
      const sType = s.sandType || 'UNASSIGNED';
      if (!bySand.has(sType)) bySand.set(sType, new Map());
      const slots = bySand.get(sType)!;
      const list = slots.get(s.manualPriority) || [];
      list.push(s.siloNumber);
      slots.set(s.manualPriority, list);
    }

    for (const slots of bySand.values()) {
      for (const list of slots.values()) {
        if (list.length > 1) list.forEach((n) => dupes.add(n));
      }
    }
    return dupes;
  }, [siloStates]);

  // Silo rows are whatever `side` labels the pad actually uses — never a
  // hardcoded A/B. A three-row pad or an East/West pad groups correctly.
  const silosBySide = useMemo(() => {
    const sides = Array.from(new Set(siloStates.map((s) => (s.side || 'A').trim())));
    return sides.map((sideName) => ({
      sideName,
      silos: siloStates.filter((s) => (s.side || 'A').trim() === sideName),
    }));
  }, [siloStates]);

  const handleSharePullSheet = async () => {
    const origin = typeof window !== 'undefined' ? window.location.origin : '';
    const pathname = typeof window !== 'undefined' ? window.location.pathname : '';
    const shareUrl = `${origin}${pathname}?pad=${encodeURIComponent(state.padId)}&well=${encodeURIComponent(padSummary.activeWellId)}&stage=${padSummary.nextStageNumber}`;

    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopiedShareLink(true);
      if (onSuccessMessage) {
        onSuccessMessage(
          `Stage pull sheet link copied for ${padSummary.nextWellName} stage ${padSummary.nextStageNumber}.`
        );
      }
      setTimeout(() => setCopiedShareLink(false), 3000);
    } catch (err) {
      console.error('Failed to copy share link:', err);
    }
  };

  const handleClearAllOverrides = () => {
    if (onClearAllSiloPriorities) {
      onClearAllSiloPriorities();
    } else {
      lockedSilos.forEach((s) => onChangeSiloPriority(s.siloNumber, null));
    }
  };

  const handleSaveWholeOrder = (priorityMap: Record<number, number | null>) => {
    if (onSetAllSiloPriorities) {
      onSetAllSiloPriorities(priorityMap);
    } else {
      Object.entries(priorityMap).forEach(([siloNumStr, prio]) => {
        onChangeSiloPriority(Number(siloNumStr), prio);
      });
    }
  };

  const customerName = padSummary.activeWellCustomerName || padSummary.customerName;
  const strategyLabel = STRATEGY_LABEL[config.drawStrategy] || 'Sequential carousel';

  return (
    <div className="mx-auto flex w-full max-w-6xl flex-col gap-5 pb-12">
      {/* ------------------------------------------- manual override --- */}
      {hasActiveOverrides && (
        <div className="card flex flex-col gap-3 ring-locked-1 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-3">
            <Lock className="mt-0.5 size-5 shrink-0 text-locked" />
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="eyebrow text-locked">Manual run-order overrides active</span>
                <span className="badge badge-locked">
                  <span className="num">{lockedSilos.length}</span> pinned
                </span>
              </div>
              <div className="mt-1 text-sm text-fg">
                Run order is locked on{' '}
                <span className="num">{lockedSilos.length}</span> silo
                {lockedSilos.length === 1 ? '' : 's'} — the rotation is not controlling those.
              </div>
            </div>
          </div>
          <button type="button" onClick={handleClearAllOverrides} className="btn tap shrink-0">
            <RotateCcw className="size-4" /> Clear all
          </button>
        </div>
      )}

      {/* ---------------------------------------------- reorder alert --- */}
      {padSummary.hasReorderAlert && (
        <div className="card flex items-start gap-3 ring-danger-1">
          <AlertTriangle className="mt-0.5 size-5 shrink-0 text-danger" />
          <div>
            <div className="eyebrow text-danger">Reorder threshold reached</div>
            <div className="mt-1 text-sm text-fg">
              One or more sand types have dropped below the{' '}
              <span className="num">{config.reorderThresholdStages || 5}</span>-stage pad reserve.
            </div>
          </div>
        </div>
      )}

      {/* ------------------------------------------------- pad header --- */}
      <div className="card">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-start lg:justify-between">
          <div className="min-w-0">
            <div className="eyebrow">
              Silo board{customerName ? ` · ${customerName}` : ''}
            </div>
            <h1 className="text-2xl font-medium tracking-tight">{padSummary.padName}</h1>
            <p className="max-w-2xl text-sm text-muted">
              {strategyLabel} draw
              {hasActiveOverrides ? ' with manual pins' : ''} · planned pull is the per-stage
              design split across the cans holding that sand
              {stageLbsOverride !== undefined ? ', overridden below' : ''}. Stages left is
              on-hand divided by that design.
            </p>
          </div>

          <div className="shrink-0 rounded-md bg-elevated p-3 ring-border">
            <div className="flex items-start gap-3">
              <Layers className="mt-0.5 size-5 shrink-0 text-accent" />
              <div>
                <div className="eyebrow">Next up for pull</div>
                <div className="mt-1 flex flex-wrap items-center gap-2">
                  <span className="text-base font-medium">{padSummary.nextWellName}</span>
                  <span className="badge badge-accent">
                    Stage <span className="num">{padSummary.nextStageNumber}</span>
                  </span>
                </div>
              </div>
            </div>

            <label className="mt-3 block">
              <span className="eyebrow">Stage lbs override</span>
              <input
                type="number"
                inputMode="numeric"
                placeholder="Design lbs"
                value={stageLbsOverride ?? ''}
                onChange={(e) => {
                  const val = e.target.value;
                  setStageLbsOverride(val === '' ? undefined : parseInt(val, 10) || 0);
                }}
                className="input input-num mt-1"
              />
            </label>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={handleSharePullSheet}
                className="btn tap flex-1"
                title="Copy a deep link to this stage's pull sheet"
              >
                {copiedShareLink ? (
                  <>
                    <Check className="size-4 text-ok" /> Copied
                  </>
                ) : (
                  <>
                    <Share2 className="size-4" /> Share
                  </>
                )}
              </button>

              {onNavigateToPullSheet && (
                <button type="button" onClick={onNavigateToPullSheet} className="btn tap flex-1">
                  <FileText className="size-4" /> Pull sheet
                </button>
              )}

              {onNavigateToRun && (
                <button
                  type="button"
                  onClick={onNavigateToRun}
                  className="btn btn-accent tap flex-1"
                >
                  Record run <ArrowRight className="size-4" />
                </button>
              )}
            </div>
          </div>
        </div>

        {/* ------------------------------------- per sand type totals --- */}
        <div className="mt-4 grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
          {padSummary.sandTypeSummaries.map((sand) => {
            const tone = sandClasses(sand.sandType, config.sandTypes);
            const short = sand.stageShortfallLbs > 0;

            return (
              <div
                key={sand.sandType}
                className={cn(
                  'rounded-md bg-elevated p-3',
                  short
                    ? 'ring-danger-1'
                    : sand.isBelowReorderThreshold
                      ? 'ring-warn-1'
                      : 'ring-border'
                )}
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className={cn('size-2 shrink-0 rounded-full', tone.fill)} />
                      <span className="eyebrow truncate">{sand.sandType} total</span>
                    </div>
                    <div className="stat-v mt-1">{formatLbs(sand.onHandLbs)}</div>
                    <div className="text-xs text-muted">
                      {formatTons(sand.onHandTons)} ·{' '}
                      {formatTruckloads(sand.onHandLbs, config.lbsPerTruckload)}
                    </div>
                  </div>

                  <div className="shrink-0 text-right">
                    <div className="eyebrow">Stages left</div>
                    <div
                      className={cn(
                        'num mt-1 text-lg font-semibold',
                        short || sand.isBelowReorderThreshold ? 'text-danger' : 'text-fg'
                      )}
                    >
                      {sand.stagesLeft.toFixed(2)}
                    </div>
                  </div>
                </div>

                {short && (
                  <div className="mt-2 flex items-center justify-between gap-2 rounded-sm bg-danger-dim px-2 py-1.5 text-danger">
                    <span className="flex items-center gap-1.5 text-xs font-semibold">
                      <AlertTriangle className="size-4 shrink-0" />
                      Short by <span className="num">{formatLbs(sand.stageShortfallLbs)}</span>
                    </span>
                    <span className="num text-[11px]">
                      {formatTons(sand.stageShortfallLbs / (config.lbsPerTon || 2000))}
                    </span>
                  </div>
                )}
              </div>
            );
          })}

          {/* draw strategy indicator */}
          <div className="flex items-center justify-between gap-2 rounded-md bg-elevated p-3 ring-border">
            <div className="min-w-0">
              <div className="eyebrow">Draw sequence</div>
              <div className="mt-1 flex items-center gap-1.5 text-sm font-medium">
                <ArrowUpDown className="size-4 shrink-0 text-accent" />
                <span className="truncate">
                  {hasActiveOverrides ? 'Manual overrides set' : strategyLabel}
                </span>
              </div>
            </div>
            {hasActiveOverrides && (
              <span className="badge badge-locked shrink-0">
                <Lock className="size-3" /> <span className="num">{lockedSilos.length}</span> locked
              </span>
            )}
          </div>
        </div>
      </div>

      {/* -------------------------------------- pull order control bar --- */}
      <div className="card flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <Sliders className="mt-0.5 size-5 shrink-0 text-accent" />
          <div>
            <div className="eyebrow">Pull order control</div>
            <div className="mt-0.5 text-sm text-muted">
              {hasActiveOverrides
                ? `Run order is pinned manually on ${lockedSilos.length} silo${lockedSilos.length === 1 ? '' : 's'}.`
                : 'The automated draw rotation is choosing the pull sequence.'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {hasActiveOverrides && (
            <button type="button" onClick={handleClearAllOverrides} className="btn tap">
              <RotateCcw className="size-4" /> Reset to auto
            </button>
          )}

          <button
            type="button"
            onClick={() => setIsReorderModalOpen(true)}
            className="btn btn-accent tap"
          >
            <Sliders className="size-4" /> Set run order
          </button>
        </div>
      </div>

      {/* -------------------------------------------- the silo board --- */}
      <div className="flex flex-col gap-5">
        {silosBySide.map(({ sideName, silos: sideSilos }) => {
          const title = sideName.toUpperCase().startsWith('SIDE')
            ? sideName
            : `Side ${sideName}`;

          return (
            <div key={sideName}>
              <div className="mb-2 flex items-center gap-3">
                <div className="eyebrow-aside">
                  {title} · <span className="num">{sideSilos.length}</span> cans
                </div>
                <div className="divider flex-1" />
              </div>

              <div className="grid grid-cols-1 gap-3 md:grid-cols-2 lg:grid-cols-3">
                {sideSilos.map((sDerived) => (
                  <SiloCell
                    key={sDerived.siloNumber}
                    silo={sDerived}
                    state={state}
                    totalSilosCount={config.silos.length}
                    duplicateSlot={duplicateLockedSilos.has(sDerived.siloNumber)}
                    onOpenSandModal={() => setSelectedSiloForSandChange(sDerived.siloNumber)}
                    onChangePriority={(priority) =>
                      onChangeSiloPriority(sDerived.siloNumber, priority)
                    }
                    onToggleMaintenance={(isOffline) =>
                      onToggleSiloMaintenance(sDerived.siloNumber, isOffline)
                    }
                    onNavigateToDelivery={onNavigateToDelivery}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* -------------------------------------- sand assignment modal --- */}
      {selectedSiloForSandChange !== null && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-bg/80 p-4 backdrop-blur-sm"
          role="dialog"
          aria-modal="true"
        >
          <div className="card w-full max-w-md">
            <div className="card-hd">
              <div>
                <div className="eyebrow">Sand assignment</div>
                <h2 className="text-xl font-medium tracking-tight">
                  Silo <span className="num">#{selectedSiloForSandChange}</span>
                </h2>
                <p className="text-sm text-muted">
                  Changing the assignment re-bases this can's on-hand against the new product.
                </p>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              {config.sandTypes.map((st) => {
                const tone = sandClasses(st.name, config.sandTypes);
                return (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => {
                      onChangeSiloSand(selectedSiloForSandChange, st.name);
                      setSelectedSiloForSandChange(null);
                    }}
                    className="tap flex h-14 w-full items-center justify-between gap-3 rounded-sm bg-elevated px-4 text-left ring-border transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
                  >
                    <span className="flex min-w-0 items-center gap-2">
                      <span className={cn('size-2.5 shrink-0 rounded-full', tone.fill)} />
                      <span className="truncate font-medium">{st.name}</span>
                    </span>
                    <span className="num shrink-0 text-xs text-muted">
                      {st.perStageDesignLbs.toLocaleString()} lbs / stage
                    </span>
                  </button>
                );
              })}

              <button
                type="button"
                onClick={() => {
                  onChangeSiloSand(selectedSiloForSandChange, null);
                  setSelectedSiloForSandChange(null);
                }}
                className="btn btn-ghost tap w-full"
              >
                Clear sand assignment (empty)
              </button>
            </div>

            <div className="mt-4 flex justify-end">
              <button
                type="button"
                onClick={() => setSelectedSiloForSandChange(null)}
                className="btn tap"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      <SetRunOrderModal
        isOpen={isReorderModalOpen}
        onClose={() => setIsReorderModalOpen(false)}
        state={state}
        siloStates={siloStates}
        onSaveOrders={handleSaveWholeOrder}
        onClearAllOverrides={handleClearAllOverrides}
      />
    </div>
  );
}

/* ------------------------------------------------------------------------ */

interface SiloCellProps {
  silo: SiloDerivedState;
  state: AppState;
  totalSilosCount: number;
  duplicateSlot: boolean;
  onOpenSandModal: () => void;
  onChangePriority: (priority: number | null) => void;
  onToggleMaintenance: (isOffline: boolean) => void;
  onNavigateToDelivery?: (siloNumber?: number) => void;
}

/**
 * One can plus its controls.
 *
 * The Canister is the whole readout — number, side, run-order pill, fill,
 * sand, on-hand, tons, stages, planned pull, status sentence. Everything that
 * WRITES lives in the strip below it, so a gloved thumb on the can can only
 * ever open the sand assignment.
 */
function SiloCell({
  silo,
  state,
  totalSilosCount,
  duplicateSlot,
  onOpenSandModal,
  onChangePriority,
  onToggleMaintenance,
  onNavigateToDelivery,
}: SiloCellProps) {
  const isLocked = silo.manualPriority !== null && silo.manualPriority !== undefined;
  const slotCount = Math.max(6, totalSilosCount);

  return (
    <div className="flex flex-col gap-2">
      <Canister
        silo={silo}
        sandTypes={state.config.sandTypes}
        duplicateSlot={duplicateSlot}
        onClick={onOpenSandModal}
      />

      {/* Alerts that carry a number the canister sentence does not. */}
      {silo.isNegative && (
        <div className="flex items-center gap-1.5 rounded-sm bg-danger-dim px-2 py-1.5 text-[11px] text-danger">
          <AlertTriangle className="size-3.5 shrink-0" />
          <span>Negative balance — a delivery ticket is probably missing.</span>
        </div>
      )}

      {silo.isOverCapacity && (
        <div className="flex items-center gap-1.5 rounded-sm bg-warn-dim px-2 py-1.5 text-[11px] text-warn">
          <AlertTriangle className="size-3.5 shrink-0" />
          <span className="num">
            Exceeds {formatLbs(silo.maxCapacityLbs)} max capacity
          </span>
        </div>
      )}

      {/* ----------------------------------------------- control strip --- */}
      <div className="card-flush flex flex-col gap-2 p-2.5">
        <div className="flex items-center justify-between gap-2">
          <div className="eyebrow truncate">
            {silo.percentFull.toFixed(1)}% of {formatLbs(silo.maxCapacityLbs)}
          </div>
          <button
            type="button"
            title={silo.isOutOfService ? 'Bring this silo back online' : 'Take this silo offline'}
            aria-pressed={silo.isOutOfService}
            onClick={() => onToggleMaintenance(!silo.isOutOfService)}
            className={cn(
              'tap inline-flex h-8 shrink-0 items-center gap-1.5 rounded-full px-2.5 text-[11px] font-medium uppercase tracking-[0.04em] transition-colors duration-150',
              silo.isOutOfService
                ? 'bg-danger-dim text-danger'
                : 'bg-elevated text-muted hover:text-fg'
            )}
          >
            <Wrench className="size-3" />
            {silo.isOutOfService ? 'Offline' : 'Online'}
          </button>
        </div>

        <button
          type="button"
          onClick={onOpenSandModal}
          className="tap flex h-11 w-full items-center justify-between gap-2 rounded-sm bg-elevated px-3 text-left ring-border transition-[box-shadow] duration-150 hover:shadow-[var(--shadow-border-hover)]"
        >
          <span className="truncate text-sm font-medium">
            {silo.sandType || <span className="text-subtle">No sand assigned</span>}
          </span>
          <span className="eyebrow-aside">Change</span>
        </button>

        {!silo.isOutOfService && (
          <>
            <label className="flex items-center gap-2">
              <span className="eyebrow-aside">Run order</span>
              <select
                value={silo.manualPriority ?? 'auto'}
                onChange={(e) => {
                  const val = e.target.value;
                  onChangePriority(val === 'auto' ? null : Number(val));
                }}
                className={cn('select num h-11 flex-1', isLocked && 'text-locked')}
              >
                <option value="auto">Auto (rotation)</option>
                {Array.from({ length: slotCount }, (_, i) => i + 1).map((n) => (
                  <option key={n} value={n}>
                    Slot #{n}
                  </option>
                ))}
              </select>
            </label>

            {isLocked && (
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="badge badge-locked">
                  <Lock className="size-3" /> Pinned to slot{' '}
                  <span className="num">#{silo.manualPriority}</span>
                </span>
                {duplicateSlot && (
                  <span
                    className="badge badge-danger"
                    title="Another online silo of this sand holds the same slot — the rotation tie-break decides"
                  >
                    <AlertTriangle className="size-3" /> Duplicate slot{' '}
                    <span className="num">#{silo.manualPriority}</span>
                  </span>
                )}
              </div>
            )}
          </>
        )}

        {onNavigateToDelivery && (
          <button
            type="button"
            onClick={() => onNavigateToDelivery(silo.siloNumber)}
            className="btn tap w-full"
          >
            <Plus className="size-4" /> Ticket entry
          </button>
        )}
      </div>
    </div>
  );
}
